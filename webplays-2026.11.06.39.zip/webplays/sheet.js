/* WEBPLAYS productblad: maakt een PDF van een collectie-item (logo linksboven, gegevens, foto, specificaties, optioneel een tekening).
   Wordt pas geladen als iemand op de knop klikt. jsPDF (vendor/jspdf.umd.min.js) wordt dan ook pas geladen.
   Geen site-specifieke dingen hier: logo, lettertypen en voettekst komen uit site.json (collection-detail → props.sheet). */
(function () {
  'use strict';
  var ENGINE = (document.currentScript && document.currentScript.src || '').replace(/[^\/]*$/, '');
  var T = {
    nl: { sheet: 'Productblad', specs: 'Specificaties', layout: 'Opstelling', page: 'Pagina' },
    en: { sheet: 'Product sheet', specs: 'Specifications', layout: 'Layout', page: 'Page' },
    de: { sheet: 'Datenblatt', specs: 'Spezifikationen', layout: 'Aufbau', page: 'Seite' },
    fr: { sheet: 'Fiche produit', specs: 'Caractéristiques', layout: 'Configuration', page: 'Page' }
  };
  function loadScript(src) {
    return new Promise(function (res, rej) {
      if (window.jspdf && window.jspdf.jsPDF) return res();
      var s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = function () { rej(new Error('jsPDF niet geladen')); }; document.head.appendChild(s);
    });
  }
  function fetchB64(url) {
    return fetch(url).then(function (r) { if (!r.ok) throw new Error(url); return r.arrayBuffer(); }).then(function (buf) {
      var b = new Uint8Array(buf), s = '', i; for (i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s);
    });
  }
  // beeld → {data, w, h, fmt}; png behoudt transparantie (logo), de rest wordt jpeg op wit (foto's)
  function loadImg(url, png) {
    return new Promise(function (res) {
      if (!url) return res(null);
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () {
        try {
          var k = Math.min(1, 1800 / Math.max(im.naturalWidth, im.naturalHeight)), w = Math.round(im.naturalWidth * k), h = Math.round(im.naturalHeight * k);
          var c = document.createElement('canvas'); c.width = w; c.height = h; var g = c.getContext('2d');
          if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); }
          g.drawImage(im, 0, 0, w, h);
          res({ data: c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.9), w: w, h: h, fmt: png ? 'PNG' : 'JPEG' });
        } catch (e) { res(null); }
      };
      im.onerror = function () { res(null); };
      im.src = url;
    });
  }
  function fit(w, h, bw, bh) { var k = Math.min(bw / w, bh / h); return { w: w * k, h: h * k }; }

  // o: {lang, name, sku, crumb, description, rows:[[label,value]], image, logo, fonts:{regular,bold}, accent, ink, muted, line, footer, url, drawing:Promise|null, title}
  function build(o) {
    var L = T[o.lang] || T.nl;
    return loadScript(ENGINE + 'vendor/jspdf.umd.min.js').then(function () {
      return Promise.all([
        loadImg(o.logo, true), loadImg(o.image, false), o.drawing ? Promise.resolve(o.drawing).catch(function () { return null; }) : null,
        o.fonts && o.fonts.regular ? fetchB64(o.fonts.regular).catch(function () { return null; }) : null,
        o.fonts && o.fonts.bold ? fetchB64(o.fonts.bold).catch(function () { return null; }) : null
      ]);
    }).then(function (r) {
      var logo = r[0], image = r[1], drawing = r[2], fr = r[3], fb = r[4];
      var doc = new window.jspdf.jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait', compress: true });
      var F = 'helvetica';
      if (fr) { doc.addFileToVFS('brand-regular.ttf', fr); doc.addFont('brand-regular.ttf', 'Brand', 'normal'); F = 'Brand'; if (fb) { doc.addFileToVFS('brand-bold.ttf', fb); doc.addFont('brand-bold.ttf', 'Brand', 'bold'); } else doc.addFont('brand-regular.ttf', 'Brand', 'bold'); }
      var PW = 210, PH = 297, M = 15, CW = PW - 2 * M, y = 0;
      var ink = o.ink || '#1d1d1b', muted = o.muted || '#6b6f76', line = o.line || '#e3e5e8', accent = o.accent || '#8E0B0B';
      function txt(s, x, yy, size, bold, col, opt) { doc.setFont(F, bold ? 'bold' : 'normal'); doc.setFontSize(size); doc.setTextColor(col || ink); doc.text(s, x, yy, opt); }
      function header() {
        if (logo) { var f = fit(logo.w, logo.h, 55, 14); doc.addImage(logo.data, logo.fmt, M, 12, f.w, f.h); }
        txt((o.title || L.sheet).toUpperCase(), PW - M, 19, 9, true, muted, { align: 'right' });
        doc.setDrawColor(accent); doc.setLineWidth(0.7); doc.line(M, 30, PW - M, 30);
        y = 40;
      }
      function newPage() { doc.addPage(); header(); }
      header();
      if (o.crumb) { txt(o.crumb.toUpperCase(), M, y, 8.5, true, accent); y += 7; }
      doc.setFont(F, 'bold'); doc.setFontSize(22);
      var tl = doc.splitTextToSize(o.name || '', CW); txt(tl, M, y + 5, 22, true, ink); y += tl.length * 9 + 2;
      if (o.sku) { txt(o.sku, M, y + 3, 10, false, muted); y += 9; }
      if (o.description) { var dl = doc.splitTextToSize(o.description, CW); txt(dl, M, y + 3, 10.5, false, ink); y += dl.length * 5.2 + 7; }
      // foto en/of tekening
      var bw = (image && drawing) ? (CW - 8) / 2 : CW, bh = (image && drawing) ? 62 : (drawing ? 62 : 80);
      if (image || drawing) {
        if (y + bh > PH - 32) { newPage(); }
        var x0 = M;
        if (image) { var fi = fit(image.w, image.h, bw, bh); doc.addImage(image.data, image.fmt, x0 + (bw - fi.w) / 2, y + (bh - fi.h) / 2, fi.w, fi.h); x0 += bw + 8; }
        if (drawing) {
          var fd = fit(drawing.w, drawing.h, bw, bh - 6);
          doc.setDrawColor(line); doc.setLineWidth(0.3); doc.roundedRect(x0, y, bw, bh, 2, 2, 'S');
          doc.addImage(drawing.data, 'PNG', x0 + (bw - fd.w) / 2, y + 3 + (bh - 6 - fd.h) / 2, fd.w, fd.h);
          txt(L.layout, x0 + 3, y + bh - 2, 7.5, false, muted);
        }
        y += bh + 10;
      }
      // specificaties
      if (o.rows && o.rows.length) {
        if (y + 22 > PH - 28) newPage();
        txt(L.specs.toUpperCase(), M, y, 9, true, ink); y += 3;
        doc.setDrawColor(accent); doc.setLineWidth(0.5); doc.line(M, y, PW - M, y); y += 1;
        var colW = 62, rh = 6.2;
        o.rows.forEach(function (rw, i) {
          var vl = doc.splitTextToSize(String(rw[1]), CW - colW - 4), h = Math.max(rh, vl.length * 4.6 + 1.8);
          if (y + h > PH - 28) { newPage(); }
          if (i % 2 === 0) { doc.setFillColor('#f6f7f8'); doc.rect(M, y, CW, h, 'F'); }
          txt(String(rw[0]), M + 2, y + 4.3, 9.5, false, muted); txt(vl, M + colW, y + 4.3, 9.5, true, ink);
          y += h;
        });
      }
      // voettekst + paginanummers
      var n = doc.getNumberOfPages(), i;
      for (i = 1; i <= n; i++) {
        doc.setPage(i); doc.setDrawColor(line); doc.setLineWidth(0.3); doc.line(M, PH - 20, PW - M, PH - 20);
        if (o.footer) txt(doc.splitTextToSize(o.footer, CW - 24), M, PH - 15.5, 8, false, muted);
        txt(n > 1 ? L.page + ' ' + i + '/' + n : '', PW - M, PH - 15.5, 8, false, muted, { align: 'right' });
        if (o.url) txt(o.url, M, PH - 6, 7.5, false, muted);
      }
      doc.setProperties({ title: (o.name || '') + (o.sku ? ' – ' + o.sku : ''), subject: L.sheet });
      return doc.output('blob');
    });
  }
  function save(blob, name) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  window.WPSheet = { build: build, save: save, labels: T };
})();
