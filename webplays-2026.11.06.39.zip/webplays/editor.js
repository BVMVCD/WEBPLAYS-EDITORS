/*  WEBPLAYS simpele editor — schrijft site.json (de vorm).
    Selecteren, slepen, maat, tekst per taal, kleur, stijl, toevoegen, verwijderen, opslaan.
*/
(function () {
  'use strict';

  var S = window.WPSpeler;
  var $ = function (id) { return document.getElementById(id); };
  var PAGEPANEL = false;   // paginapaneel (titel, hoogte, palet) handmatig open
  var SITE, SEL = null, EXTRA = [], DIRTY = false, PAGE_EL = null, VIEW = null;   // EXTRA = extra selectie (shift-klik)

  // ---------- opstart ----------
  window.WP_OPTIONS.onBuilt = function (pageEl, view) {
    PAGE_EL = pageEl; VIEW = view;
    pageEl.addEventListener('mousedown', onDown);
    pageEl.addEventListener('dblclick', onDbl);
    markEnter();
    placeLocks();
    drawGrid();
    var cv = document.getElementById('canvas');
    if (!cv._wpDown) {                                       // ook naast de pagina beginnen met slepen
      cv._wpDown = true;
      cv.addEventListener('mousedown', function (ev) {
        if (ev.button !== 0 || (PAGE_EL && PAGE_EL.contains(ev.target))) return;
        if (ev.target === cv && (ev.offsetX >= cv.clientWidth || ev.offsetY >= cv.clientHeight)) return;   // schuifbalk
        marquee(ev, null);
      });
    }
    placeSel();
  };

  S.load().then(function (site) {
    SITE = site;
    NOW_JSON = snap();
    // dag/nacht: WEBPLAYS wit-blauw of donker; keuze wordt in deze browser onthouden
    if (!$('themeBtn')) {
      var tb = document.createElement('button'); tb.id = 'themeBtn';
      var setTheme = function (day) {
        document.documentElement.classList.toggle('wp-day', day);
        tb.textContent = day ? '\u263E' : '\u2600'; tb.title = day ? 'Nachtmodus' : 'Dagmodus (WEBPLAYS wit en blauw)';
        try { localStorage.setItem('wpTheme', day ? 'day' : 'night'); } catch (x) {}
      };
      var saved = 'night'; try { saved = localStorage.getItem('wpTheme') || 'night'; } catch (x) {}
      setTheme(saved === 'day');
      tb.onclick = function () { setTheme(!document.documentElement.classList.contains('wp-day')); };
      $('view').before(tb);
    }
    var anchor = $('status');                     // rechts in de balk, naast Opslaan
    if (anchor && !$('undoBtn')) {
      var ub = document.createElement('button'); ub.id = 'undoBtn'; ub.textContent = '\u21B6'; ub.onclick = function () { undo(); };
      var pb = document.createElement('button'); pb.id = 'panelBtn';
      pb.innerHTML = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path d="M10.5 2.5v11"/></svg>';
      pb.onclick = function () { togglePanel(); };
      anchor.before(pb);
      var gb = document.createElement('button'); gb.id = 'gridBtn'; gb.title = 'Grid en snappen'; gb.innerHTML = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M1 5.5h14M1 10.5h14M5.5 1v14M10.5 1v14"/></svg>';
      gb.onclick = function (e) { e.stopPropagation(); gridMenu(gb); };
      anchor.before(gb);
      var rb = document.createElement('button'); rb.id = 'redoBtn'; rb.textContent = '\u21B7'; rb.title = 'Opnieuw (Ctrl+Shift+Z of Ctrl+Y)'; rb.onclick = function () { redo(); };
      anchor.before(ub, rb); undoButtons();
    }
    SITE.pages.forEach(function (p) { $('selPage').add(new Option(S.tr(p.title) + '  (' + p.id + ')', p.id)); });
    SITE.site.languages.forEach(function (l) { $('selLang').add(new Option(l.toUpperCase(), l)); });
    $('selLang').value = SITE.site.defaultLanguage;
    // geopend op de site zelf (adres + ?edit): begin op die pagina en taal
    if (ON_SITE && S.here) { var h = S.here(); $('selPage').value = h.page; $('selLang').value = h.lang; }
    $('selPage').onchange = function () { SEL = null; EXTRA = []; show(); pvPost(); };
    $('selLang').onchange = function () { show(); pvPost(); };
    $('addText').onclick = addText;
    $('addSurface').onclick = addSurface;
    if ($('addIcon')) $('addIcon').onclick = addIcon;
    $('save').onclick = save;
    if ($('dlJson')) $('dlJson').onclick = function () {   // huidige stand (ook niet-opgeslagen) als site.json-bestand, voor lokaal gebruik of in een andere agent
      try {
        var blob = new Blob([JSON.stringify(SITE, null, 2) + '\n'], { type: 'application/json' });
        var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'site.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
        $('status').textContent = 'site.json gedownload' + (DIRTY ? ' (incl. niet-opgeslagen wijzigingen)' : ' · versie ' + (SITE.meta && SITE.meta.version));
      } catch (e) { $('status').textContent = 'download mislukt: ' + e.message; }
    };
    $('logout').onclick = function () {   // deze browser vergeet de sleutel/sessie en gaat terug naar de site
      if (DIRTY && !confirm('Er zijn niet-opgeslagen wijzigingen. Toch uitloggen?')) return;
      DIRTY = false; setKey('');
      try { localStorage.removeItem('wpKey'); sessionStorage.removeItem('wpKey'); } catch (e) {}
      location.href = './';
    };
    $('pageBtn').onclick = function () { PAGEPANEL = !PAGEPANEL; SEL = null; EXTRA = []; placeSel(); panel(); };
    show(); updateWatch();
  }).catch(function (e) { $('status').textContent = 'site.json laden mislukt: ' + e.message; });

  // editor op de site zelf: het adres volgt de pagina (zodat herladen op dezelfde plek blijft) en 'Sluiten' gaat naar die pagina
  var ON_SITE = /[?&]edit(=|&|$)/.test(location.search);
  function syncUrl() {
    if (!ON_SITE || !S.urlFor) return;
    var u = S.urlFor($('selPage').value, $('selLang').value) || '/';
    try { history.replaceState(null, '', u + '?edit'); } catch (e) {}
    var v = $('view'); if (v) { v.href = u; v.target = '_self'; v.textContent = 'Sluiten ✕'; v.title = 'Terug naar de site (niet opgeslagen werk gaat verloren)'; }
  }
  function show() { S.show($('selPage').value, $('selLang').value); panel(); syncUrl(); }
  function refreshPages() {
    var cur = $('selPage').value; $('selPage').innerHTML = '';
    SITE.pages.forEach(function (p) { $('selPage').add(new Option(S.tr(p.title) + '  (' + p.id + ')', p.id)); });
    $('selPage').value = SITE.pages.some(function (p) { return p.id === cur; }) ? cur : SITE.pages[0].id;
  }
  // voor de agent (agent.js): lezen, en een goedgekeurd voorstel overnemen
  window.WPEditor = {
    site: function () { return SITE; },
    page: function () { return $('selPage').value; },
    lang: function () { return $('selLang').value; },
    key: function () { return getKey(); },
    askKey: function (onOk, onCancel) { askKey(onOk, onCancel); },
    adopt: function (next, pageId) {
      SITE = next; S.setSite(next); SEL = null; refreshPages(); PV.site = next;
      if (pageId) $('selPage').value = pageId;
      dirty(); show();
    },
    preview: function (next, pageId) { S.setSite(next); if (pageId) S.show(pageId, $('selLang').value); pvPost(next, pageId); },
    restore: function () { S.setSite(SITE); show(); pvPost(SITE); },
    goPage: function (id) { refreshPages(); $('selPage').value = id; SEL = null; EXTRA = []; ENTER = []; show(); },
    refreshPages: function () { refreshPages(); },
    selection: function () { return SEL ? [SEL].concat(EXTRA) : []; },
    selectionInfo: function () {
      return (SEL ? [SEL].concat(EXTRA) : []).map(function (id) { var f = findO(id); return f ? f.obj.type : '?'; });
    },
    clearSelection: function () { SEL = null; EXTRA = []; placeSel(); panel(); },
    // bibliotheken (libraries.js): na een wijziging aan SITE → markeren (undo), opnieuw tekenen, selectie behouden
    changed: function (msg) { dirty(); rebuild(); placeSel(); if (msg) $('status').textContent = msg + ' · niet opgeslagen'; },
    setSelection: function (ids) { setSel(ids || []); placeSel(); panel(); },
    pageEl: function () { return PAGE_EL; },
    scale: function () { return (VIEW && VIEW.scale) || 1; }
  };
  function rebuild() { S.build(); panel(); }
  function dirty() {
    DIRTY = true; $('save').classList.remove('clean'); $('status').textContent = 'niet opgeslagen';
    track();
    pvPost(SITE);
  }

  // ---------- ongedaan maken / opnieuw ----------
  // Zoals in WEBPLAYS: geen losse undo per soort actie, maar een momentopname van het hele bestand vóór elke wijziging.
  // Werkt dus voor alles: slepen, tekst, kleur, groeperen, verwijderen, agent-voorstellen. Snel achter elkaar typen = één stap.
  var UNDO = [], REDO = [], NOW_JSON = null, LAST_T = 0, MAX_UNDO = 80;
  function snap() { return JSON.stringify(SITE); }
  function track() {
    var cur = snap();
    if (NOW_JSON === null || cur === NOW_JSON) { NOW_JSON = cur; return; }
    var t = Date.now();
    if (t - LAST_T > 700 || !UNDO.length) { UNDO.push(NOW_JSON); if (UNDO.length > MAX_UNDO) UNDO.shift(); }
    LAST_T = t; REDO = []; NOW_JSON = cur; undoButtons();
  }
  function restore(json) {
    var meta = SITE.meta, next = JSON.parse(json);
    next.meta = meta;                                  // versie/hash blijven van nu, anders weigert opslaan (409)
    SITE = next; NOW_JSON = snap(); LAST_T = 0;
    TONE.base = null; TONE.hue = TONE.sat = TONE.light = 0;   // schuifjes weer op 0 na ongedaan maken
    S.setSite(SITE); PV.site = SITE; refreshPages();
    setSel(selIds().filter(function (id) { return !!findO(id); }));
    DIRTY = true; $('save').classList.remove('clean');
    show(); placeSel(); pvPost(SITE); undoButtons();
  }
  function undo() { if (!UNDO.length) return; REDO.push(NOW_JSON); restore(UNDO.pop()); $('status').textContent = 'ongedaan gemaakt · niet opgeslagen'; }
  function redo() { if (!REDO.length) return; UNDO.push(NOW_JSON); restore(REDO.pop()); $('status').textContent = 'opnieuw gedaan · niet opgeslagen'; }
  function undoButtons() {
    var u = $('undoBtn'), r = $('redoBtn'); if (!u) return;
    u.disabled = !UNDO.length; r.disabled = !REDO.length;
    u.title = 'Ongedaan maken (Ctrl+Z)' + (UNDO.length ? ' · ' + UNDO.length + ' stap' + (UNDO.length > 1 ? 'pen' : '') : '');
  }

  // ---------- live voorbeeld: de echte speler in een iframe, met het (nog niet opgeslagen) bestand ----------
  var PV = { on: false, ready: false, site: null, frame: null };
  function pvPost(site, pageId) {
    PV.site = site || PV.site;
    if (!PV.on || !PV.ready) return;
    clearTimeout(PV.t);
    PV.t = setTimeout(function () {
      PV.frame.contentWindow.postMessage({ type: 'wp-site', site: PV.site, page: pageId || $('selPage').value, lang: $('selLang').value }, location.origin);
    }, 120);
  }
  function pvMode(on) {
    PV.on = on; document.body.classList.toggle('pv', on);
    [].forEach.call(document.querySelectorAll('#modeSeg button'), function (b) { b.classList.toggle('on', (b.dataset.m === 'preview') === on); });
    if (on) {
      PV.frame = $('pvFrame'); PV.ready = false;
      PV.site = PV.site || SITE;
      PV.frame.src = (ON_SITE && S.urlFor ? S.urlFor($('selPage').value, $('selLang').value) : location.pathname.replace(/editor\.html$/, '')) + '?preview=1&t=' + Date.now();
    } else { PV.frame && (PV.frame.src = 'about:blank'); SEL = null; show(); }
  }
  function pvDevice(d) {
    [].forEach.call(document.querySelectorAll('#devSeg button'), function (b) { b.classList.toggle('on', b.dataset.d === d); });
    $('preview').classList.toggle('dev', d !== 'desktop');
    $('pvWrap').style.width = d === 'desktop' ? '100%' : d + 'px';
  }
  window.addEventListener('message', function (ev) {
    if (ev.origin !== location.origin || !ev.data) return;
    if (ev.data.type === 'wp-ready') { PV.ready = true; pvPost(PV.site || SITE); }
    else if (ev.data.type === 'wp-page' && ev.data.page && ev.data.page !== $('selPage').value) {
      $('selPage').value = ev.data.page; SEL = null; S.show(ev.data.page, $('selLang').value); syncUrl();   // editor volgt het voorbeeld
    }
  });
  document.addEventListener('DOMContentLoaded', function () {});
  [].forEach.call(document.querySelectorAll('#modeSeg button'), function (b) { b.onclick = function () { pvMode(b.dataset.m === 'preview'); }; });
  [].forEach.call(document.querySelectorAll('#devSeg button'), function (b) { b.onclick = function () { pvDevice(b.dataset.d); }; });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') { e.preventDefault(); pvMode(!PV.on); }
  });
  window.addEventListener('beforeunload', function (e) { if (DIRTY) { e.preventDefault(); e.returnValue = ''; } });

  function uid(p) { return p + '-' + Math.random().toString(36).slice(2, 8); }

  // ---------- in een samengevoegd object werken (dubbelklik = erin, Esc of klik ernaast = eruit) ----------
  var ENTER = [], ENTER_SNAP = null;   // ENTER = pad van groep-uuids (buitenste eerst)
  function groupObj() {
    if (!ENTER.length) return null;
    var f = S.findObject(ENTER[0]); if (!f) return null;
    var g = f.obj;
    for (var i = 1; i < ENTER.length && g; i++) g = (g.children || []).filter(function (c) { return c.uuid === ENTER[i]; })[0];
    return g && g.type === 'group' ? g : null;
  }
  function findO(id) {
    var g = groupObj();
    if (g) { var c = (g.children || []).filter(function (x) { return x.uuid === id; })[0]; if (c) return { obj: c, list: g.children, owner: (S.findObject(ENTER[0]) || {}).owner || 'page', inGroup: true }; }
    return S.findObject(id);
  }
  function groupEl() { return ENTER.length && PAGE_EL ? PAGE_EL.querySelector('[data-uuid="' + ENTER[ENTER.length - 1] + '"]') : null; }
  // na elke opbouw: de onderdelen van de open groep klikbaar maken, de rest dimmen
  function markEnter() {
    if (!PAGE_EL) return;
    [].forEach.call(PAGE_EL.querySelectorAll('[data-top="in"]'), function (d) { delete d.dataset.top; });
    [].forEach.call(PAGE_EL.querySelectorAll('.wp-inpath'), function (d) { d.classList.remove('wp-inpath', 'wp-open'); });
    PAGE_EL.classList.remove('wp-entering');
    if (ENTER.length && !groupObj()) ENTER = [];             // groep bestaat niet meer (ongedaan maken)
    if (!ENTER.length) return;
    ENTER.forEach(function (id) { var d = PAGE_EL.querySelector('[data-uuid="' + id + '"]'); if (d) d.classList.add('wp-inpath'); });
    var ge = groupEl(); if (!ge) return;
    ge.classList.add('wp-open'); ge.style.overflow = 'visible';
    [].forEach.call(ge.children, function (c) { if (c.dataset && c.dataset.uuid) c.dataset.top = 'in'; });
    PAGE_EL.classList.add('wp-entering');
  }
  function enterGroup(id) {
    if (!ENTER.length) ENTER_SNAP = JSON.stringify(S.findObject(id) && S.findObject(id).obj);
    ENTER.push(id); setSel([]); markEnter(); placeSel(); panel();
    $('status').textContent = 'in het object · klik een onderdeel · Esc of klik ernaast = eruit';
  }
  // eruit: de omtrek van elke geopende groep sluit weer precies om zijn onderdelen (alleen als er iets veranderde)
  function exitGroup() {
    if (!ENTER.length) return;
    var top = ENTER[0], f0 = S.findObject(top), changed = f0 && JSON.stringify(f0.obj) !== ENTER_SNAP;
    if (changed) {
      for (var n = ENTER.length; n > 0; n--) {
        var path = ENTER.slice(0, n); ENTER = path; var g = groupObj(); if (!g || !(g.children || []).length) continue;
        var x0 = Math.min.apply(null, g.children.map(function (c) { return c.layout.x; })), y0 = Math.min.apply(null, g.children.map(function (c) { return c.layout.y; }));
        var x1 = Math.max.apply(null, g.children.map(function (c) { return c.layout.x + c.layout.w; })), y1 = Math.max.apply(null, g.children.map(function (c) { return c.layout.y + c.layout.h; }));
        g.children.forEach(function (c) { c.layout.x -= x0; c.layout.y -= y0; });
        g.layout.x += x0; g.layout.y += y0; g.layout.w = x1 - x0; g.layout.h = y1 - y0;
      }
    }
    ENTER = []; ENTER_SNAP = null; setSel(S.findObject(top) ? [top] : []);
    if (changed) dirty();
    rebuild(); placeSel(); $('status').textContent = changed ? 'klaar in het object · niet opgeslagen' : 'uit het object';
  }
  // ---------- vergrendelen (zoals in WEBPLAYS: slotje linksboven, klik erop = los) ----------
  // Een vergrendeld object is niet te selecteren: je klikt er doorheen naar wat eronder ligt.
  var LOCK_SVG = 'data:image/svg+xml,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><circle cx="8" cy="8" r="7.5" fill="#fff" fill-opacity=".85"/>' +
    '<rect x="4.75" y="7.25" width="6.5" height="5" rx="1" fill="#00A4E4"/>' +
    '<path d="M6 7.25V5.9a2 2 0 0 1 4 0v1.35" fill="none" stroke="#00A4E4" stroke-width="1.3"/></svg>');
  function isLocked(id) { var f = findO(id); return !!(f && f.obj.base && f.obj.base.locked); }
  function setLock(objs, on) {
    objs.forEach(function (o) { o.base = o.base || {}; if (on) o.base.locked = true; else { delete o.base.locked; if (!Object.keys(o.base).length) delete o.base; } });
  }
  function lockSel() {
    var ids = expand(selIds()); if (!ids.length) { $('status').textContent = 'selecteer eerst wat je wilt vergrendelen'; return; }
    setLock(ids.map(function (id) { return findO(id); }).filter(Boolean).map(function (f) { return f.obj; }), true);
    setSel([]); dirty(); rebuild(); placeSel();
    $('status').textContent = ids.length + ' vergrendeld · klik het slotje om los te maken · niet opgeslagen';
  }
  function unlockAll() {
    var n = 0; (function walk(l) { l.forEach(function (o) { if (o.base && o.base.locked) { setLock([o], false); n++; } if (o.children) walk(o.children); }); })(lockLists());
    if (n) { dirty(); rebuild(); } $('status').textContent = n ? n + ' ontgrendeld · niet opgeslagen' : 'niets vergrendeld op deze pagina';
  }
  function lockLists() {
    var pg = SITE.pages.filter(function (p) { return p.id === $('selPage').value; })[0];
    return (pg ? pg.objects : []).concat(((SITE.masters || {})[pg && pg.master] || { objects: [] }).objects);
  }
  function countLocked() { var n = 0; (function walk(l) { l.forEach(function (o) { if (o.base && o.base.locked) n++; if (o.children) walk(o.children); }); })(lockLists()); return n; }
  function placeLocks() {
    if (!PAGE_EL) return;
    [].forEach.call(PAGE_EL.querySelectorAll('.wp-lock'), function (n) { n.remove(); });
    var k = 1 / ((VIEW && VIEW.scale) || 1), groups = {};
    [].forEach.call(PAGE_EL.querySelectorAll('[data-top][data-uuid]'), function (d) {
      var f = findO(d.dataset.uuid); d.classList.toggle('wp-locked', !!(f && f.obj.base && f.obj.base.locked));
      if (!f || !(f.obj.base && f.obj.base.locked)) return;
      var key = (f.obj.base.gid || d.dataset.uuid) + '|' + (d.parentNode === PAGE_EL ? 'p' : 'g');
      (groups[key] = groups[key] || { par: d.parentNode, els: [], objs: [] }); groups[key].els.push(d); groups[key].objs.push(f.obj);
    });
    Object.keys(groups).forEach(function (key) {
      var g = groups[key], x = 1e9, y = 1e9;
      g.els.forEach(function (d) { x = Math.min(x, parseFloat(d.style.left) || 0); y = Math.min(y, parseFloat(d.style.top) || 0); });
      var ic = document.createElement('div'); ic.className = 'wp-lock';
      ic.title = (g.els.length > 1 ? 'Groep vergrendeld' : 'Vergrendeld') + ' — klik om los te maken';
      ic.style.cssText = 'left:' + (x + 3 * k) + 'px;top:' + (y + 3 * k) + 'px;width:' + (16 * k) + 'px;height:' + (16 * k) + 'px;background-image:url("' + LOCK_SVG + '")';
      ic.addEventListener('mousedown', function (e) { e.stopPropagation(); e.preventDefault(); });
      ic.addEventListener('click', function (e) {
        e.stopPropagation(); setLock(g.objs, false); dirty(); rebuild();
        setSel(g.objs.map(function (o) { return o.uuid; })); placeSel(); panel();
        $('status').textContent = 'ontgrendeld · niet opgeslagen';
      });
      g.par.appendChild(ic);
    });
  }

  // ---------- grid en snappen ----------
  // Instellingen per site in site.json (site.grid), alleen voor de editor; de speler doet er niets mee.
  function gridCfg() { var g = (SITE && SITE.site.grid) || {}; return { size: g.size || 10, snap: g.snap !== false, objects: g.objects !== false, show: !!g.show }; }
  // bij het begin van slepen: waar kan het naartoe klikken? (randen en middens van de andere objecten, midden van de pagina)
  function snapPrep(items) {
    var cfg = gridCfg(), k = (VIEW && VIEW.scale) || 1, par = items[0] && items[0].dom ? items[0].dom.parentNode : PAGE_EL;
    var moving = items.map(function (it) { return it.dom; }), xs = [], ys = [];
    var W = ENTER.length && groupObj() ? groupObj().layout.w : SITE.site.width;
    if (cfg.objects) {
      [].forEach.call(par ? par.children : [], function (d) {
        if (!d.dataset || !d.dataset.uuid || !d.dataset.top || moving.indexOf(d) >= 0) return;
        var x = parseFloat(d.style.left), y = parseFloat(d.style.top), w = parseFloat(d.style.width), h = parseFloat(d.style.height);
        if (!isFinite(y) || !isFinite(h)) return;
        var f = findO(d.dataset.uuid), band = f && f.obj.base && f.obj.base.triggerSw;
        if (!band && isFinite(x) && isFinite(w)) xs.push(x, x + w / 2, x + w);
        ys.push(y, y + h / 2, y + h);
      });
      xs.push(0, W / 2, W);                                      // pagina: randen en midden
    }
    return { cfg: cfg, xs: xs, ys: ys, thr: 6 / k, par: par || PAGE_EL, guides: [] };
  }
  function nearest(list, vals, thr) {   // beste paar (eigen rand/midden ↔ doel) binnen de drempel
    var best = null;
    vals.forEach(function (v) { list.forEach(function (t) { var d = t - v; if (Math.abs(d) <= thr && (!best || Math.abs(d) < Math.abs(best.d))) best = { d: d, at: t }; }); });
    return best;
  }
  function snapMove(SN, items, dx, dy) {
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, band = items.some(function (it) { return it.tsw; });
    items.forEach(function (it) { x0 = Math.min(x0, it.x0); y0 = Math.min(y0, it.y0 + it.dy); x1 = Math.max(x1, it.x0 + it.w0); y1 = Math.max(y1, it.y0 + it.dy + it.h0); });
    var nx = x0 + dx, ny = y0 + dy, w = x1 - x0, h = y1 - y0, g = SN.cfg.size;
    var bx = band ? null : nearest(SN.xs, [nx, nx + w / 2, nx + w], SN.thr), by = nearest(SN.ys, [ny, ny + h / 2, ny + h], SN.thr);
    if (bx) { dx += bx.d; SN.guides.push({ v: true, at: bx.at }); } else if (SN.cfg.snap && !band) dx += Math.round(nx / g) * g - nx;
    if (by) { dy += by.d; SN.guides.push({ v: false, at: by.at }); } else if (SN.cfg.snap) dy += Math.round(ny / g) * g - ny;
    return [Math.round(dx), Math.round(dy)];
  }
  function snapEdge(SN, v, vertical) {   // één rand (bij een greep): eerst andere objecten, anders het grid
    var b = nearest(vertical ? SN.xs : SN.ys, [v], SN.thr);
    if (b) { SN.guides.push({ v: vertical, at: b.at }); return v + b.d; }
    return SN.cfg.snap ? Math.round(v / SN.cfg.size) * SN.cfg.size : v;
  }
  function snapGrip(SN, it, L, grip, MIN) {
    var dy = it.dy;
    if ((grip === 'r' || grip === 'cs') && !it.tsw) L.w = Math.max(MIN, Math.round(snapEdge(SN, L.x + L.w, true) - L.x));
    if (grip === 'l' && !it.tsw) { var r = it.x0 + it.w0, nl = Math.min(r - MIN, Math.round(snapEdge(SN, L.x, true))); L.x = nl; L.w = r - nl; }
    if (grip === 'b' || grip === 'hp' || grip === 'cs') L.h = Math.max(MIN, Math.round(snapEdge(SN, L.y + dy + L.h, false) - dy - L.y));
    if (grip === 't') { var bt = it.y0 + it.h0, nt = Math.min(bt - MIN, Math.round(snapEdge(SN, L.y + dy, false) - dy)); L.y = nt; L.h = bt - nt; }
  }
  function drawGuides(SN) {
    [].forEach.call(document.querySelectorAll('.wp-guide'), function (n) { n.remove(); });
    if (!SN.par.isConnected) SN.par = (ENTER.length && groupEl()) || PAGE_EL;   // pagina is intussen opnieuw opgebouwd
    if (!SN.par) return;
    var k = (VIEW && VIEW.scale) || 1, H = SN.par.offsetHeight || 4000, Wd = SN.par.offsetWidth || SITE.site.width;
    SN.guides.forEach(function (g) {
      var d = document.createElement('div'); d.className = 'wp-guide';
      d.style.cssText = g.v ? 'left:' + g.at + 'px;top:0;width:0;height:' + H + 'px;border-left:' + (1 / k) + 'px solid #00A4E4'
                            : 'top:' + g.at + 'px;left:0;height:0;width:' + Wd + 'px;border-top:' + (1 / k) + 'px solid #00A4E4';
      SN.par.appendChild(d);
    });
  }
  // het grid zelf zichtbaar maken (schaalt mee met de pagina)
  function drawGrid() {
    if (!PAGE_EL || !SITE) return;
    var g = $('wpGrid'), cfg = gridCfg();
    if (!cfg.show) { if (g) g.remove(); return; }
    if (!g) { g = document.createElement('div'); g.id = 'wpGrid'; PAGE_EL.appendChild(g); }
    var k = (VIEW && VIEW.scale) || 1, lw = 1 / k, sz = cfg.size, big = sz * Math.max(1, Math.round(100 / sz));
    g.style.backgroundImage = 'linear-gradient(to right, rgba(0,164,228,.22) ' + lw + 'px, transparent ' + lw + 'px),linear-gradient(to bottom, rgba(0,164,228,.22) ' + lw + 'px, transparent ' + lw + 'px),' +
      'linear-gradient(to right, rgba(0,164,228,.09) ' + lw + 'px, transparent ' + lw + 'px),linear-gradient(to bottom, rgba(0,164,228,.09) ' + lw + 'px, transparent ' + lw + 'px)';
    g.style.backgroundSize = big + 'px ' + big + 'px,' + big + 'px ' + big + 'px,' + sz + 'px ' + sz + 'px,' + sz + 'px ' + sz + 'px';
  }
  // knop in de balk met een klein instellingenvenster
  function gridMenu(btn) {
    var m = $('gridMenu');
    if (m) { m.remove(); return; }
    m = document.createElement('div'); m.id = 'gridMenu';
    var cfg = gridCfg();
    function setG(k, v) { SITE.site.grid = Object.assign(gridCfg(), SITE.site.grid || {}); SITE.site.grid[k] = v; drawGrid(); dirty(); }
    m.innerHTML = '<b>Grid</b><label class="gs">Grootte <input type="range" min="5" max="100" step="5"><em></em></label>' +
      '<label><input type="checkbox" data-k="snap"> Snap aan grid</label>' +
      '<label><input type="checkbox" data-k="objects"> Snap aan andere objecten <span>(hulplijnen)</span></label>' +
      '<label><input type="checkbox" data-k="show"> Toon grid</label>' +
      '<p>Ctrl ingedrukt tijdens slepen = even vrij. Tip: 10, 20 of 25 deelt de 1000 px van de pagina mooi op.</p>';
    var r = m.querySelector('input[type=range]'), em = m.querySelector('em');
    r.value = cfg.size; em.textContent = cfg.size + ' px';
    r.oninput = function () { em.textContent = r.value + ' px'; setG('size', +r.value); };
    [].forEach.call(m.querySelectorAll('input[type=checkbox]'), function (c) { c.checked = cfg[c.dataset.k]; c.onchange = function () { setG(c.dataset.k, c.checked); }; });
    document.body.appendChild(m);
    var b = btn.getBoundingClientRect(); m.style.top = (b.bottom + 6) + 'px'; m.style.left = Math.max(8, Math.min(innerWidth - 270, b.left - 100)) + 'px';
    setTimeout(function () {
      document.addEventListener('mousedown', function off(e) { if (!m.contains(e.target) && e.target !== btn) { m.remove(); document.removeEventListener('mousedown', off); } });
    }, 0);
  }

  // ---------- uitlijnen en verdelen ----------
  // Een groep (Ctrl+G) telt als één blok. Eén blok geselecteerd: uitlijnen op de pagina.
  function alignUnits() {
    var fs = expand(selIds()).map(function (id) { return findO(id); }).filter(Boolean), by = {}, units = [];
    fs.forEach(function (f) {
      var k = (f.obj.base && f.obj.base.gid) || f.obj.uuid;
      if (!by[k]) { by[k] = { objs: [] }; units.push(by[k]); } by[k].objs.push(f.obj);
    });
    units.forEach(function (u) {
      u.x = Math.min.apply(null, u.objs.map(function (o) { return o.layout.x; })); u.y = Math.min.apply(null, u.objs.map(function (o) { return o.layout.y; }));
      u.r = Math.max.apply(null, u.objs.map(function (o) { return o.layout.x + o.layout.w; })); u.b = Math.max.apply(null, u.objs.map(function (o) { return o.layout.y + o.layout.h; }));
      u.w = u.r - u.x; u.h = u.b - u.y; u.band = u.objs.some(function (o) { return o.base && o.base.triggerSw; });
    });
    return units;
  }
  function moveUnit(u, dx, dy) { u.objs.forEach(function (o) { if (!(o.base && o.base.triggerSw)) o.layout.x = Math.round(o.layout.x + dx); o.layout.y = Math.round(o.layout.y + dy); }); }
  function sizeUnit(u, w, h) {   // maat gelijk: losse objecten krijgen de maat, een groep schaalt niet (alleen losse objecten)
    if (u.objs.length !== 1) return; var L = u.objs[0].layout; if (w != null && !u.band) L.w = Math.round(w); if (h != null) L.h = Math.round(h);
  }
  function align(how) {
    var us = alignUnits(); if (!us.length) return;
    var gEl = ENTER.length ? groupObj() : null;
    var A = us.length > 1 ? {
      x: Math.min.apply(null, us.map(function (u) { return u.x; })), y: Math.min.apply(null, us.map(function (u) { return u.y; })),
      r: Math.max.apply(null, us.map(function (u) { return u.r; })), b: Math.max.apply(null, us.map(function (u) { return u.b; }))
    } : gEl ? { x: 0, y: 0, r: gEl.layout.w, b: gEl.layout.h } : { x: 0, y: us[0].y, r: SITE.site.width, b: us[0].b };   // één blok: op de pagina (of in het object)
    if (us.length === 1 && !gEl && /top|middle|bottom/.test(how)) { $('status').textContent = 'verticaal uitlijnen: selecteer 2 of meer'; return; }
    var key = (us[0].objs[0] || {}).uuid;
    if (how === 'left') us.forEach(function (u) { moveUnit(u, A.x - u.x, 0); });
    if (how === 'center') us.forEach(function (u) { moveUnit(u, (A.x + A.r) / 2 - (u.x + u.w / 2), 0); });
    if (how === 'right') us.forEach(function (u) { moveUnit(u, A.r - u.r, 0); });
    if (how === 'top') us.forEach(function (u) { moveUnit(u, 0, A.y - u.y); });
    if (how === 'middle') us.forEach(function (u) { moveUnit(u, 0, (A.y + A.b) / 2 - (u.y + u.h / 2)); });
    if (how === 'bottom') us.forEach(function (u) { moveUnit(u, 0, A.b - u.b); });
    if (how === 'distH' || how === 'distV') {
      if (us.length < 3) { $('status').textContent = 'verdelen: selecteer 3 of meer'; return; }
      var hz = how === 'distH', s = us.slice().sort(function (a, b) { return hz ? a.x - b.x : a.y - b.y; });
      var span = hz ? s[s.length - 1].r - s[0].x : s[s.length - 1].b - s[0].y, tot = s.reduce(function (t, u) { return t + (hz ? u.w : u.h); }, 0);
      var gap = (span - tot) / (s.length - 1), pos = hz ? s[0].x : s[0].y;
      s.forEach(function (u) { if (hz) moveUnit(u, pos - u.x, 0); else moveUnit(u, 0, pos - u.y); pos += (hz ? u.w : u.h) + gap; });
    }
    if (how === 'spread') {
      // over de breedte: dezelfde marge links en rechts (die van het meest linkse blok), en gelijke ruimte ertussen
      if (us.length < 2) { $('status').textContent = 'over de breedte: selecteer 2 of meer'; return; }
      var Wp = gEl ? gEl.layout.w : SITE.site.width, s2 = us.slice().sort(function (a, b) { return a.x - b.x; });
      var mL = Math.max(0, s2[0].x), tw = s2.reduce(function (t, u) { return t + u.w; }, 0);
      if (tw > Wp - 2 * mL) mL = Math.max(0, (Wp - tw) / 2);
      var gp = (Wp - 2 * mL - tw) / (s2.length - 1), px = mL;
      s2.forEach(function (u) { moveUnit(u, px - u.x, 0); px += u.w + gp; });
    }
    if (how === 'sameW' || how === 'sameH') {
      if (us.length < 2) { $('status').textContent = 'gelijke maat: selecteer 2 of meer'; return; }
      var ref = us.filter(function (u) { return u.objs[0].uuid === SEL; })[0] || us[0];   // de maat van het eerst aangeklikte
      us.forEach(function (u) { if (u !== ref) sizeUnit(u, how === 'sameW' ? ref.w : null, how === 'sameH' ? ref.h : null); });
    }
    dirty(); rebuild(); placeSel();
    $('status').textContent = ({ left: 'links uitgelijnd', center: 'gecentreerd', right: 'rechts uitgelijnd', top: 'boven uitgelijnd', middle: 'midden uitgelijnd', bottom: 'onder uitgelijnd',
      distH: 'gelijk verdeeld (horizontaal)', distV: 'gelijk verdeeld (verticaal)', spread: 'over de breedte verdeeld', sameW: 'zelfde breedte', sameH: 'zelfde hoogte' })[how] + (us.length === 1 && !gEl ? ' op de pagina' : '') + ' · niet opgeslagen';
  }
  // icoontjes (16×16, lijn = de uitlijnlijn)
  var AL_ICONS = {
    left: '<path d="M2 1v14"/><rect x="4" y="3" width="9" height="3"/><rect x="4" y="9" width="6" height="3"/>',
    center: '<path d="M8 1v14"/><rect x="3" y="3" width="10" height="3"/><rect x="5" y="9" width="6" height="3"/>',
    right: '<path d="M14 1v14"/><rect x="3" y="3" width="9" height="3"/><rect x="6" y="9" width="6" height="3"/>',
    top: '<path d="M1 2h14"/><rect x="3" y="4" width="3" height="9"/><rect x="9" y="4" width="3" height="6"/>',
    middle: '<path d="M1 8h14"/><rect x="3" y="3" width="3" height="10"/><rect x="9" y="5" width="3" height="6"/>',
    bottom: '<path d="M1 14h14"/><rect x="3" y="3" width="3" height="9"/><rect x="9" y="6" width="3" height="6"/>',
    distH: '<path d="M1 2v12M15 2v12"/><rect x="3.5" y="5" width="3" height="6"/><rect x="9.5" y="5" width="3" height="6"/>',
    distV: '<path d="M2 1h12M2 15h12"/><rect x="5" y="3.5" width="6" height="3"/><rect x="5" y="9.5" width="6" height="3"/>',
    spread: '<path d="M1 1v14M15 1v14"/><rect x="3" y="5" width="2.5" height="6"/><rect x="6.75" y="5" width="2.5" height="6"/><rect x="10.5" y="5" width="2.5" height="6"/>',
    sameW: '<path d="M2 4v8M14 4v8M2 8h12"/><path d="M4.5 6 2.5 8l2 2M11.5 6l2 2-2 2"/>',
    sameH: '<path d="M4 2h8M4 14h8M8 2v12"/><path d="M6 4.5 8 2.5l2 2M6 11.5l2 2 2-2"/>'
  };
  var AL_TIPS = { left: 'Links uitlijnen', center: 'Horizontaal centreren', right: 'Rechts uitlijnen', top: 'Boven uitlijnen', middle: 'Verticaal centreren', bottom: 'Onder uitlijnen',
    distH: 'Gelijk verdelen, horizontaal (3+)', distV: 'Gelijk verdelen, verticaal (3+)', spread: 'Over de breedte verdelen: gelijke marge links en rechts, gelijke ruimte ertussen', sameW: 'Zelfde breedte als de eerste', sameH: 'Zelfde hoogte als de eerste' };
  function alignBar(nUnits) {
    var bar = document.createElement('div'); bar.className = 'wp-align';
    ['left', 'center', 'right', 'top', 'middle', 'bottom', 'distH', 'distV', 'spread', 'sameW', 'sameH'].forEach(function (k) {
      var b = document.createElement('button'); b.type = 'button'; b.title = AL_TIPS[k];
      b.innerHTML = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.3">' + AL_ICONS[k] + '</svg>';
      if ((/dist/.test(k) && nUnits < 3) || (/same|spread/.test(k) && nUnits < 2) || (nUnits < 2 && !ENTER.length && /top|middle|bottom/.test(k))) b.disabled = true;
      b.onclick = function () { align(k); };
      bar.appendChild(b);
    });
    return bar;
  }

  // samenvoegen: de selectie wordt één object (een echte groep) — één box, op mobiel één geheel
  function freezeSel() {
    var ids = expand(selIds());
    if (ids.length < 2) { $('status').textContent = 'selecteer eerst 2 of meer objecten om samen te voegen'; return; }
    var fs = ids.map(function (id) { return findO(id); }).filter(Boolean);
    if (fs.some(function (f) { return f.list !== fs[0].list; })) { $('status').textContent = 'samenvoegen kan niet tussen pagina en master'; return; }
    if (fs.some(function (f) { return f.obj.base && f.obj.base.triggerSw; })) { $('status').textContent = 'een schermbrede band kan niet in een samengevoegd object'; return; }
    var g0 = fs[0].obj.base && fs[0].obj.base.gid;
    if (g0 && fs.every(function (f) { return f.obj.base && f.obj.base.gid === g0; })) fs.forEach(function (f) { popGid(f.obj); });   // die groep wordt nu het object zelf
    var L = fs[0].list, at = Math.min.apply(null, fs.map(function (f) { return L.indexOf(f.obj); }));
    fs.sort(function (a, b) { return L.indexOf(a.obj) - L.indexOf(b.obj); });   // lagen houden: wat achter lag, blijft achter (niet de klikvolgorde)
    var g = WPGroups.wrap(fs.map(function (f) { return f.obj; }), uid('g'));
    fs.forEach(function (f) { L.splice(L.indexOf(f.obj), 1); }); L.splice(at, 0, g);
    setSel([g.uuid]); dirty(); rebuild(); placeSel();
    $('status').textContent = 'samengevoegd tot één object (' + fs.length + ') · dubbelklik = erin bewerken · niet opgeslagen';
  }
  function cur() { return SEL ? findO(SEL) : null; }

  // ---------- selectie en slepen ----------
  function topEl(t) { while (t && t !== PAGE_EL) { if (t.dataset && t.dataset.top) return t; t = t.parentNode; } return null; }

  function selIds() { return SEL ? [SEL].concat(EXTRA) : []; }
  function setSel(ids) { SEL = ids[0] || null; EXTRA = ids.slice(1); }
  function isBand(el) { var f = findO(el.dataset.uuid); return !!(f && f.obj.base && f.obj.base.triggerSw); }

  // ---------- groepen (zoals WEBPLAYS: leden houden hun eigen plek, ze delen alleen base.gid) ----------
  // klik op een lid = de hele groep · Alt+klik = alleen dat object · Shift+klik = hele groep erbij/eraf
  // sleep-selectie die één lid raakt = hele groep · Ctrl+G groeperen · Ctrl+Shift+G opheffen
  function gidOf(id) { var f = findO(id); return (f && f.obj.base && f.obj.base.gid) || null; }
  function members(id) {
    var f = findO(id), g = f && f.obj.base && f.obj.base.gid;
    if (!g) return [id];
    var m = f.list.filter(function (o) { return o.base && o.base.gid === g && !o.base.locked; }).map(function (o) { return o.uuid; });
    return m.length > 1 ? m : [id];
  }
  function expand(ids) {
    var out = [];
    ids.forEach(function (id) { members(id).forEach(function (m) { if (out.indexOf(m) < 0) out.push(m); }); });
    return out;
  }
  // groep in groep: base.gid is altijd de buitenste groep; eerdere groepen staan in base.gidStack (binnenste eerst).
  // Groeperen legt er een laag bovenop, opheffen haalt precies één laag weg — dan zijn je eerdere groepen er weer.
  function pushGid(o, g) {
    o.base = o.base || {};
    if (o.base.gid) o.base.gidStack = (o.base.gidStack || []).concat([o.base.gid]);
    o.base.gid = g;
  }
  function popGid(o) {
    var b = o.base; if (!b || !b.gid) return false;
    var st = b.gidStack || [];
    if (st.length) { b.gid = st[st.length - 1]; st = st.slice(0, -1); if (st.length) b.gidStack = st; else delete b.gidStack; }
    else delete b.gid;
    if (!Object.keys(b).length) delete o.base;
    return true;
  }
  function groupSel() {
    var ids = expand(selIds());
    if (ids.length < 2) { $('status').textContent = 'selecteer eerst 2 of meer objecten (Shift-klik of klik-en-sleep)'; return; }
    var fs = ids.map(function (id) { return findO(id); }).filter(Boolean);
    if (fs.some(function (f) { return f.list !== fs[0].list; })) { $('status').textContent = 'groeperen kan niet tussen pagina en master'; return; }
    var g0 = fs[0].obj.base && fs[0].obj.base.gid;
    if (g0 && fs.every(function (f) { return f.obj.base && f.obj.base.gid === g0; })) { $('status').textContent = 'dit is al één groep'; return; }
    var g = uid('g');
    fs.forEach(function (f) { pushGid(f.obj, g); });
    dirty(); rebuild(); setSel(ids); placeSel(); $('status').textContent = 'gegroepeerd (' + fs.length + ') · niet opgeslagen';
  }
  function ungroupSel() {
    var ids = expand(selIds()), n = 0, loose = [];
    var withGid = ids.filter(function (id) { var f = findO(id); return f && f.obj.base && f.obj.base.gid; });
    if (withGid.length) {
      // één laag eraf: de buitenste groep verdwijnt, de groepen die erin zaten blijven bestaan
      withGid.forEach(function (id) { if (popGid(findO(id).obj)) n++; });
      loose = ids;
    } else {
      // geen losse groep meer over: dan een echte groep (type group) uit elkaar — onderdelen worden losse objecten op dezelfde plek
      ids.forEach(function (id) {
        var f = findO(id);
        if (f && f.obj.type === 'group' && window.WPGroups) {
          var kids = WPGroups.explode(f.obj); f.list.splice.apply(f.list, [f.list.indexOf(f.obj), 1].concat(kids));
          kids.forEach(function (k) { loose.push(k.uuid); }); n++;
        }
      });
    }
    if (!n) { $('status').textContent = 'geen groep geselecteerd'; return; }
    dirty(); rebuild(); setSel(loose); placeSel(); panel();
    var left = expand(loose).length < loose.length || loose.some(function (id) { return gidOf(id); });
    $('status').textContent = 'groep opgeheven' + (left ? ' (eerdere groepen blijven)' : ' (' + loose.length + ' los)') + ' · niet opgeslagen';
  }

  // welke greep van de WEBPLAYS-selectiebox is aangeklikt?  t/l/r/b = randbalk, cs = witte middencirkel, hp = ruimte maken
  function gripOf(t) { return t && t.dataset && t.dataset.grip ? t.dataset.grip : null; }

  function onDown(ev) {
    if (ev.button !== 0) return;
    var grip = gripOf(ev.target);
    if (grip === 'b' && ev.shiftKey) grip = 'hp';              // Shift + onderste greep = ruimte maken (ook bij kleine objecten)
    if (grip === 'hp' && ENTER.length) grip = 'b';             // ruimte maken geldt voor de pagina, niet binnen een object
    var el = grip ? null : topEl(ev.target);
    if (ENTER.length && !grip && !(el && el.dataset.top === 'in')) { ev.preventDefault(); exitGroup(); return; }   // klik ernaast = eruit
    if (el && ev.shiftKey && SEL && !isBand(el)) {          // shift-klik: object erbij / eraf
      var id = el.dataset.uuid, ids = selIds(), grp = members(id);
      if (ids.indexOf(id) >= 0) ids = ids.filter(function (x) { return grp.indexOf(x) < 0; });
      else grp.forEach(function (x) { if (ids.indexOf(x) < 0) ids.push(x); });
      setSel(ids); placeSel(); panel(); ev.preventDefault(); return;
    }
    // klik-en-sleep selectie: op lege plek, op een schermbrede band, of overal met Alt
    if (!grip && (!el || ev.altKey || isBand(el))) { marquee(ev, el); return; }
    if (el) {
      var id2 = el.dataset.uuid, cur2 = selIds();
      if (cur2.indexOf(id2) < 0) setSel([id2].concat(members(id2).filter(function (x) { return x !== id2; })));
      else if (id2 !== SEL) { cur2.splice(cur2.indexOf(id2), 1); setSel([id2].concat(cur2)); }
      placeSel(); panel();
    }
    if (!cur()) return;
    ev.preventDefault();
    if (grip === 'rot') { startRotate(ev); return; }
    var sx = ev.clientX, sy = ev.clientY, moved = false;
    // verplaatsen: alle geselecteerde objecten; een greep: alleen het hoofdobject
    var items = (grip ? [SEL] : selIds()).map(function (id) {
      var f = findO(id); if (!f) return null;
      var dom = PAGE_EL.querySelector('[data-top][data-uuid="' + id + '"]'), L = f.obj.layout;
      return { L: L, tsw: f.obj.base && f.obj.base.triggerSw, dom: dom, dy: +(dom && dom.dataset.dy) || 0, x0: L.x, y0: L.y, w0: L.w, h0: L.h };
    }).filter(Boolean);
    var MIN = grip === 'cs' ? 25 : 4;
    var SN = snapPrep(items);                                  // grid + slimme hulplijnen (Alt = even niet snappen)
    // ruimte maken: alles wat op of onder de oude onderrand begint (niet de master, niet het object zelf)
    var push = null;
    if (grip === 'hp' && items[0]) {
      var bot0 = items[0].y0 + items[0].h0, pg = SITE.pages.filter(function (p) { return p.id === $('selPage').value; })[0];
      var below = (pg ? pg.objects : []).filter(function (o) { return o.uuid !== SEL && o.layout && o.layout.y >= bot0; })
        .map(function (o) { return { L: o.layout, y0: o.layout.y, dom: PAGE_EL.querySelector('[data-top][data-uuid="' + o.uuid + '"]') }; });
      push = { bot0: bot0, first: below.length ? Math.min.apply(null, below.map(function (b) { return b.y0; })) : Infinity, list: below, page: pg, h0: pg ? pg.height : 0 };
    }

    function mv(e) {
      var dx = Math.round((e.clientX - sx) / VIEW.scale), dyy = Math.round((e.clientY - sy) / VIEW.scale);
      if (!moved && Math.abs(dx) + Math.abs(dyy) < 3) return;   // pas na 3px: een trillende klik verschuift niets
      moved = true;
      var free = e.ctrlKey || e.metaKey; SN.guides = [];   // Ctrl ingedrukt tijdens slepen = vrij (Alt is al de lasso)
      if (!grip && !free) { var sd = snapMove(SN, items, dx, dyy); dx = sd[0]; dyy = sd[1]; }
      items.forEach(function (it) {
        var L = it.L, dom = it.dom;
        if (!grip) { if (!it.tsw) L.x = it.x0 + dx; L.y = it.y0 + dyy; }
        else if (grip === 't') { var nh = Math.max(MIN, it.h0 - dyy); L.y = it.y0 + it.h0 - nh; L.h = nh; }
        else if (grip === 'b' || grip === 'hp') { L.h = Math.max(MIN, it.h0 + dyy); }
        else if (grip === 'l') { if (!it.tsw) { var nw = Math.max(MIN, it.w0 - dx); L.x = it.x0 + it.w0 - nw; L.w = nw; } }
        else if (grip === 'r') { if (!it.tsw) L.w = Math.max(MIN, it.w0 + dx); }
        else if (grip === 'cs') { if (!it.tsw) L.w = Math.max(MIN, it.w0 + dx); L.h = Math.max(MIN, it.h0 + dyy); }
        if (grip && !free) snapGrip(SN, it, L, grip, MIN);
        if (dom) { if (!it.tsw) { dom.style.left = L.x + 'px'; dom.style.width = L.w + 'px'; } dom.style.top = (L.y + it.dy) + 'px'; dom.style.height = L.h + 'px'; }
      });
      if (push) {
        // eerst gaat de lege ruimte op; zodra de onderrand het eerste object raakt, schuift alles eronder als één blok mee
        var nb = items[0].L.y + items[0].L.h, d = Math.max(0, nb - push.first);
        push.list.forEach(function (b) { b.L.y = b.y0 + d; if (b.dom) b.dom.style.top = (b.L.y + (+b.dom.dataset.dy || 0)) + 'px'; });
        if (push.page) push.page.height = push.h0 + d;
        pushLine(nb);
      }
      drawGuides(SN);
      placeSel(); fillLayout();
    }
    function up() {
      document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up);
      pushLine(null); SN.guides = []; drawGuides(SN);
      if (moved) { dirty(); rebuild(); }
    }
    document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
  }

  // draaien: sleep aan de middencirkel (de donkerblauwe rand); het object draait om zijn midden. Shift = stappen van 15°.
  function startRotate(ev) {
    var f = findO(SEL); if (!f || !f.obj.layout) return;
    var L = f.obj.layout, dom = PAGE_EL.querySelector('[data-top][data-uuid="' + SEL + '"]'), box = $('sel');
    if (!dom || !box) return;
    var rc = box.getBoundingClientRect(), cx = rc.left + rc.width / 2, cy = rc.top + rc.height / 2;
    var ang = function (e) { return Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI; };
    var a0 = ang(ev), r0 = L.r || 0, moved = false;
    document.body.style.cursor = 'grabbing';
    function mv(e) {
      var r = r0 + (ang(e) - a0);
      if (e.shiftKey) r = Math.round(r / 15) * 15; else r = Math.round(r);
      r = ((r + 540) % 360) - 180;                    // -180 … 180
      if (r === -180) r = 180;
      if (!moved && r === r0) return;
      moved = true;
      if (r) L.r = r; else delete L.r;
      dom.style.transform = r ? 'rotate(' + r + 'deg)' : '';
      placeSel(); fillLayout();
      $('status').textContent = 'rotatie ' + r + '°';
    }
    function up() {
      document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up);
      document.body.style.cursor = '';
      if (moved) { dirty(); rebuild(); }
    }
    document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
  }

  // dubbelklik: in een samengevoegd object gaan, of uit een groep alleen dit ene object pakken
  function onDbl(ev) {
    if (gripOf(ev.target) === 'rot') {                // dubbelklik op de draaigreep: terug naar 0°
      var fr = findO(SEL);
      if (fr && fr.obj.layout && fr.obj.layout.r) { delete fr.obj.layout.r; dirty(); rebuild(); placeSel(); panel(); $('status').textContent = 'rotatie 0°'; }
      ev.preventDefault(); return;
    }
    var el = topEl(ev.target); if (!el) return;
    var f = findO(el.dataset.uuid); if (!f) return;
    if (f.obj.type === 'group') { ev.preventDefault(); enterGroup(f.obj.uuid); return; }
    if (members(f.obj.uuid).length > 1) { setSel([f.obj.uuid]); placeSel(); panel(); }
  }

  // stippellijn over de hele pagina op de onderrand, alleen tijdens "ruimte maken"
  function pushLine(y) {
    var l = $('wpPushLine');
    if (y === null) { if (l) l.remove(); return; }
    if (!l) { l = document.createElement('div'); l.id = 'wpPushLine'; PAGE_EL.appendChild(l); }
    l.style.top = y + 'px'; l.style.borderTopWidth = (1.5 / VIEW.scale) + 'px';
  }

  // lasso: rechthoek trekken; alles wat hij raakt wordt geselecteerd, schermbrede banden nooit (Shift = erbij). Slepen op een band trekt een kader, klikken pakt de band.
  function marquee(ev, startEl) {
    ev.preventDefault();
    var sx = ev.clientX, sy = ev.clientY, add = ev.shiftKey, altOnly = ev.altKey, base = add ? selIds() : [], box = null;
    var cv = $('canvas'), sc0 = cv.scrollTop, lastE = ev, timer = null;
    function rect(e) {
      var y0 = sy - (cv.scrollTop - sc0);                      // beginpunt scrollt mee
      return { l: Math.min(sx, e.clientX), t: Math.min(y0, e.clientY), r: Math.max(sx, e.clientX), b: Math.max(y0, e.clientY) };
    }
    function hits(R) {
      var out = [];
      [].forEach.call(PAGE_EL.querySelectorAll('[data-top][data-uuid]'), function (d) {
        var q = d.getBoundingClientRect(); if (!q.width || !q.height) return;
        var inside = q.left >= R.l - 1 && q.right <= R.r + 1 && q.top >= R.t - 1 && q.bottom <= R.b + 1;
        var touch = q.left < R.r && q.right > R.l && q.top < R.b && q.bottom > R.t;
        if (isLocked(d.dataset.uuid)) return;                        // vergrendeld: niet meepakken
        if (isBand(d)) return;                                      // een schermbrede band telt nooit mee in een kader (klik erop om hem te pakken)
        if (touch) out.push(d.dataset.uuid);
      });
      return out;
    }
    function draw(e) {
      lastE = e;
      var R = rect(e);
      if (!box) { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) < 4) return; box = document.createElement('div'); box.className = 'marq'; document.body.appendChild(box); }
      box.style.cssText = 'left:' + R.l + 'px;top:' + R.t + 'px;width:' + (R.r - R.l) + 'px;height:' + (R.b - R.t) + 'px';
      var ids = base.slice();
      expand(hits(R)).forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
      setSel(ids); placeSel();
    }
    function autoScroll() {                                    // bij de rand van het canvas doorscrollen
      var c = cv.getBoundingClientRect(), y = lastE.clientY, v = 0;
      if (y > c.bottom - 30) v = 18; else if (y < c.top + 30) v = -18;
      if (v && box) { cv.scrollTop += v; draw(lastE); }
    }
    function up() {
      document.removeEventListener('mousemove', draw); document.removeEventListener('mouseup', up); clearInterval(timer);
      if (box) { box.remove(); panel(); return; }
      // geen sleepbeweging: gewone klik
      if (startEl) {
        var one = altOnly ? [startEl.dataset.uuid] : members(startEl.dataset.uuid);
        setSel(add && SEL ? base.concat(one.filter(function (x) { return base.indexOf(x) < 0; })) : one);
      }
      else if (!add) setSel([]);
      placeSel(); panel();
    }
    document.addEventListener('mousemove', draw); document.addEventListener('mouseup', up);
    timer = setInterval(autoScroll, 30);
  }

  // ---------- de selectiebox, zoals in WEBPLAYS ----------
  // Eén object: lijn 1,5px #00A4E4, vier randbalken (30×10 / 10×30, half doorzichtig blauw) die elk één as schalen,
  // in het midden een blauwe cirkel (75px, kleiner bij kleine objecten) met een witte cirkel om vrij te schalen,
  // en rechtsonder binnen de box de greep "ruimte maken" (vanaf 150×60).  Meer objecten: alleen omlijning + lichte vulling.
  // Alle maten blijven op het scherm gelijk, ook als de pagina in de editor geschaald is.
  var BLUE = '#00A4E4';
  function placeSel() {
    var old = $('sel'); if (old) old.remove();
    [].forEach.call(document.querySelectorAll('.sel2'), function (n) { n.remove(); });
    window.dispatchEvent(new CustomEvent('wp-selection'));
    if (!SEL || !PAGE_EL) return;
    var k = 1 / ((VIEW && VIEW.scale) || 1), px = function (v) { return (v * k) + 'px'; };
    var ids = selIds();
    function chip(box, text) {
      var c = document.createElement('div'); c.className = 'wp-chip'; c.textContent = text;
      c.style.cssText = 'top:' + px(-18) + ';left:' + px(-1) + ';font-size:' + px(9) + ';line-height:' + px(16) + ';padding:0 ' + px(6) + ';letter-spacing:' + px(1);
      box.appendChild(c);
    }
    function boxFor(id, cls) {
      var d = PAGE_EL.querySelector('[data-top][data-uuid="' + id + '"]'); if (!d) return null;
      var b = document.createElement('div'); b.className = cls;
      b.style.cssText = 'left:' + d.style.left + ';top:' + d.style.top + ';width:' + d.style.width + ';height:' + d.style.height + ';outline-width:' + px(1.5);
      (d.parentNode || PAGE_EL).appendChild(b);                   // binnen een object: in dezelfde laag als het onderdeel
      var f = findO(id);
      if (f && f.obj.layout && f.obj.layout.r) b.style.transform = 'rotate(' + f.obj.layout.r + 'deg)';   // gedraaid object: de box draait mee
      if (f && f.owner === 'master') chip(b, f.obj.base && f.obj.base.footer ? 'FOOTER' : 'MASTER');
      return { el: b, w: parseFloat(d.style.width) || 0, h: parseFloat(d.style.height) || 0, f: f };
    }
    if (ids.length > 1) {
      var g0 = gidOf(ids[0]), whole = g0 && ids.every(function (id) { return gidOf(id) === g0; }) && members(ids[0]).length === ids.length;
      if (whole) {
        var X0 = 1e9, Y0 = 1e9, X1 = -1e9, Y1 = -1e9;
        ids.forEach(function (id) {
          var d = PAGE_EL.querySelector('[data-top][data-uuid="' + id + '"]'); if (!d) return;
          var x = parseFloat(d.style.left), y = parseFloat(d.style.top);
          X0 = Math.min(X0, x); Y0 = Math.min(Y0, y); X1 = Math.max(X1, x + parseFloat(d.style.width)); Y1 = Math.max(Y1, y + parseFloat(d.style.height));
        });
        var gb = document.createElement('div'); gb.className = 'sel2 grp';
        gb.style.cssText = 'left:' + X0 + 'px;top:' + Y0 + 'px;width:' + (X1 - X0) + 'px;height:' + (Y1 - Y0) + 'px;outline-width:' + px(1.5);
        var d0 = PAGE_EL.querySelector('[data-top][data-uuid="' + ids[0] + '"]');
        ((d0 && d0.parentNode) || PAGE_EL).appendChild(gb);
        var f0 = findO(ids[0]);
        if (f0 && f0.owner === 'master') chip(gb, ids.some(function (id) { var f = findO(id); return f && f.obj.base && f.obj.base.footer; }) ? 'FOOTER' : 'MASTER');
        return;
      }
      ids.forEach(function (id) { boxFor(id, 'sel2'); }); return;
    }
    var B = boxFor(SEL, 'wpsel'); if (!B) { SEL = null; return; }
    B.el.id = 'sel';
    var w = B.w, h = B.h, tsw = B.f && B.f.obj.base && B.f.obj.base.triggerSw;
    var rotd = !!(B.f && B.f.obj.layout && B.f.obj.layout.r);   // gedraaid: randgrepen uit (eerst terug naar 0°), alleen de draaigreep blijft
    function grip(name, css, cursor) {
      if (rotd && name !== 'rot') return document.createElement('div');
      var g = document.createElement('div'); g.dataset.grip = name; g.className = 'wpg wpg-' + name;
      g.style.cssText = css + ';cursor:' + cursor; B.el.appendChild(g); return g;
    }
    // randbalken (op het scherm 30×10), binnen de box, op het midden van elke rand
    var L = 30 * k, T = 10 * k;
    grip('t', 'left:' + (w / 2 - L / 2) + 'px;top:0;width:' + L + 'px;height:' + T + 'px', 'n-resize');
    grip('b', 'left:' + (w / 2 - L / 2) + 'px;top:' + (h - T) + 'px;width:' + L + 'px;height:' + T + 'px', 's-resize');
    if (!tsw) {
      grip('l', 'left:0;top:' + (h / 2 - L / 2) + 'px;width:' + T + 'px;height:' + L + 'px', 'w-resize');
      grip('r', 'left:' + (w - T) + 'px;top:' + (h / 2 - L / 2) + 'px;width:' + T + 'px;height:' + L + 'px', 'e-resize');
    }
    // middencirkel: blauw 75px (bij objecten kleiner dan 75: een derde), witte binnencirkel = vrij schalen
    var minDim = Math.min(w, h) / k, bd = (minDim < 75 ? Math.round(minDim / 3) : 75) * k, wd = bd / 2;
    if (!tsw) {
      var cr = grip('rot', 'left:' + (w / 2 - bd / 2) + 'px;top:' + (h / 2 - bd / 2) + 'px;width:' + bd + 'px;height:' + bd + 'px', 'grab');
      cr.title = 'Draaien: sleep (Shift = stappen van 15°, dubbelklik = terug naar 0°)';
    } else {
      var cr0 = document.createElement('div'); cr0.className = 'wpg-cr';
      cr0.style.cssText = 'left:' + (w / 2 - bd / 2) + 'px;top:' + (h / 2 - bd / 2) + 'px;width:' + bd + 'px;height:' + bd + 'px';
      B.el.appendChild(cr0);
    }
    grip('cs', 'left:' + (w / 2 - wd / 2) + 'px;top:' + (h / 2 - wd / 2) + 'px;width:' + wd + 'px;height:' + wd + 'px', 'se-resize');
    // ruimte maken: 14px rechtsonder binnen de box, alleen bij een box van minstens 150×60
    if (w / k >= 150 && h / k >= 60) {
      var hp = grip('hp', 'left:' + (w - 14 * k) + 'px;top:' + (h - 14 * k) + 'px;width:' + (14 * k) + 'px;height:' + (14 * k) + 'px;font-size:' + (11 * k) + 'px', 'ns-resize');
      hp.textContent = '⇣'; hp.title = 'Ruimte maken: hoogte aanpassen en alles eronder schuift mee (of Shift + onderste greep)';
    }
  }

  // ---------- eigenschappenpaneel verbergen (Tab of de knop in de balk): dan bewerk je over de volle schermbreedte ----------
  function setPanelHidden(on, keep) {
    document.body.classList.toggle('nopanel', !!on);
    var b = $('panelBtn'); if (b) { b.classList.toggle('on', !!on); b.title = on ? 'Paneel tonen (Tab)' : 'Paneel verbergen (Tab)'; }
    if (!keep) { try { localStorage.setItem('wpPanelHidden', on ? '1' : '0'); } catch (e) {} }
    setTimeout(function () { window.dispatchEvent(new Event('resize')); placeSel(); }, 0);
  }
  function togglePanel() { setPanelHidden(!document.body.classList.contains('nopanel')); }
  (function () { var h = false; try { h = localStorage.getItem('wpPanelHidden') === '1'; } catch (e) {} if (h) setPanelHidden(true, true); })();

  // ---------- motor bijwerken: de site kijkt bij het openen of er een nieuwere, ondertekende motor is; één klik installeert hem ----------
  function updApi(action, body) {
    return fetch(SITE.site.api + '?a=' + action, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': getKey() }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Onverwacht antwoord van de server.' }; }); });
  }
  function updateWatch() {
    updApi('updateCheck').then(function (r) {
      if (!r || !r.ok || !r.configured || !r.newer || $('updBtn')) return;
      var b = document.createElement('button'); b.id = 'updBtn'; b.textContent = '\u2191 ' + r.latest.replace(/^.*\./, '.');   // kort, zodat de balk niet vol raakt (\u2191 .33)
      b.title = 'Motor ' + r.latest + ' beschikbaar (nu ' + r.current + ')' + (r.notes ? ' · ' + r.notes : '') + ' — klik om bij te werken';
      b.onclick = function () { installUpdate(r); };
      $('status').before(b);
    }).catch(function () {});
  }
  function installUpdate(r) {
    if (DIRTY) { WPPrompt.notice('Sla eerst je wijzigingen op, daarna kun je bijwerken.'); return; }
    WPPrompt.confirm('Motor bijwerken van ' + r.current + ' naar ' + r.latest + '? Dit geldt voor alle sites op deze server. De vorige versie blijft bewaard en wordt vanzelf teruggezet als iets misgaat.',
      { title: 'Motor bijwerken', ok: 'Bijwerken' }, function () {
        var b = $('updBtn'); if (b) b.disabled = true; $('status').textContent = 'motor bijwerken…';
        var fail = function (m) { if (b) b.disabled = false; $('status').textContent = 'bijwerken mislukt'; WPPrompt.notice(m || 'Bijwerken is mislukt. Er is niets veranderd.', { title: 'Bijwerken mislukt' }); };
        updApi('updateInstall').then(function (j) {
          if (j && j.ok) WPPrompt.notice('Bijgewerkt naar ' + j.to + '. De editor wordt opnieuw geladen.', { title: 'Klaar' }, function () { DIRTY = false; location.reload(); });
          else fail(j && j.error);
        }).catch(function () { fail('Geen verbinding met de server. Controleer of de site nog werkt en probeer het opnieuw.'); });
      });
  }

  // ---------- toetsen ----------
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); return; }
    if (e.key === 'Escape' && !(window.WPPrompt && WPPrompt.isOpen())) {
      if (document.activeElement) document.activeElement.blur();
      if (ENTER.length) { exitGroup(); return; }
      SEL = null; EXTRA = []; placeSel(); panel(); return;
    }
    var tag = (document.activeElement && document.activeElement.tagName) || '';
    if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
    if (e.key === 'Tab' && !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey && (!document.activeElement || document.activeElement === document.body)) { e.preventDefault(); togglePanel(); return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); redo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') { e.preventDefault(); if (e.shiftKey) unlockAll(); else lockSel(); return; }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'f') { e.preventDefault(); freezeSel(); return; }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'm') { e.preventDefault(); var fm = cur(); if (fm) moveSel(fm.owner !== 'master'); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'g') { e.preventDefault(); if (e.shiftKey) ungroupSel(); else groupSel(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a' && PAGE_EL) {   // Ctrl+A: alles op de pagina (geen banden, geen master)
      e.preventDefault();
      var all = [].map.call(PAGE_EL.querySelectorAll('[data-top][data-uuid]'), function (d) { return d.dataset.uuid; })
        .filter(function (id) { var g = findO(id); return g && !(g.obj.base && g.obj.base.locked) && (ENTER.length ? g.inGroup : g.owner !== 'master' && !(g.obj.base && g.obj.base.triggerSw)); });
      setSel(all); placeSel(); panel(); return;
    }
    var f = cur(); if (!f) return;
    var st = e.shiftKey ? 10 : 1, mx = 0, my = 0;
    if (e.key === 'ArrowLeft') mx = -st; else if (e.key === 'ArrowRight') mx = st;
    else if (e.key === 'ArrowUp') my = -st; else if (e.key === 'ArrowDown') my = st;
    if (mx || my) {
      selIds().forEach(function (id) {
        var g = findO(id); if (!g) return;
        if (!(g.obj.base && g.obj.base.triggerSw)) g.obj.layout.x += mx;
        g.obj.layout.y += my;
      });
    }
    else if (e.key === 'Delete' || e.key === 'Backspace') { del(); e.preventDefault(); return; }
    else if (e.key === 'Escape') { SEL = null; placeSel(); panel(); return; }
    else return;
    e.preventDefault(); dirty(); rebuild();
  });

  // ---------- toevoegen en verwijderen ----------
  function visibleY() { return Math.max(40, Math.round($('canvas').scrollTop + 120)); }

  function addText() {
    var key = uid('t'), lang = $('selLang').value;
    SITE.translations[key] = {};
    SITE.site.languages.forEach(function (l) { SITE.translations[key][l] = l === 'nl' ? 'Nieuwe tekst' : 'New text'; });
    var o = { uuid: uid('o'), type: 'text', layout: { x: 60, y: visibleY(), w: 400, h: 40 }, props: { style: 'tx-body', text: key } };
    S.page().objects.push(o); SEL = o.uuid; dirty(); rebuild();
    void lang;
  }
  function addIcon() {
    var names = Object.keys((SITE.icons && SITE.icons.items) || {});
    if (!names.length) names = ['social:linkedin'];      // geen eigen iconenset: begin met een social-icoon
    var first = Object.keys(SITE.colors).indexOf('brand') >= 0 ? '@brand' : '@' + Object.keys(SITE.colors)[0];
    var o = { uuid: uid('o'), type: 'icon', layout: { x: 60, y: visibleY(), w: 64, h: 64 }, props: { icon: names[0], color: first } };
    S.page().objects.push(o); SEL = o.uuid; dirty(); rebuild();
  }
  function addSurface() {
    var o = { uuid: uid('o'), type: 'surface', layout: { x: 60, y: visibleY(), w: 300, h: 160 },
      surface: { fills: [{ type: 'solid', color: '@brand', alpha: 1 }], shape: { kind: 'rect', radius: [0, 0, 0, 0] } } };
    S.page().objects.unshift(o); SEL = o.uuid; dirty(); rebuild();   // vooraan = achter de rest
  }
  function del() {
    var fs = selIds().map(function (id) { return findO(id); }).filter(Boolean);
    if (!fs.length) return;
    var nm = fs.filter(function (f) { return f.owner === 'master'; }).length;
    function go() { fs.forEach(function (f) { var i = f.list.indexOf(f.obj); if (i >= 0) f.list.splice(i, 1); }); setSel([]); dirty(); rebuild(); }
    if (!nm) return go();
    WPPrompt.confirm((fs.length > 1 ? nm + ' van de ' + fs.length + ' objecten horen' : 'Dit object hoort') + ' bij de master en staa' + (fs.length > 1 ? 'n' : 't') + ' op alle pagina\'s. Verwijderen?',
      { ok: 'Verwijderen', danger: true }, go);
  }
  // ---------- naar de master / terug naar de pagina ----------
  // Zelfde plek, zelfde laagvolgorde; een groep (gid of samengevoegd) gaat altijd in z'n geheel. Ctrl+Z werkt.
  function masterOfPage(pg, make) {
    SITE.masters = SITE.masters || {};
    if (pg.master && SITE.masters[pg.master]) return pg.master;
    if (!make) return null;
    var keys = Object.keys(SITE.masters), name = keys[0] || 'standaard';
    if (!SITE.masters[name]) SITE.masters[name] = { objects: [] };
    pg.master = name;
    return name;
  }
  // target: 'master' | 'footer' (= in de master én onderaan in de footer-zone) | 'page' | 'unfooter' (footer → gewone master)
  function isFoot(f) { return !!(f.obj.base && f.obj.base.footer); }
  function setFoot(o, on) {
    o.base = o.base || {};
    if (on) o.base.footer = true; else { delete o.base.footer; if (!Object.keys(o.base).length) delete o.base; }
  }
  function moveSel(target) {
    if (target === true) target = 'master'; else if (target === false) target = 'page';
    if (ENTER.length) { $('status').textContent = 'eerst uit het object (Esc), dan het hele object verplaatsen'; return; }
    var pg = S.page(); if (!pg) return;
    var fs = expand(selIds()).map(function (id) { return findO(id); }).filter(function (f) {
      if (!f || f.inGroup) return false;
      if (target === 'master') return f.owner !== 'master' || isFoot(f);
      if (target === 'footer') return f.owner !== 'master' || !isFoot(f);
      if (target === 'unfooter') return f.owner === 'master' && isFoot(f);
      return f.owner === 'master';
    });
    var already = { master: 'staat al in de master', footer: 'staat al in de footer', page: 'staat al op de pagina', unfooter: 'is geen footer' };
    if (!fs.length) { $('status').textContent = already[target]; return; }
    var toM = target !== 'page';
    function go() {
      var name = masterOfPage(pg, true), mList = SITE.masters[name].objects, dest = toM ? mList : pg.objects;
      fs.sort(function (a, b) { return a.list.indexOf(a.obj) - b.list.indexOf(b.obj); });   // laagvolgorde houden
      fs.forEach(function (f) {
        if (f.list !== dest) { var i = f.list.indexOf(f.obj); if (i >= 0) f.list.splice(i, 1); dest.push(f.obj); }
        setFoot(f.obj, target === 'footer');
      });
      setSel(fs.map(function (f) { return f.obj.uuid; })); dirty(); rebuild(); placeSel();
      var what = fs.length + (fs.length > 1 ? ' objecten' : ' object');
      $('status').textContent = what + ({
        master: ' naar master “' + name + '” · op alle pagina\'s met deze master',
        footer: ' naar de footer van “' + name + '” · staat onderaan op alle pagina\'s met deze master',
        unfooter: ' is geen footer meer · blijft in de master, op zijn eigen plek',
        page: ' naar deze pagina · weg van de andere pagina\'s'
      })[target] + ' · niet opgeslagen';
    }
    var n = pg.master ? SITE.pages.filter(function (p) { return p.master === pg.master; }).length : 1;
    var fromPage = fs.some(function (f) { return f.owner !== 'master'; });
    if (target === 'page') return WPPrompt.confirm('Naar deze pagina: dit verdwijnt van de andere pagina\'s met master “' + pg.master + '” en staat alleen nog hier. Doorgaan?', { ok: 'Naar pagina' }, go);
    if (fromPage && n > 1) return WPPrompt.confirm((target === 'footer' ? 'Naar de footer' : 'Naar de master') + ': dit komt op alle ' + n + ' pagina\'s met master “' + pg.master + '”. Doorgaan?', { ok: target === 'footer' ? 'Naar footer' : 'Naar master' }, go);
    go();
  }
  function order(dir) {
    var f = cur(); if (!f) return;
    var i = f.list.indexOf(f.obj), j = dir > 0 ? f.list.length - 1 : 0;
    f.list.splice(i, 1); f.list.splice(j, 0, f.obj);
    dirty(); rebuild();
  }

  // ---------- palet verschuiven (kleurtoon / levendig / licht) ----------
  var TONE = { base: null, hue: 0, sat: 0, light: 0 };
  function shiftColor(hex, dh, ds, dl) {
    var m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return hex;
    var n = parseInt(m[1], 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn, hh = 0, ss = 0;
    if (d) {
      ss = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh /= 6;
    }
    hh = ((hh * 360 + dh) % 360 + 360) % 360 / 360;
    ss = ds >= 0 ? ss + (1 - ss) * ss * ds / 100 : ss * (1 + ds / 100);   // grijs blijft grijs, kleur wordt feller of rustiger
    l = dl >= 0 ? l + (1 - l) * dl / 100 : l * (1 + dl / 100);
    ss = Math.max(0, Math.min(1, ss)); l = Math.max(0, Math.min(1, l));
    function f(t) { var q = l < .5 ? l * (1 + ss) : l + ss - l * ss, p = 2 * l - q; t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < .5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; }
    var o = [f(hh + 1 / 3), f(hh), f(hh - 1 / 3)].map(function (v) { return ('0' + Math.round(v * 255).toString(16)).slice(-2); });
    return '#' + o.join('');
  }

  // ---------- paneel ----------
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in attrs || {}) { if (k === 'text') e.textContent = attrs[k]; else if (k.slice(0, 2) === 'on') e[k] = attrs[k]; else e.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function row(label, input) { return h('div', { class: 'row' }, [h('label', { text: label }), input]); }
  function num(val, on) { var i = h('input', { type: 'number', value: val }); i.oninput = function () { if (i.value !== '') on(+i.value); }; return i; }

  function colorRow(label, val, on) {
    var t = h('input', { type: 'text', value: val || '' });
    var c = h('input', { type: 'color' });
    function sync() { var v = S.color(t.value); if (/^#[0-9a-f]{6}$/i.test(v || '')) c.value = v; }
    sync();
    t.onchange = function () { sync(); on(t.value); };
    c.oninput = function () { t.value = c.value; on(c.value); };
    var r = h('div', { class: 'row' }, [h('label', { text: label }), t, c]);
    var sw = h('div', { class: 'sw' });
    Object.keys(SITE.colors).forEach(function (n) {
      var i = h('i', { title: '@' + n }); i.style.background = SITE.colors[n];
      i.onclick = function () { t.value = '@' + n; sync(); on(t.value); };
      sw.appendChild(i);
    });
    var wrap = h('div'); wrap.appendChild(r); wrap.appendChild(sw); return wrap;
  }

  function styleSelect(kind, val, on) {
    var s = h('select');
    s.add(new Option('— geen —', ''));
    Object.keys(SITE.styles).forEach(function (k) { if (SITE.styles[k].kind === kind) s.add(new Option(SITE.styles[k].name, k)); });
    s.value = val || '';
    s.onchange = function () { on(s.value); };
    return s;
  }

  var LAYOUT_INPUTS = null;
  function fillLayout() {
    var f = cur(); if (!f || !LAYOUT_INPUTS) return;
    ['x', 'y', 'w', 'h'].forEach(function (k) { if (document.activeElement !== LAYOUT_INPUTS[k]) LAYOUT_INPUTS[k].value = f.obj.layout[k]; });
  }

  function change(fn) { return function (v) { fn(v); dirty(); S.build(); }; }

  function panel() {
    var P = $('panel'); P.innerHTML = ''; LAYOUT_INPUTS = null;
    var f = cur(), lang = $('selLang').value, page = S.page();

    // paneel alleen als er iets geselecteerd is, of als je zelf 'Pagina' opent
    var hide = !f && !PAGEPANEL;
    if (document.body.classList.contains('no-panel') !== hide) {
      document.body.classList.toggle('no-panel', hide);
      setTimeout(function () { window.dispatchEvent(new Event('resize')); }, 0);
    }
    if ($('pageBtn')) $('pageBtn').classList.toggle('on', PAGEPANEL && !f);
    if (hide) return;
    if (!f) {
      P.appendChild(h('h3', { text: 'Pagina' }));
      var t = h('input', { type: 'text', value: S.tr(page.title) });
      t.onchange = function () { setText(page, 'title', t.value); dirty(); };
      P.appendChild(row('Titel', t));
      var d = h('textarea', {}); d.value = S.tr(page.description); d.style.minHeight = '60px';
      d.onchange = function () { setText(page, 'description', d.value); dirty(); };
      P.appendChild(row('Omschr.', d));
      P.appendChild(row('Hoogte', num(page.height || 0, change(function (v) { page.height = v; }))));
      // welke master (kop/menu/footer) deze pagina gebruikt
      var ms = h('select'); ms.add(new Option('— geen —', ''));
      Object.keys(SITE.masters || {}).forEach(function (m) { ms.add(new Option(m + ' (' + SITE.pages.filter(function (p) { return p.master === m; }).length + ' p.)', m)); });
      ms.add(new Option('+ nieuwe master…', '__new'));
      ms.value = page.master && (SITE.masters || {})[page.master] ? page.master : '';
      ms.onchange = function () {
        if (ms.value === '__new') {
          WPPrompt.ask('Naam van de nieuwe master', { placeholder: 'bijv. landing', validate: function (v) {
            v = (v || '').trim(); return !v ? 'vul een naam in' : (SITE.masters || {})[v] ? 'die naam bestaat al' : null; } },
            function (v) { v = v.trim(); SITE.masters = SITE.masters || {}; SITE.masters[v] = { objects: [] }; page.master = v; dirty(); rebuild(); },
            function () { panel(); });
          return;
        }
        if (ms.value) page.master = ms.value; else delete page.master;
        dirty(); rebuild();
      };
      P.appendChild(row('Master', ms));

      // zoekmachines: deze pagina wel/niet in de sitemap en zoekresultaten
      var ni = h('input', { type: 'checkbox' }); ni.checked = !!page.noindex; ni.style.cssText = 'width:16px;min-width:16px;height:16px;flex:none;padding:0;margin:0';
      ni.onchange = function () { if (ni.checked) page.noindex = true; else delete page.noindex; dirty(); };
      P.appendChild(row('Niet vindbaar', h('label', { style: 'display:flex;gap:6px;align-items:center;cursor:pointer' }, [ni, h('span', { text: 'niet in zoekmachines en sitemap' })])));

      // favicon (icoon in het tabblad): SVG + PNG-reserve, eventueel animatie

      // site-adres voor de sitemap
      P.appendChild(h('h3', { text: 'Zoekmachines' }));
      var su = h('input', { type: 'text', placeholder: 'https://www.voorbeeld.nl', value: SITE.site.url || '' });
      su.onchange = function () { var v = su.value.trim().replace(/\/+$/, ''); if (v) SITE.site.url = v; else delete SITE.site.url; dirty(); };
      P.appendChild(row('Site-adres', su));
      P.appendChild(h('p', { class: 'note', text: 'Bij elke keer opslaan maakt WEBPLAYS sitemap.xml en robots.txt uit je pagina\'s en talen. Leeg laten: het adres waarop je de editor gebruikt (lokaal wordt er geen sitemap gemaakt).' }));
      var sb = h('button', { text: 'Sitemap nu maken' });
      sb.onclick = function () {
        $('status').textContent = 'sitemap maken…';
        fetch(SITE.site.api + '?a=sitemap', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': getKey() }, body: '{}' })
          .then(function (r) { return r.json().catch(function () { return { ok: false }; }); })
          .then(function (j) { $('status').textContent = !j.ok ? 'sitemap mislukt' : /^ok:/.test(j.sitemap) ? 'sitemap gemaakt (' + j.sitemap.slice(3) + ' adressen)' : 'geen sitemap: vul eerst het site-adres in'; })
          .catch(function () { $('status').textContent = 'sitemap mislukt'; });
      };
      P.appendChild(sb);
      P.appendChild(h('h3', { text: 'Favicon (icoon in het tabblad)' }));
      var fav = function () { return SITE.site.favicon || null; };
      var favSet = function (k, v) {
        var o = SITE.site.favicon = SITE.site.favicon || {};
        if (v === '' || v === undefined || v === null || (Array.isArray(v) && !v.length)) delete o[k]; else o[k] = v;
        if (!Object.keys(o).length) delete SITE.site.favicon;
        dirty(); rebuild();
      };
      var favUp = function (file, done, retry) {
        $('status').textContent = 'uploaden…';
        fetch(SITE.site.api + '?a=mediaUpload&name=' + encodeURIComponent(file.name), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-WP-Key': getKey() }, body: file })
          .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'HTTP ' + r.status }; }).then(function (j) { j._s = r.status; return j; }); })
          .then(function (j) {
            if (j._s === 401 && retry !== true) { askKey(function () { favUp(file, done, true); }, function () { $('status').textContent = 'geen sleutel'; }); return; }
            if (!j.ok || !j.item) { $('status').textContent = 'niet geplaatst: ' + (j.error || 'mislukt'); return; }
            $('status').textContent = ''; done(j.item.file);
          }).catch(function (x) { $('status').textContent = 'uploaden mislukt: ' + x.message; });
      };
      var favFile = function (label, key, hint) {
        var inp = h('input', { type: 'text', placeholder: hint, value: (fav() && fav()[key]) || '' });
        inp.onchange = function () { favSet(key, inp.value.trim()); panel(); };
        var pick = h('input', { type: 'file', accept: '.svg,.png,.gif,.webp,.jpg,.jpeg,image/*' }); pick.style.display = 'none';
        pick.onchange = function () { if (pick.files[0]) favUp(pick.files[0], function (f) { favSet(key, f); panel(); }); };
        var btn = h('button', { text: 'Uploaden…', title: 'Kies een bestand van je computer' }); btn.onclick = function () { pick.click(); };
        var w = h('div', {}, [inp, pick, btn]); w.style.cssText = 'display:flex;gap:6px'; inp.style.flex = '1';
        return row(label, w);
      };
      P.appendChild(favFile('Bestand', 'file', 'media/favicon.svg'));
      P.appendChild(favFile('Reserve', 'fallback', 'media/favicon.png (voor Safari)'));
      var an = h('select'); [['', 'Geen (stilstaand)'], ['draai', 'Draaien'], ['puls', 'Pulseren'], ['beeldjes', 'Beeldjes (eigen animatie)']].forEach(function (o) { an.add(new Option(o[1], o[0])); });
      an.value = (fav() && fav().animate) || '';
      an.onchange = function () { favSet('animate', an.value); panel(); };
      P.appendChild(row('Animatie', an));
      if (an.value) {
        var spd = h('input', { type: 'number', step: 'any', min: '0.2', value: (fav() && fav().speed) || '', placeholder: an.value === 'beeldjes' ? '4 beeldjes per seconde' : an.value === 'draai' ? '4 seconden per rondje' : '2 seconden per puls' });
        spd.onchange = function () { favSet('speed', spd.value === '' ? '' : +spd.value); };
        P.appendChild(row(an.value === 'beeldjes' ? 'Beeldjes/sec' : 'Seconden', spd));
      }
      if (an.value === 'beeldjes') {
        var fr = h('textarea', { placeholder: 'één bestand per regel, bijv.\nmedia/f1.png\nmedia/f2.png' }); fr.value = ((fav() && fav().frames) || []).join('\n'); fr.style.minHeight = '70px';
        fr.onchange = function () { favSet('frames', fr.value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean)); };
        P.appendChild(row('Beeldjes', fr));
      }
      P.appendChild(h('p', { class: 'note', text: 'Gebruik een SVG (scherp) en een PNG als reserve: Safari toont geen SVG-icoon. Animatie draait in Chrome, Edge en Firefox; Safari en bezoekers die "beweging verminderen" hebben aan, zien het stilstaande icoon.' }));
      if (fav()) { var fd = h('button', { text: 'Favicon verwijderen' }); fd.onclick = function () { delete SITE.site.favicon; dirty(); rebuild(); panel(); }; P.appendChild(fd); }

      // delen: voorbeeld op sociale media en WhatsApp (Open Graph); titel en omschrijving komen van de pagina zelf
      P.appendChild(h('h3', { text: 'Delen (voorbeeld op sociale media)' }));
      var shFile = function (label, get, set, hint) {
        var inp = h('input', { type: 'text', placeholder: hint, value: get() || '' });
        inp.onchange = function () { set(inp.value.trim()); dirty(); panel(); };
        var pick = h('input', { type: 'file', accept: '.png,.jpg,.jpeg,.webp,.gif,image/*' }); pick.style.display = 'none';
        pick.onchange = function () { if (pick.files[0]) favUp(pick.files[0], function (f) { set(f); dirty(); panel(); }); };
        var btn = h('button', { text: 'Uploaden…', title: 'Kies een afbeelding van je computer' }); btn.onclick = function () { pick.click(); };
        var w = h('div', {}, [inp, pick, btn]); w.style.cssText = 'display:flex;gap:6px'; inp.style.flex = '1';
        return row(label, w);
      };
      P.appendChild(shFile('Deze pagina', function () { return page.share; }, function (v) { if (v) page.share = v; else delete page.share; }, 'media/delen.jpg'));
      P.appendChild(shFile('Hele site', function () { return SITE.site.share; }, function (v) { if (v) SITE.site.share = v; else delete SITE.site.share; }, 'standaard, als een pagina er geen heeft'));
      P.appendChild(h('p', { class: 'note', text: 'Aanbevolen: 1200 × 630 px (JPG of PNG, liefst onder 300 KB; geen SVG). Titel en omschrijving komen van de pagina. Na het delen onthouden WhatsApp en sociale media een voorbeeld soms dagenlang.' }));

      P.appendChild(h('h3', { text: 'Kleuren (palet) — klik om te wijzigen' }));
      var grid = h('div', { class: 'pal' });
      Object.keys(SITE.colors).forEach(function (n) {
        var pick = h('input', { type: 'color' }); pick.value = SITE.colors[n];
        var chip = h('label', { class: 'chip', title: '@' + n + ' ' + SITE.colors[n] }, [h('i'), h('span', { text: n }), pick]);
        chip.querySelector('i').style.background = SITE.colors[n];
        pick.oninput = function () { TONE.base = null; TONE.hue = TONE.sat = TONE.light = 0; SITE.colors[n] = pick.value; chip.querySelector('i').style.background = pick.value; dirty(); S.build(); };
        grid.appendChild(chip);
      });
      P.appendChild(grid);

      // hele site in één keer: het palet verschuiven (alles met @kleur verandert mee)
      P.appendChild(h('h3', { text: 'Hele site' }));
      var TB = TONE.base || (TONE.base = JSON.parse(JSON.stringify(SITE.colors)));
      function retone() {
        Object.keys(TB).forEach(function (n) { SITE.colors[n] = shiftColor(TB[n], TONE.hue, TONE.sat, TONE.light); });
        [].forEach.call(grid.querySelectorAll('label.chip'), function (c, i) {
          var n = Object.keys(SITE.colors)[i]; if (!n) return;
          c.querySelector('i').style.background = SITE.colors[n]; c.querySelector('input').value = SITE.colors[n];
        });
        dirty(); S.build();
      }
      function slider(label, key, min, max, fmt) {
        var out = h('em', { text: fmt(TONE[key]) }), r = h('input', { type: 'range', min: min, max: max, value: TONE[key] });
        r.oninput = function () { TONE[key] = +r.value; out.textContent = fmt(TONE[key]); retone(); };
        r.ondblclick = function () { TONE[key] = 0; r.value = 0; out.textContent = fmt(0); retone(); };
        return h('div', { class: 'row tone' }, [h('label', { text: label }), r, out]);
      }
      var pct = function (v) { return (v > 0 ? '+' : '') + v + '%'; };
      P.appendChild(slider('Kleurtoon', 'hue', -180, 180, function (v) { return (v > 0 ? '+' : '') + v + '\u00b0'; }));
      P.appendChild(slider('Levendig', 'sat', -100, 100, pct));
      P.appendChild(slider('Licht', 'light', -50, 50, pct));
      P.appendChild(h('div', { class: 'row tonebtn' }, [
        h('button', { text: 'Terug naar origineel', onclick: function () { TONE.hue = TONE.sat = TONE.light = 0; retone(); TONE.base = null; panel(); } }),
        h('button', { text: 'Zo houden', title: 'Dit wordt het nieuwe uitgangspunt van de schuifjes', onclick: function () { TONE.base = null; TONE.hue = TONE.sat = TONE.light = 0; panel(); $('status').textContent = 'nieuw palet · niet opgeslagen'; } })
      ]));
      P.appendChild(h('p', { class: 'note', text: 'Schuif om het hele palet tegelijk te verschuiven: alles wat een paletkleur gebruikt verandert mee. Dubbelklik op een schuifje = terug naar 0. Ctrl+Z werkt ook.' }));
      var nl = countLocked();
      if (nl) P.appendChild(h('div', { class: 'row tonebtn' }, [h('button', { text: 'Alles ontgrendelen (' + nl + ')', title: 'Ctrl+Shift+L', onclick: unlockAll })]));
      P.appendChild(h('p', { class: 'note', text: 'Klik een object om het te bewerken. Slepen = verplaatsen, blokje rechtsonder = maat, pijltjes = 1px (shift 10px), Delete = weg, Ctrl+S = opslaan.' }));
      return;
    }

    var o = f.obj;
    P.appendChild(h('h3', {}, [document.createTextNode(o.type), f.owner === 'master' ? h('span', { class: 'tag', text: 'master' }) : null]));
    if (!f.inGroup) {
      var mb = function (text, title, t) { return h('button', { text: text, title: title, onclick: function () { moveSel(t); } }); };
      var foot = f.owner === 'master' && isFoot(f);
      P.appendChild(h('div', { class: 'row tonebtn' }, f.owner !== 'master'
        ? [mb('→ naar master', 'Op alle pagina\'s met deze master (Ctrl+Shift+M)', 'master'), mb('→ naar footer', 'In de master, onderaan in de footer-zone', 'footer')]
        : foot
          ? [mb('→ naar pagina', 'Alleen nog op deze pagina (Ctrl+Shift+M)', 'page'), mb('Geen footer', 'Blijft in de master, maar niet meer in de footer-zone', 'unfooter')]
          : [mb('→ naar pagina', 'Alleen nog op deze pagina (Ctrl+Shift+M)', 'page'), mb('→ naar footer', 'Onderaan in de footer-zone', 'footer')]));
    }
    // uitlijnen bovenaan: bij meerdere objecten is dat meestal waarvoor je het paneel opent
    var nUnits = alignUnits().length;
    if (nUnits > 1) P.appendChild(h('h3', { text: 'Uitlijnen (' + nUnits + ')' }));
    P.appendChild(alignBar(nUnits));
    if (nUnits < 2) P.lastChild.title = 'Eén object: uitlijnen op de ' + (ENTER.length ? 'rand van het object' : 'pagina');

    var q = h('div', { class: 'quad' });
    LAYOUT_INPUTS = {};
    var tsw = o.base && o.base.triggerSw;
    ['x', 'y', 'w', 'h'].forEach(function (k) {
      var i = num(o.layout[k], change(function (v) { o.layout[k] = v; }));
      if (tsw && (k === 'x' || k === 'w')) i.disabled = true;
      LAYOUT_INPUTS[k] = i;
      q.appendChild(h('div', {}, [h('span', { text: k }), i]));
    });
    P.appendChild(q);
    var tswBox = h('input', { type: 'checkbox' }); tswBox.checked = !!tsw; tswBox.style.width = 'auto';
    tswBox.onchange = change(function () { o.base = o.base || {}; if (tswBox.checked) o.base.triggerSw = true; else delete o.base.triggerSw; });
    P.appendChild(row('Volle br.', tswBox));
    // op een telefoon (smaller dan 600 px) niet tonen
    var hmBox = h('input', { type: 'checkbox' }); hmBox.checked = !!(o.base && o.base.hideOnMobile); hmBox.style.width = 'auto';
    hmBox.onchange = change(function () { o.base = o.base || {}; if (hmBox.checked) o.base.hideOnMobile = true; else delete o.base.hideOnMobile; if (!Object.keys(o.base).length) delete o.base; });
    hmBox.title = 'Verbergen op een telefoon (smaller dan 600 px)';
    P.appendChild(row('Niet op mobiel', hmBox));
    if (o.type === 'group' && (o.children || []).some(function hid(c) { return (c.base && c.base.hideOnMobile) || (c.children || []).some(hid); }))
      P.appendChild(h('p', { class: 'note', text: 'Let op: binnenin staan onderdelen op "niet op mobiel". Dubbelklik om ze te vinden, of klik hier: ' }, [
        h('button', { text: 'Alles tonen op mobiel', onclick: function () { (function clr(l) { l.forEach(function (c) { if (c.base) { delete c.base.hideOnMobile; if (!Object.keys(c.base).length) delete c.base; } clr(c.children || []); }); })(o.children); dirty(); rebuild(); } })
      ]));

    if (o.type === 'text') {
      o.props = o.props || {};
      P.appendChild(h('h3', { text: 'Tekst · ' + lang.toUpperCase() }));
      var ta = h('textarea', {}); ta.value = S.tr(o.props.text);
      var raw = rawText(o.props.text);
      if (Array.isArray(raw) && raw.length > 1) P.appendChild(h('p', { class: 'note', text: 'Deze tekst heeft gemengde opmaak. Na wijzigen krijgt alles de opmaak van het eerste stuk.' }));
      ta.oninput = function () { setText(o.props, 'text', ta.value); dirty(); S.build(); };
      P.appendChild(ta);
      P.appendChild(h('h3', { text: 'Opmaak' }));
      P.appendChild(row('Stijl', styleSelect('text', o.props.style, change(function (v) { if (v) o.props.style = v; else delete o.props.style; }))));
      P.appendChild(row('Grootte', num(o.props.size || '', change(function (v) { if (v) o.props.size = v; else delete o.props.size; }))));
      var al = h('select'); ['', 'left', 'center', 'right'].forEach(function (a) { al.add(new Option(a || '— stijl —', a)); });
      al.value = o.props.align || ''; al.onchange = change(function () { if (al.value) o.props.align = al.value; else delete o.props.align; });
      P.appendChild(row('Uitlijnen', al));
      P.appendChild(colorRow('Kleur', o.props.color || '', change(function (v) { if (v) o.props.color = v; else delete o.props.color; })));
      var tg = h('select'); [['', 'Automatisch'], ['h1', 'Kop 1 (hoofdkop)'], ['h2', 'Kop 2'], ['h3', 'Kop 3'], ['p', 'Gewone tekst']].forEach(function (x) { tg.add(new Option(x[1], x[0])); });
      tg.value = o.props.tag || ''; tg.onchange = change(function () { if (tg.value) o.props.tag = tg.value; else delete o.props.tag; });
      tg.title = 'Voor zoekmachines: wat is dit voor tekst? Automatisch kiest de grootste teksten als kop.';
      P.appendChild(row('Voor Google', tg));
    }

    if (o.type === 'icon') {
      o.props = o.props || {};
      P.appendChild(h('h3', { text: 'Icoon' }));
      var isel = h('select');
      Object.keys((SITE.icons && SITE.icons.items) || {}).forEach(function (n) { var d = SITE.icons.items[n]; isel.add(new Option(n + (d.label ? ' – ' + S.tr(d.label) : ''), n)); });
      var sg = document.createElement('optgroup'); sg.label = 'Social';
      Object.keys(S.social || {}).forEach(function (k) { sg.appendChild(new Option(S.social[k].t, 'social:' + k)); }); if (sg.children.length) isel.appendChild(sg);
      isel.value = o.props.icon || ''; isel.onchange = change(function () { o.props.icon = isel.value; });
      P.appendChild(row('Icoon', isel));
      if (String(o.props.icon || '').indexOf('social:') === 0) {      // merklogo: alleen een kleur; de link zet je bij "Link"
        P.appendChild(colorRow('Kleur', o.props.color, change(function (v) { o.props.color = v; })));
        P.appendChild(h('p', { class: 'note', text: 'Zet de link naar je profiel hieronder bij Link (adres).' }));
      } else {
      P.appendChild(colorRow('Lijnkleur', o.props.color, change(function (v) { o.props.color = v; })));
      P.appendChild(colorRow('Vlakkleur', o.props.tint, change(function (v) { if (v) o.props.tint = v; else delete o.props.tint; })));
      P.appendChild(row('Vlak %', num(Math.round((o.props.tintAlpha === undefined ? 0.6 : o.props.tintAlpha) * 100), change(function (v) { o.props.tintAlpha = Math.max(0, Math.min(100, v)) / 100; }))));
      P.appendChild(row('Lijndikte', num(o.props.weight || (SITE.icons && SITE.icons.weight) || 2.25, change(function (v) { if (v) o.props.weight = v; else delete o.props.weight; }))));      }
    }
    if (o.type === 'surface') {
      o.surface = o.surface || {};
      var stId = (o.props && o.props.style) || o.surface.style;
      P.appendChild(h('h3', { text: 'Vlak' }));
      P.appendChild(row('Stijl', styleSelect('surface', stId, change(function (v) {
        o.props = o.props || {}; if (v) o.props.style = v; else delete o.props.style; delete o.surface.style;
      }))));
      var fill = (o.surface.fills && o.surface.fills[0]) || (stId && SITE.styles[stId] && SITE.styles[stId].props.fills && SITE.styles[stId].props.fills[0]) || { color: '' , alpha: 1 };
      P.appendChild(colorRow('Vulling', fill.color, change(function (v) {
        o.surface.fills = [{ type: 'solid', color: v, alpha: fill.alpha === undefined ? 1 : fill.alpha }];
      })));
      P.appendChild(row('Dekking', num(Math.round((fill.alpha === undefined ? 1 : fill.alpha) * 100), change(function (v) {
        var c = (o.surface.fills && o.surface.fills[0]) || { type: 'solid', color: fill.color };
        c.alpha = Math.max(0, Math.min(100, v)) / 100; o.surface.fills = [c]; fill = c;
      }))));
      var rad = (o.surface.shape && o.surface.shape.radius) ? o.surface.shape.radius[0] : 0;
      P.appendChild(row('Radius', num(rad, change(function (v) {
        o.surface.shape = o.surface.shape || { kind: 'rect' }; o.surface.shape.radius = [v, v, v, v];
      }))));
      var st = o.surface.stroke || {};
      P.appendChild(row('Lijn px', num(st.width || 0, change(function (v) {
        o.surface.stroke = o.surface.stroke || { color: '@ink', alpha: 1 }; o.surface.stroke.width = v;
        if (!v) delete o.surface.stroke;
      }))));
      if (o.surface.stroke) P.appendChild(colorRow('Lijnkleur', o.surface.stroke.color, change(function (v) { o.surface.stroke.color = v; })));
    }

    if (o.type === 'group') {
      P.appendChild(h('div', { class: 'row' }, [
        h('button', { text: 'Erin bewerken', title: 'of dubbelklik op het object', onclick: function () { enterGroup(o.uuid); } }),
        h('button', { text: 'Uit elkaar', title: 'Ctrl+Shift+G', onclick: function () { ungroupSel(); } })
      ]));
      P.appendChild(h('p', { class: 'note', text: 'Eén geheel: verplaatst en schaalt samen, ook op mobiel. Dubbelklik om een onderdeel te bewerken; Esc of klik ernaast = klaar.' }));
    }
    // ---------- product: een groep als productkaart (de agent kent dan het assortiment) ----------
    var PR = window.WPProducts;
    if (PR && o.type === 'group' && !f.inGroup && f.owner !== 'master') {
      var pd = o.base && o.base.product;
      P.appendChild(h('h3', { text: 'Product' }));
      var pc = h('input', { type: 'checkbox' }); pc.style.width = 'auto'; pc.checked = !!pd;
      pc.title = 'Deze groep is een productkaart: de agent kent hem en het bestelformulier haalt zijn keuzes eruit';
      pc.onchange = function () {
        o.base = o.base || {};
        if (pc.checked) {
          var R0 = PR.roleMap(o), nm = R0.name && R0.name.props ? PR.trVal(SITE, R0.name.props.text) : '';
          var id0 = PR.slug(nm || 'product'), ids = PR.list(SITE).map(function (x) { return x.id; });
          while (ids.indexOf(id0) >= 0) id0 += '-2';
          o.base.product = { id: id0 };
        } else delete o.base.product;
        PR.syncOptions(SITE); dirty(); S.build(); panel();
      };
      P.appendChild(row('Is product', pc));
      if (pd) {
        var pid = h('input', { type: 'text', value: pd.id || '' });
        pid.title = 'Korte naam zonder spaties; staat in de bestelling en in links (?krat=…)';
        pid.onchange = function () { var r = PR.update(SITE, { id: pd.id, newId: pid.value }); if (r.error) $('status').textContent = r.error; dirty(); S.build(); panel(); };
        P.appendChild(row('Id', pid));
        var pp = h('input', { type: 'text', value: pd.price != null ? PR.fmt(pd.price).replace('€ ', '') : '', placeholder: 'bv. 22,50' });
        pp.onchange = function () { PR.update(SITE, { id: pd.id, price: pp.value.trim() === '' ? null : pp.value }); dirty(); S.build(); panel(); };
        P.appendChild(row('Prijs €', pp));
        var pu = h('input', { type: 'text', value: pd.unit || '', placeholder: 'bv. per week (optioneel)' });
        pu.onchange = function () { PR.update(SITE, { id: pd.id, unit: pu.value.trim() }); dirty(); };
        P.appendChild(row('Eenheid', pu));
        var RM = PR.roleMap(o), have = PR.ROLES.filter(function (r) { return RM[r]; });
        P.appendChild(h('p', { class: 'note', text: 'Rollen: ' + (have.length ? have.map(function (r) { return PR.ROLE_NL[r]; }).join(', ') : 'nog geen')
          + '. Dubbelklik in de kaart en kies per onderdeel zijn rol (naam, prijs, beeld…). Daarna kan de agent producten toevoegen: "nieuw product Suus Sinaasappel, 22,50, 88 sinaasappels".' }));
      }
    }
    if (PR && f.inGroup) {
      var top = S.findObject(ENTER[0]);
      if (top && top.obj.base && top.obj.base.product) {
        var rs = h('select'); rs.add(new Option('— geen —', ''));
        PR.ROLES.forEach(function (r) { rs.add(new Option(PR.ROLE_NL[r], r)); });
        rs.value = (o.base && o.base.role) || '';
        rs.onchange = function () {
          o.base = o.base || {};
          if (rs.value) o.base.role = rs.value; else { delete o.base.role; if (!Object.keys(o.base).length) delete o.base; }
          PR.syncOptions(SITE); dirty(); S.build();
        };
        P.appendChild(h('h3', { text: 'Rol in product “' + top.obj.base.product.id + '”' }));
        P.appendChild(row('Rol', rs));
      }
    }
    if (f.inGroup) P.appendChild(h('p', { class: 'note', text: 'Onderdeel van een samengevoegd object. Esc of klik ernaast = klaar.' }));
    // ---------- link: waar gaat een klik op dit object heen (base.action) ----------
    if (o.type !== 'nav' && o.type !== 'form' && o.type !== 'language') {
      var act = (o.base && o.base.action) || null;
      P.appendChild(h('h3', { text: 'Link' }));
      var lt = h('select');
      [['', '— geen —'], ['page', 'Pagina'], ['url', 'Webadres of bestand'], ['mail', 'E-mail'], ['scroll', 'Naar object op deze pagina']]
        .forEach(function (x) { lt.add(new Option(x[1], x[0])); });
      lt.value = act ? act.type : '';
      var setAct = function (a) {
        o.base = o.base || {};
        if (a) o.base.action = a; else { delete o.base.action; if (!Object.keys(o.base).length) delete o.base; }
        dirty(); S.build();
      };
      lt.onchange = function () {
        var t = lt.value;
        if (!t) setAct(null);
        else if (t === 'page') setAct({ type: 'page', target: (act && act.type === 'page' && act.target) || SITE.site.homePage || (SITE.pages[0] && SITE.pages[0].id) });
        else setAct({ type: t, target: '' });
        panel();
      };
      P.appendChild(row('Soort', lt));
      if (act && act.type === 'page') {
        var pgSel = h('select');
        SITE.pages.forEach(function (p) { pgSel.add(new Option(S.tr(p.title) ? (S.tr(p.title).split('·')[0].trim() || p.id) + ' (' + (p.path || '/' + p.id) + ')' : p.id, p.id)); });
        pgSel.value = act.target; pgSel.onchange = function () { act.target = pgSel.value; dirty(); S.build(); };
        P.appendChild(row('Pagina', pgSel));
      } else if (act && (act.type === 'url' || act.type === 'mail')) {
        var ti = h('input', { type: 'text', value: act.target || '', placeholder: act.type === 'mail' ? 'naam@domein.nl' : 'https://… of media/bestand.pdf' });
        ti.onchange = function () {
          var v = ti.value.trim();
          if (act.type === 'mail') v = v.replace(/^mailto:/i, '');
          if (/^\s*javascript:/i.test(v)) { ti.value = act.target || ''; $('status').textContent = 'javascript:-links zijn niet toegestaan'; return; }
          act.target = v; dirty(); S.build();
        };
        P.appendChild(row(act.type === 'mail' ? 'Adres' : 'Adres', ti));
        if (act.type === 'url') {
          var nt = h('input', { type: 'checkbox' }); nt.style.width = 'auto'; nt.checked = act.open === '_blank';
          nt.onchange = function () { if (nt.checked) act.open = '_blank'; else delete act.open; dirty(); S.build(); };
          P.appendChild(row('Nieuw tabblad', nt));
          P.appendChild(h('p', { class: 'note', text: 'Een bestand (bv. een PDF) zet je in de map media/ van de site; het adres is dan media/naam.pdf.' }));
        }
      } else if (act && act.type === 'scroll') {
        var sc = h('select'); sc.add(new Option('— kies —', ''));
        (page.objects || []).forEach(function (x) {
          var nm = x.type === 'text' && x.props ? String(S.tr(x.props.text) || '').slice(0, 30) : '';
          sc.add(new Option((nm || x.type) + ' · y ' + Math.round(x.layout.y), x.uuid));
        });
        sc.value = act.target || ''; sc.onchange = function () { act.target = sc.value; dirty(); S.build(); };
        P.appendChild(row('Object', sc));
      }
      if (f.inGroup) P.appendChild(h('p', { class: 'note', text: 'Tip: een link op het hele samengevoegde object is meestal handiger (Esc, dan het object selecteren).' }));
    }
    if (o.type === 'language' || (o.type === 'nav' && o.props && o.props.languageSwitch)) {
      o.props = o.props || {};   // taalkiezer: vlaggetjes en uitklappen
      P.appendChild(h('h3', { text: 'Taalkiezer' }));
      [['flags', 'Vlaggetjes'], ['collapse', 'Uitklappen']].forEach(function (x) {
        var cb = h('input', { type: 'checkbox' }); cb.checked = !!o.props[x[0]]; cb.style.cssText = 'width:16px;min-width:16px;height:16px;flex:none;padding:0;margin:0';
        cb.onchange = change(function () { if (cb.checked) o.props[x[0]] = true; else delete o.props[x[0]]; });
        P.appendChild(row(x[1], h('label', { style: 'display:flex;gap:6px;align-items:center;cursor:pointer' }, [cb])));
      });
      P.appendChild(h('p', { class: 'note', text: 'Vlaggen bestaan voor nl, en, de, fr, es, it; andere talen houden de code. Uitklappen: klik op de kiezer toont de andere talen.' }));
    } else if (o.type === 'nav' || o.type === 'form') P.appendChild(h('p', { class: 'note', text: 'Module (' + o.type + '): plaats en maat hier; instellingen komen later.' }));

    // animatie
    P.appendChild(h('h3', { text: 'Animatie' }));
    var mo = (o.base && o.base.motion) || {};
    function setMotion(k, v) {
      o.base = o.base || {}; var m = Object.assign({}, o.base.motion || {});
      if (v === '' || v === 'none' || v === 0) delete m[k]; else m[k] = v;
      if (Object.keys(m).length) o.base.motion = m; else delete o.base.motion;
      dirty();
    }
    var inSel = h('select'); [['', '— geen —'], ['fade', 'Infaden'], ['up', 'Van onder'], ['down', 'Van boven'], ['left', 'Van links'], ['right', 'Van rechts'], ['zoom', 'Inzoomen']]
      .forEach(function (x) { inSel.add(new Option(x[1], x[0])); });
    inSel.value = mo.in || ''; inSel.onchange = function () { setMotion('in', inSel.value); panel(); };
    P.appendChild(row('Verschijnen', inSel));
    // wanneer: in gewone woorden i.p.v. milliseconden (opgeslagen blijft het ms)
    var dlSel = h('select'), DL = [[0, 'Meteen'], [150, 'Als 2e (0,15 s)'], [300, 'Als 3e (0,3 s)'], [450, 'Als 4e (0,45 s)'], [600, 'Als 5e (0,6 s)'], [1000, 'Na 1 seconde']];
    var dCur = mo.delay || 0;
    if (!DL.some(function (x) { return x[0] === dCur; })) DL.push([dCur, (dCur / 1000).toString().replace('.', ',') + ' s']);
    DL.sort(function (a, b) { return a[0] - b[0]; }).forEach(function (x) { dlSel.add(new Option(x[1], x[0])); });
    dlSel.value = String(dCur); dlSel.onchange = function () { setMotion('delay', +dlSel.value); };
    if (mo.in) P.appendChild(row('Wanneer', dlSel));
    var lpSel = h('select'); [['', '— geen —'], ['float', 'Zweven'], ['pulse', 'Pulseren'], ['spin', 'Draaien'], ['sway', 'Wiegen']]
      .forEach(function (x) { lpSel.add(new Option(x[1], x[0])); });
    lpSel.value = mo.loop || ''; lpSel.onchange = function () { setMotion('loop', lpSel.value); };
    P.appendChild(row('Doorlopend', lpSel));
    P.appendChild(h('p', { class: 'note', text: 'Animaties zie je in Voorbeeld (Ctrl+P), niet tijdens het bewerken.' }));

    P.appendChild(h('h3', { text: 'Object' }));
    P.appendChild(h('div', { class: 'row' }, [
      h('button', { text: 'Naar voren', onclick: function () { order(1); } }),
      h('button', { text: 'Naar achter', onclick: function () { order(-1); } })
    ]));
    P.appendChild(h('div', { class: 'row' }, [h('button', { text: '\uD83D\uDD12 Vergrendelen', title: 'Ctrl+L — daarna niet meer per ongeluk te pakken; klik het slotje om los te maken', onclick: lockSel })]));
    var nSel = selIds().length, inGroup = !!gidOf(o.uuid);
    if (nSel > 1 || inGroup) P.appendChild(h('div', { class: 'row' }, [
      h('button', { text: inGroup && nSel === members(o.uuid).length ? 'Groep opheffen' : 'Groeperen (' + nSel + ')',
        title: 'Ctrl+G groeperen · Ctrl+Shift+G opheffen',
        onclick: function () { if (inGroup && nSel === members(o.uuid).length) ungroupSel(); else groupSel(); } }),
      nSel > 1 ? h('button', { text: 'Samenvoegen', title: 'Ctrl+Shift+F — één object: één box, op mobiel één geheel; dubbelklik om erin te bewerken', onclick: freezeSel }) : null
    ]));
    if (inGroup) P.appendChild(h('p', { class: 'note', text: 'Hoort bij een groep. Klik = de hele groep, Alt+klik = alleen dit object.' }));
    P.appendChild(h('div', { class: 'row' }, [h('button', { class: 'danger', text: 'Verwijderen', onclick: del })]));
    P.appendChild(h('p', { class: 'note', text: 'uuid: ' + o.uuid }));
    [].forEach.call(P.querySelectorAll('button'), function (b) {
      if (b.closest('.wp-align')) return;                      // uitlijn-icoontjes hebben hun eigen opmaak
      if (!b.className) { b.style.cssText = 'font:inherit;color:var(--tx);background:var(--ui2);border:1px solid var(--line);border-radius:5px;padding:5px 8px;cursor:pointer;flex:1'; }
      else b.style.cssText += ';font:inherit;border-radius:5px;padding:5px 8px;flex:1';
    });
  }

  // tekst per taal schrijven: sleutel in translations, object per taal, of nieuw maken
  function rawText(v) {
    if (typeof v === 'string' && SITE.translations[v]) v = SITE.translations[v];
    if (v && typeof v === 'object' && !Array.isArray(v)) v = v[$('selLang').value];
    return v;
  }
  // opmaak (font, grootte, kleur) van de runs behouden bij het typen
  function keepRuns(map, lang, value) {
    var cur = map[lang], base = Array.isArray(cur) ? cur : (Array.isArray(map.nl) ? map.nl : null);
    if (!base || !base.length) return value;
    var r = {}; for (var k in base[0]) if (k !== 't') r[k] = base[0][k];
    r.t = value; return [r];
  }
  function setText(holder, field, value) {
    var lang = $('selLang').value, v = holder[field];
    if (typeof v === 'string' && SITE.translations[v]) { SITE.translations[v][lang] = keepRuns(SITE.translations[v], lang, value); return; }
    if (v && typeof v === 'object' && !Array.isArray(v)) { v[lang] = keepRuns(v, lang, value); return; }
    var key = uid('t'); SITE.translations[key] = {}; SITE.translations[key][lang] = value;
    if (typeof v === 'string') SITE.site.languages.forEach(function (l) { if (l !== lang) SITE.translations[key][l] = v; });
    holder[field] = key;
  }

  // ---------- opslaan ----------
  // de sleutel wordt in DEZE browser onthouden (eenmalig invullen); bij een verkeerde sleutel wordt hij vergeten en opnieuw gevraagd
  function getKey() { try { return localStorage.getItem('wpKey') || sessionStorage.getItem('wpKey') || ''; } catch (e) { return ''; } }
  function setKey(k) { try { if (k) localStorage.setItem('wpKey', k); else { localStorage.removeItem('wpKey'); sessionStorage.removeItem('wpKey'); } } catch (e) {} }
  // sleutel vragen (opslaan én agent); blijft bewaard zolang dit tabblad open is
  // vraagt de sleutel in de centrale melding; onOk/onCancel worden aangeroepen zodra er gekozen is
  var ASKING = null;
  function askKey(onOk, onCancel) {
    if (ASKING) { ASKING.push([onOk, onCancel]); return; }       // al open (bijv. opslaan én inzendingen tegelijk): wachten op hetzelfde antwoord
    ASKING = [[onOk, onCancel]]; setKey('');
    WPPrompt.ask('Vul de editor-sleutel in (editorKey uit .secrets/webplays.php). Deze browser onthoudt hem daarna.',
      { title: 'Editor-sleutel', password: true, placeholder: 'sleutel', ok: 'Doorgaan' },
      function (k) {
        var w = ASKING; ASKING = null; setKey(k);   // sleutel meteen tegen de server wisselen voor een sessietoken
        var done = function () { w.forEach(function (x) { if (x[0]) x[0](); }); };
        fetch(SITE.site.api + '?a=auth', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': k }, body: '{}' })
          .then(function (r) { return r.json().catch(function () { return {}; }); })
          .then(function (j) { if (j && j.ok && j.token) setKey(j.token); else if (j && j.error && j.error !== 'key') $('status').textContent = 'inloggen geweigerd: ' + j.error; done(); }, done);
      },
      function () { var w = ASKING; ASKING = null; w.forEach(function (x) { if (x[1]) x[1](); }); });
  }

  function save(retry) {
    if (!DIRTY && retry !== true) { $('status').textContent = 'niets te bewaren'; return; }
    $('status').textContent = 'opslaan…';
    fetch(SITE.site.api + '?a=save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Key': getKey() },
      body: JSON.stringify(SITE)
    }).then(function (r) { return r.json().then(function (j) { return { status: r.status, j: j }; }); })
      .then(function (res) {
        if (res.status === 401) {
          askKey(function () { save(true); }, function () { $('status').textContent = 'niet opgeslagen (geen sleutel)'; });
          return;
        }
        if (res.status === 409) { $('status').textContent = 'site.json is elders gewijzigd (v' + res.j.version + '). Herlaad.'; return; }
        if (res.status === 422 && res.j.error === 'brand') { $('status').textContent = 'niet opgeslagen: huisstijl — ' + (res.j.issues || []).slice(0, 3).join('; '); console.warn('Huisstijl:', res.j.issues); return; }
        if (res.status === 422 && res.j.error === 'site') { $('status').textContent = 'niet opgeslagen: ' + (res.j.issues || []).slice(0, 3).join('; '); console.warn('Controle bij opslaan:', res.j.issues); return; }
        if (!res.j.ok) throw new Error(res.j.error || res.status);
        SITE.meta.version = res.j.version; SITE.meta.updatedAt = res.j.updatedAt; SITE.meta.previous = res.j.previous;
        if (res.j.fontsLocal && res.j.fontsLocal.length) { SITE.site.fontsLocal = res.j.fontsLocal; SITE.site.fontsCss = res.j.fontsCss; }
        else { delete SITE.site.fontsLocal; delete SITE.site.fontsCss; }
        DIRTY = false; $('save').classList.add('clean');
        var bi = res.j.brandIssues || [];
        $('status').textContent = 'opgeslagen · versie ' + res.j.version + (bi.length ? ' · ' + bi.length + ' huisstijl-opmerking' + (bi.length > 1 ? 'en' : '') + ' (zie console)' : '');
        if (bi.length) console.warn('Huisstijl:', bi);
      })
      .catch(function (e) { $('status').textContent = 'opslaan mislukt: ' + e.message; });
  }
})();
