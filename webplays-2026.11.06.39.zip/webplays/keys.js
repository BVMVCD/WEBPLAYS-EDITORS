/*  WEBPLAYS editor — je sleutel (24 woorden, BIP39) en versleutelde inzendingen.

    Op de server staat ALLEEN de publieke sleutel (.secrets/webplays.php: 'boxPublicKey' => '…').
    Daarmee kan de server een inzending dichtmaken (sealed box), maar nooit meer openen.
    Openen kan alleen hier, in de editor, met je 24 woorden. Die blijven in het geheugen van dit tabblad:
    nooit opgeslagen, nooit verstuurd.

    Afleiding (vast, zodat dezelfde 24 woorden altijd dezelfde sleutel geven):
      seed    = PBKDF2-HMAC-SHA512(woorden, "mnemonic", 2048) → 64 bytes      (standaard BIP39, geen extra wachtwoord)
      boxSeed = BLAKE2b-256(seed, sleutel "webplays-box-key-v1")
      sleutelpaar = crypto_box_seed_keypair(boxSeed)   (X25519)

    Gebruik je NIET de zin van een echte wallet; maak hier een eigen zin.
*/
(function () {
  'use strict';
  var me = document.currentScript && document.currentScript.src;
  var BASE = me ? me.replace(/[^\/]*(\?.*)?$/, '') : '/webplays/';
  var SOD = null, WORDS = null, KP = null;           // KP = ontgrendeld sleutelpaar (alleen in geheugen)

  function load(src) { return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = BASE + src; s.onload = ok; s.onerror = function () { no(new Error(src + ' niet gevonden')); }; document.head.appendChild(s); }); }
  function ready() {
    if (SOD) return Promise.resolve(SOD);
    var p = window.sodium && window.sodium.ready ? Promise.resolve() : load('vendor/libsodium.js').then(function () { return load('vendor/libsodium-wrappers.js'); });
    return p.then(function () { return window.sodium.ready; }).then(function () { SOD = window.sodium; return SOD; });
  }
  function words() {
    if (WORDS) return Promise.resolve(WORDS);
    return fetch(BASE + 'vendor/bip39-english.json').then(function (r) { return r.json(); }).then(function (w) { if (w.length !== 2048) throw new Error('woordenlijst'); WORDS = w; return w; });
  }
  function bitsOf(bytes) { return [].map.call(bytes, function (b) { return ('00000000' + b.toString(2)).slice(-8); }).join(''); }
  function sha256(bytes) { return crypto.subtle.digest('SHA-256', bytes).then(function (h) { return new Uint8Array(h); }); }

  // nieuwe zin: 256 bits toeval + 8 bits controle = 24 woorden
  function newPhrase() {
    return words().then(function (W) {
      var ent = crypto.getRandomValues(new Uint8Array(32));
      return sha256(ent).then(function (h) {
        var bits = bitsOf(ent) + bitsOf(h).slice(0, 8), out = [];
        for (var i = 0; i < 24; i++) out.push(W[parseInt(bits.slice(i * 11, i * 11 + 11), 2)]);
        return out;
      });
    });
  }
  // plakken mag in elke vorm: onder elkaar, met nummers ("1. abandon"), komma's, enz.
  function norm(phrase) { return String(phrase || '').toLowerCase().normalize('NFKD').replace(/[^a-z]+/g, ' ').trim().split(' ').filter(Boolean); }
  // klopt de zin? (woorden uit de lijst + controlegetal)
  function check(phrase) {
    var ws = norm(phrase);
    return words().then(function (W) {
      if (ws.length !== 24) return { ok: false, error: 'Dat zijn ' + ws.length + ' woorden; het moeten er 24 zijn.' };
      var bad = ws.filter(function (w) { return W.indexOf(w) < 0; });
      if (bad.length) return { ok: false, error: 'Onbekend woord: ' + bad.slice(0, 3).join(', ') + '. Controleer de spelling.' };
      var bits = ws.map(function (w) { return ('00000000000' + W.indexOf(w).toString(2)).slice(-11); }).join('');
      var ent = new Uint8Array(32); for (var i = 0; i < 32; i++) ent[i] = parseInt(bits.slice(i * 8, i * 8 + 8), 2);
      return sha256(ent).then(function (h) { return bitsOf(h).slice(0, 8) === bits.slice(256) ? { ok: true, words: ws } : { ok: false, error: 'De woorden kloppen niet als geheel (controlegetal). Staat er een woord op de verkeerde plek?' }; });
    });
  }
  function keypair(ws) {
    var enc = new TextEncoder();
    return crypto.subtle.importKey('raw', enc.encode(ws.join(' ').normalize('NFKD')), 'PBKDF2', false, ['deriveBits'])
      .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-512', salt: enc.encode('mnemonic'), iterations: 2048 }, k, 512); })
      .then(function (seed) {
        return ready().then(function (S) {
          var boxSeed = S.crypto_generichash(32, new Uint8Array(seed), S.from_string('webplays-box-key-v1'));
          return S.crypto_box_seed_keypair(boxSeed);
        });
      });
  }
  function b64(bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); }
  function unb64(s) { var b = atob(String(s).replace(/-/g, '+').replace(/_/g, '/')), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }

  // inzending openen (geeft het data-object, of null als het niet lukt)
  function openBox(encB64) {
    if (!KP || !SOD) return null;
    try { return JSON.parse(SOD.to_string(SOD.crypto_box_seal_open(unb64(encB64), KP.publicKey, KP.privateKey))); } catch (e) { return null; }
  }

  // ---------- schermpjes (zelfde stijl als WPPrompt) ----------
  function modal(title) {
    var dim = document.createElement('div'); dim.className = 'wpp-dim wpk'; dim.style.zIndex = 30500;
    var box = document.createElement('div'); box.className = 'wpp-box wpk-box';
    box.innerHTML = '<div class="wpp-title"></div><div class="wpk-c"></div>';
    box.querySelector('.wpp-title').textContent = title;
    dim.appendChild(box); document.body.appendChild(dim);
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    function close() { document.removeEventListener('keydown', onKey, true); dim.remove(); }
    return { c: box.querySelector('.wpk-c'), close: close, title: function (t) { box.querySelector('.wpp-title').textContent = t; } };
  }
  function h(tag, cls, txt) { var d = document.createElement(tag); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  function btn(txt, cls, fn) { var b = h('button', cls || 'wpp-no', txt); b.onclick = fn; return b; }
  function row(btns) { var r = h('div', 'wpp-btns'); btns.forEach(function (b) { if (b) r.appendChild(b); }); return r; }

  // sleutel maken of herstellen → laat de regel zien voor .secrets
  function setup(serverPk, onDone) {
    var M = modal('Sleutel voor je inzendingen');
    function intro() {
      M.c.innerHTML = '';
      M.c.appendChild(h('p', 'wpk-p', 'Met deze sleutel worden inzendingen van formulieren versleuteld opgeslagen. De server kan ze dan wel bewaren, maar niet meer lezen. Alleen jij opent ze, hier in de editor, met 24 woorden.'));
      if (serverPk) M.c.appendChild(h('p', 'wpk-ok', '✓ Er staat al een publieke sleutel op de server. Een nieuwe maken betekent: inzendingen met de oude sleutel kun je alleen nog met de oude woorden openen.'));
      M.c.appendChild(h('p', 'wpk-warn', 'Belangrijk: gebruik niet de woorden van een echte wallet. Schrijf de woorden op papier. Kwijt = de versleutelde inzendingen zijn voor altijd onleesbaar (je site werkt gewoon door).'));
      M.c.appendChild(row([btn('Annuleren', 'wpp-no', M.close), btn('Ik heb al 24 woorden', 'wpp-no', restore), btn('Nieuwe sleutel maken', 'wpp-ok', create)]));
    }
    function create() {
      newPhrase().then(function (ws) {
        M.c.innerHTML = '';
        M.c.appendChild(h('p', 'wpk-p', 'Schrijf deze 24 woorden op, in deze volgorde. Niet fotograferen, niet in een mail of chat zetten.'));
        var g = h('ol', 'wpk-words'); ws.forEach(function (w) { g.appendChild(h('li', null, w)); }); M.c.appendChild(g);
        var cpw = btn('Kopieer als één regel', 'wpp-no', function () { try { navigator.clipboard.writeText(ws.join(' ')); cpw.textContent = 'Gekopieerd ✓ (plak in je wachtwoordbeheerder of .secrets)'; } catch (e) {} });
        M.c.appendChild(row([cpw]));
        var lab = h('label', 'wpk-chk'), cb = h('input'); cb.type = 'checkbox'; lab.appendChild(cb); lab.appendChild(document.createTextNode(' Ik heb de 24 woorden opgeschreven'));
        M.c.appendChild(lab);
        var go = btn('Verder', 'wpp-ok', function () { verify(ws); }); go.disabled = true; cb.onchange = function () { go.disabled = !cb.checked; };
        M.c.appendChild(row([btn('Annuleren', 'wpp-no', M.close), go]));
      }).catch(fail);
    }
    function verify(ws) {
      var pos = []; while (pos.length < 3) { var p = Math.floor(Math.random() * 24); if (pos.indexOf(p) < 0) pos.push(p); } pos.sort(function (a, b) { return a - b; });
      M.c.innerHTML = '';
      M.c.appendChild(h('p', 'wpk-p', 'Controle: typ deze drie woorden van je papier over.'));
      var ins = pos.map(function (p) { var r = h('label', 'wpk-in'); r.appendChild(h('span', null, 'Woord ' + (p + 1))); var i = h('input'); i.autocomplete = 'off'; i.spellcheck = false; r.appendChild(i); M.c.appendChild(r); return i; });
      var err = h('div', 'wpp-err'); M.c.appendChild(err);
      function ok() {
        if (ins.some(function (i, k) { return i.value.trim().toLowerCase() !== ws[pos[k]]; })) { err.textContent = 'Niet goed. Kijk nog eens op je papier.'; return; }
        done(ws);
      }
      ins.forEach(function (i) { i.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); }); });
      M.c.appendChild(row([btn('Terug', 'wpp-no', function () { M.c.innerHTML = ''; var g = h('ol', 'wpk-words'); ws.forEach(function (w) { g.appendChild(h('li', null, w)); }); M.c.appendChild(g); M.c.appendChild(row([btn('Verder', 'wpp-ok', function () { verify(ws); })])); }), btn('Controleren', 'wpp-ok', ok)]));
      setTimeout(function () { ins[0].focus(); }, 30);
    }
    function restore() {
      M.c.innerHTML = '';
      M.c.appendChild(h('p', 'wpk-p', 'Typ je 24 woorden, met spaties ertussen.'));
      var ta = h('textarea', 'wpk-ta'); ta.spellcheck = false; ta.autocomplete = 'off'; M.c.appendChild(ta);
      var err = h('div', 'wpp-err'); M.c.appendChild(err);
      M.c.appendChild(row([btn('Terug', 'wpp-no', intro), btn('Verder', 'wpp-ok', function () { check(ta.value).then(function (r) { if (!r.ok) { err.textContent = r.error; return; } done(r.words); }).catch(fail); })]));
      setTimeout(function () { ta.focus(); }, 30);
    }
    function done(ws) {
      keypair(ws).then(function (kp) {
        KP = kp; var pk = b64(kp.publicKey);
        M.title('Bijna klaar: publieke sleutel op de server');
        M.c.innerHTML = '';
        M.c.appendChild(h('p', 'wpk-p', 'Zet deze regel in .secrets/webplays.php, lokaal én online (in de lijst tussen [ en ]). Dit is alleen de publieke sleutel: die mag op de server staan.'));
        var line = "'boxPublicKey' => '" + pk + "',";
        var code = h('code', 'wpk-code', line); M.c.appendChild(code);
        var cp = btn('Kopiëren', 'wpp-no', function () { try { navigator.clipboard.writeText(line); cp.textContent = 'Gekopieerd ✓'; } catch (e) {} });
        if (serverPk && serverPk !== pk) M.c.appendChild(h('p', 'wpk-warn', 'Let op: dit is een andere sleutel dan die nu op de server staat.'));
        if (serverPk && serverPk === pk) M.c.appendChild(h('p', 'wpk-ok', '✓ Deze sleutel staat al op de server. Je inzendingen zijn nu ontgrendeld in dit tabblad.'));
        M.c.appendChild(h('p', 'wpk-p small', 'Liever niet typen (gemak, minder streng)? Zet dan in plaats van deze regel je woorden in .secrets: \'boxPhrase\' => \'woord1 woord2 … woord24\','));
        M.c.appendChild(h('p', 'wpk-p small', 'Daarna: Inzendingen opnieuw openen. Nieuwe inzendingen worden vanaf dan versleuteld; met "Nu versleutelen" doe je de oude.'));
        M.c.appendChild(row([cp, btn('Klaar', 'wpp-ok', function () { M.close(); if (onDone) onDone(pk); })]));
      }).catch(fail);
    }
    function fail(e) { M.c.appendChild(h('div', 'wpp-err', 'Mislukt: ' + e.message)); }
    intro();
  }

  // ontgrendelen om te lezen: 24 woorden → moet passen bij de publieke sleutel op de server
  function unlock(serverPk, onOk) {
    if (KP && SOD && b64(KP.publicKey) === serverPk) { onOk(); return; }
    var M = modal('Inzendingen ontgrendelen');
    M.c.appendChild(h('p', 'wpk-p', 'Typ je 24 woorden. Ze blijven alleen in dit tabblad (tot je het sluit) en worden nergens opgeslagen of verstuurd.'));
    var ta = h('textarea', 'wpk-ta'); ta.spellcheck = false; ta.autocomplete = 'off'; M.c.appendChild(ta);
    var err = h('div', 'wpp-err'); M.c.appendChild(err);
    function go() {
      err.textContent = 'even rekenen…';
      check(ta.value).then(function (r) {
        if (!r.ok) { err.textContent = r.error; return; }
        return keypair(r.words).then(function (kp) {
          if (b64(kp.publicKey) !== serverPk) { err.textContent = 'Deze woorden horen niet bij de sleutel op de server.'; return; }
          KP = kp; ta.value = ''; M.close(); onOk();
        });
      }).catch(function (e) { err.textContent = 'Mislukt: ' + e.message; });
    }
    ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
    M.c.appendChild(row([btn('Annuleren', 'wpp-no', M.close), btn('Ontgrendelen', 'wpp-ok', go)]));
    setTimeout(function () { ta.focus(); }, 30);
  }

  window.WPKeys = {
    setup: setup, unlock: unlock, open: openBox, ready: ready,
    unlocked: function (serverPk) { return !!(KP && SOD && b64(KP.publicKey) === serverPk); },
    lock: function () { KP = null; },
    _test: { newPhrase: newPhrase, check: check, keypair: keypair, b64: b64 }
  };
})();
