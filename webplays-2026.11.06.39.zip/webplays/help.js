/*  WEBPLAYS editor — Hulp: korte uitleg voor wie in de editor iets niet weet.
    Knop "? Hulp" in de bovenbalk (of F1). Alleen tekst; raakt de site niet aan.
*/
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  if (!$('bar')) return;

  var TOPICS = [
    ['Aan de slag', '<p>Je ziet de pagina zoals bezoekers hem zien. Klik op iets om het te selecteren; rechts verschijnen dan de instellingen.</p>' +
      '<ul><li><b>Tekst aanpassen:</b> dubbelklik op de tekst en typ.</li><li><b>Verplaatsen:</b> sleep het object.</li><li><b>Opslaan:</b> knop <b>Opslaan</b> rechtsboven (of Ctrl+S). Zolang je niet opslaat, staat er niets online.</li><li><b>Fout gemaakt?</b> Ctrl+Z maakt het ongedaan.</li></ul>'],
    ['De balk bovenin', '<ul><li><b>Paginaboom</b> (knop naast de paginakeuze): de hele site als boom; hier orden, maak en dupliceer je pagina\'s.</li><li><b>Bibliotheek</b>: kleuren, stijlen, typografie en beeld van deze site.</li><li><b>Zon-knop</b>: wisselt de editor tussen dag en nacht (alleen voor jou, niet voor de site).</li><li><b>Raster-knop</b>: grid en uitlijnen aan of uit.</li><li><b>Pijltjes ↶ ↷</b>: ongedaan maken en opnieuw.</li></ul>'],
    ['Tekst en talen', '<p>Kies bovenin de <b>taal</b> waarin je wilt schrijven. Elke taal heeft zijn eigen tekst: pas je het Nederlands aan, dan blijft het Engels staan.</p>' +
      '<ul><li>Dubbelklik op een tekst om hem te wijzigen.</li><li>Wissel van taal en controleer of de tekst daar ook klopt.</li><li>Nieuwe tekst: <b>+ Tekst</b>.</li></ul>'],
    ['Toevoegen en verwijderen', '<ul><li><b>+ Tekst</b>, <b>+ Icoon</b>, <b>+ Vlak</b> voegen een nieuw onderdeel toe, op de plek die je nu ziet.</li><li>Selecteer een onderdeel en druk op <b>Delete</b> om het te verwijderen.</li><li>Per ongeluk weg? <b>Ctrl+Z</b>.</li></ul>'],
    ['Verplaatsen en grootte', '<ul><li>Sleep een onderdeel om het te verplaatsen. Het klikt vanzelf uit aan andere onderdelen. Wil je helemaal vrij plaatsen: houd <b>Ctrl</b> ingedrukt tijdens slepen.</li><li>Met de <b>grepen</b> rond het onderdeel maak je het groter of kleiner.</li><li><b>Pijltjestoetsen</b> verschuiven stapje voor stapje; met <b>Shift</b> in grotere stappen.</li><li><b>Draaien:</b> sleep aan de donkerblauwe rand van de cirkel in het midden. Met <b>Shift</b> draai je in stappen van 15°; <b>dubbelklik</b> op die cirkel zet het terug op 0°. Zolang een onderdeel gedraaid is, zijn de randgrepen uit: zet het eerst terug op 0° om de grootte te wijzigen.</li><li><b>Ruimte maken:</b> sleep aan de greep <b>⇣</b> (of Shift + de onderste greep). Alles eronder schuift mee.</li></ul>'],
    ['Meerdere onderdelen', '<ul><li><b>Shift + klik</b> voegt toe aan wat je geselecteerd hebt.</li><li>Sleep een <b>kader</b> over een lege plek (of houd Alt ingedrukt) om meerdere onderdelen te pakken.</li><li><b>Ctrl+A</b> selecteert alles op de pagina.</li><li><b>Ctrl+G</b> maakt er een groep van, <b>Ctrl+Shift+G</b> maakt de groep weer los.</li><li><b>Ctrl+L</b> zet vast, zodat je het niet per ongeluk verschuift. <b>Ctrl+Shift+L</b> maakt alles weer los.</li></ul>'],
    ['Zoekmachines en sitemap', '<p>Onder <b>Pagina &amp; kleuren</b> (klik eerst op een lege plek) staat per pagina een vinkje <b>niet in zoekmachines en sitemap</b>. Gebruik dat voor pagina\'s die niet gevonden hoeven te worden, zoals een bedankpagina.</p><ul><li>Vul bij <b>Site-adres</b> het adres van de site in (bijvoorbeeld https://www.voorbeeld.nl).</li><li>Elke keer dat je opslaat, maakt WEBPLAYS automatisch een <b>sitemap.xml</b> en <b>robots.txt</b> met alle pagina\'s en talen.</li><li>Lokaal (op je eigen computer) wordt er geen sitemap gemaakt; die komt pas als je online opslaat of het site-adres invult.</li><li><b>Delen:</b> onder <b>Delen</b> kies je een plaatje (aanbevolen 1200 × 630 px) voor het voorbeeld in WhatsApp en op sociale media, per pagina of voor de hele site. Titel en omschrijving komen van de pagina zelf.</li><li>Een site die nog nooit met deze versie is opgeslagen? Klik op <b>Sitemap nu maken</b>.</li></ul>'],
    ['Bedrijfsgegevens voor Google', '<p>Zoekmachines krijgen vanzelf gegevens over je site, de pagina\'s (broodkruimels) en je producten met prijs. Wil je ook je logo, telefoonnummer, e-mail of social media meegeven? Vraag de agent: <i>"zet bij bedrijfsgegevens mijn telefoonnummer en Instagram"</i>.</p>'],
    ['Inloggen met een persoonlijke sleutel', '<p>Je kunt per persoon een eigen editor-sleutel krijgen. De beheerder geeft hem uit (en trekt hem in); de site controleert elke inlog tegen een ondertekende lijst. Na het inloggen onthoudt deze browser een tijdelijke sessie (12 uur), niet je sleutel zelf. Meldingen: <b>Onjuiste of ingetrokken sleutel</b> (vraag een nieuwe), <b>Te veel foute pogingen</b> (wacht een kwartier), <b>Deze versie is te oud</b> (motor bijwerken), <b>Editor staat op slot</b>.</p>'],
    ['Social media-iconen', '<p>Klik op <b>+ Icoon</b>, kies in de keuzelijst onder <b>Social</b> het netwerk (LinkedIn, Instagram, Facebook, X, YouTube, TikTok, WhatsApp …) en kies een kleur. Zet de link naar je profiel bij <b>Link</b> (adres). Wil je ze in de footer op elke pagina? Zet ze met <b>→ naar footer</b> in de footer. De agent kan het ook: geef hem de adressen van je profielen.</p>'],
    ['Koppen voor Google', '<p>Zoekmachines lezen de tekst van je pagina als gewone HTML. De grootste teksten worden vanzelf <b>kop 1, 2 en 3</b>. Wil je het zelf bepalen: selecteer een tekst en kies rechts bij <b>Voor Google</b> de koptype (of <b>Gewone tekst</b>). Gebruik per pagina één hoofdkop. Beelden krijgen een omschrijving via het veld <b>alt</b>; zonder omschrijving worden ze als versiering gezien en overgeslagen.</p>'],
    ['Favicon (tabblad-icoon)', '<p>Het kleine icoontje in het tabblad van de browser. Je stelt het in via <b>Pagina &amp; kleuren</b>, onder <b>Favicon</b> (klik eerst op een lege plek, zodat er niets geselecteerd is).</p><ul><li><b>Bestand:</b> upload een <b>SVG</b> (scherp op elke grootte) of kies een bestand dat al in de media staat.</li><li><b>Reserve:</b> een PNG voor Safari, dat geen SVG-icoon toont.</li><li><b>Animatie:</b> draaien, pulseren of eigen beeldjes. Safari en bezoekers die beweging verminderd hebben, zien het stilstaande icoon.</li></ul>'],
    ['Pagina\'s en kleuren', '<ul><li>Wissel van pagina met de keuzelijst linksboven.</li><li><b>Pagina &amp; kleuren</b> opent de instellingen van de pagina en het kleurenpalet.</li><li>Pas kleuren bij voorkeur aan in het palet: dan verandert het overal waar die kleur of stijl wordt gebruikt.</li></ul>'],
    ['Telefoon en tablet', '<p>Met <b>Desktop / Tablet / Mobiel</b> bekijk je de pagina op een andere schermbreedte. Controleer altijd even of het op de telefoon goed staat.</p>'],
    ['Voorbeeld en opslaan', '<ul><li><b>Voorbeeld</b> (of Ctrl+P) toont de site precies zoals bezoekers hem zien, zonder grepen. Ga terug met <b>Bewerken</b>.</li><li><b>Opslaan</b> zet je wijzigingen in de site. De knop kleurt als er iets is dat nog niet is opgeslagen.</li><li>Bij elke keer opslaan wordt de vorige versie bewaard; vraag de beheerder als je een oude versie terug wilt.</li><li><b>Bekijk site ↗</b> opent de echte site in een nieuw tabblad.</li></ul>'],
    ['Agent (AI-hulp)', '<p>De knop <b>✦ Agent</b> (of Ctrl+K) opent een assistent. Beschrijf in gewone woorden wat je wilt, bijvoorbeeld een tekst herschrijven of iets toevoegen. Wijzigingen van de agent zie je eerst en keur je goed of wijs je af.</p>'],
    ['Inzendingen', '<p>Wat bezoekers via formulieren op de site versturen, vind je onder <b>Inzendingen</b>. Het getal ernaast zijn de nog ongelezen berichten.</p>'],
    ['Sneltoetsen', '<table class="hp-keys"><tr><td>Ctrl+S</td><td>Opslaan</td></tr><tr><td>Ctrl+Z / Ctrl+Shift+Z</td><td>Ongedaan maken / opnieuw</td></tr><tr><td>Ctrl+A</td><td>Alles selecteren</td></tr><tr><td>Ctrl+G / Ctrl+Shift+G</td><td>Groeperen / losmaken</td></tr><tr><td>Ctrl+L / Ctrl+Shift+L</td><td>Vastzetten / alles losmaken</td></tr><tr><td>Ctrl+P</td><td>Voorbeeld aan of uit</td></tr><tr><td>Ctrl+K</td><td>Agent</td></tr><tr><td>Delete</td><td>Verwijderen</td></tr><tr><td>Esc</td><td>Selectie opheffen</td></tr><tr><td>F1</td><td>Deze hulp</td></tr></table>'],
    ['Het lukt niet', '<ul><li><b>"niet opgeslagen: …" onderin of bovenin:</b> lees de melding; die zegt wat er niet klopt. Er is dan niets veranderd in de site.</li><li><b>Je wordt weer om een sleutel gevraagd:</b> de sleutel is gewijzigd of gewist. Vraag de beheerder om de nieuwe.</li><li><b>Je ziet geen wijziging op de site:</b> sla je wel op? En ververs de site met Ctrl+F5.</li><li><b>Iets raars na een grote wijziging:</b> Ctrl+Z, of vraag de beheerder om de vorige versie.</li></ul>']
  ];

  var st = document.createElement('style');
  st.textContent =
    '#hpBtn{margin-left:4px}' +
    '#hp{position:fixed;inset:0;z-index:2147483000;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.55);padding:16px}' +
    '#hp.open{display:flex}' +
    '.hp-box{width:min(820px,100%);max-height:min(560px,calc(100vh - 32px));display:flex;flex-direction:column;background:var(--ui,#1d2330);color:var(--tx,#e8ebf1);border:1px solid var(--line,#3a4356);border-radius:12px;box-shadow:0 12px 50px rgba(0,0,0,.5);overflow:hidden;font:14px/1.5 Inter,system-ui,sans-serif}' +
    '.hp-head{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--line,#3a4356)}' +
    '.hp-head b{font-size:15px}.hp-head .sp{flex:1}' +
    '.hp-head button{background:transparent;border:0;color:var(--mut,#9aa3b5);font-size:18px;cursor:pointer}.hp-head button:hover{color:var(--tx,#e8ebf1)}' +
    '.hp-body{display:flex;min-height:0;flex:1}' +
    '.hp-nav{width:210px;flex:none;overflow:auto;padding:8px;border-right:1px solid var(--line,#3a4356);display:flex;flex-direction:column;gap:2px}' +
    '.hp-nav button{text-align:left;background:transparent;border:0;color:var(--mut,#9aa3b5);padding:7px 10px;border-radius:7px;font:inherit;cursor:pointer}' +
    '.hp-nav button:hover{background:var(--ui2,#2a3242);color:var(--tx,#e8ebf1)}.hp-nav button.on{background:var(--acc,#00A4E4);color:#fff}' +
    '.hp-main{flex:1;overflow:auto;padding:16px 20px}.hp-main h2{margin:0 0 8px;font-size:17px}.hp-main p,.hp-main ul{margin:0 0 10px}.hp-main li{margin:4px 0}' +
    '.hp-keys{border-collapse:collapse;width:100%}.hp-keys td{padding:6px 8px;border-bottom:1px solid var(--line,#3a4356)}.hp-keys td:first-child{white-space:nowrap;font-weight:600;width:210px}' +
    '@media (max-width:640px){.hp-body{flex-direction:column}.hp-nav{width:auto;flex-direction:row;overflow:auto;border-right:0;border-bottom:1px solid var(--line,#3a4356)}.hp-nav button{white-space:nowrap}}';
  document.head.appendChild(st);

  var btn = document.createElement('button');
  btn.id = 'hpBtn'; btn.title = 'Hulp (F1)'; btn.textContent = '? Hulp';
  $('bar').insertBefore(btn, $('view'));

  var ov = document.createElement('div'); ov.id = 'hp';
  ov.innerHTML = '<div class="hp-box" role="dialog" aria-label="Hulp"><div class="hp-head"><b>Hulp bij de editor</b><span class="sp"></span><button id="hpX" title="Sluiten (Esc)">✕</button></div>' +
    '<div class="hp-body"><div class="hp-nav" id="hpNav"></div><div class="hp-main" id="hpMain"></div></div></div>';
  document.body.appendChild(ov);

  var nav = $('hpNav'), main = $('hpMain'), btns = [];
  function show(i) {
    btns.forEach(function (b, j) { b.classList.toggle('on', j === i); });
    main.innerHTML = '<h2></h2>' + TOPICS[i][1];
    main.firstChild.textContent = TOPICS[i][0];
    main.scrollTop = 0;
  }
  TOPICS.forEach(function (t, i) {
    var b = document.createElement('button'); b.textContent = t[0]; b.onclick = function () { show(i); };
    nav.appendChild(b); btns.push(b);
  });
  function open() { ov.classList.add('open'); show(0); }
  function close() { ov.classList.remove('open'); }
  btn.onclick = open; $('hpX').onclick = close;
  ov.addEventListener('mousedown', function (e) { if (e.target === ov) close(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'F1') { e.preventDefault(); if (ov.classList.contains('open')) close(); else open(); }
    else if (e.key === 'Escape' && ov.classList.contains('open')) { e.stopPropagation(); close(); }
  }, true);
})();
