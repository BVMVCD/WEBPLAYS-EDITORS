/*  WEBPLAYS editor — Pagina's: de site als boom (zoals Manage › Pages in de originele WEBPLAYS).
    De pagina's zelf blijven plat (hun adres verandert niet door de boom); de boom staat in site.json als
    `tree` en is voor overzicht en ordening. Ordeningsknooppunten (geen echte pagina) mogen ook.

      tree: [ { "p": "home" }, { "n": "n-ab12cd", "name": "Over ons", "kids": [ { "p": "team" } ] } ]

    Alles gaat via de editor (E.changed), dus Ctrl+Z en Opslaan werken zoals overal.
*/
(function () {
  'use strict';
  var E = window.WPEditor, S = window.WPSpeler, $ = function (id) { return document.getElementById(id); };
  if (!E || !S || !$('bar') || !window.WPLibs) return;

  var CW = 210, CH = 40, PAD = 28;
  var ST = { orient: 'h', scale: 1, filter: '', collapsed: {}, sel: {}, anchor: null, drag: null };
  try { ST.orient = localStorage.getItem('wpPtOrient') === 'v' ? 'v' : 'h'; } catch (e) {}
  try { ST.collapsed = JSON.parse(localStorage.getItem('wpPtCollapsed') || '{}') || {}; } catch (e) {}
  try { var sc = parseFloat(localStorage.getItem('wpPtScale')); if (sc >= 0.3 && sc <= 2.2) ST.scale = sc; } catch (e) {}
  function keep() { try { localStorage.setItem('wpPtOrient', ST.orient); localStorage.setItem('wpPtCollapsed', JSON.stringify(ST.collapsed)); localStorage.setItem('wpPtScale', String(ST.scale)); } catch (e) {} }

  function site() { return E.site(); }
  function el(tag, cls, txt) { var d = document.createElement(tag); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  function pageById(id) { return site().pages.filter(function (p) { return p.id === id; })[0]; }
  function title(p) { var t = S.tr(p.title); return t || p.id; }
  function short(p) { var t = title(p).split(/\s+[·|–—-]\s+/)[0]; return t || p.id; }   // "Hoe het werkt · MakePeas" → "Hoe het werkt"
  function slug(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'pagina'; }

  // ---------- de boom (site.tree) ----------
  // sleutel per item: 'p:<pagina-id>' of 'n:<knooppunt-id>'
  function keyOf(it) { return it.p ? 'p:' + it.p : 'n:' + it.n; }
  function tree() {
    var s = site(); if (!Array.isArray(s.tree)) s.tree = [];
    // opschonen: pagina's die niet meer bestaan eruit, dubbele eruit
    var seen = {};
    (function clean(list) {
      for (var i = list.length - 1; i >= 0; i--) {
        var it = list[i], k = keyOf(it);
        if ((it.p && !pageById(it.p)) || seen[k]) { list.splice.apply(list, [i, 1].concat(it.kids || [])); continue; }
        seen[k] = 1; if (it.kids) { clean(it.kids); if (!it.kids.length) delete it.kids; }
      }
    })(s.tree);
    return s.tree;
  }
  // waar staat een item? → { list, idx, item, parentKey }
  function locate(key, list, parentKey) {
    list = list || tree();
    for (var i = 0; i < list.length; i++) {
      if (keyOf(list[i]) === key) return { list: list, idx: i, item: list[i], parentKey: parentKey || null };
      if (list[i].kids) { var r = locate(key, list[i].kids, keyOf(list[i])); if (r) return r; }
    }
    return null;
  }
  function itemFor(key) {
    var f = locate(key); if (f) return f.item;
    return key.slice(0, 2) === 'p:' ? { p: key.slice(2) } : null;     // losse pagina: nog niet in de boom
  }
  function takeOut(key) { var f = locate(key); if (!f) return itemFor(key); f.list.splice(f.idx, 1); if (f.parentKey) { var pa = locate(f.parentKey); if (pa && pa.item.kids && !pa.item.kids.length) delete pa.item.kids; } return f.item; }
  function isInside(key, ancestor) {   // zit key in (of is) ancestor?
    if (key === ancestor) return true;
    var a = locate(ancestor); if (!a || !a.item.kids) return false;
    var hit = false; (function walk(l) { l.forEach(function (x) { if (keyOf(x) === key) hit = true; if (x.kids) walk(x.kids); }); })(a.item.kids);
    return hit;
  }
  // verplaatsen: zone 'into' = eronder, 'before'/'after' = ernaast
  function move(keys, target, zone) {
    if (keys.some(function (k) { return isInside(target, k); })) return false;    // niet in zichzelf
    var items = keys.map(takeOut).filter(Boolean);
    if (zone === 'into') {
      var t = locate(target); if (!t) { t = { item: { p: target.slice(2) } }; tree().push(t.item); }
      t.item.kids = (t.item.kids || []).concat(items); delete ST.collapsed[target];
    } else {
      var tt = locate(target);
      if (!tt) { tree().push({ p: target.slice(2) }); tt = locate(target); }
      tt.list.splice.apply(tt.list, [tt.idx + (zone === 'after' ? 1 : 0), 0].concat(items));
    }
    return true;
  }

  // ---------- acties ----------
  function changed(msg) { E.changed(msg); E.refreshPages(); render(); }
  function newPage(parentKey) {
    WPPrompt.ask('Naam van de nieuwe pagina' + (parentKey ? ' (onder "' + label(parentKey) + '")' : '') + '.', { title: 'Nieuwe pagina', placeholder: 'bijv. Contact', ok: 'Maken' }, function (name) {
      var s = site(), base = slug(name), id = base, i = 2;
      while (pageById(id)) id = base + '-' + i++;
      var cur = pageById(E.page()) || s.pages[0], ttl = {}, desc = {};
      s.site.languages.forEach(function (l) { ttl[l] = name; desc[l] = ''; });
      s.pages.push({ id: id, path: '/' + id, master: cur ? cur.master : undefined, height: 1000, title: ttl, description: desc, objects: [] });
      var it = { p: id };
      if (parentKey) { var t = locate(parentKey) || (tree().push({ p: parentKey.slice(2) }), locate(parentKey)); t.item.kids = (t.item.kids || []).concat([it]); delete ST.collapsed[parentKey]; }
      else tree().push(it);
      ST.sel = {}; ST.sel['p:' + id] = 1;
      changed('nieuwe pagina "' + name + '" (' + '/' + id + ') — zet hem nog in het menu als dat moet');
    });
  }
  function newNode(parentKey) {
    WPPrompt.ask('Naam van het knooppunt. Dat is geen echte pagina, alleen een map om pagina\'s onder te ordenen.', { title: 'Nieuw knooppunt', placeholder: 'bijv. Producten', ok: 'Maken' }, function (name) {
      var it = { n: 'n-' + Math.random().toString(36).slice(2, 8), name: name };
      if (parentKey) { var t = locate(parentKey) || (tree().push({ p: parentKey.slice(2) }), locate(parentKey)); t.item.kids = (t.item.kids || []).concat([it]); delete ST.collapsed[parentKey]; }
      else tree().push(it);
      ST.sel = {}; ST.sel[keyOf(it)] = 1; changed('knooppunt "' + name + '"');
    });
  }
  function label(key) { var it = itemFor(key); if (!it) return ''; if (it.n) return it.name; var p = pageById(it.p); return p ? short(p) : it.p; }
  function rename(key) {
    var it = itemFor(key);
    if (it.n) { WPPrompt.ask('Nieuwe naam voor het knooppunt.', { title: 'Hernoemen', value: it.name, ok: 'Opslaan' }, function (v) { locate(key).item.name = v; changed('knooppunt hernoemd'); }); return; }
    var p = pageById(it.p), lang = E.lang();
    WPPrompt.ask('Nieuwe naam voor deze pagina (' + lang.toUpperCase() + ').' + (p.path !== '/' ? '\nHet adres verandert mee (bijv. /contact); het oude adres werkt daarna niet meer.' : ''), { title: 'Pagina hernoemen', value: title(p), ok: 'Opslaan' }, function (v) {
      p.title = typeof p.title === 'object' && p.title ? p.title : {}; p.title[lang] = v;
      if (p.path !== '/' && lang === site().site.defaultLanguage) {
        var np = '/' + slug(v), i = 2, b = np;
        while (site().pages.some(function (x) { return x !== p && x.path === np; })) np = b + '-' + i++;
        if (p.path && p.path !== np && p.path !== '/') { p.aliases = (p.aliases || []).filter(function (x) { return x !== p.path && x !== np; }); p.aliases.push(p.path); if (p.aliases.length > 20) p.aliases.shift(); }   // het oude adres blijft doorverwijzen (301 via de voordeur, in de speler zonder)
        else if (p.aliases) p.aliases = p.aliases.filter(function (x) { return x !== np; });
        p.path = np;
      }
      changed('pagina hernoemd → ' + v + ' (' + p.path + ')');
    });
  }
  // kopie: nieuwe uuids én eigen teksten (anders verandert de tekst op beide pagina's tegelijk)
  function duplicate(key) {
    var p = pageById(itemFor(key).p); if (!p) return;
    WPPrompt.ask('Naam voor de kopie van "' + title(p) + '".', { title: 'Pagina dupliceren', value: title(p) + ' kopie', ok: 'Dupliceren' }, function (name) {
      var s = site(), base = slug(name), id = base, i = 2;
      while (pageById(id)) id = base + '-' + i++;
      var c = JSON.parse(JSON.stringify(p)), tr = s.translations || (s.translations = {}), rnd = function () { return Math.random().toString(36).slice(2, 8); };
      delete c.aliases; c.id = id; c.path = '/' + id; c.title = {}; s.site.languages.forEach(function (l) { c.title[l] = name; });
      var gids = {};
      (function walk(list) {
        list.forEach(function (o) {
          o.uuid = o.uuid.replace(/-[^-]*$/, '') + '-' + rnd();
          if (o.base && o.base.gid) o.base.gid = gids[o.base.gid] || (gids[o.base.gid] = 'g-' + rnd());
          if (o.base && o.base.gidStack) o.base.gidStack = o.base.gidStack.map(function (g) { return gids[g] || (gids[g] = 'g-' + rnd()); });
          (function txt(obj) {
            Object.keys(obj || {}).forEach(function (k) {
              var v = obj[k];
              if (typeof v === 'string' && tr[v] && k !== 'style' && k !== 'font') { var nk = v + '-' + rnd(); tr[nk] = JSON.parse(JSON.stringify(tr[v])); obj[k] = nk; }
              else if (v && typeof v === 'object' && k !== 'children') txt(v);
            });
          })(o.props);
          if (o.children) walk(o.children);
        });
      })(c.objects || []);
      s.pages.splice(s.pages.indexOf(p) + 1, 0, c);
      var f = locate(key), it = { p: id };
      if (f) f.list.splice(f.idx + 1, 0, it); else tree().push(it);
      ST.sel = {}; ST.sel['p:' + id] = 1; changed('pagina gedupliceerd → ' + name);
    }, null);
  }
  function usesOf(id) {   // knoppen, menu-items en links die naar deze pagina gaan
    var n = 0, s = site();
    function chk(a) { if (a && a.type === 'page' && a.target === id) n++; }
    function walk(l) { l.forEach(function (o) { chk(o.base && o.base.action); ((o.props && o.props.items) || []).forEach(function (it) { chk(it.action); (function sub(xs) { (xs || []).forEach(function (x) { chk(x.action); sub(x.items); }); })(it.items); }); if (o.children) walk(o.children); }); }
    s.pages.forEach(function (p) { walk(p.objects || []); }); Object.keys(s.masters || {}).forEach(function (m) { walk(s.masters[m].objects || []); });
    return n;
  }
  function remove(keys) {
    var s = site(), pages = keys.filter(function (k) { return k.slice(0, 2) === 'p:'; }), nodes = keys.filter(function (k) { return k.slice(0, 2) === 'n:'; });
    if (pages.length >= s.pages.length) { WPPrompt.notice('De laatste pagina kan niet weg.'); return; }
    var home = s.site.homePage || s.pages[0].id;
    if (pages.indexOf('p:' + home) >= 0) { WPPrompt.notice('De startpagina kan niet weg. Maak eerst een andere pagina de startpagina.'); return; }
    var refs = pages.reduce(function (t, k) { return t + usesOf(k.slice(2)); }, 0);
    var names = keys.slice(0, 6).map(function (k) { return '• ' + label(k) + (k.slice(0, 2) === 'n:' ? ' (knooppunt)' : ''); }).join('\n') + (keys.length > 6 ? '\n… en ' + (keys.length - 6) + ' meer' : '');
    WPPrompt.confirm((pages.length ? pages.length + ' pagina' + (pages.length > 1 ? '\'s' : '') + ' verwijderen, met alles erop' : '') + (pages.length && nodes.length ? ' en ' : '') +
      (nodes.length ? nodes.length + ' knooppunt' + (nodes.length > 1 ? 'en' : '') : '') + '?\n\n' + names +
      '\n\nWat eronder hangt blijft bestaan en schuift een niveau omhoog.' + (refs ? '\nLet op: ' + refs + ' knop(pen) of menu-item(s) verwijzen hiernaar.' : '') + '\nOngedaan maken kan met Ctrl+Z.',
      { ok: 'Verwijderen', danger: true }, function () {
        keys.forEach(function (k) {
          var f = locate(k); if (f) f.list.splice.apply(f.list, [f.idx, 1].concat(f.item.kids || []));
          if (k.slice(0, 2) === 'p:') { var p = pageById(k.slice(2)); if (p) s.pages.splice(s.pages.indexOf(p), 1); }
        });
        ST.sel = {};
        if (!pageById(E.page())) E.goPage(home);
        changed(keys.length + ' verwijderd');
      });
  }
  function openPage(key) { var it = itemFor(key); if (it && it.p) { E.goPage(it.p); render(); } }

  // ---------- opmaak (zoals WPEPageTree: kaartjes, lijnen, losse pagina's als raster eronder) ----------
  function visible() {
    var f = ST.filter.trim().toLowerCase(); if (!f) return null;
    var vis = {};
    function walk(list, path) { list.forEach(function (it) { var k = keyOf(it), p2 = path.concat([k]); if (label(k).toLowerCase().indexOf(f) >= 0 || (it.p || '').indexOf(f) >= 0) p2.forEach(function (x) { vis[x] = 1; }); if (it.kids) walk(it.kids, p2); }); }
    walk(tree(), []); looseKeys().forEach(function (k) { if (label(k).toLowerCase().indexOf(f) >= 0) vis[k] = 1; });
    return vis;
  }
  function looseKeys() {
    var inTree = {}; (function walk(l) { l.forEach(function (x) { inTree[keyOf(x)] = 1; if (x.kids) walk(x.kids); }); })(tree());
    return site().pages.filter(function (p) { return !inTree['p:' + p.id]; }).map(function (p) { return 'p:' + p.id; });
  }
  function layout(availW) {
    var vis = visible(), v = ST.orient === 'v', cw = v ? 170 : CW;
    var unit = v ? cw + 14 : CH + 12, dstep = v ? CH + 44 : cw + 56;
    var nodes = [], edges = [], order = [], cursor = PAD, maxD = 0;
    function kidsOf(it) { var k = keyOf(it); if (ST.collapsed[k] && !vis) return []; return (it.kids || []).filter(function (x) { return !vis || vis[keyOf(x)]; }); }
    function place(it, d) {
      var k = keyOf(it); order.push(k);
      var ks = kidsOf(it), b;
      if (!ks.length) { b = cursor; cursor += unit; }
      else { var cs = ks.map(function (x) { return place(x, d + 1); }); b = (cs[0].b + cs[cs.length - 1].b) / 2; cs.forEach(function (c) { edges.push([k, c.k]); }); }
      var n = { k: k, it: it, b: b, d: d, w: cw, h: CH, axis: v ? 'x' : 'y', kids: (it.kids || []).length };
      n.x = v ? b : PAD + d * dstep; n.y = v ? PAD + d * dstep : b;
      nodes.push(n); maxD = Math.max(maxD, d); return n;
    }
    var roots = tree().filter(function (x) { return !vis || vis[keyOf(x)]; });
    roots.forEach(function (r) { place(r, 0); });
    var tw = 0, th = 0;
    if (roots.length) { var breadth = cursor - (v ? 14 : 12) + PAD, depth = PAD + maxD * dstep + (v ? CH : cw) + PAD; tw = v ? breadth : depth; th = v ? depth : breadth; }
    var loose = looseKeys().filter(function (k) { return !vis || vis[k]; }), grid = null, gap = 14;
    if (loose.length) {
      var cols = Math.max(1, Math.floor((Math.max(tw, availW) - 2 * PAD + gap) / (cw + gap))), top = roots.length ? th + 16 : PAD;
      loose.forEach(function (k, i) { order.push(k); nodes.push({ k: k, it: { p: k.slice(2) }, w: cw, h: CH, axis: 'x', kids: 0, loose: true, x: PAD + (i % cols) * (cw + gap), y: top + 30 + Math.floor(i / cols) * (CH + 12) }); });
      grid = { top: top, n: loose.length, h: 30 + Math.ceil(loose.length / cols) * (CH + 12) - 12, w: PAD * 2 + Math.min(cols, loose.length) * (cw + gap) - gap, line: roots.length > 0 };
    }
    var pos = {}; nodes.forEach(function (n) { pos[n.k] = n; });
    return { nodes: nodes, edges: edges, pos: pos, order: order, v: v, grid: grid, w: Math.max(tw, grid ? grid.w : 0), h: grid ? grid.top + grid.h + PAD : th };
  }

  // ---------- venster ----------
  var W = null, UI = {};
  function build(body) {
    body.innerHTML = ''; body.classList.add('pt-body');
    var bar = el('div', 'pt-bar');
    var add = el('button', 'pt-btn pri', '+ Nieuwe pagina'); add.onclick = function () { newPage(null); };
    var nod = el('button', 'pt-btn', '▤ Knooppunt'); nod.title = 'Ordeningsknooppunt: geen echte pagina, alleen om onder te ordenen'; nod.onclick = function () { newNode(null); };
    var q = el('input', 'pt-search'); q.placeholder = 'Zoek pagina…'; q.value = ST.filter; q.oninput = function () { ST.filter = q.value; render(); };
    function ib(path, tip, fn) { var b = el('button', 'pt-ib'); b.title = tip; b.innerHTML = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="' + path + '"/></svg>'; b.onclick = fn; return b; }
    var exp = ib('M4 6l4-3 4 3M4 10l4 3 4-3', 'Alles uitklappen', function () { ST.collapsed = {}; keep(); render(); });
    var col = ib('M4 3l4 3 4-3M4 13l4-3 4 3', 'Alles inklappen', function () { ST.collapsed = {}; (function w(l) { l.forEach(function (x) { if (x.kids && x.kids.length) { ST.collapsed[keyOf(x)] = 1; w(x.kids); } }); })(tree()); keep(); render(); });
    UI.ori = ib('', '', function () { ST.orient = ST.orient === 'v' ? 'h' : 'v'; keep(); render(); });
    var zo = ib('M3.5 8h9', 'Uitzoomen', function () { zoom(ST.scale / 1.2); }), zi = ib('M3.5 8h9M8 3.5v9', 'Inzoomen', function () { zoom(ST.scale * 1.2); });
    UI.zl = el('span', 'pt-zl'); UI.zl.title = 'Terug naar 100%'; UI.zl.onclick = function () { zoom(1); };
    [add, nod, q, exp, col, UI.ori, el('i', 'pt-sep'), zo, UI.zl, zi].forEach(function (x) { bar.appendChild(x); });
    body.appendChild(bar);
    UI.hint = el('div', 'pt-hint', 'Sleep een pagina óp een andere om hem eronder te zetten, of ertussen om de volgorde te wijzigen. Meerdere: Ctrl/Shift+klik. Dubbelklik = openen, Delete = verwijderen.');
    body.appendChild(UI.hint);
    UI.cv = el('div', 'pt-canvas'); UI.sz = el('div', 'pt-sizer'); UI.st = el('div', 'pt-stage');
    UI.sz.appendChild(UI.st); UI.cv.appendChild(UI.sz); body.appendChild(UI.cv);
    UI.foot = el('div', 'pt-foot'); body.appendChild(UI.foot);
    canvasControls(UI.cv);
    render();
  }
  // zoomen, schuiven, selectiekader en loslaten op lege ruimte — zoals in de originele WEBPLAYS
  //   wiel = zoomen rond de muis · Shift+wiel = opzij · Alt+wiel = op/neer · trackpad-knijpen zoomt ook
  //   spatie of middelste muisknop + slepen = schuiven · slepen op lege ruimte = selectiekader
  function canvasControls(cv) {
    function empty(t) { return t === cv || t === UI.sz || t === UI.st || t.tagName === 'svg' || t.tagName === 'path' || (t.classList && (t.classList.contains('pt-gridh') || t.classList.contains('pt-divider'))); }
    cv.addEventListener('wheel', function (e) {
      e.preventDefault();
      if (e.shiftKey && !e.ctrlKey) { cv.scrollLeft += (e.deltaY || e.deltaX); return; }
      if (e.altKey && !e.ctrlKey) { cv.scrollTop += (e.deltaY || e.deltaX); return; }
      var r = cv.getBoundingClientRect(), d = e.deltaMode === 1 ? e.deltaY * 33 : e.deltaY;
      zoom(ST.scale * Math.exp(-d * (e.ctrlKey ? 0.01 : 0.0015)), e.clientX - r.left, e.clientY - r.top);
    }, { passive: false });
    // schuiven (eerst: capture, zodat een kaartje dan niet gaat slepen)
    cv.addEventListener('mousedown', function (e) {
      if (!(ST.space && e.button === 0) && e.button !== 1) return;
      e.preventDefault(); e.stopPropagation();
      var sx = e.clientX, sy = e.clientY, l0 = cv.scrollLeft, t0 = cv.scrollTop; cv.classList.add('panning');
      function mv(ev) { cv.scrollLeft = l0 - (ev.clientX - sx); cv.scrollTop = t0 - (ev.clientY - sy); }
      function up() { document.removeEventListener('mousemove', mv, true); document.removeEventListener('mouseup', up, true); cv.classList.remove('panning'); }
      document.addEventListener('mousemove', mv, true); document.addEventListener('mouseup', up, true);
    }, true);
    // selectiekader op lege ruimte (Ctrl/Shift = erbij)
    cv.addEventListener('mousedown', function (e) {
      if (e.button !== 0 || !empty(e.target)) return;
      e.preventDefault();
      var cr = cv.getBoundingClientRect();
      function pt(ev) { return { x: (ev.clientX - cr.left + cv.scrollLeft) / ST.scale, y: (ev.clientY - cr.top + cv.scrollTop) / ST.scale }; }
      var st = pt(e), moved = false, base = (e.ctrlKey || e.metaKey || e.shiftKey) ? Object.assign({}, ST.sel) : {};
      var box = el('div', 'pt-marq'); UI.st.appendChild(box);
      function mv(ev) {
        var q = pt(ev), x1 = Math.min(st.x, q.x), y1 = Math.min(st.y, q.y), x2 = Math.max(st.x, q.x), y2 = Math.max(st.y, q.y);
        if (!moved && (x2 - x1 > 4 || y2 - y1 > 4)) moved = true;
        if (!moved) return;
        box.style.cssText = 'display:block;left:' + x1 + 'px;top:' + y1 + 'px;width:' + (x2 - x1) + 'px;height:' + (y2 - y1) + 'px';
        var sel = Object.assign({}, base);
        UI.L.nodes.forEach(function (n) { if (n.x < x2 && n.x + n.w > x1 && n.y < y2 && n.y + n.h > y1) sel[n.k] = 1; });
        ST.sel = sel;
        [].forEach.call(UI.st.querySelectorAll('.pt-card'), function (c) { c.classList.toggle('sel', !!sel[c.dataset.k]); });   // alleen de kaartjes, geen hele render
      }
      function up() {
        document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up);
        box.remove();
        if (!moved) { ST.sel = {}; ST.anchor = null; }
        render();
      }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
    // tijdens slepen van een kaartje: aan de randen meeschuiven; loslaten op lege ruimte = bovenste niveau, achteraan
    cv.addEventListener('dragover', function (e) {
      if (!ST.drag) return;
      var r = cv.getBoundingClientRect(), m = 50;
      if (e.clientY < r.top + m) cv.scrollTop -= 14; else if (e.clientY > r.bottom - m) cv.scrollTop += 14;
      if (e.clientX < r.left + m) cv.scrollLeft -= 14; else if (e.clientX > r.right - m) cv.scrollLeft += 14;
      if (empty(e.target)) { e.preventDefault(); hideInd(); }
    });
    cv.addEventListener('drop', function (e) {
      if (!ST.drag || !empty(e.target)) return;
      e.preventDefault();
      var ks = ST.drag; ST.drag = null; hideInd();
      var items = ks.map(takeOut).filter(Boolean); tree().push.apply(tree(), items);
      changed(ks.length + (ks.length > 1 ? ' items' : ' item') + ' naar het bovenste niveau');
    });
    cv.addEventListener('mouseleave', function () { if (ST.space) { ST.space = false; cv.classList.remove('space'); } });
  }
  // spatie ingedrukt (muis in het venster) = handje — één keer voor het hele document
  document.addEventListener('keydown', function (e) {
    var cv = UI.cv; if (e.code !== 'Space' || !cv || !cv.isConnected || !cv.matches(':hover')) return;
    var a = document.activeElement; if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) return;
    e.preventDefault(); if (!ST.space) { ST.space = true; cv.classList.add('space'); }
  }, true);
  document.addEventListener('keyup', function (e) { if (e.code === 'Space' && ST.space) { ST.space = false; if (UI.cv) UI.cv.classList.remove('space'); } }, true);
  function zoom(ns, mx, my) {
    ns = Math.max(0.3, Math.min(2.2, ns)); var cv = UI.cv; if (!cv) return;
    if (mx == null) { mx = cv.clientWidth / 2; my = cv.clientHeight / 2; }
    var cx = (cv.scrollLeft + mx) / ST.scale, cy = (cv.scrollTop + my) / ST.scale;
    ST.scale = ns; keep(); render(); cv.scrollLeft = cx * ns - mx; cv.scrollTop = cy * ns - my;
  }
  function render() {
    if (!UI.st || !UI.st.isConnected) return;
    var L = layout(UI.cv.clientWidth / ST.scale), stage = UI.st;
    UI.L = L; stage.innerHTML = '';
    stage.style.width = L.w + 'px'; stage.style.height = L.h + 'px'; stage.style.transform = 'scale(' + ST.scale + ')';
    UI.sz.style.width = Math.ceil(L.w * ST.scale) + 'px'; UI.sz.style.height = Math.ceil(L.h * ST.scale) + 'px';
    UI.zl.textContent = Math.round(ST.scale * 100) + '%';
    UI.ori.innerHTML = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="' +
      (ST.orient === 'v' ? 'M8 2.5v3M4 5.5h8M4 5.5v3M12 5.5v3M2.5 8.5h3v5h-3zM10.5 8.5h3v5h-3z' : 'M2.5 8h3M5.5 4v8M5.5 4h3M5.5 12h3M8.5 2.5h5v3h-5zM8.5 10.5h5v3h-5z') + '"/></svg>';
    UI.ori.title = ST.orient === 'v' ? 'Richting: boven → onder (klik voor links → rechts)' : 'Richting: links → rechts (klik voor boven → onder)';
    // verbindingslijnen
    var NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', L.w); svg.setAttribute('height', L.h); svg.setAttribute('class', 'pt-lines');
    L.edges.forEach(function (e) {
      var a = L.pos[e[0]], b = L.pos[e[1]]; if (!a || !b) return;
      var d = L.v ? 'M' + (a.x + a.w / 2) + ' ' + (a.y + a.h) + ' V' + (a.y + a.h + 22) + ' H' + (b.x + b.w / 2) + ' V' + b.y
                  : 'M' + (a.x + a.w) + ' ' + (a.y + a.h / 2) + ' H' + (a.x + a.w + 28) + ' V' + (b.y + b.h / 2) + ' H' + b.x;
      var pth = document.createElementNS(NS, 'path'); pth.setAttribute('d', d); svg.appendChild(pth);
    });
    stage.appendChild(svg);
    UI.ind = el('div', 'pt-ind'); stage.appendChild(UI.ind);
    L.nodes.forEach(function (n) { stage.appendChild(card(n)); });
    if (L.grid) {
      if (L.grid.line) { var ln = el('div', 'pt-divider'); ln.style.top = (L.grid.top - 8) + 'px'; stage.appendChild(ln); }
      var gh = el('div', 'pt-gridh', 'Losse pagina\'s (' + L.grid.n + ')'); gh.style.top = (L.grid.top + (L.grid.line ? 2 : 0)) + 'px'; stage.appendChild(gh);
    }
    var nP = site().pages.length, nN = 0; (function w(l) { l.forEach(function (x) { if (x.n) nN++; if (x.kids) w(x.kids); }); })(tree());
    var ns = Object.keys(ST.sel).length;
    UI.foot.textContent = nP + ' pagina\'s' + (nN ? ' · ' + nN + ' knooppunt' + (nN > 1 ? 'en' : '') : '') + (ns > 1 ? ' · ' + ns + ' geselecteerd' : '') + ' · wiel = zoomen, spatie+slepen = schuiven, slepen op leeg = kader · bewaard bij Opslaan';
    UI.hint.style.display = tree().some(function (x) { return x.kids && x.kids.length; }) ? 'none' : 'block';
  }
  function card(n) {
    var k = n.k, it = n.it, isNode = !!it.n, p = it.p ? pageById(it.p) : null, cur = it.p === E.page(), home = it.p === (site().site.homePage || site().pages[0].id);
    var c = el('div', 'pt-card' + (isNode ? ' node' : '') + (cur ? ' cur' : '') + (ST.sel[k] ? ' sel' : '') + (ST.filter && label(k).toLowerCase().indexOf(ST.filter.toLowerCase()) >= 0 ? ' hit' : ''));
    c.style.left = n.x + 'px'; c.style.top = n.y + 'px'; c.style.width = n.w + 'px'; c.style.height = n.h + 'px';
    c.dataset.k = k;
    c.draggable = true;
    var chev = el('span', 'pt-chev', n.kids ? (ST.collapsed[k] ? '▶' : '▼') : '');
    if (n.kids) chev.onclick = function (e) { e.stopPropagation(); if (ST.collapsed[k]) delete ST.collapsed[k]; else ST.collapsed[k] = 1; keep(); render(); };
    c.appendChild(chev);
    if (isNode) c.appendChild(el('span', 'pt-ico', '▤'));
    var nm = el('span', 'pt-name', label(k)); c.appendChild(nm);
    if (p) c.title = title(p) + '\n' + (p.path || '/' + p.id) + (home ? ' · startpagina' : '') + (p.master ? ' · master ' + p.master : '') + '\nDubbelklik = openen';
    if (home) c.appendChild(el('span', 'pt-tag', 'home'));
    if (ST.collapsed[k] && n.kids) c.appendChild(el('span', 'pt-count', String(n.kids)));
    if (cur) { var dot = el('span', 'pt-dot'); dot.title = 'Huidige pagina'; c.appendChild(dot); }
    // acties bij hover
    var tools = el('div', 'pt-tools');
    function tb(txt, tip, fn, cls) { var b = el('button', cls || '', txt); b.title = tip; b.onmousedown = function (e) { e.stopPropagation(); }; b.onclick = function (e) { e.stopPropagation(); fn(); }; tools.appendChild(b); }
    if (!isNode) tb('↗', 'Open pagina', function () { openPage(k); });
    tb('+', 'Nieuwe subpagina', function () { newPage(k); });
    tb('▤', 'Nieuw knooppunt hieronder', function () { newNode(k); });
    tb('✎', 'Hernoemen', function () { rename(k); });
    if (!isNode) tb('⧉', 'Dupliceren', function () { duplicate(k); });
    tb('✕', 'Verwijderen', function () { remove([k]); }, 'del');
    c.appendChild(tools);
    c.onclick = function (e) {
      if (e.shiftKey && ST.anchor && UI.L) {
        var o = UI.L.order, a = o.indexOf(ST.anchor), b = o.indexOf(k);
        if (!(e.ctrlKey || e.metaKey)) ST.sel = {};
        for (var i = Math.min(a, b); i <= Math.max(a, b); i++) if (o[i]) ST.sel[o[i]] = 1;
      } else if (e.ctrlKey || e.metaKey) { if (ST.sel[k]) delete ST.sel[k]; else ST.sel[k] = 1; ST.anchor = k; }
      else { ST.sel = {}; ST.sel[k] = 1; ST.anchor = k; }
      render();
    };
    c.ondblclick = function () { if (isNode) { if (n.kids) { if (ST.collapsed[k]) delete ST.collapsed[k]; else ST.collapsed[k] = 1; keep(); render(); } } else openPage(k); };
    // slepen in de boom
    c.addEventListener('dragstart', function (e) {
      if (!ST.sel[k]) { ST.sel = {}; ST.sel[k] = 1; ST.anchor = k; }
      var ks = Object.keys(ST.sel).filter(function (x) { return !Object.keys(ST.sel).some(function (y) { return y !== x && isInside(x, y); }); });   // wat onder een geselecteerde ouder hangt, gaat vanzelf mee
      ST.drag = ks.sort(function (a, b) { return UI.L.order.indexOf(a) - UI.L.order.indexOf(b); });
      try { e.dataTransfer.setData('text/plain', 'wp-page'); e.dataTransfer.effectAllowed = 'move'; } catch (x) {}
      c.classList.add('ghost');
    });
    c.addEventListener('dragend', function () { ST.drag = null; c.classList.remove('ghost'); hideInd(); });
    c.addEventListener('dragover', function (e) {
      if (!ST.drag) return;
      var z = zone(e, c, n.axis);
      if (ST.drag.some(function (d) { return isInside(k, d); })) { hideInd(); return; }   // niet in zichzelf of eigen onderdelen
      e.preventDefault(); e.dataTransfer.dropEffect = 'move'; hideInd();
      if (z === 'into') { c.classList.add('into'); UI.hot = c; return; }
      var s = UI.ind.style; s.display = 'block';
      if (n.axis === 'x') { s.width = '3px'; s.height = (n.h + 8) + 'px'; s.top = (n.y - 4) + 'px'; s.left = (z === 'before' ? n.x - 8 : n.x + n.w + 5) + 'px'; }
      else { s.height = '3px'; s.width = n.w + 'px'; s.left = n.x + 'px'; s.top = (z === 'before' ? n.y - 7 : n.y + n.h + 5) + 'px'; }
    });
    c.addEventListener('dragleave', function () { c.classList.remove('into'); });
    c.addEventListener('drop', function (e) {
      if (!ST.drag) return; e.preventDefault(); e.stopPropagation();
      var z = zone(e, c, n.axis), ks = ST.drag; ST.drag = null; hideInd();
      if (move(ks, k, z)) changed(ks.length + (ks.length > 1 ? ' items' : ' item') + (z === 'into' ? ' ondergebracht bij ' : ' verplaatst naast ') + label(k));
    });
    return c;
  }
  function zone(e, c, axis) { var r = c.getBoundingClientRect(), f = axis === 'x' ? (e.clientX - r.left) / r.width : (e.clientY - r.top) / r.height; return f < 0.28 ? 'before' : f > 0.72 ? 'after' : 'into'; }
  function hideInd() { if (UI.ind) UI.ind.style.display = 'none'; if (UI.hot) { UI.hot.classList.remove('into'); UI.hot = null; } }

  // Delete: alleen als de muis/focus in het venster is
  document.addEventListener('keydown', function (e) {
    if (!W || !W.el.isConnected || !(e.key === 'Delete' || e.key === 'Backspace')) return;
    if (!W.el.matches(':hover') || (window.WPPrompt && WPPrompt.isOpen())) return;
    var a = document.activeElement; if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) return;
    var ks = Object.keys(ST.sel); if (!ks.length) return;
    e.preventDefault(); e.stopPropagation(); remove(ks);
  }, true);

  function open() {
    if (W && W.el.isConnected) { W.focus(); return; }
    var vw = innerWidth, vh = innerHeight, w = Math.round(vw * 0.6), h = Math.round(vh * 0.7);
    W = WPLibs.createWin({ id: 'pages', title: 'PAGINA\'S', left: Math.round((vw - w) / 2), top: Math.round(56 + (vh - 56 - h) / 2), width: w, height: h, build: build });
    var cl = W.close; W.close = function () { cl(); W = null; ptBtn.classList.remove('on'); };
    ptBtn.classList.add('on');
  }
  // knop naast de paginakeuze
  var ptBtn = el('button'); ptBtn.id = 'ptBtn'; ptBtn.title = 'Pagina\'s: de site als boom (ordenen, nieuw, dupliceren…)';
  ptBtn.innerHTML = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 2.5h4v3h-4zM10.5 1.5h4v3h-4zM10.5 6.5h4v3h-4zM10.5 11.5h4v3h-4zM5.5 4h2.5v9h2.5M8 8h2.5M8 3h2.5"/></svg>';
  ptBtn.onclick = function () { if (W && W.el.isConnected) W.close(); else open(); };
  $('selPage').after(ptBtn);
  // na elke wijziging elders (undo, agent, paneel): boom bijwerken
  var _ch = E.changed; E.changed = function (m) { _ch(m); render(); };
  $('selPage').addEventListener('change', function () { render(); });
  if (WPLibs.stored('pages').open) open();
  window.WPPages = { open: open, render: render };
})();
