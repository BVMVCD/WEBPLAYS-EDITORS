/*  WEBPLAYS editor — laadt de editor uit de motor (één plek voor alle sites).
    De site heeft alleen een klein editor.html dat dit bestand laadt; site.json en api/ blijven van de site.
*/
(function () {
  'use strict';
  var me = document.currentScript && document.currentScript.src;
  var E = window.WP_ENGINE || (me ? me.replace(/[^\/]*$/, '') : '/webplays/');
  var V = '?v=' + Date.now();   // altijd de nieuwste editor laden, nooit een oude uit de browsercache
  var css = document.createElement('link'); css.rel = 'stylesheet'; css.href = E + 'editor.css' + V; var cssReady = new Promise(function (res) { css.onload = css.onerror = res; setTimeout(res, 4000); });   // de balk pas tonen als de stijl er is
  document.head.appendChild(css);
  Promise.all([fetch(E + 'editor-body.html' + V, { cache: 'no-store' }).then(function (r) { return r.text(); }), cssReady]).then(function (a) { return a[0]; }).then(function (html) {
    document.body.insertAdjacentHTML('afterbegin', html);
    // versie van de motor: staat in VERSION.txt (zelfde nummer als de git-tag); alleen zichtbaar als tooltip op het logo
    fetch(E + 'VERSION.txt' + V, { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; }).then(function (t) {
      t = (t || '').trim();
      var l = document.querySelector('#bar .logo');
      if (!l || !/^[0-9][0-9A-Za-z._-]{0,29}$/.test(t)) return;
      window.WP_VERSION = t;
      l.title = 'WEBPLAYS motor v' + t;
    }).catch(function () {});
    window.WP_OPTIONS = { editor: true };
    return ['dialog.js', 'speler.js', 'editor.js', 'agent.js', 'keys.js', 'inbox.js', 'libraries.js', 'pages.js', 'help.js'].reduce(function (p, f) {
      return p.then(function () {
        return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = E + f + V; s.onload = res; s.onerror = rej; document.body.appendChild(s); });
      });
    }, Promise.resolve());
  }).catch(function (e) { document.body.textContent = 'WEBPLAYS-motor niet gevonden op ' + E + ' (' + e.message + ')'; });
})();
