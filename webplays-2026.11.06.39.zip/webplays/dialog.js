/*  WEBPLAYS editor — centrale meldingen (zoals WPEConfirm / WPENotice / WPEPrompt in de oude editor).
    Eén box in het midden van het scherm, de rest gedimd. Nooit meer de kale browser-prompts ("localhost zegt…").

      WPPrompt.notice('Opgeslagen.', [opts], [onClose])
      WPPrompt.confirm('Dit verwijderen?', { ok: 'Verwijderen', danger: true }, onYes, [onNo])
      WPPrompt.ask('Naam van de kleur', { placeholder, value, password, validate: fn(v) → foutmelding|null }, onSubmit(v), [onCancel])

    Enter = OK, Esc = annuleren, klik naast de box = annuleren. Meerdere boven elkaar kan (elke nieuwe komt bovenop).
*/
(function () {
  'use strict';
  var STACK = [];
  document.addEventListener('keydown', function (e) {
    if (!STACK.length) return;
    var top = STACK[STACK.length - 1];
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); top.cancel(); }
    else if (e.key === 'Enter' && !(e.target && e.target.tagName === 'TEXTAREA')) { e.preventDefault(); e.stopPropagation(); top.ok(); }
  }, true);

  function box(o) {
    var dim = document.createElement('div'); dim.className = 'wpp-dim';
    dim.style.zIndex = 30000 + STACK.length * 2;
    var b = document.createElement('div'); b.className = 'wpp-box'; b.setAttribute('role', 'dialog'); b.setAttribute('aria-modal', 'true');
    if (o.title) { var t = document.createElement('div'); t.className = 'wpp-title'; t.textContent = o.title; b.appendChild(t); }
    var m = document.createElement('div'); m.className = 'wpp-msg'; m.textContent = o.message || ''; b.appendChild(m);
    var input = null, err = null;
    if (o.input) {
      input = document.createElement('input'); input.className = 'wpp-in';
      input.type = o.input.password ? 'password' : 'text';
      input.placeholder = o.input.placeholder || ''; input.value = o.input.value || '';
      input.autocomplete = o.input.password ? 'current-password' : 'off'; input.spellcheck = false;
      err = document.createElement('div'); err.className = 'wpp-err';
      input.addEventListener('input', function () { err.textContent = ''; });
      b.appendChild(input); b.appendChild(err);
    }
    var row = document.createElement('div'); row.className = 'wpp-btns';
    var no = null;
    if (o.cancelText !== false) { no = document.createElement('button'); no.className = 'wpp-no'; no.textContent = o.cancelText || 'Annuleren'; row.appendChild(no); }
    var yes = document.createElement('button'); yes.className = 'wpp-ok' + (o.danger ? ' danger' : ''); yes.textContent = o.okText || 'OK'; row.appendChild(yes);
    b.appendChild(row); dim.appendChild(b); document.body.appendChild(dim);
    var api = {
      close: function () { if (dim.parentNode) dim.remove(); var i = STACK.indexOf(api); if (i >= 0) STACK.splice(i, 1); },
      ok: function () {
        var v = input ? input.value.trim() : true;
        if (input && o.input.required !== false && !v) { err.textContent = 'Vul iets in.'; input.focus(); return; }
        if (input && o.input.validate) { var e = o.input.validate(v); if (e) { err.textContent = e; input.focus(); input.select(); return; } }
        api.close(); if (o.onOk) o.onOk(v);
      },
      cancel: function () { api.close(); if (o.onCancel) o.onCancel(); }
    };
    yes.onclick = api.ok; if (no) no.onclick = api.cancel;
    dim.addEventListener('mousedown', function (e) { if (e.target === dim) api.cancel(); });
    STACK.push(api);
    setTimeout(function () { (input || yes).focus(); if (input) input.select(); }, 20);
    return api;
  }

  window.WPPrompt = {
    notice: function (message, opts, onClose) {
      if (typeof opts === 'function') { onClose = opts; opts = {}; }
      opts = opts || {};
      return box({ title: opts.title, message: message, okText: opts.ok || 'OK', cancelText: false, onOk: onClose, onCancel: onClose });
    },
    confirm: function (message, opts, onYes, onNo) {
      if (typeof opts === 'function') { onNo = onYes; onYes = opts; opts = {}; }
      opts = opts || {};
      return box({ title: opts.title, message: message, okText: opts.ok || 'OK', cancelText: opts.cancel || 'Annuleren', danger: !!opts.danger, onOk: onYes, onCancel: onNo });
    },
    ask: function (message, opts, onSubmit, onCancel) {
      if (typeof opts === 'function') { onCancel = onSubmit; onSubmit = opts; opts = {}; }
      opts = opts || {};
      return box({ title: opts.title, message: message, okText: opts.ok || 'OK', cancelText: opts.cancel || 'Annuleren',
        input: { placeholder: opts.placeholder, value: opts.value, password: opts.password, validate: opts.validate, required: opts.required },
        onOk: onSubmit, onCancel: onCancel });
    },
    isOpen: function () { return STACK.length > 0; }
  };
  // dezelfde namen als in de oude editor, voor wie ze gewend is
  window.WPEConfirm = function (msg, onYes) { return WPPrompt.confirm(msg, { ok: 'Verwijderen', danger: true }, onYes); };
  window.WPENotice = function (msg, onClose) { return WPPrompt.notice(msg, onClose); };
  window.WPEPrompt = function (msg, placeholder, onSubmit, value) { return WPPrompt.ask(msg, { placeholder: placeholder, value: value }, onSubmit); };
})();
