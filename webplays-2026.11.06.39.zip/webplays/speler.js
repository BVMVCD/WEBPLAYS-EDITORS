/*  WEBPLAYS speler — de renderer van site.json (webplays-site/1)
    Vorm: statisch uit site.json.  Interactie: modules praten met de API.
    Primitieven: surface, text, image, group (+ action in base).  Modules: nav, form.
    Schema's: schema/*.schema.json.  Breaks: kolom-modus volgens de core-regels
    (WEBPLAYS_Core_Breakpoint_Regels.md): nesting, stapelruimte, WPText-x, meegroeiende vlakken, footer-zone.
*/
(function () {
  'use strict';

  var OPT = window.WP_OPTIONS || {};   // editor zet { editor:true, onBuilt:fn }
  var ENGINE = (document.currentScript && document.currentScript.src || '/webplays/speler.js').replace(/[^\/]*$/, '');
  var EDIT = !!OPT.editor;
  var SITE = null;
  var LANG = 'nl';
  var PAGE = null;
  var ROOT = document.getElementById(OPT.root || 'wp-root');

  // ---------- helpers ----------
  function color(c) {
    if (!c) return null;
    if (c.charAt(0) === '@') return (SITE.colors && SITE.colors[c.slice(1)]) || '#000000';
    return c;
  }
  function rgba(c, a) {
    c = color(c) || '#000000';
    if (a === undefined || a === null) a = 1;
    var h = c.replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  // tekst: sleutel uit translations, object per taal, of platte string
  function tr(v) {
    if (v === undefined || v === null) return '';
    if (typeof v === 'string' && SITE.translations && SITE.translations[v]) v = SITE.translations[v];
    if (typeof v === 'object' && !Array.isArray(v)) v = (v[LANG] !== undefined) ? v[LANG] : v[SITE.site.defaultLanguage];
    return v;
  }
  function trPlain(v) {
    v = tr(v);
    if (Array.isArray(v)) return v.map(function (r) { return r.t; }).join('');
    return v || '';
  }
  // stijl-token samenvoegen met eigen velden (eigen veld wint)
  function withStyle(own, styleId) {
    var st = styleId && SITE.styles ? SITE.styles[styleId] : null;
    var out = {};
    if (st) for (var k in st.props) out[k] = st.props[k];
    for (var j in own) if (j !== 'style') out[j] = own[j];
    return out;
  }
  // eigen vlak-opmaak + een vlakstijl (props.style) — voor beeld en video
  function surfaceOf(o) {
    var id = o.props && o.props.style, st = id && SITE.styles ? SITE.styles[id] : null;
    if (!(st && st.kind === 'surface') && !o.surface) return null;
    return withStyle(o.surface || {}, st && st.kind === 'surface' ? id : null);
  }
  function el(tag, cls) { var e = document.createElement(tag); if (cls) e.className = cls; return e; }
  function place(e, L, pw) {
    var x = L.x, mir = pw && rtl();            // pw = breedte van de bovenliggende ruimte: bij rtl wordt de x gespiegeld (het ontwerp is één raster)
    if (mir) x = pw - L.x - L.w;
    e.style.left = x + 'px'; e.style.top = L.y + 'px';
    e.style.width = L.w + 'px'; e.style.height = L.h + 'px';
    if (L.r) e.style.transform = 'rotate(' + (mir ? -L.r : L.r) + 'deg)';
  }

  // ---------- primitieven ----------
  function applySurface(e, s) {
    if (!s) return;
    var fills = s.fills || [];
    var bg = [];
    fills.forEach(function (f) {
      if (f.type === 'solid') bg.push('linear-gradient(' + rgba(f.color, f.alpha) + ',' + rgba(f.color, f.alpha) + ')');
      else if (f.type === 'image' && f.src) {   // foto als vulling: crop = vullen, fit = passend, tile = herhalen
        var pos = f.focus ? (f.focus.x * 100) + '% ' + (f.focus.y * 100) + '%' : '50% 50%';
        var size = ({ fit: 'contain', fill: '100% 100%', tile: 'auto' })[f.fit] || 'cover';
        bg.push('url("' + String(asset(f.src)).replace(/"/g, '%22') + '") ' + pos + ' / ' + size + (f.fit === 'tile' ? ' repeat' : ' no-repeat'));
      }
      else if (f.type === 'linear') bg.push('linear-gradient(' + (f.angle || 180) + 'deg,' + f.stops.map(function (st) { return rgba(st.color, st.alpha) + ' ' + (st.at * 100) + '%'; }).join(',') + ')');
    });
    if (bg.length) e.style.background = bg.reverse().join(',');
    if (s.stroke && s.stroke.width) e.style.boxShadow = 'inset 0 0 0 ' + s.stroke.width + 'px ' + rgba(s.stroke.color, s.stroke.alpha);
    if (s.shape) {
      if (s.shape.kind === 'ellipse') e.style.borderRadius = '50%';
      else if (s.shape.radius) e.style.borderRadius = s.shape.radius.map(function (r) { return r + 'px'; }).join(' ');
    }
    if (s.opacity != null && s.opacity < 1) e.style.opacity = s.opacity;
    if (s.shadows && s.shadows.length) {
      var sh = s.shadows.map(function (d) {
        return (d.inner ? 'inset ' : '') + d.dx + 'px ' + d.dy + 'px ' + d.blur + 'px ' + (d.spread || 0) + 'px ' + rgba(d.color, d.alpha);
      });
      if (e.style.boxShadow) sh.unshift(e.style.boxShadow);
      e.style.boxShadow = sh.join(',');
    }
  }

  function renderSurface(o) {
    var e = el('div', 'wp-o wp-surface');
    var s = withStyle(o.surface || {}, (o.props && o.props.style) || (o.surface && o.surface.style));
    applySurface(e, s);
    return e;
  }

  function renderText(o) {
    var e = el('div', 'wp-o wp-text');
    var p = withStyle(o.props || {}, o.props && o.props.style);
    e.style.fontFamily = (p.font ? '"' + p.font + '",' : '') + 'system-ui,sans-serif';
    if (/^h[1-3]$/.test(p.tag || '')) { e.setAttribute('role', 'heading'); e.setAttribute('aria-level', p.tag.charAt(1)); }   // props.tag: kop voor zoekmachines en schermlezers
    if (p.size) e.style.fontSize = p.size + 'px';
    if (p.weight) e.style.fontWeight = p.weight;
    e.style.lineHeight = p.lineHeight || 1.3;
    if (p.italic) e.style.fontStyle = 'italic';
    if (p.letterSpacing) e.style.letterSpacing = p.letterSpacing + 'px';
    if (p.color) e.style.color = color(p.color);
    if (p.align) e.style.textAlign = rtl() && (p.align === 'left' || p.align === 'right') ? (p.align === 'left' ? 'right' : 'left') : p.align;
    if (p.valign === 'middle') { e.style.display = 'flex'; e.style.flexDirection = 'column'; e.style.justifyContent = 'center'; }
    if (p.padding) e.style.padding = p.padding.map(function (v) { return v + 'px'; }).join(' ');
    var v = tr(p.text);
    if (Array.isArray(v)) {
      v.forEach(function (r) {
        var s = el('span'); s.textContent = r.t;
        if (r.b) s.style.fontWeight = 700;
        if (r.i) s.style.fontStyle = 'italic';
        if (r.u) s.style.textDecoration = 'underline';
        if (r.size) s.style.fontSize = r.size + 'px';
        if (r.color) s.style.color = color(r.color);
        if (r.font) s.style.fontFamily = '"' + r.font + '",system-ui,sans-serif';
        e.appendChild(s);
      });
    } else e.textContent = v || '';
    if (o.surface) applySurface(e, o.surface);      // tekst mag een eigen vulling/rand hebben (bijv. via een kleur-drop)
    return e;
  }

  function renderImage(o) {
    var e = el('div', 'wp-o wp-image');
    var p = o.props || {};
    var img = el('img');
    img.src = asset(p.src); img.alt = trPlain(p.alt); img.loading = 'lazy';
    img.style.objectFit = ({ fill: 'fill', fit: 'contain', crop: 'cover' })[p.fit || 'crop'];
    if (p.focus) img.style.objectPosition = (p.focus.x * 100) + '% ' + (p.focus.y * 100) + '%';
    e.appendChild(img);
    var sf = surfaceOf(o);
    if (sf) { applySurface(e, sf); e.style.overflow = 'hidden'; }
    return e;
  }

  // ---------- icoon (neutraal): tekening komt uit site.icons, kleuren uit het palet ----------
  var ICON_TAGS = { g: 1, path: 1, circle: 1, ellipse: 1, rect: 1, line: 1, polyline: 1, polygon: 1 };
  var ICON_ATTR = /^(d|cx|cy|r|rx|ry|x|y|x1|y1|x2|y2|width|height|points|transform|stroke-width|stroke-dasharray|stroke-linecap|stroke-linejoin|fill-rule)$/;
  function iconMarkup(parent, markup) {          // alleen veilige tekenelementen; geen script, geen stijl, geen links
    if (!markup) return;
    var doc = new DOMParser().parseFromString('<svg xmlns="http://www.w3.org/2000/svg">' + markup + '</svg>', 'image/svg+xml');
    if (doc.getElementsByTagName('parsererror').length) return;
    (function walk(src, dst) {
      Array.prototype.forEach.call(src.childNodes, function (n) {
        if (n.nodeType !== 1 || !ICON_TAGS[n.localName]) return;
        var c = document.createElementNS('http://www.w3.org/2000/svg', n.localName);
        Array.prototype.forEach.call(n.attributes, function (a) { if (ICON_ATTR.test(a.name)) c.setAttribute(a.name, a.value); });
        dst.appendChild(c); walk(n, c);
      });
    })(doc.documentElement, parent);
  }
  // sociale iconen (merklogo's uit Simple Icons, CC0): props.icon = "social:<naam>", gevuld met props.color; link via action {type:"url"}
  var SOCIAL = {
    "linkedin": { t: "LinkedIn", p: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" },
    "instagram": { t: "Instagram", p: "M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077" },
    "facebook": { t: "Facebook", p: "M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z" },
    "x": { t: "X", p: "M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z" },
    "youtube": { t: "YouTube", p: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" },
    "tiktok": { t: "TikTok", p: "M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" },
    "whatsapp": { t: "WhatsApp", p: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" },
    "github": { t: "GitHub", p: "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" },
    "pinterest": { t: "Pinterest", p: "M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z" },
    "bluesky": { t: "Bluesky", p: "M5.202 2.857C7.954 4.922 10.913 9.11 12 11.358c1.087-2.247 4.046-6.436 6.798-8.501C20.783 1.366 24 .213 24 3.883c0 .732-.42 6.156-.667 7.037-.856 3.061-3.978 3.842-6.755 3.37 4.854.826 6.089 3.562 3.422 6.299-5.065 5.196-7.28-1.304-7.847-2.97-.104-.305-.152-.448-.153-.327 0-.121-.05.022-.153.327-.568 1.666-2.782 8.166-7.847 2.97-2.667-2.737-1.432-5.473 3.422-6.3-2.777.473-5.899-.308-6.755-3.369C.42 10.04 0 4.615 0 3.883c0-3.67 3.217-2.517 5.202-1.026" },
    "threads": { t: "Threads", p: "M18.263 11.097c-.03-3.486-1.92-5.586-5.111-5.586-2.13 0-3.922.963-4.863 2.499l2.062 1.438c.535-.843 1.272-1.543 2.628-1.543 1.528 0 2.318.85 2.544 2.431a15 15 0 0 0-2.236-.173c-4.125 0-6.068 1.867-6.068 4.336s1.943 3.99 4.804 3.99c3.139 0 5.013-2.115 5.781-4.735.798.361 1.348 1.204 1.348 2.47 0 3.387-3.907 5.232-7.22 5.232-4.885 0-8.077-3.207-8.077-8.424 0-6.392 4.223-10.487 9.9-10.487 3.808 0 5.69 1.671 6.97 3.914l2.108-1.475C21.44 2.078 18.331 0 13.663 0 6.227 0 1.168 5.277 1.168 12.934c0 7 4.953 11.066 10.856 11.066 4.878 0 9.809-2.846 9.809-7.716 0-2.545-1.46-4.231-3.569-5.187m-6.33 4.855c-1.077 0-2.026-.512-2.026-1.453 0-1.483 1.822-1.934 3.606-1.934.678 0 1.34.045 1.927.173-.422 1.927-1.671 3.215-3.508 3.214Z" },
    "mastodon": { t: "Mastodon", p: "M23.268 5.313c-.35-2.578-2.617-4.61-5.304-5.004C17.51.242 15.792 0 11.813 0h-.03c-3.98 0-4.835.242-5.288.309C3.882.692 1.496 2.518.917 5.127.64 6.412.61 7.837.661 9.143c.074 1.874.088 3.745.26 5.611.118 1.24.325 2.47.62 3.68.55 2.237 2.777 4.098 4.96 4.857 2.336.792 4.849.923 7.256.38.265-.061.527-.132.786-.213.585-.184 1.27-.39 1.774-.753a.057.057 0 0 0 .023-.043v-1.809a.052.052 0 0 0-.02-.041.053.053 0 0 0-.046-.01 20.282 20.282 0 0 1-4.709.545c-2.73 0-3.463-1.284-3.674-1.818a5.593 5.593 0 0 1-.319-1.433.053.053 0 0 1 .066-.054c1.517.363 3.072.546 4.632.546.376 0 .75 0 1.125-.01 1.57-.044 3.224-.124 4.768-.422.038-.008.077-.015.11-.024 2.435-.464 4.753-1.92 4.989-5.604.008-.145.03-1.52.03-1.67.002-.512.167-3.63-.024-5.545zm-3.748 9.195h-2.561V8.29c0-1.309-.55-1.976-1.67-1.976-1.23 0-1.846.79-1.846 2.35v3.403h-2.546V8.663c0-1.56-.617-2.35-1.848-2.35-1.112 0-1.668.668-1.67 1.977v6.218H4.822V8.102c0-1.31.337-2.35 1.011-3.12.696-.77 1.608-1.164 2.74-1.164 1.311 0 2.302.5 2.962 1.498l.638 1.06.638-1.06c.66-.999 1.65-1.498 2.96-1.498 1.13 0 2.043.395 2.74 1.164.675.77 1.012 1.81 1.012 3.12z" },
    "mail": { t: "E-mail", p: "M3 5h18a1 1 0 0 1 1 1v.4l-10 6.2L2 6.4V6a1 1 0 0 1 1-1zm-1 3.75l10 6.2 10-6.2V18a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V8.75z" }
  };
  function renderIcon(o) {
    var e = el('div', 'wp-o wp-icon');
    var p = o.props || {};
    if (typeof p.icon === 'string' && p.icon.indexOf('social:') === 0) {      // merklogo, gevuld in de gekozen kleur
      var sd = SOCIAL[p.icon.slice(7)]; if (!sd) return e;
      var sv = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      sv.setAttribute('viewBox', '0 0 24 24'); sv.setAttribute('fill', color(p.color) || '#000000'); sv.setAttribute('role', 'img');
      sv.setAttribute('aria-label', trPlain(p.alt) || sd.t);
      var sp = document.createElementNS('http://www.w3.org/2000/svg', 'path'); sp.setAttribute('d', sd.p); sv.appendChild(sp);
      e.appendChild(sv); return e;
    }
    var def = ((SITE.icons && SITE.icons.items) || {})[p.icon];
    if (!def) return e;
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', (SITE.icons.viewBox || '0 0 48 48'));
    svg.setAttribute('fill', 'none'); svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('stroke-width', p.weight || SITE.icons.weight || 2.25);
    svg.setAttribute('stroke', color(p.color) || '#000000');
    svg.setAttribute('role', 'img');
    var lbl = trPlain(p.alt) || (def.label && cv(def.label)) || '';
    if (lbl) svg.setAttribute('aria-label', lbl); else svg.setAttribute('aria-hidden', 'true');
    var tint = p.tint ? rgba(p.tint, p.tintAlpha === undefined ? 0.6 : p.tintAlpha) : rgba(p.color, 0.18);
    if (def.tint) { var gt = document.createElementNS(NS, 'g'); gt.setAttribute('fill', tint); gt.setAttribute('stroke', 'none'); iconMarkup(gt, def.tint); svg.appendChild(gt); }
    var gl = document.createElementNS(NS, 'g'); iconMarkup(gl, def.line); svg.appendChild(gl);
    e.appendChild(svg);
    return e;
  }

  function renderGroup(o) {
    var e = el('div', 'wp-o wp-group');
    if (o.props && o.props.clip) e.style.overflow = 'hidden';
    (o.children || []).forEach(function (c) { var ce = renderObject(c, o.layout && o.layout.w); if (ce) e.appendChild(ce); });
    return e;
  }

  // ---------- modules (dynamisch deel via API) ----------
    // vlaggetjes voor de taalkiezer (nav-prop "flags": true); taal zonder vlag valt terug op de code
  var FLAGS = {
    nl: '<rect width="30" height="20" fill="#21468B"/><rect width="30" height="13.4" fill="#fff"/><rect width="30" height="6.7" fill="#AE1C28"/>',
    de: '<rect width="30" height="20" fill="#FFCE00"/><rect width="30" height="13.4" fill="#DD0000"/><rect width="30" height="6.7" fill="#000"/>',
    en: '<g transform="scale(.5)"><rect width="60" height="40" fill="#012169"/><path d="M0 0L60 40M60 0L0 40" stroke="#fff" stroke-width="8"/><path d="M0 0L60 40M60 0L0 40" stroke="#C8102E" stroke-width="3"/><path d="M30 0V40M0 20H60" stroke="#fff" stroke-width="12"/><path d="M30 0V40M0 20H60" stroke="#C8102E" stroke-width="7"/></g>',
    fr: '<rect width="30" height="20" fill="#EF4135"/><rect width="20" height="20" fill="#fff"/><rect width="10" height="20" fill="#0055A4"/>',
    es: '<rect width="30" height="20" fill="#AA151B"/><rect y="5" width="30" height="10" fill="#F1BF00"/>',
    it: '<rect width="30" height="20" fill="#CE2B37"/><rect width="20" height="20" fill="#fff"/><rect width="10" height="20" fill="#009246"/>'
  };
  // taalkiezer (gedeeld door nav met languageSwitch en het object language): codes, vlaggetjes (props.flags) en uitklap (props.collapse)
  function langSwitch(p) {
      var langName = function (l) { var nm = ''; try { nm = new Intl.DisplayNames([l], { type: 'language' }).of(l); } catch (x) { } nm = nm || l.toUpperCase(); return nm.charAt(0).toUpperCase() + nm.slice(1); };
      var flagSvg = function (l) { return FLAGS[l] ? '<svg viewBox="0 0 30 20" width="26" height="18" preserveAspectRatio="none" aria-hidden="true">' + FLAGS[l] + '</svg>' : ''; };
      var sw;
      if (p.collapse) {   // alleen de actieve taal zichtbaar; klik = klein menu met de andere talen (nav-prop "collapse": true)
        sw = el('span', 'wp-lang wp-lang-dd' + (p.flags ? ' wp-lang-flags' : ''));
        var cur = el('button', 'wp-lang-cur'); cur.type = 'button'; cur.setAttribute('aria-haspopup', 'true'); cur.setAttribute('aria-expanded', 'false');
        cur.setAttribute('aria-label', langName(LANG)); cur.style.color = color(p.color) || 'inherit';
        cur.innerHTML = (p.flags && FLAGS[LANG] ? '<span class="wp-fl">' + flagSvg(LANG) + '</span>' : '<b>' + LANG.toUpperCase() + '</b>') + '<svg class="wp-chev" viewBox="0 0 10 6" width="10" height="6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        var menu = el('span', 'wp-lang-menu'); menu.setAttribute('role', 'menu');
        SITE.site.languages.forEach(function (l) {
          if (l === LANG) return;
          var a = el('a'); a.href = urlFor(PAGE.id, l) + location.search; a.setAttribute('role', 'menuitem');
          a.innerHTML = (p.flags && FLAGS[l] ? '<span class="wp-fl">' + flagSvg(l) + '</span>' : '<b>' + l.toUpperCase() + '</b>') + '<span>' + langName(l) + '</span>';
          menu.appendChild(a);
        });
        var close = function () { sw.classList.remove('open'); cur.setAttribute('aria-expanded', 'false'); };
        cur.onclick = function (ev) { ev.stopPropagation(); var o = sw.classList.toggle('open'); cur.setAttribute('aria-expanded', o ? 'true' : 'false'); };
        document.addEventListener('click', function (ev) { if (!sw.contains(ev.target)) close(); });
        document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
        sw.appendChild(cur); sw.appendChild(menu);
      } else {
      sw = el('span', 'wp-lang' + (p.flags ? ' wp-lang-flags' : ''));
      SITE.site.languages.forEach(function (l) {
        var a = el('a'); a.href = urlFor(PAGE.id, l) + location.search;
        var fl = p.flags ? FLAGS[l] : null;
        if (fl) {   // vlaggetje (svg, werkt ook op Windows waar vlag-emoji als letters verschijnen)
          a.innerHTML = flagSvg(l);
          a.setAttribute('aria-label', langName(l)); a.title = langName(l);
          if (l === LANG) { a.className = 'on'; a.style.setProperty('--wpf-ring', color(p.activeColor) || 'currentColor'); }
        } else { a.textContent = l.toUpperCase(); a.style.color = color(l === LANG ? p.activeColor : p.color); }
        sw.appendChild(a);
      });
      }
      return sw;
  }
  function renderNav(o) {
    var e = el('nav', 'wp-o wp-nav');
    var p = o.props;
    var ps = p.style ? withStyle({}, p.style) : {};
    if (p.font || ps.font) e.style.fontFamily = '"' + (p.font || ps.font) + '",system-ui,sans-serif';
    if (p.pill) {
      e.classList.add('wp-nav-pill');
      if (o.surface) applySurface(e, o.surface);
      e.style.padding = '4px';
    }
    e.style.gap = (p.gap || 20) + 'px';
    e.style.fontSize = (p.size || 15) + 'px';
    if (o._burger) return renderBurger(o, e, p);
    p.items.forEach(function (it) {
      var a = el('a'); a.textContent = trPlain(it.label);
      a.href = actionHref(it.action);
      var active = it.action.type === 'page' && it.action.target === PAGE.id;
      if (p.pill) { a.className = active ? 'on' : ''; }
      else a.style.color = color(active ? p.activeColor : p.color);
      if (active) a.setAttribute('aria-current', 'page');
      e.appendChild(a);
    });
    if (p.languageSwitch && SITE.site.languages.length > 1) e.appendChild(langSwitch(p));
    return e;
  }

  // hamburgermenu: knop + uitklapmenu (items onder elkaar, items met children als uitklap)
  function renderBurger(o, e, p) {
    e.classList.add('wp-burger');
    var lbl = wpt('menu');
    var col = color(p.color) || 'currentColor';
    var btn = el('button', 'wp-bg-btn'); btn.type = 'button'; btn.setAttribute('aria-label', lbl); btn.setAttribute('aria-expanded', 'false'); btn.style.color = col;
    btn.innerHTML = '<i></i><i></i><i></i>';
    var panel = el('div', 'wp-bg-panel'); panel.setAttribute('role', 'menu');
    var addItem = function (it, host, sub) {
      var kids = it.children && it.children.length ? it.children : null;
      var row = el('div', 'wp-bg-row' + (sub ? ' sub' : ''));
      var a = el('a'); a.textContent = trPlain(it.label); a.href = actionHref(it.action);
      var active = it.action.type === 'page' && it.action.target === PAGE.id;
      a.style.color = color(active ? p.activeColor : p.color) || '';
      if (active) a.setAttribute('aria-current', 'page');
      row.appendChild(a);
      host.appendChild(row);
      if (kids) {
        var tg = el('button', 'wp-bg-tg'); tg.type = 'button'; tg.setAttribute('aria-expanded', 'false'); tg.innerHTML = '<svg viewBox="0 0 10 6" width="12" height="8" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        var box = el('div', 'wp-bg-sub');
        kids.forEach(function (c) { addItem(c, box, true); });
        tg.onclick = function (ev) { ev.stopPropagation(); var on = row.classList.toggle('open'); tg.setAttribute('aria-expanded', on ? 'true' : 'false'); };
        row.appendChild(tg); host.appendChild(box);
      }
    };
    p.items.forEach(function (it) { addItem(it, panel, false); });
    var close = function () { e.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); };
    btn.onclick = function (ev) { ev.stopPropagation(); var on = e.classList.toggle('open'); btn.setAttribute('aria-expanded', on ? 'true' : 'false'); };
    panel.addEventListener('click', function (ev) { if (ev.target.tagName === 'A') close(); });
    document.addEventListener('click', function (ev) { if (!e.contains(ev.target)) close(); });
    document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
    e.appendChild(btn); e.appendChild(panel);
    return e;
  }

  function renderForm(o) {
    var p = o.props;
    var f = el('form', 'wp-o wp-form');
    f.noValidate = false;
    // uiterlijk per formulier: props.look = "strip" (dikke lijn + harde schaduw) en eigen kleuren/fonts
    if (p.look) f.classList.add('wp-form-' + p.look);
    [['ink', '--wpf-ink'], ['accent', '--wpf-accent'], ['fieldBg', '--wpf-bg'], ['textColor', '--wpf-text']].forEach(function (k) { var c = color(p[k[0]]); if (c) f.style.setProperty(k[1], c); });
    if (p.font) f.style.setProperty('--wpf-font', "'" + p.font + "', system-ui, sans-serif");
    if (p.labelFont) f.style.setProperty('--wpf-label', "'" + p.labelFont + "', system-ui, sans-serif");
    if (p.radius != null) f.style.setProperty('--wpf-r', p.radius + 'px');
    p.fields.forEach(function (fd) {
      if (fd.type === 'pickup') { f.appendChild(renderPickup(fd)); return; }   // afhaalpunt + kalender (site.json → "afhaal")
      if (fd.type === 'choice') { f.appendChild(renderChoice(fd)); return; }   // keuze als kaarten (bv. welk kratje)
      if (fd.type === 'qty') { f.appendChild(renderQty(fd)); return; }         // aantal met − en +
      if (fd.type === 'cart') { var cw = renderCartField(fd); f._cart = cw; f.appendChild(cw); return; }   // winkelmandje
      if (fd.type === 'select') {
        var ls = el('label'); ls.textContent = trPlain(fd.label);
        var se = el('select'); se.name = fd.name; se.required = !!fd.required;
        (fd.options || []).forEach(function (op) { se.add(new Option(trPlain(op.label), op.value)); });
        ls.appendChild(se); f.appendChild(ls); return;
      }
      var lab = el('label'); lab.textContent = trPlain(fd.label);
      var inp = fd.type === 'textarea' ? el('textarea') : el('input');
      if (fd.type !== 'textarea') inp.type = fd.type;
      inp.name = fd.name; inp.required = !!fd.required;
      lab.appendChild(inp); f.appendChild(lab);
    });
    var hp = el('input'); hp.name = 'website'; hp.tabIndex = -1; hp.autocomplete = 'off'; hp.className = 'wp-hp'; f.appendChild(hp);
    // vooraf invullen vanuit het adres: /bestellen?krat=klein&aantal=2 (veldnaam = parameter)
    try {
      var qs = new URLSearchParams(location.search);
      p.fields.forEach(function (fd) {
        var v = qs.get(fd.name); if (v == null) return;
        if (fd.type === 'choice' && fd.cart) {   // /bestellen?krat=klein legt dat krat één keer in het mandje en haalt de parameter weg
          if (!EDIT && (fd.options || []).some(function (op) { return op.value === v; })) { cartAdd(v, 1); qs.delete(fd.name); try { history.replaceState(null, '', location.pathname + (qs.toString() ? '?' + qs : '') + location.hash); } catch (e) {} }
          return;
        }
        var inp = f.querySelectorAll('[name="' + fd.name + '"]');
        [].forEach.call(inp, function (x) {
          if (x.type === 'radio') x.checked = x.value === v;
          else if (fd.type !== 'pickup') x.value = v;
          x.dispatchEvent(new Event('change', { bubbles: true }));
        });
      });
    } catch (e) {}
    // knop en melding op één regel: de melding neemt geen extra hoogte in, dus niets schuift over andere teksten
    var row = el('div', 'wp-form-row');
    var btn = el('button'); btn.type = 'submit'; btn.textContent = trPlain(p.submit);
    btn.style.background = color(p.accent);
    var msg = el('div', 'wp-form-msg'); msg.setAttribute('role', 'status'); msg.setAttribute('aria-live', 'polite');
    row.appendChild(btn); row.appendChild(msg); f.appendChild(row);
    // na versturen: het formulier maakt plaats voor een rustige bevestiging, binnen hetzelfde vak
    var done = el('div', 'wp-form-done');
    var tick = el('div', 'wp-form-tick'); tick.textContent = '\u2713'; tick.style.background = color(p.accent) || '#1b1b1b';
    var okTx = el('p'); var again = el('button', 'wp-form-again'); again.type = 'button';
    again.textContent = wpt('again');
    again.style.color = color(p.accent) || '#1b1b1b';
    again.onclick = function () { f.classList.remove('sent'); };
    done.appendChild(tick); done.appendChild(okTx); done.appendChild(again); f.appendChild(done);
    var label0 = btn.textContent, bg0 = btn.style.background;
    function say(t) { msg.textContent = t || ''; }
    // mislukt: de knop zelf zegt het (rood, "opnieuw proberen"), zodat er geen extra regel nodig is; de volledige tekst staat in de tooltip
    function fail() {
      btn.classList.add('err'); btn.style.background = '#b3261e'; btn.title = trPlain(p.error);
      btn.textContent = wpt('failBtn');
    }
    function unfail() { if (!btn.classList.contains('err')) return; btn.classList.remove('err'); btn.style.background = bg0; btn.textContent = label0; btn.title = ''; }
    f.addEventListener('input', unfail);
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (EDIT) return;
      if (window.WP_PREVIEW) { say('Voorbeeld: hier wordt niets verstuurd.'); return; }
      var data = {}; new FormData(f).forEach(function (v, k) { data[k] = v; });
      if (f._cart && !cartCount()) { say(stx('empty')); msg.classList.add('err'); return; }
      // props.requireOne = ["phone","email"]: minstens één ingevuld; anders een vriendelijke melding en focus op het eerste veld
      if (Array.isArray(p.requireOne) && p.requireOne.length && !p.requireOne.some(function (n) { return String(data[n] || '').trim() !== ''; })) {
        say(trPlain(p.requireOneMsg) || wpt('one'));
        msg.classList.add('err');
        var first = f.querySelector('[name="' + p.requireOne[0] + '"]'); if (first) first.focus();
        return;
      }
      msg.classList.remove('err');
      unfail(); btn.disabled = true; say('…');
      fetch(asset(SITE.site.api) + '?a=form', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ formId: p.formId, page: PAGE.id, lang: LANG, data: data }, f._cart ? f._cart._state() : {}))
      }).then(function (r) { return r.json(); }).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'fout');
        if (r.pay && r.pay.url) { say('…'); location.href = r.pay.url; return; }   // betaalprovider: door naar betalen
        if (f._cart) f._cart._clear();   // besteld: mandje leeg
        say(''); okTx.textContent = trPlain(p.ok); f.reset(); f.classList.add('sent');
        [].forEach.call(f.querySelectorAll('.wp-pick, .wp-qty'), function (w) { if (w._reset) w._reset(); });
      }).catch(function () { say(''); fail(); })
        .then(function () { btn.disabled = false; });
    });
    return f;
  }

  // ---------- keuze als kaarten (veldtype "choice"): options [{value, label, sub, img}] ----------
  function renderChoice(fd) {
    var w = el('div', 'wp-choice-wrap');
    var h = el('div', 'wp-choice-h'); h.textContent = trPlain(fd.label); w.appendChild(h);
    var row = el('div', 'wp-choice');
    (fd.options || []).forEach(function (op, i) {
      var lab = el('label', 'wp-choice-o');
      if (fd.cart) {   // webshop: een klik op de kaart legt 1 stuk in het mandje (geen keuzerondje)
        lab.classList.add('wp-choice-add'); lab.tabIndex = 0; lab.setAttribute('role', 'button');
        var go = function (ev) { ev.preventDefault(); if (EDIT) return; cartAdd(String(op.value), 1); lab.classList.add('added'); setTimeout(function () { lab.classList.remove('added'); }, 900); };
        lab.addEventListener('click', go); lab.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') go(ev); });
      } else {
        var r = el('input'); r.type = 'radio'; r.name = fd.name; r.value = op.value; if (fd.required && i === 0) r.required = true;
        lab.appendChild(r);
      }
      if (op.img) { var im = el('img'); im.src = asset(op.img); im.alt = ''; lab.appendChild(im); }
      var t = el('b'); t.textContent = trPlain(op.label); lab.appendChild(t);
      if (op.sub) { var sb = el('small'); sb.textContent = trPlain(op.sub); lab.appendChild(sb); }
      if (fd.cart) {
        var it = (((SITE.collections || {})[fd.collection || 'producten'] || {}).items || []).filter(function (x) { return x.sku === op.value || x.id === op.value; })[0];
        if (it && sellable(it)) { var pl = priceLine(it); pl.className = 'wp-choice-price'; lab.appendChild(pl); }
        var ad = el('span', 'wp-choice-btn'); ad.textContent = stx('add'); lab.appendChild(ad);
      }
      row.appendChild(lab);
    });
    w.appendChild(row);
    return w;
  }
  // ---------- aantal met − en + (veldtype "qty"): min, max, value ----------
  function renderQty(fd) {
    var min = fd.min == null ? 1 : fd.min, max = fd.max == null ? 10 : fd.max, start = fd.value == null ? min : fd.value;
    var w = el('div', 'wp-qty');
    var h = el('div', 'wp-choice-h'); h.textContent = trPlain(fd.label); w.appendChild(h);
    var row = el('div', 'wp-qty-row');
    var minus = el('button'); minus.type = 'button'; minus.textContent = '−'; minus.className = 'wp-qty-b';
    var inp = el('input'); inp.type = 'number'; inp.name = fd.name; inp.min = min; inp.max = max; inp.value = start; inp.required = !!fd.required; inp.className = 'wp-qty-v';
    var plus = el('button'); plus.type = 'button'; plus.textContent = '+'; plus.className = 'wp-qty-b';
    function set(n) { n = Math.max(min, Math.min(max, n | 0)); inp.value = n; minus.disabled = n <= min; plus.disabled = n >= max; }
    minus.onclick = function () { set(+inp.value - 1); }; plus.onclick = function () { set(+inp.value + 1); };
    inp.addEventListener('change', function () { set(+inp.value); });
    row.appendChild(minus); row.appendChild(inp); row.appendChild(plus); w.appendChild(row);
    w._reset = function () { set(start); };
    set(start);
    return w;
  }


  // ---------- webshop: mandje (bewaard in de browser), prijsweergave, mandje-veld in een formulier ----------
  // Het mandje bevat alleen SKU + aantal. Prijzen, btw en verzending rekent de server uit site.json (a=shop-quote / bij bestellen).
  var CART_KEY = 'wpcart:' + location.host, cartMem = [];
  function cartGet() {
    try { var j = JSON.parse(localStorage.getItem(CART_KEY) || 'null'); if (Array.isArray(j)) return j; } catch (e) {}
    return cartMem;
  }
  function cartSet(a) {
    cartMem = a; try { localStorage.setItem(CART_KEY, JSON.stringify(a)); } catch (e) {}
    window.dispatchEvent(new Event('wpcart'));
  }
  function cartCount() { return cartGet().reduce(function (n, l) { return n + (l.qty | 0); }, 0); }
  function cartAdd(sku, qty) {
    var a = cartGet().slice(), hit = a.filter(function (l) { return l.sku === sku; })[0];
    if (hit) hit.qty += qty; else a.push({ sku: sku, qty: qty });
    cartSet(a);
  }
  function eur(c, cur) { try { return new Intl.NumberFormat(locale(), { style: 'currency', currency: cur || (SITE.shop && SITE.shop.currency) || 'EUR' }).format(c / 100); } catch (e) { return (c / 100).toFixed(2); } }
  // ---------- teksten van de motor zelf, per taal ----------
  // Ingebouwd voor nl, en, de, fr. Elke andere taal (of een eigen formulering) zet de site in site.json → translations onder de sleutel "wp.<naam>",
  // bv. translations["wp.cart"] = {"nl": "Winkelmandje", "ar": "عربة التسوق"}. Volgorde: site → ingebouwd (taal) → Engels.
  var WPT = {
    nl: { menu: 'Menu', again: 'Nog een bericht sturen', failBtn: 'Niet gelukt · opnieuw', one: 'Vul minstens één manier in om je te bereiken.', none: 'Geen producten gevonden.', all: 'Alles', search: 'Zoeken…', nores: 'Niets gevonden', nf: 'Product niet gevonden.', sheet: 'Productblad (PDF)', sheetFail: 'Mislukt, probeer opnieuw', specs: 'Specificaties',
      add: 'In winkelmandje', added: 'Toegevoegd ✓', view: 'Naar winkelmandje', empty: 'Je winkelmandje is leeg.', total: 'Totaal', incl: 'incl. btw', excl: 'excl. btw', ship: 'Verzending', pickup: 'Afhalen', free: 'Gratis', remove: 'Verwijderen', vat: 'waarvan btw', cart: 'Winkelmandje', err: 'Het mandje kon niet worden uitgerekend.', how: 'Levering',
      pp: 'Kies je afhaalpunt…', near: 'Dichtbij mij', ppFirst: 'Kies eerst een afhaalpunt, dan zie je de dagen.', on: 'Afhalen op ', and: ' en ', today: 'Vandaag', soon: 'Te kort dag: we hebben {n} dagen nodig om je kratje klaar te zetten', busy: 'Deze dag is bezet', day: 'Kies deze dag', lgOpen: 'afhalen kan', lgFull: 'vol / niet mogelijk', lgOn: 'jouw keuze', noGeo: 'Je browser kan je locatie niet geven; kies hierboven.', geoNo: 'Locatie niet gedeeld; kies hierboven je afhaalpunt.', yes: 'Ja', no: 'Nee' },
    en: { menu: 'Menu', again: 'Send another message', failBtn: 'Failed · try again', one: 'Please fill in at least one way to reach you.', none: 'No products found.', all: 'All', search: 'Search…', nores: 'No results', nf: 'Product not found.', sheet: 'Product sheet (PDF)', sheetFail: 'Failed, try again', specs: 'Specifications',
      add: 'Add to cart', added: 'Added ✓', view: 'View cart', empty: 'Your cart is empty.', total: 'Total', incl: 'incl. VAT', excl: 'excl. VAT', ship: 'Shipping', pickup: 'Pick-up', free: 'Free', remove: 'Remove', vat: 'of which VAT', cart: 'Cart', err: 'The cart could not be calculated.', how: 'Delivery',
      pp: 'Choose a pickup point…', near: 'Near me', ppFirst: 'Choose a pickup point first.', on: 'Pickup on ', and: ' & ', today: 'Today', soon: 'Too soon', busy: 'Not available', day: 'Choose this day', lgOpen: 'available', lgFull: 'full', lgOn: 'your choice', noGeo: 'Location not available.', geoNo: 'Location not shared.', yes: 'Yes', no: 'No' },
    de: { menu: 'Menü', again: 'Noch eine Nachricht senden', failBtn: 'Fehler · nochmal', one: 'Bitte gib mindestens einen Weg an, dich zu erreichen.', none: 'Keine Produkte gefunden.', all: 'Alle', search: 'Suchen…', nores: 'Nichts gefunden', nf: 'Produkt nicht gefunden.', sheet: 'Datenblatt (PDF)', sheetFail: 'Fehlgeschlagen', specs: 'Spezifikationen',
      add: 'In den Warenkorb', added: 'Hinzugefügt ✓', view: 'Zum Warenkorb', empty: 'Dein Warenkorb ist leer.', total: 'Gesamt', incl: 'inkl. MwSt.', excl: 'zzgl. MwSt.', ship: 'Versand', pickup: 'Abholung', free: 'Kostenlos', remove: 'Entfernen', vat: 'davon MwSt.', cart: 'Warenkorb', err: 'Der Warenkorb konnte nicht berechnet werden.', how: 'Lieferung',
      pp: 'Abholort wählen…', near: 'In meiner Nähe', ppFirst: 'Wähle zuerst einen Abholort.', on: 'Abholung am ', and: ' und ', today: 'Heute', soon: 'Zu kurzfristig', busy: 'Nicht verfügbar', day: 'Diesen Tag wählen', lgOpen: 'verfügbar', lgFull: 'voll', lgOn: 'deine Wahl', noGeo: 'Standort nicht verfügbar.', geoNo: 'Standort nicht geteilt.', yes: 'Ja', no: 'Nein' },
    fr: { menu: 'Menu', again: 'Envoyer un autre message', failBtn: 'Échec · réessayer', one: 'Indiquez au moins un moyen de vous joindre.', none: 'Aucun produit trouvé.', all: 'Tout', search: 'Rechercher…', nores: 'Aucun résultat', nf: 'Produit introuvable.', sheet: 'Fiche produit (PDF)', sheetFail: 'Échec, réessayez', specs: 'Caractéristiques',
      add: 'Ajouter au panier', added: 'Ajouté ✓', view: 'Voir le panier', empty: 'Votre panier est vide.', total: 'Total', incl: 'TVA incluse', excl: 'hors TVA', ship: 'Livraison', pickup: 'Retrait', free: 'Gratuit', remove: 'Supprimer', vat: 'dont TVA', cart: 'Panier', err: 'Le panier n’a pas pu être calculé.', how: 'Livraison',
      pp: 'Choisir un point de retrait…', near: 'Près de moi', ppFirst: 'Choisissez d’abord un point de retrait.', on: 'Retrait le ', and: ' et ', today: 'Aujourd’hui', soon: 'Trop tôt', busy: 'Indisponible', day: 'Choisir ce jour', lgOpen: 'disponible', lgFull: 'complet', lgOn: 'votre choix', noGeo: 'Position indisponible.', geoNo: 'Position non partagée.', yes: 'Oui', no: 'Non' }
  };
  function wpt(k) {
    var o = SITE.translations && SITE.translations['wp.' + k];
    if (o && typeof o === 'object' && typeof o[LANG] === 'string' && o[LANG] !== '') return o[LANG];
    var d = WPT[LANG] && WPT[LANG][k];
    return d !== undefined ? d : (WPT.en[k] !== undefined ? WPT.en[k] : k);
  }
  function stx(k) { return wpt(k); }
  // datum en getal in de taal van de bezoeker (de browser kent de talen zelf)
  function locale() { return LANG === 'nl' ? 'nl-NL' : LANG === 'en' ? 'en-GB' : LANG; }
  // rechts-naar-links: talen uit de standaardlijst, of eigen lijst in site.site.rtl (bv. ["ar"]). In de editor altijd links-naar-rechts (de editor werkt op het ontwerp).
  var RTL_LANGS = ['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'yi', 'ckb', 'ug', 'dv'];
  function rtl() { return !EDIT && ((SITE.site && Array.isArray(SITE.site.rtl)) ? SITE.site.rtl : RTL_LANGS).indexOf(String(LANG).split('-')[0]) >= 0; }
  function maand(i) { try { return new Date(2000, i, 1).toLocaleDateString(locale(), { month: 'short' }); } catch (e) { return String(i + 1); } }
  function dagnaam(i, long) { try { return new Date(2023, 0, 1 + i).toLocaleDateString(locale(), { weekday: long ? 'long' : 'short' }); } catch (e) { return String(i); } }
  function shopCartHref() { var pg = SITE.shop && SITE.shop.cartPage; return pg && pageById(pg) ? urlFor(pg) : null; }
  function sellable(it) { return !!(SITE.shop && it && it.price && typeof it.price.amount === 'number' && !(it.sell && it.sell.online === false) && it.active !== false); }
  // prijs bij een product (zoals opgeslagen; de bezoeker ziet wat in site.shop.priceDisplay staat)
  function priceLine(it) {
    var pr = it.price, rate = (SITE.shop.vat || {})[pr.vat || 'hoog'] || 0, want = (SITE.shop.priceDisplay || 'incl') === 'incl';
    var a = pr.amount; if (!!pr.incl !== want) a = pr.incl ? Math.round(a / (1 + rate / 100)) : Math.round(a * (1 + rate / 100));
    var d = el('div', 'wp-cd-price'); d.textContent = eur(a, pr.currency) + ' '; var sm = el('small'); sm.textContent = want ? stx('incl') : stx('excl'); d.appendChild(sm);
    return d;
  }
  function addToCartBlock(it) {
    var sell = it.sell || {}, min = sell.min || 1, step = sell.step || 1, max = sell.max || 999;
    var box = el('div', 'wp-addcart'), q = el('input'); q.type = 'number'; q.min = min; q.max = max; q.step = step; q.value = min; q.className = 'wp-addcart-q'; q.setAttribute('aria-label', 'aantal');
    var b = el('button', 'wp-addcart-b'); b.type = 'button'; b.textContent = stx('add');
    var go = el('a', 'wp-addcart-go'); go.textContent = stx('view'); go.style.display = 'none'; var href = shopCartHref();
    if (href) { go.href = href; go.addEventListener('click', function (ev) { ev.preventDefault(); navigate(href); }); }
    b.addEventListener('click', function () {
      if (EDIT) return;
      var n = Math.max(min, Math.min(max, parseInt(q.value, 10) || min)); q.value = n;
      cartAdd(String(it.sku || it.id), n); b.textContent = stx('added'); if (href) go.style.display = '';
      setTimeout(function () { b.textContent = stx('add'); }, 1800);
    });
    box.appendChild(q); box.appendChild(b); box.appendChild(go);
    return box;
  }
  // symbool met aantal (props.page = pagina met het mandje; anders site.shop.cartPage)
  function renderCartLink(o) {
    var p = o.props || {}, a = el('a', 'wp-o wp-cartlink'), href = null, pg = p.page || (SITE.shop && SITE.shop.cartPage);
    if (pg && pageById(pg)) href = urlFor(pg);
    a.setAttribute('aria-label', stx('cart'));
    var ic = el('span', 'wp-cartlink-i'); ic.textContent = '🛒'; a.appendChild(ic);
    var n = el('span', 'wp-cartlink-n'); a.appendChild(n);
    function upd() { var c = cartCount(); n.textContent = c; n.style.display = c ? '' : 'none'; }
    window.addEventListener('wpcart', upd); upd();
    if (href) { a.href = href; a.addEventListener('click', function (ev) { ev.preventDefault(); if (!EDIT) navigate(href); }); }
    return a;
  }
  // veldtype "cart" in een formulier: regels, aantallen, levering en totaal; w._state() geeft {cart, fulfilment}
  function renderCartField(fd) {
    var w = el('div', 'wp-cart'), list = el('div', 'wp-cart-list'), how = el('div', 'wp-cart-how'), tot = el('div', 'wp-cart-tot');
    w.appendChild(list); w.appendChild(how); w.appendChild(tot);
    var fu = (SITE.shop && SITE.shop.fulfilment) || [], chosen = fu.length ? fu[0].id : '', seq = 0;
    if (fu.length > 1) {
      var h = el('div', 'wp-choice-h'); h.textContent = stx('how'); how.appendChild(h);
      fu.forEach(function (f, i) {
        var lab = el('label', 'wp-cart-f'), r = el('input'); r.type = 'radio'; r.name = '_fulfil'; r.value = f.id; r.checked = i === 0;
        r.addEventListener('change', function () { chosen = f.id; refresh(); });
        var t = el('span'); t.textContent = f.label ? trPlain(f.label) : (f.kind === 'pickup' ? stx('pickup') : stx('ship'));
        lab.appendChild(r); lab.appendChild(t); how.appendChild(lab);
      });
    }
    function row(a, b, cls) { var r = el('div', 'wp-cart-r' + (cls ? ' ' + cls : '')), x = el('span'), y = el('span'); x.textContent = a; y.textContent = b; r.appendChild(x); r.appendChild(y); return r; }
    function setQty(sku, n) { cartSet(cartGet().map(function (l) { return l.sku === sku ? { sku: sku, qty: n } : l; }).filter(function (l) { return l.qty > 0; })); }
    function refresh() {
      var mine = ++seq, c = cartGet();
      if (!c.length) { list.textContent = ''; tot.textContent = ''; var e = el('p', 'wp-cart-empty'); e.textContent = stx('empty'); list.appendChild(e); how.style.display = 'none'; return; }
      how.style.display = '';
      fetch(asset(SITE.site.api) + '?a=shop-quote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cart: c, fulfilment: chosen, collection: (fd.collection || 'producten') }) })
        .then(function (r) { return r.json(); }).then(function (q) {
          if (mine !== seq) return;
          list.textContent = ''; tot.textContent = '';
          if (!q.ok) {                                                  // bv. een artikel is niet meer te koop: haal het uit het mandje
            var bad = String(q.error || '').split(':')[1];
            if (bad && /^(unknown|notforsale|noprice|currency)/.test(q.error)) { cartSet(cartGet().filter(function (l) { return l.sku !== bad; })); return; }
            var m = el('p', 'wp-cart-empty'); m.textContent = stx('err') + ' (' + q.error + ')'; list.appendChild(m); return;
          }
          if (q.empty) { refresh(); return; }
          q.lines.forEach(function (l) {
            var r = el('div', 'wp-cart-line'), nm = el('div', 'wp-cart-nm'), nb = el('b'), sk = el('small');
            nb.textContent = cv(l.name); sk.textContent = l.sku; nm.appendChild(nb); nm.appendChild(sk);
            var qt = el('div', 'wp-cart-q'), mi = el('button'), pl = el('button'), v = el('span');
            mi.type = pl.type = 'button'; mi.textContent = '−'; pl.textContent = '+'; v.textContent = l.qty; mi.className = pl.className = 'wp-qty-b';
            var it = (((SITE.collections || {})[fd.collection || 'producten'] || {}).items || []).filter(function (x) { return x.sku === l.sku || x.id === l.sku; })[0] || {}, sl = it.sell || {}, st = sl.step || 1;
            mi.onclick = function () { setQty(l.sku, l.qty - st < (sl.min || 1) ? 0 : l.qty - st); };
            pl.onclick = function () { setQty(l.sku, Math.min(sl.max || 999, l.qty + st)); };
            qt.appendChild(mi); qt.appendChild(v); qt.appendChild(pl);
            var pr = el('div', 'wp-cart-p'); pr.textContent = eur(l.gross, q.currency);
            var x = el('button', 'wp-cart-x'); x.type = 'button'; x.textContent = '×'; x.title = stx('remove'); x.setAttribute('aria-label', stx('remove')); x.onclick = function () { setQty(l.sku, 0); };
            r.appendChild(nm); r.appendChild(qt); r.appendChild(pr); r.appendChild(x); list.appendChild(r);
          });
          var sh = q.shipping;
          if (sh && sh.id) tot.appendChild(row(sh.kind === 'pickup' ? stx('pickup') : stx('ship'), sh.gross ? eur(sh.gross, q.currency) : stx('free')));
          tot.appendChild(row(stx('total') + ' (' + stx('incl') + ')', eur(q.totals.gross, q.currency), 'wp-cart-sum'));
          tot.appendChild(row(stx('vat'), eur(q.totals.vat, q.currency), 'wp-cart-vat'));
        }).catch(function () { if (mine !== seq) return; list.textContent = ''; var m = el('p', 'wp-cart-empty'); m.textContent = stx('err'); list.appendChild(m); });
    }
    window.addEventListener('wpcart', refresh);
    w._state = function () { return { cart: cartGet(), fulfilment: chosen }; };
    w._clear = function () { cartSet([]); };
    refresh();
    return w;
  }

  // ---------- afhaalpunt + kalender (veldtype "pickup" in een formulier) ----------
  // Gegevens: site.json → "afhaal": { lead: 2, weeks: 6, radius: 5, places: [{id, plaats, provincie, lat, lng, actief, dagen:["za"], tijd, plek}],
  //                                   blocked: [{place: "<id>" | "*", date: "2026-11-14", reden}] }
  // Waarde in het formulier: "<id>|<datum>"; de server controleert alles opnieuw (actief, dag, niet geblokkeerd, op tijd).
  var DAGNR = { zo: 0, ma: 1, di: 2, wo: 3, do: 4, vr: 5, za: 6 };
  var DAGKORT = ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'];   // codes zoals ze in site.json staan (afhaal.dagen); weergave via dagnaam()
  function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function kmTussen(a, b, c, d) {
    var R = 6371, r = Math.PI / 180, x = Math.sin((c - a) * r / 2), y = Math.sin((d - b) * r / 2);
    return 2 * R * Math.asin(Math.sqrt(x * x + Math.cos(a * r) * Math.cos(c * r) * y * y));
  }
  function renderPickup(fd) {
    var A = SITE.afhaal || {}, places = (A.places || []).filter(function (q) { return q.actief !== false; });
    var lead = A.lead == null ? 2 : A.lead, weeks = A.weeks || 6, radius = A.radius || 5;
    var w = el('div', 'wp-pick'), cur = null, pickDate = null;
    var head = el('div', 'wp-pick-h'); head.textContent = trPlain(fd.label); w.appendChild(head);
    var hidden = el('input'); hidden.type = 'text'; hidden.name = fd.name; hidden.required = !!fd.required; hidden.className = 'wp-pick-val';
    hidden.tabIndex = -1; hidden.setAttribute('aria-hidden', 'true'); w.appendChild(hidden);
    var bar = el('div', 'wp-pick-bar');
    var sel = el('select'); sel.add(new Option(wpt('pp'), ''));
    var byProv = {};
    places.forEach(function (q) { (byProv[q.provincie || ''] = byProv[q.provincie || ''] || []).push(q); });
    Object.keys(byProv).sort().forEach(function (pv) {
      var g = el('optgroup'); g.label = pv || '—';
      byProv[pv].sort(function (a, b) { return a.plaats.localeCompare(b.plaats); }).forEach(function (q) { g.appendChild(new Option(q.plaats, q.id)); });
      sel.appendChild(g);
    });
    var geo = el('button', 'wp-pick-geo'); geo.type = 'button'; geo.textContent = '📍 ' + wpt('near');
    bar.appendChild(sel); bar.appendChild(geo); w.appendChild(bar);
    var info = el('div', 'wp-pick-info'); w.appendChild(info);
    var cal = el('div', 'wp-pick-cal'); w.appendChild(cal);
    var chosen = el('div', 'wp-pick-chosen'); w.appendChild(chosen);
    function blocked(id, d) {
      return (A.blocked || []).filter(function (b) { return (b.place === '*' || b.place === id) && b.date === d; })[0] || null;
    }
    function setVal() {
      hidden.value = cur && pickDate ? cur.id + '|' + pickDate : '';
      if (cur && pickDate) {
        var d = new Date(pickDate + 'T12:00:00');
        // tijd: staat er per dag een tijd ("wo 17:00–18:30 · za 10:00–12:00"), toon dan alleen die van de gekozen dag
        var tijd = cur.tijd || '', dk = DAGKORT[d.getDay()], dkTxt = dagnaam(d.getDay());
        tijd.split(/\s*[·,;]\s*/).some(function (seg) { var m = new RegExp('^' + dk + '\\b\\s*(.+)$', 'i').exec(seg.trim()); if (m) { tijd = m[1]; return true; } });
        chosen.textContent = '✓ ' + cur.plaats + ' · ' + dkTxt + ' ' + d.getDate() + ' ' + maand(d.getMonth()) + (tijd ? ' · ' + tijd : '');
      } else chosen.textContent = '';
      hidden.dispatchEvent(new Event('input', { bubbles: true }));
    }
    function drawCal() {
      cal.innerHTML = ''; info.textContent = '';
      if (!cur) { cal.textContent = wpt('ppFirst'); cal.className = 'wp-pick-cal empty'; return; }
      cal.className = 'wp-pick-cal';
      var dagenTxt = (cur.dagen || []).map(function (x) { return DAGNR[x] !== undefined ? dagnaam(DAGNR[x], true) : x; });
      dagenTxt = dagenTxt.length > 1 ? dagenTxt.slice(0, -1).join(', ') + wpt('and') + dagenTxt[dagenTxt.length - 1] : dagenTxt.join('');
      info.textContent = (cur.plek ? cur.plek + ' · ' : '') + (cur.tijd ? cur.tijd : wpt('on') + dagenTxt);
      var days = (cur.dagen || []).map(function (x) { return DAGNR[x]; });
      var now = new Date(); now.setHours(12, 0, 0, 0);
      var first = new Date(now); first.setDate(first.getDate() + lead);
      // begin bij de week van de eerste dag waarop afhalen kan (geen rij vol voorbije dagen)
      var start = new Date(first); start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
      var last = new Date(start); last.setDate(start.getDate() + weeks * 7 - 1);
      var MLANG = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
      var title = el('div', 'wp-pick-mh');
      var tt = MLANG[start.getMonth()] + (start.getMonth() !== last.getMonth() ? ' – ' + MLANG[last.getMonth()] : '') + ' ' + last.getFullYear();
      title.textContent = tt.charAt(0).toUpperCase() + tt.slice(1);
      cal.appendChild(title);
      ['ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'].forEach(function (x) { var c = el('div', 'wp-pick-dn'); c.textContent = x; cal.appendChild(c); });
      for (var i = 0; i < weeks * 7; i++) {
        var d = new Date(start); d.setDate(start.getDate() + i);
        var key = ymd(d), b = blocked(cur.id, key);
        if (d < now && ymd(d) !== ymd(now)) { cal.appendChild(el('div', 'wp-pick-d past')); continue; }   // voorbij: lege plek
        var c = el('button', 'wp-pick-d'); c.type = 'button'; c.textContent = d.getDate();
        if (d.getDate() === 1 || i === 0) { var m = el('small'); m.textContent = maand(d.getMonth()); c.appendChild(m); }
        if (ymd(d) === ymd(now)) { c.classList.add('today'); c.title = wpt('today'); }
        var open = days.indexOf(d.getDay()) >= 0 && d >= first && !b;
        if (days.indexOf(d.getDay()) < 0 || d < first) c.classList.add('off');
        if (days.indexOf(d.getDay()) >= 0 && d < first) c.title = wpt('soon').replace('{n}', lead);
        if (b && days.indexOf(d.getDay()) >= 0 && d >= first) { c.classList.add('full'); c.title = b.reden || wpt('busy'); }
        if (open) { c.classList.add('open'); c.title = wpt('day'); }
        if (key === pickDate) c.classList.add('on');
        c.disabled = !open;
        (function (k) { c.onclick = function () { pickDate = k; setVal(); drawCal(); }; })(key);
        cal.appendChild(c);
      }
      // uitleg onder de kalender
      var lg = el('div', 'wp-pick-legend');
      lg.innerHTML = '<span><i class="lg-open"></i>' + wpt('lgOpen') + '</span>'
        + ((A.blocked || []).some(function (x) { return x.place === '*' || x.place === cur.id; }) ? '<span><i class="lg-full"></i>' + wpt('lgFull') + '</span>' : '')
        + '<span><i class="lg-on"></i>' + wpt('lgOn') + '</span>';
      cal.appendChild(lg);
    }
    sel.onchange = function () { cur = places.filter(function (q) { return q.id === sel.value; })[0] || null; pickDate = null; setVal(); drawCal(); };
    geo.onclick = function () {
      if (!navigator.geolocation) { info.textContent = wpt('noGeo'); return; }
      info.textContent = '…';
      navigator.geolocation.getCurrentPosition(function (pos) {
        var best = null, bk = 1e9;
        places.forEach(function (q) { var k = kmTussen(pos.coords.latitude, pos.coords.longitude, q.lat, q.lng); if (k < bk) { bk = k; best = q; } });
        if (!best) return;
        sel.value = best.id; sel.onchange();
        info.textContent = (bk <= radius ? '📍 ' + best.plaats + ' ligt op ' : '📍 Nog geen afhaalpunt binnen ' + radius + ' km. Dichtstbij: ' + best.plaats + ', ') + bk.toFixed(1).replace('.', ',') + ' km. ' + info.textContent;
      }, function () { info.textContent = wpt('geoNo'); }, { timeout: 8000, maximumAge: 600000 });
    };
    w._reset = function () { cur = null; pickDate = null; sel.value = ''; setVal(); drawCal(); };
    drawCal();
    return w;
  }

  // taalkeuze (was de actor WPLanguage)
  function renderLanguage(o) {
    var e = el('div', 'wp-o wp-language');
    var p = o.props || {};
    if (o.surface) applySurface(e, o.surface);
    e.style.fontSize = (p.size || 12) + 'px';
    if ((p.flags || p.collapse) && SITE.site.languages.length > 1) { e.appendChild(langSwitch(p)); return e; }   // vlaggetjes en/of uitklap
    SITE.site.languages.forEach(function (l) {
      var a = el('a'); a.textContent = l.toUpperCase(); a.href = urlFor(PAGE.id, l);
      a.style.color = color(p.color) || 'inherit';
      if (l === LANG) a.className = 'on';
      e.appendChild(a);
    });
    return e;
  }

  // ---------- module video: eigen speler (mp4) of YouTube (privacy-modus) ----------
  var ICON_PLAY = '<svg viewBox="0 0 24 24" width="28" height="28"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>';
  var ICON_PAUSE = '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="currentColor"/></svg>';
  var ICON_SOUND = '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7" stroke="currentColor" stroke-width="2" fill="none"/></svg>';
  var ICON_MUTE = '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 9l5 6M21 9l-5 6" stroke="currentColor" stroke-width="2"/></svg>';
  function renderVideo(o) {
    var p = o.props || {}, e = el('div', 'wp-o wp-video');
    var sfv = surfaceOf(o); if (sfv) applySurface(e, sfv);
    var accent = color(p.accent) || '#ffffff';
    if (p.youtube) {
      var f = el('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(p.youtube) + '?rel=0&modestbranding=1';
      f.title = trPlain(p.title) || 'video'; f.allow = 'accelerometer; autoplay; encrypted-media; picture-in-picture'; f.allowFullscreen = true;
      f.loading = 'lazy'; e.appendChild(f); return e;
    }
    var v = el('video');
    v.src = asset(p.src); if (p.poster) v.poster = asset(p.poster);
    v.playsInline = true; v.preload = 'metadata'; v.loop = !!p.loop; v.muted = p.muted !== false;
    v.style.objectFit = ({ fit: 'contain', fill: 'fill', crop: 'cover' })[p.fit || 'crop'];
    if (p.autoplay && !EDIT) { v.muted = true; v.autoplay = true; }
    e.appendChild(v);
    var play = el('button', 'wp-video-play'); play.type = 'button'; play.innerHTML = ICON_PLAY; play.style.background = accent;
    play.setAttribute('aria-label', 'Afspelen');
    var bar = el('div', 'wp-video-bar'), fillBar = el('div'); fillBar.style.background = accent; bar.appendChild(fillBar);
    var mute = el('button', 'wp-video-mute'); mute.type = 'button'; mute.innerHTML = v.muted ? ICON_MUTE : ICON_SOUND;
    mute.setAttribute('aria-label', 'Geluid');
    if (p.title) { var cap = el('div', 'wp-video-title'); cap.textContent = trPlain(p.title); e.appendChild(cap); }
    e.appendChild(play); e.appendChild(bar); e.appendChild(mute);
    function sync() { e.classList.toggle('playing', !v.paused); play.innerHTML = v.paused ? ICON_PLAY : ICON_PAUSE; }
    if (!EDIT) {
      e.addEventListener('click', function (ev) {
        if (ev.target.closest('.wp-video-mute') || ev.target.closest('.wp-video-bar')) return;
        if (v.paused) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () { e.classList.add('error'); }); } else v.pause();
      });
      mute.addEventListener('click', function () { v.muted = !v.muted; mute.innerHTML = v.muted ? ICON_MUTE : ICON_SOUND; });
      bar.addEventListener('click', function (ev) { var r = bar.getBoundingClientRect(); if (v.duration) v.currentTime = (ev.clientX - r.left) / r.width * v.duration; });
      v.addEventListener('play', sync); v.addEventListener('pause', sync);
      v.addEventListener('timeupdate', function () { fillBar.style.width = (v.duration ? v.currentTime / v.duration * 100 : 0) + '%'; });
    }
    return e;
  }


  // ---------- modules: collecties (neutraal; de data en de veldbeschrijving staan in site.json → collections) ----------
  function coll(name) { return SITE.collections && SITE.collections[name]; }
  function cv(v) {                       // waarde per taal: object {nl,en,de} of platte waarde (geen vertaalsleutel-opzoeking)
    if (v === undefined || v === null) return '';
    if (Array.isArray(v)) return v.map(cv).join(', ');
    if (typeof v === 'object') return v[LANG] !== undefined && v[LANG] !== '' ? v[LANG] : (v[SITE.site.defaultLanguage] || '');
    return String(v);
  }
  function cget(o, path) { return String(path).split('.').reduce(function (a, k) { return a == null ? a : a[k]; }, o); }
    function cfmt(f, v) {                  // veldwaarde → tekst (null = niet tonen)
    if (v === undefined || v === null || v === '') return null;
    if (f.type === 'bool') return wpt(v ? 'yes' : 'no');
    if (f.type === 'number' && typeof v === 'number') return v.toLocaleString(locale()) + (f.unit ? ' ' + f.unit : '');
    var t = cv(v); return t === '' ? null : t + (f.unit && f.type !== 'text' ? ' ' + f.unit : '');
  }
  function cfield(c, key) { return (c.fields || []).filter(function (f) { return f.key === key; })[0]; }
  function cgroup(c, kind, id) { return ((c.groups || {})[kind] || []).filter(function (g) { return g.id === id; })[0]; }
  function cimg(it) { var l = it.images || []; return l.filter(function (i) { return i.primary; })[0] || l[0] || null; }
  function cfilter(c, f) {
    f = f || {};
    return (c.items || []).filter(function (it) {
      if (f.active !== false && it.active === false) return false;
      if (f.division && it.division !== f.division) return false;
      if (f.categories && !(it.categories || []).some(function (k) { return f.categories.indexOf(k) >= 0; })) return false;
      if (f.ids && f.ids.indexOf(it.id) < 0) return false;
      return true;
    });
  }
  function csort(c, list, how) {
    var o = {}; ((c.groups || {}).categories || []).forEach(function (g) { o[g.id] = g.order; });
    return list.slice().sort(function (a, b) {
      if (how === 'name') return cv(a.name).localeCompare(cv(b.name), LANG, { numeric: true });
      if (how === 'sku') return String(a.sku).localeCompare(String(b.sku), 'en', { numeric: true });
      var ka = o[(a.categories || [])[0]] || 999, kb = o[(b.categories || [])[0]] || 999;
      return ka - kb || String(a.sku).localeCompare(String(b.sku), 'en', { numeric: true });
    });
  }
  function cshell(o, cls) {
    var p = o.props || {};
    var e = el('div', 'wp-o wp-coll wp-grow ' + cls);
    var ac = color(p.accent) || color('@rood') || '#8E0B0B';
    e.style.setProperty('--wpc-accent', ac);
    if (p.font) e.style.setProperty('--wpc-font', "'" + p.font + "', system-ui, sans-serif");
    if (p.radius != null) e.style.setProperty('--wpc-r', p.radius + 'px');
    var inner = el('div', 'wp-coll-in'); e.appendChild(inner);
    if (EDIT) e.style.overflow = 'auto';
    return { e: e, inner: inner, p: p, ac: ac };
  }
  function cgo(p, id) { if (EDIT) return; navigate(urlFor(p.detailPage || 'product') + '?id=' + encodeURIComponent(id)); }
  function cmissing(inner, name) { inner.innerHTML = ''; var m = el('div', 'wp-coll-empty'); m.textContent = 'collectie "' + name + '" niet gevonden'; inner.appendChild(m); }

  function renderCollGrid(o) {
    var S = cshell(o, 'wp-cgrid'), p = S.p, c = coll(p.collection);
    if (!c) { cmissing(S.inner, p.collection); return S.e; }
    var base = cfilter(c, p.filter), cat = '', q = '';
    var bar = el('div', 'wp-coll-bar'), grid = el('div', 'wp-coll-cards');
    grid.style.gridTemplateColumns = 'repeat(auto-fill,minmax(' + (p.minCard || 260) + 'px,1fr))';
    if (p.columns) grid.style.gridTemplateColumns = 'repeat(' + p.columns + ',minmax(0,1fr))';
    if (p.gap != null) grid.style.gap = p.gap + 'px';
    S.inner.appendChild(bar); S.inner.appendChild(grid);
    function draw() {
      grid.innerHTML = '';
      var list = base.filter(function (it) { return (!cat || (it.categories || []).indexOf(cat) >= 0) && (!q || (cv(it.name) + ' ' + it.sku).toLowerCase().indexOf(q) >= 0); });
      list = csort(c, list, p.sort);
      if (p.limit) list = list.slice(0, p.limit);
      if (!list.length) { var m = el('div', 'wp-coll-empty'); m.textContent = cv(p.empty) || wpt('none'); grid.appendChild(m); }
      list.forEach(function (it) {
        var d = el('div', 'wp-card'); d.dataset.id = it.id;
        var im = cimg(it), box = el('div', 'wp-card-img');
        if (p.imageRatio) box.style.aspectRatio = String(p.imageRatio).replace(':', ' / ');
        if (im) { var i = el('img'); i.src = asset(im.src); i.alt = cv(im.alt) || cv(it.name); i.loading = 'lazy'; if (p.imageFit === 'crop') i.style.objectFit = 'cover'; box.appendChild(i); }
        else box.classList.add('empty');
        d.appendChild(box);
        var b = el('div', 'wp-card-b');
        var sk = el('div', 'wp-card-sku'); sk.textContent = it.sku; b.appendChild(sk);
        var t = el('div', 'wp-card-t'); t.textContent = cv(it.name); b.appendChild(t);
        if (p.showText !== false && it.description) { var x = el('div', 'wp-card-x'); x.textContent = cv(it.description); b.appendChild(x); }
        (p.showFields || []).forEach(function (k) {
          var f = cfield(c, k) || { key: k, type: 'text' }, v = cfmt(f, cget(it, k)); if (v === null) return;
          var r = el('div', 'wp-card-f'); r.textContent = (f.label ? cv(f.label) + ': ' : '') + v; b.appendChild(r);
        });
        d.appendChild(b);
        d.addEventListener('click', function () { cgo(p, it.id); });
        grid.appendChild(d);
      });
    }
    var cats = ((c.groups || {}).categories || []).filter(function (g) { return base.some(function (it) { return (it.categories || []).indexOf(g.id) >= 0; }); });
    if (Array.isArray(p.chips)) cats = p.chips.map(function (id) { return cats.filter(function (g) { return g.id === id; })[0]; }).filter(Boolean);   // props.chips = welke categorieën als filterknop (en in welke volgorde)
    if (p.filters && cats.length > 1) {
      var all = el('button', 'wp-chip on'); all.type = 'button'; all.textContent = wpt('all'); bar.appendChild(all);
      var chips = [all];
      cats.forEach(function (g) {
        var b = el('button', 'wp-chip'); b.type = 'button'; b.textContent = cv(g.name).split(' — ').pop(); bar.appendChild(b); chips.push(b);
        b.addEventListener('click', function () { cat = g.id; chips.forEach(function (x) { x.classList.toggle('on', x === b); }); draw(); });
      });
      all.addEventListener('click', function () { cat = ''; chips.forEach(function (x) { x.classList.toggle('on', x === all); }); draw(); });
    }
    if (p.search) {
      var inp = el('input', 'wp-coll-search'); inp.type = 'search'; inp.placeholder = wpt('search');
      inp.addEventListener('input', function () { q = inp.value.trim().toLowerCase(); draw(); }); bar.appendChild(inp);
    }
    if (!bar.children.length) bar.style.display = 'none';
    draw();
    return S.e;
  }

  function renderCollList(o) {
    var S = cshell(o, 'wp-clist'), p = S.p, c = coll(p.collection);
    if (!c) { cmissing(S.inner, p.collection); return S.e; }
    var cols = p.columns || ['sku', 'name'];
    var tb = el('table'), th = el('thead'), tr1 = el('tr');
    var LBL = { sku: { nl: 'Artikel', en: 'Item', de: 'Artikel', fr: 'Article' }, name: { nl: 'Naam', en: 'Name', de: 'Name', fr: 'Nom' }, division: { nl: 'Divisie', en: 'Division', de: 'Bereich', fr: 'Division' }, category: { nl: 'Categorie', en: 'Category', de: 'Kategorie', fr: 'Catégorie' } };
    cols.forEach(function (k) { var h = el('th'); var f = cfield(c, k); h.textContent = cv(f ? f.label : LBL[k] || k); tr1.appendChild(h); });
    th.appendChild(tr1); tb.appendChild(th);
    var body = el('tbody'); tb.appendChild(body);
    csort(c, cfilter(c, p.filter), p.sort).forEach(function (it) {
      var r = el('tr'); r.addEventListener('click', function () { cgo(p, it.id); });
      cols.forEach(function (k) {
        var td = el('td'), f = cfield(c, k), v;
        if (k === 'sku') v = it.sku; else if (k === 'name') v = cv(it.name);
        else if (k === 'division') { var g = cgroup(c, 'divisions', it.division); v = g ? cv(g.name) : ''; }
        else if (k === 'category') { var g2 = cgroup(c, 'categories', (it.categories || [])[0]); v = g2 ? cv(g2.name) : ''; }
        else v = cfmt(f || { type: 'text' }, cget(it, k));
        td.textContent = v === null || v === undefined ? '–' : v; r.appendChild(td);
      });
      body.appendChild(r);
    });
    var wrap = el('div', 'wp-clist-wrap'); wrap.appendChild(tb); S.inner.appendChild(wrap);
    return S.e;
  }

  function renderCollDetail(o) {
    var S = cshell(o, 'wp-cdetail'), p = S.p, c = coll(p.collection);
    if (!c) { cmissing(S.inner, p.collection); return S.e; }
    var want = (new URLSearchParams(location.search).get('id') || p.item || (PAGE && PAGE.id) || '').toLowerCase();
    var it = (c.items || []).filter(function (x) { return String(x.id).toLowerCase() === want || String(x.sku).toLowerCase() === want; })[0];
    if (p.back !== false) {
      var back = el('a', 'wp-cd-back'); back.textContent = (rtl() ? '→ ' : '← ') + (cv(p.backText) || cv(c.title) || 'Terug');
      var bp = (p.back && p.back.page) || p.listPage; back.href = bp && pageById(bp) ? urlFor(bp) : '#';
      back.addEventListener('click', function (ev) { ev.preventDefault(); if (EDIT || !bp || !pageById(bp)) { if (!EDIT) history.back(); return; } navigate(urlFor(bp)); });
      S.inner.appendChild(back);
    }
    if (!it) { var m = el('div', 'wp-coll-empty'); m.textContent = wpt('nf'); S.inner.appendChild(m); return S.e; }
    var wrap = el('div', 'wp-cd'), left = el('div', 'wp-cd-gal'), right = el('div', 'wp-cd-info');
    var imgs = it.images || [], main = el('div', 'wp-cd-main' + (p.imageFit === 'crop' ? ' crop' : ''));
    if (imgs.length) {
      var im = el('img'); im.src = asset((cimg(it) || imgs[0]).src); im.alt = cv((cimg(it) || imgs[0]).alt) || cv(it.name); main.appendChild(im); left.appendChild(main);
      if (imgs.length > 1) {
        var th = el('div', 'wp-cd-thumbs' + (p.imageFit === 'crop' ? ' crop' : ''));
        imgs.forEach(function (x) { var t = el('img'); t.src = asset(x.src); t.alt = ''; t.loading = 'lazy'; t.addEventListener('click', function () { im.src = asset(x.src); }); th.appendChild(t); });
        left.appendChild(th);
      }
    } else { main.classList.add('empty'); left.appendChild(main); }
    var g = cgroup(c, 'categories', (it.categories || [])[0]) || null, dv = cgroup(c, 'divisions', it.division);
    var crumb = el('div', 'wp-cd-crumb'); crumb.textContent = [dv && cv(dv.name), g && cv(g.name).split(' — ').pop()].filter(Boolean).join(' › '); if (crumb.textContent) right.appendChild(crumb);
    var h = el('h1', 'wp-cd-t'); h.textContent = cv(it.name); right.appendChild(h);
    var sk = el('div', 'wp-cd-sku'); sk.textContent = it.sku; right.appendChild(sk);
    if (sellable(it) && p.cart !== false) { right.appendChild(priceLine(it)); right.appendChild(addToCartBlock(it)); }   // webshop: prijs + in winkelmandje
    if (it.description) { var d = el('p', 'wp-cd-d'); d.textContent = cv(it.description); right.appendChild(d); }
    var planOn = false;
    if (p.sheet) {   // productblad als PDF (props.sheet: {logo, fonts:{regular,bold}, footer, title, button}); de PDF-code (sheet.js + jsPDF) wordt pas bij de klik geladen
      var sh = p.sheet, sb = el('button', 'wp-cd-sheet'); sb.type = 'button';
      var sbl = cv(sh.button) || wpt('sheet');
      sb.textContent = sbl;
      sb.addEventListener('click', function () {
        sb.disabled = true; sb.textContent = '…';
        var done = function () { sb.disabled = false; sb.textContent = sbl; };
        new Promise(function (res, rej) {
          if (window.WPSheet) return res();
          var sc = el('script'); sc.src = ENGINE + 'sheet.js'; sc.onload = res; sc.onerror = function () { rej(new Error('sheet.js')); }; document.head.appendChild(sc);
        }).then(function () {
          var drawing = null, pl2 = p.plan;
          if (planOn && pl2) drawing = loadPlan(pl2.script).then(function () {
            return new Promise(function (res) { window.WPConfigurator.renderImage(it[pl2.field || 'tekening'], { lang: LANG }, function (r) { res(r ? { data: r.dataUrl, w: r.w, h: r.h } : null); }); });
          }).catch(function () { return null; });
          var im0 = cimg(it), fn = sh.fonts || {};
          return window.WPSheet.build({
            lang: LANG, title: cv(sh.title) || '', name: cv(it.name), sku: String(it.sku || it.id || ''), crumb: crumb.textContent,
            description: it.description ? cv(it.description) : '', rows: rows, image: im0 ? asset(im0.src) : null,
            logo: sh.logo ? asset(sh.logo) : null, fonts: { regular: fn.regular ? asset(fn.regular) : null, bold: fn.bold ? asset(fn.bold) : null },
            accent: S.ac, ink: color(sh.ink) || '#1d1d1b', footer: sh.footer ? cv(sh.footer) : '', url: location.href.replace(/#.*$/, ''), drawing: drawing
          });
        }).then(function (blob) {
          window.WPSheet.save(blob, String(it.sku || it.id || 'product').replace(/[^\w.-]+/g, '-') + '-' + cv(it.name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.pdf');
        }).then(done, function () { done(); sb.textContent = wpt('sheetFail'); setTimeout(function () { sb.textContent = sbl; }, 2500); });
      });
      right.appendChild(sb);
    }
    var rows = [];
    (c.fields || []).forEach(function (f) {
      if ((f.show || []).indexOf('detail') < 0) return;
      var v = cfmt(f, cget(it, f.key)); if (v !== null) rows.push([cv(f.label), v]);
    });
    if (rows.length) {
      var hd = el('div', 'wp-cd-h'); hd.textContent = wpt('specs'); right.appendChild(hd);
      var tb = el('div', 'wp-cd-specs');
      rows.forEach(function (r) { var a = el('div', 'k'); a.textContent = r[0]; var b = el('div', 'v'); b.textContent = r[1]; tb.appendChild(a); tb.appendChild(b); });
      right.appendChild(tb); collapsible(hd, tb, p.specsCollapse);
    }
    wrap.appendChild(left); wrap.appendChild(right); S.inner.appendChild(wrap);
    // optioneel: een tekenmotor van de site rechtstreeks in de pagina (props.plan {script, title, field}).
    // script = .js in de site (laadt een keer); die zet window.WPConfigurator met mount(host, data, {lang, sku, title}) en
    // renderImage(data, {lang}, cb). data = het veld (standaard 'tekening') van het item; geen data = geen blok.
    var pl = p.plan, planData = pl && it[pl.field || 'tekening'];
    if (pl && planData && typeof pl.script === 'string' && /^[\w\/.-]+\.js$/i.test(pl.script) && pl.script.indexOf('..') < 0) {
      var eb = el('div', 'wp-cd-embed');
      var et = null; if (pl.title) { et = el('div', 'wp-cd-h'); et.textContent = cv(pl.title); eb.appendChild(et); }
      var host = el('div'); eb.appendChild(host); if (et) collapsible(et, host, pl.collapse); S.inner.appendChild(eb); planOn = true;
      loadPlan(pl.script).then(function () { window.WPConfigurator.mount(host, planData, { lang: LANG, sku: String(it.sku || it.id || ''), title: cv(it.name) }); }).catch(function () { eb.style.display = 'none'; planOn = false; });
    }
    if (!EDIT) setTimeout(function () { document.title = cv(it.name) + ' · ' + (trPlain(PAGE && PAGE.title) || '').split('·').pop().trim(); }, 0);
    return S.e;
  }


  // zoeken in de hele site (object "search"): invoerveld + resultatenlijst uit site.json zelf, in de taal van de bezoeker, zonder server.
  // Doorzocht: titel, beschrijving en tekstobjecten van elke pagina (niet noindex, niet de detailpagina van een collectie) en de items van props.collections (naam, sku, beschrijving).
  var SEARCH_IDX = null, SEARCH_LANG = null, SEARCH_SITE = null;
  function searchIndex(cols) {
    var key = LANG + '|' + (cols || []).join(',');
    if (SEARCH_IDX && SEARCH_LANG === key && SEARCH_SITE === SITE) return SEARCH_IDX;
    var idx = [];
    function texts(list, out) {
      (list || []).forEach(function (o) {
        if (o.type === 'text' && o.props && o.props.text !== undefined) { var t = trPlain(o.props.text); if (t) out.push(t); }
        if (o.children) texts(o.children, out);
      });
      return out;
    }
    SITE.pages.forEach(function (pg) {
      if (pg.noindex) return;
      var hasDetail = (pg.objects || []).some(function (o) { return o.type === 'collection-detail'; });
      if (hasDetail) return;
      idx.push({ title: trPlain(pg.title) || pg.id, url: urlFor(pg.id), body: trPlain(pg.description) + ' ' + texts(pg.objects, []).join(' ') });
    });
    (cols || []).forEach(function (cn) {
      var c = coll(cn); if (!c) return;
      var dp = null;
      SITE.pages.forEach(function (pg) { (pg.objects || []).forEach(function (o) { if (o.type === 'collection-grid' && o.props && o.props.collection === cn && o.props.detailPage) dp = dp || o.props.detailPage; }); });
      cfilter(c, {}).forEach(function (it) {
        idx.push({ title: cv(it.name) || it.sku || it.id, url: urlFor(dp || 'product') + '?id=' + encodeURIComponent(it.id), body: [it.sku, cv(it.description)].join(' ') });
      });
    });
    SEARCH_IDX = idx; SEARCH_LANG = key; SEARCH_SITE = SITE;
    return idx;
  }
  function renderSearch(o) {
    var p = o.props || {}, e = el('div', 'wp-o wp-search');
    if (o.surface) applySurface(e, o.surface);
    var inp = el('input', 'wp-search-in'); inp.type = 'search'; inp.autocomplete = 'off';
    inp.placeholder = p.placeholder ? trPlain(p.placeholder) : wpt('search');
    inp.setAttribute('aria-label', inp.placeholder);
    if (p.size) inp.style.fontSize = p.size + 'px';
    if (p.color) inp.style.color = color(p.color);
    var box = el('div', 'wp-search-r'); box.hidden = true; box.setAttribute('role', 'listbox');
    e.appendChild(inp); e.appendChild(box);
    var max = p.maxResults || 8;
    function draw() {
      var q = inp.value.trim().toLowerCase();
      box.textContent = ''; if (!q) { box.hidden = true; return; }
      var words = q.split(/\s+/), hits = [];
      searchIndex(p.collections).forEach(function (it) {
        var t = it.title.toLowerCase(), b = it.body.toLowerCase(), score = 0;
        for (var i = 0; i < words.length; i++) {
          var inT = t.indexOf(words[i]) >= 0, inB = b.indexOf(words[i]) >= 0;
          if (!inT && !inB) return;
          score += inT ? 3 : 1;
        }
        hits.push({ it: it, score: score });
      });
      hits.sort(function (a, b) { return b.score - a.score; });
      hits.slice(0, max).forEach(function (h) {
        var a = el('a', 'wp-search-i'); a.href = h.it.url; a.setAttribute('role', 'option');
        var t = el('div', 'wp-search-t'); t.textContent = h.it.title; a.appendChild(t);
        var b = h.it.body.replace(/\s+/g, ' ').trim(), at = b.toLowerCase().indexOf(words[0]);
        if (b) { var x = el('div', 'wp-search-x'); var st = Math.max(0, at - 40); x.textContent = (st ? '… ' : '') + b.substr(st, 110) + (b.length > st + 110 ? ' …' : ''); a.appendChild(x); }
        a.addEventListener('click', function (ev) { ev.preventDefault(); if (!EDIT) navigate(h.it.url); });
        box.appendChild(a);
      });
      if (!hits.length) { var m = el('div', 'wp-search-none'); m.textContent = wpt('nores'); box.appendChild(m); }
      box.hidden = false;
    }
    inp.addEventListener('input', draw);
    inp.addEventListener('focus', draw);
    inp.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { box.hidden = true; }
      if (ev.key === 'Enter') { var f = box.querySelector('a'); if (f && !EDIT) { ev.preventDefault(); navigate(f.getAttribute('href')); } }
    });
    document.addEventListener('click', function (ev) { if (!e.contains(ev.target)) box.hidden = true; });
    return e;
  }

  var RENDER = { 'collection-grid': renderCollGrid, 'collection-list': renderCollList, 'collection-detail': renderCollDetail, video: renderVideo, surface: renderSurface, text: renderText, image: renderImage, icon: renderIcon, group: renderGroup, nav: renderNav, form: renderForm, language: renderLanguage, 'cart-link': renderCartLink, search: renderSearch };

  // ---------- adressen: echte paden (/contact, /en/contact) ----------
  var BASE = '';   // map waar de site staat, bijv. '/www.winsane.com' (bepaald bij het starten)
  function pageById(id) { return SITE.pages.filter(function (p) { return p.id === id; })[0]; }
  function pagePath(pg) { return (!pg || pg.id === SITE.site.homePage) ? '/' : (pg.path || '/' + pg.id); }
  function urlFor(id, lang) {
    lang = lang || LANG;
    var pre = lang !== SITE.site.defaultLanguage ? '/' + lang : '';
    var p = pagePath(pageById(id));
    return BASE + pre + (p === '/' && pre ? '' : p);
  }
  // relatieve bestanden (media/…, api/…) altijd vanaf de map van de site
  // inklapbare kop: mode 'open' | 'closed' | 'auto' (auto = dicht op een smal scherm, open op een breed scherm); leeg = niet inklapbaar
  function collapsible(hd, body, mode) {
    if (mode !== 'open' && mode !== 'closed' && mode !== 'auto') return;
    var open = mode === 'open' || (mode === 'auto' && window.innerWidth > 700);
    hd.classList.add('wp-cd-tog'); hd.setAttribute('role', 'button'); hd.setAttribute('tabindex', '0');
    function apply() { body.style.display = open ? '' : 'none'; hd.classList.toggle('open', open); hd.setAttribute('aria-expanded', open ? 'true' : 'false'); }
    function flip() { open = !open; apply(); }
    hd.addEventListener('click', flip);
    hd.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } });
    apply();
  }
  var PLANS = {};
  function loadPlan(src) {   // laadt het tekenscript van de site (eenmalig)
    if (window.WPConfigurator) return Promise.resolve();
    return PLANS[src] || (PLANS[src] = new Promise(function (res, rej) { var sc = document.createElement('script'); sc.src = asset(src); sc.onload = res; sc.onerror = function () { rej(new Error(src)); }; document.head.appendChild(sc); }));
  }
  // 'cdn:pad' = bestand op de cdn van de site (site.cdn, bv. https://cdn.example.com); een ander adres of pad blijft zoals het is
  function asset(u) {
    if (u && u.indexOf('cdn:') === 0 && SITE.site.cdn) return String(SITE.site.cdn).replace(/\/+$/, '') + '/' + u.slice(4).replace(/^\/+/, '');
    return (!u || /^(https?:|data:|blob:|\/)/.test(u)) ? u : BASE + '/' + u;
  }
  function detectBase() {
    var path = decodeURI(location.pathname).replace(/\/index\.html$/, '/');
    var langs = [''].concat(SITE.site.languages.filter(function (l) { return l !== SITE.site.defaultLanguage; }).map(function (l) { return '/' + l; }));
    var best = null;
    SITE.pages.forEach(function (pg) {
      [pagePath(pg), pg.path || ''].forEach(function (pp) {
        langs.forEach(function (lp) {
          var suf = (lp + (pp === '/' ? '' : pp)).replace(/\/$/, '');
          var p = path.replace(/\/$/, '');
          if (p.length >= suf.length && p.slice(p.length - suf.length) === suf) {      // pad eindigt op (taal +) paginapad
            var b = suf ? p.slice(0, p.length - suf.length) : p;
            if (best === null || b.length < best.length) best = b;
          }
        });
      });
    });
    return best !== null ? best : path.replace(/\/[^\/]*$/, '');
  }
  function navigate(href, replace) {
    if (replace) history.replaceState(null, '', href); else history.pushState(null, '', href);
    route(); arrive();
    if (window.WP_PREVIEW) window.parent.postMessage({ type: 'wp-page', page: PAGE && PAGE.id, lang: LANG }, location.origin);
  }

  // doel van een link (url/mail) mag een vertaalsleutel zijn uit site.translations: dan komt de link in de taal van de bezoeker (terugval: hoofdtaal)
  function actText(t) { return (typeof t === 'string' && SITE.translations && SITE.translations[t]) ? (trPlain(t) || t) : t; }
  function actionHref(a) {
    if (!a) return null;
    if (a.type === 'page') return urlFor(a.target) + (a.query ? '?' + String(a.query).replace(/^\?/, '') : '');   // query vult een formulier in (?krat=klein)
    if (a.type === 'url') return asset(actText(a.target));        // relatief = vanaf de sitemap (media/…); een vertaalsleutel geeft per taal een andere link
    if (a.type === 'mail') return 'mailto:' + actText(a.target);
    if (a.type === 'scroll') {                                       // naar een object: op deze pagina, of eerst naar de pagina waar het staat
      var pg = a.page ? pageById(a.page) : pageOfObj(a.target);
      return (!pg || pg === PAGE) ? '#' + a.target : urlFor(pg.id) + '#' + a.target;
    }
    return null;
  }
  // op welke pagina staat dit object? (in de master = op de huidige pagina)
  function pageOfObj(id) {
    function has(list) { return (list || []).some(function (o) { return o.uuid === id || has(o.children); }); }
    if (PAGE && (has(PAGE.objects) || (PAGE.master && SITE.masters && SITE.masters[PAGE.master] && has(SITE.masters[PAGE.master].objects)))) return PAGE;
    return SITE.pages.filter(function (p) { return has(p.objects); })[0] || null;
  }
  // na het wisselen van pagina: naar het anker (#object) als dat er is, anders bovenaan
  function arrive() {
    var id = location.hash.length > 1 && location.hash.charAt(1) !== '/' ? decodeURIComponent(location.hash.slice(1)) : '';
    window.scrollTo(0, 0);
    if (!id) return;
    requestAnimationFrame(function () { scrollToObj(id); });
    if (document.fonts) document.fonts.ready.then(function () { setTimeout(function () { scrollToObj(id); }, 60); });   // letters kunnen de hoogte nog verschuiven
  }
  // scrollen naar een object (anker); werkt in ontwerp- en kolommodus omdat het het echte element zoekt
  function scrollToObj(id) {
    var t = document.querySelector('.wp-page [data-uuid="' + id + '"]') || document.querySelector('[data-uuid="' + id + '"]');
    if (!t) return;
    var y = t.getBoundingClientRect().top + window.scrollY - (SITE.site.scrollOffset || 16);
    window.scrollTo({ top: Math.max(0, y), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  }

  function renderObject(o, pw) {
    var fn = RENDER[o.type];
    var e;
    if (fn) e = fn(o);
    else { e = el('div', 'wp-o wp-unknown'); e.textContent = o.type; } // module-regel: onbekend = lege plek met naam
    place(e, o.layout, pw);
    e.dataset.uuid = o.uuid;
    var a = o.base && o.base.action;
    if (a && !EDIT && actionHref(a)) {
      var href = actionHref(a);
      e.classList.add('wp-link');
      e.addEventListener('click', function () {
        if (a.type === 'url' && a.open === '_blank') window.open(href, '_blank', 'noopener');
        else if (a.type === 'page') navigate(href);
        else if (a.type === 'scroll') { if (href.charAt(0) === '#') scrollToObj(a.target); else navigate(href); }
        else location.href = href;
      });
    }
    if (o.base && o.base.opacity !== undefined) e.style.opacity = o.base.opacity;
    if (o.base && o.base.motion && !EDIT) applyMotion(e, o.base.motion);
    return e;
  }

  // ---------- break: kolom-modus ----------
  var STACK_GAP = 10;   // minimale ruimte bij stapelen; zijmarge direct op de pagina
  var BAND_LINE = 25;   // tekstlijn in een band op volle breedte
  var COL_GAP = 25;     // ruimte waar een nieuwe kolom begint
  var MOBILE = 600;     // hideOnMobile

  function isTsw(o) { return !!(o.base && o.base.triggerSw); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // a omvat b in het ontwerp (zoals withInXYBounds in de core); alleen vlakken zijn houders
  function contains(a, b, W) {
    if (a === b || a.type !== 'surface') return false;
    var A = a.layout, B = b.layout, ax = isTsw(a) ? -1e6 : A.x, aw = isTsw(a) ? 2e6 : A.w;
    return B.x >= ax - 1 && B.y >= A.y - 1 && B.x + B.w <= ax + aw + 1 && B.y + B.h <= A.y + A.h + 1 &&
      (isTsw(a) ? W : A.w) * A.h > B.w * B.h;
  }
  function buildTree(list, W) {
    list.forEach(function (o) { o._kids = []; o._parent = null; });
    list.forEach(function (o) {
      var best = null, ba = Infinity;
      list.forEach(function (p) {
        if (!contains(p, o, W)) return;
        var ar = (isTsw(p) ? W : p.layout.w) * p.layout.h;
        if (ar < ba) { ba = ar; best = p; }
      });
      o._parent = best;
      if (best) best._kids.push(o);
    });
    return list.filter(function (o) { return !o._parent; });
  }

  // volgorde: rijen (verticale overlap); rijen die als raster onder elkaar staan → per kolom
  function columnsOf(items) {
    var cols = [];
    items.forEach(function (o) {
      var L = o.layout, hit = [];
      cols.forEach(function (c, i) { if (L.x < c.r - 4 && L.x + L.w > c.l + 4) hit.push(i); });
      if (!hit.length) { cols.push({ l: L.x, r: L.x + L.w, items: [o] }); return; }
      var c = cols[hit[0]]; c.items.push(o); c.l = Math.min(c.l, L.x); c.r = Math.max(c.r, L.x + L.w);
      for (var k = hit.length - 1; k > 0; k--) {
        var d = cols[hit[k]]; c.items = c.items.concat(d.items); c.l = Math.min(c.l, d.l); c.r = Math.max(c.r, d.r); cols.splice(hit[k], 1);
      }
    });
    cols.sort(function (a, b) { return a.l - b.l; });   // ook bij rtl: de ontwerp-linkerkolom staat gespiegeld rechts en wordt dus het eerst gelezen
    return cols;
  }
  function order(kids) {
    var sorted = kids.slice().sort(function (a, b) { return a.layout.y - b.layout.y || a.layout.x - b.layout.x; });
    var rows = [], cur = null;
    sorted.forEach(function (o) {
      var L = o.layout;
      if (cur && L.y < cur.bottom - 2) { cur.items.push(o); cur.bottom = Math.max(cur.bottom, L.y + L.h); }
      else { cur = { items: [o], top: L.y, bottom: L.y + L.h }; rows.push(cur); }
    });
    // raster: opeenvolgende rijen met evenveel kolommen die horizontaal gelijk liggen
    var blocks = [];
    rows.forEach(function (r) {
      r.cols = columnsOf(r.items);
      var last = blocks[blocks.length - 1];
      // samenvoegen als de rij er vlak onder ligt (≤ 48px: kop + tekst van dezelfde cellen) en de kolommen op elkaar passen;
      // een rij verder weg is een nieuwe rij van het raster (1-2 / 3-4), niet dezelfde kolom
      var union = last ? columnsOf(last.items.concat(r.items)) : null;
      if (last && r.top - last.bottom <= 48 && union.length > 1 && union.length === Math.max(last.cols.length, r.cols.length)) {
        last.items = last.items.concat(r.items); last.cols = columnsOf(last.items); last.bottom = Math.max(last.bottom, r.bottom);
      } else blocks.push({ items: r.items.slice(), cols: r.cols, bottom: r.bottom });
    });
    var out = [];
    blocks.forEach(function (b) {
      b.cols.forEach(function (c, i) {
        c.items.sort(function (x, y) { return x.layout.y - y.layout.y; });
        c.items.forEach(function (o, j) { o._newCol = i > 0 && j === 0; o._inGrid = b.cols.length > 1; out.push(o); });
      });
    });
    return out;
  }

  // meten: echte hoogte van een tekst op een gegeven breedte
  var MEASURE = null;
  function measure(o, w) {
    if (!MEASURE) { MEASURE = el('div'); MEASURE.style.cssText = 'position:absolute;left:-99999px;top:0;visibility:hidden;'; ROOT.appendChild(MEASURE); }
    var e = renderObject(Object.assign({}, o, { layout: { x: 0, y: 0, w: w, h: 1 } }));
    e.style.height = 'auto';
    MEASURE.appendChild(e);
    var h = Math.ceil(e.getBoundingClientRect().height);
    MEASURE.removeChild(e);
    return h;
  }

  function place1(o, box, inset, parent, W) {
    var L = o.layout;
    if (isTsw(o)) { o._x = 0; o._w = ROOT.clientWidth; return; }
    var avail = Math.max(40, box.w - 2 * inset);
    if (o.type === 'text') {
      // gecentreerd als verhouding in het ontwerp (≤ max(6px, 2%)), anders op de lijn met de volle breedte
      var px = parent ? (isTsw(parent) ? 0 : parent.layout.x) : 0, pw = parent ? (isTsw(parent) ? W : parent.layout.w) : W;
      var left = L.x - px, right = px + pw - (L.x + L.w);
      // een kolom-item (deel van een rij naast elkaar) is nooit 'gecentreerd': altijd op de lijn
      if (!o._inGrid && Math.abs(left - right) <= Math.max(6, 0.02 * pw)) { o._w = Math.min(L.w, avail); o._x = box.x + (box.w - o._w) / 2; }
      else { o._x = box.x + inset; o._w = avail; }
    } else { o._w = Math.min(L.w, avail); o._x = box.x + (box.w - o._w) / 2; }   // vorm, kaart, beeld: eigen maat (max. de kolom), gecentreerd — zoals de core
  }

  function heightOf(o) {
    var L = o.layout, k = o._w / (L.w || 1);
    if (o.type === 'text' || o.type === 'nav') return measure(o, o._w);              // menu mag over meer regels lopen
    if (o.type === 'video') return Math.round(L.h * k);                                  // beeldverhouding houden
    if (o.type === 'image' || o.type === 'group') { o._scale = k; return Math.round(L.h * Math.min(1, k)); }
    return L.h;
  }

  // hamburgermenu (nav-prop "burger": true of een breedte in px): in de kolom-modus onder die breedte alleen een knop naast het logo
  var BURGER_VW = 0, BURGER_H = 44;
  // standaard AAN voor het hoofdmenu van de kopbalk (master, geen footer, geen pill, geen taalkiezer, minstens 2 items);
  // props.burger: false = uit, een getal = onder die breedte, true = altijd in de kolom-modus. Menu's op een pagina: alleen met burger gezet.
  function isBurger(o) {
    if (o.type !== 'nav' || EDIT || !o.props || o.props.languageSwitch || o.props.burger === false) return false;
    var b = o.props.burger;
    if (b === undefined || b === null) {
      if (o._owner !== 'master' || (o.base && o.base.footer) || o.props.pill || !o.props.items || o.props.items.length < 2) return false;
      b = true;
    }
    return b === true || BURGER_VW < +b;
  }
  function lay(kids, box, top, inset, parent, W, firstGap) {
    var y = top, prev = null, bgRow = [];
    var hasBurger = kids.some(isBurger);
    order(kids).forEach(function (o) {
      var L = o.layout, gap;
      if (hasBurger && (isBurger(o) || (o.type === 'nav' && o.props && o.props.languageSwitch))) {   // staat op de regel van het logo, telt niet mee in de hoogte
        place1(o, box, inset, parent, W);
        o._h = isBurger(o) ? BURGER_H : Math.max(L.h, 26); o._burger = isBurger(o); bgRow.push(o); return;
      }
      if (!prev) gap = firstGap !== undefined ? firstGap : (parent ? Math.max(0, L.y - parent.layout.y) : L.y);
      else {
        gap = L.y - (prev.layout.y + prev.layout.h);
        if (gap < 0) gap = STACK_GAP;                          // stond naast elkaar → onder elkaar
        if (o._newCol) gap = Math.max(gap, COL_GAP);
      }
      y += gap;
      place1(o, box, inset, parent, W);
      var h;
      if (o._kids.length) {
        var innerInset = isTsw(o) ? BAND_LINE : clamp(Math.min.apply(null, o._kids.map(function (c) { return c.layout.x - L.x; })), STACK_GAP, BAND_LINE);
        var end = lay(o._kids, { x: o._x, w: o._w }, y, innerInset, o, W);
        var padB = Math.max(0, L.y + L.h - Math.max.apply(null, o._kids.map(function (c) { return c.layout.y + c.layout.h; })));
        h = end - y + padB;
      } else h = heightOf(o);
      o._y = y; o._h = h; y += h; prev = o;
    });
    if (bgRow.length) {   // knop (rechts) en taalkiezer (links ervan) op het midden van het logo
      var logo = order(kids).filter(function (k) { return k.type === 'image'; })[0];
      var R = rtl(), side = Math.max(inset, 16);   // rtl: alles gespiegeld (logo rechts, knop links)
      if (logo) logo._x = R ? box.x + box.w - side - logo._w : box.x + side;   // logo links, knop rechts
      var mid = logo ? logo._y + logo._h / 2 : top + BURGER_H / 2, edge = R ? box.x + side : box.x + box.w - side;
      bgRow.filter(function (o) { return o._burger; }).forEach(function (o) { o._w = BURGER_H; o._x = R ? edge : edge - BURGER_H; o._y = mid - o._h / 2; edge = R ? o._x + BURGER_H + 8 : o._x - 8; });
      bgRow.filter(function (o) { return !o._burger; }).forEach(function (o) { o._w = Math.min(o.layout.w, 80); o._x = R ? edge : edge - o._w; o._y = mid - o._h / 2; if (R) edge += o._w + 8; });
    }
    return y;
  }

  function flat(list, out) { list.forEach(function (o) { out.push(o); if (o._kids) flat(order(o._kids), out); }); return out; }

  // ruimte boven de footer: 40, behalve als de pagina eindigt met een schermbrede band (dan sluit de footer er direct op aan)
  function footGap(list) {
    var b = bottomOf(list);
    return list.some(function (o) { return isTsw(o) && o.layout.y + o.layout.h >= b; }) ? 0 : 40;
  }

  // groep (Ctrl+G) op mobiel: een cluster dat uitsteekt of overlapt (telefoon + kaartjes + mascotte) blijft één geheel
  // en schaalt mee als één beeld. Een kaart met zijn eigen teksten erin wordt gewoon opnieuw geschikt (tekst blijft leesbaar).
  function unitize(list) {
    var by = {}, order = [];
    list.forEach(function (o) {
      var g = o.base && o.base.gid; if (!g || isTsw(o)) return;
      if (!by[g]) { by[g] = []; order.push(g); } by[g].push(o);
    });
    function inside(b, a) { var A = a.layout, B = b.layout; return B.x >= A.x - 2 && B.y >= A.y - 2 && B.x + B.w <= A.x + A.w + 2 && B.y + B.h <= A.y + A.h + 2; }
    order.forEach(function (g) {
      var m = by[g]; if (m.length < 2) return;
      if (m.some(function (a) { return m.every(function (b) { return b === a || inside(b, a); }); })) return;   // kaart met inhoud: opnieuw schikken
      function hit(a, b) {   // echt over elkaar heen (≥ 15% van de kleinste), niet een paar pixels rand
        var A = a.layout, B = b.layout, w = Math.min(A.x + A.w, B.x + B.w) - Math.max(A.x, B.x), h = Math.min(A.y + A.h, B.y + B.h) - Math.max(A.y, B.y);
        return w > 0 && h > 0 && w * h >= 0.15 * Math.min(A.w * A.h, B.w * B.h);
      }
      if (!m.some(function (a, i) { return m.some(function (b, j) { return j > i && hit(a, b); }); })) return;          // naast elkaar (zoals een kopbalk): gewoon onder elkaar
      var x0 = Math.min.apply(null, m.map(function (o) { return o.layout.x; })), y0 = Math.min.apply(null, m.map(function (o) { return o.layout.y; }));
      var x1 = Math.max.apply(null, m.map(function (o) { return o.layout.x + o.layout.w; })), y1 = Math.max.apply(null, m.map(function (o) { return o.layout.y + o.layout.h; }));
      var unit = { uuid: g, type: 'group', _owner: m[0]._owner, layout: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 },
        children: m.map(function (o) { var c = JSON.parse(JSON.stringify(o)); c.layout.x -= x0; c.layout.y -= y0; return c; }) };
      var at = Math.min.apply(null, m.map(function (o) { return list.indexOf(o); }));
      m.forEach(function (o) { list.splice(list.indexOf(o), 1); });
      list.splice(at, 0, unit);
    });
    return list;
  }

  // formulieren die langer worden dan hun vak (kalender uitgeklapt, extra keuzes): wat eronder staat schuift mee,
  // een kaart of band erachter groeit mee, en de pagina (met footer) wordt langer. Ook als het formulier later groeit.
  var FLOW_RO = null;
  function flowForms(page, s) {
    if (EDIT) return;
    if (FLOW_RO) { FLOW_RO.disconnect(); FLOW_RO = null; }   // waarnemer van de vorige pagina stopt altijd (anders zet hij na het navigeren de hoogte van de oude pagina)
    var forms = [].slice.call(page.children).filter(function (e) { return e.classList.contains('wp-form') || e.classList.contains('wp-grow'); });
    if (!forms.length) return;
    var els = [].slice.call(page.children).filter(function (e) { return e.dataset && e.dataset.top; });
    els.forEach(function (e) { if (e.dataset.by == null) { e.dataset.by = parseFloat(e.style.top) || 0; e.dataset.bh = parseFloat(e.style.height) || 0; } });
    if (page.dataset.bph == null) page.dataset.bph = parseFloat(page.style.height) || 0;
    function pass() {
      if (!page.isConnected) return;
      els.forEach(function (e) { e.style.top = e.dataset.by + 'px'; e.style.height = e.dataset.bh + 'px'; });
      var grow = forms.map(function (f) { return { f: f, top: +f.dataset.by, bot: +f.dataset.by + +f.dataset.bh, extra: Math.max(0, Math.ceil(f.scrollHeight) - +f.dataset.bh) }; })
        .filter(function (g) { return g.extra > 0; });
      var total = 0;
      grow.forEach(function (g) { total += g.extra; g.f.style.height = (+g.f.dataset.bh + g.extra) + 'px'; });
      if (grow.length) els.forEach(function (e) {
        if (forms.indexOf(e) >= 0 && grow.some(function (g) { return g.f === e; })) return;
        var t = +e.dataset.by, b = t + +e.dataset.bh, dy = 0, dh = 0;
        grow.forEach(function (g) {
          if (t >= g.bot - 1) dy += g.extra;                                  // eronder: schuift mee
          else if (t <= g.top + 1 && b >= g.bot - 1) dh += g.extra;           // kaart/band eromheen: groeit mee
        });
        if (dy) e.style.top = (t + dy) + 'px';
        if (dh) e.style.height = (+e.dataset.bh + dh) + 'px';
      });
      var ph = +page.dataset.bph + total;
      page.style.height = ph + 'px'; ROOT.style.height = (ph * s) + 'px';
    }
    pass();
    if ('ResizeObserver' in window) {
      if (FLOW_RO) FLOW_RO.disconnect();
      var busy = false;
      FLOW_RO = new ResizeObserver(function () { if (busy) return; busy = true; requestAnimationFrame(function () { pass(); busy = false; }); });
      forms.forEach(function (f) { [].forEach.call(f.children, function (k) { FLOW_RO.observe(k); }); });   // de inhoud, niet het formulier zelf (dat zetten we zelf)
    }
  }

  function buildBreak(page, W, vw, vh, mBody, mFoot) {
    BURGER_VW = vw;
    var keep = function (o) { return !(vw < MOBILE && o.base && o.base.hideOnMobile); };
    var clone = function (o, owner) { var c = JSON.parse(JSON.stringify(o)); c._owner = owner; return c; };
    var content = mBody.filter(keep).map(function (o) { return clone(o, 'master'); })
      .concat(PAGE.objects.filter(keep).map(function (o) { return clone(o, 'page'); }));
    unitize(content);
    if (!EDIT) inheritMotion(content, W);
    var roots = buildTree(content, W);
    var end = lay(roots, { x: 0, w: vw }, 0, STACK_GAP, null, W);

    var foot = unitize(mFoot.filter(keep).map(function (o) { return clone(o, 'master'); }));
    var all = flat(roots.slice().sort(function (a, b) { return a._y - b._y; }), []);
    if (foot.length) {
      var froots = buildTree(foot, W);
      var fEnd = lay(froots, { x: 0, w: vw }, end + footGap(mBody.concat(PAGE.objects)), STACK_GAP, null, W, 0);
      var shift = Math.max(0, vh - fEnd);                       // in een break: minimaal de schermhoogte
      var fl = flat(froots, []); fl.forEach(function (o) { o._y += shift; });
      all = all.concat(fl); end = fEnd + shift;
    }
    page.style.width = vw + 'px';
    page.style.height = end + 'px';
    page.style.transform = 'none';
    ROOT.style.height = end + 'px';
    all.forEach(function (o) {
      var c = Object.assign({}, o, { layout: { x: o._x, y: o._y, w: o._w, h: o._h } });
      var e = renderObject(c);
      if (o._scale && o._scale < 1 && o.type === 'group') {
        e.style.width = o.layout.w + 'px'; e.style.height = o.layout.h + 'px';
        e.style.transformOrigin = '0 0'; e.style.transform = 'scale(' + o._scale + ')';
      }
      e.dataset.top = o._owner;
      page.appendChild(e);
    });
  }

  // ---------- animatie (base.motion) ----------
  // in: verschijnen bij in beeld komen · loop: doorlopend. Respecteert 'beperkte beweging' van het systeem.
  var IO = null;
  var SEEN = new Set();   // al eens in beeld geweest op deze pagina → bij opnieuw tekenen (resize) meteen zichtbaar, niet opnieuw animeren
  function applyMotion(e, m) {
    if (m.in && m.in !== 'none') {
      e.classList.add('wp-m-in', 'wp-in-' + m.in);
      if (e.dataset.uuid && SEEN.has(e.dataset.uuid)) { e.classList.add('wp-shown', 'wp-instant'); }
      else {
      if (m.duration) e.style.transitionDuration = m.duration + 'ms';
      if (m.delay) e.style.transitionDelay = m.delay + 'ms';
      if (!IO && 'IntersectionObserver' in window) {
        IO = new IntersectionObserver(function (list) {
          list.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('wp-shown'); if (en.target.dataset.uuid) SEEN.add(en.target.dataset.uuid); IO.unobserve(en.target); } });
        }, { threshold: 0.15 });
      }
      if (IO) IO.observe(e); else e.classList.add('wp-shown');
      }
    }
    if (m.loop && m.loop !== 'none') {
      e.classList.add('wp-loop-' + m.loop);
      if (m.loopDuration) e.style.animationDuration = m.loopDuration + 'ms';
    }
  }

  // wat op een geanimeerd vlak ligt (tekst op een kaart), beweegt mee — tenzij het een eigen animatie heeft
  function inheritMotion(list, W) {
    list.forEach(function (a) {
      var m = a.base && a.base.motion; if (!m || !m.in || m.in === 'none' || a.type !== 'surface') return;
      list.forEach(function (b) {
        if (b === a || (b.base && b.base.motion) || !contains(a, b, W)) return;
        b.base = b.base || {}; b.base.motion = { in: m.in, delay: m.delay, duration: m.duration };
      });
    });
  }

  // ---------- pagina ----------
  function bottomOf(list) {
    var b = 0;
    list.forEach(function (o) { b = Math.max(b, o.layout.y + o.layout.h); });
    return b;
  }

  // ---------- favicon (icoon in het tabblad): site.favicon = { file, fallback, animate: 'draai'|'puls'|'beeldjes', speed, frames: [..] } ----------
  // SVG als hoofdbeeld + PNG-reserve (Safari); animatie via een canvas dat het icoon steeds opnieuw als PNG zet (werkt in elke browser behalve Safari, en niet bij 'beweging verminderen').
  var FAV = { sig: '', timer: 0 };
  function applyFavicon() {
    if (window.WP_PREVIEW) return;
    var f = SITE && SITE.site && SITE.site.favicon, sig = JSON.stringify(f || null);
    if (sig === FAV.sig) return;
    FAV.sig = sig;
    if (FAV.timer) { clearInterval(FAV.timer); FAV.timer = 0; }
    [].forEach.call(document.querySelectorAll('link[rel~="icon"], link[rel="shortcut icon"]'), function (l) { l.remove(); });
    if (!f || !f.file) return;
    function mime(u) { u = String(u).split('?')[0].toLowerCase(); return /\.svg$/.test(u) ? 'image/svg+xml' : /\.png$/.test(u) ? 'image/png' : /\.gif$/.test(u) ? 'image/gif' : /\.webp$/.test(u) ? 'image/webp' : /\.jpe?g$/.test(u) ? 'image/jpeg' : 'image/x-icon'; }
    function link(href, type) {
      var l = document.createElement('link'); l.rel = 'icon'; l.setAttribute('data-wp-fav', '1');
      if (type) l.type = type; if (type === 'image/svg+xml') l.sizes = 'any';
      l.href = href; document.head.appendChild(l); return l;
    }
    function still() {
      [].forEach.call(document.querySelectorAll('link[data-wp-fav]'), function (l) { l.remove(); });
      if (f.fallback) link(asset(f.fallback), mime(f.fallback));
      link(asset(f.file), mime(f.file));
    }
    still();
    var mode = f.animate;
    if (mode !== 'draai' && mode !== 'puls' && mode !== 'beeldjes') return;
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var srcs = mode === 'beeldjes' ? (f.frames || []).filter(Boolean).slice(0, 60) : [f.file];
    if (!srcs.length) return;
    var sp = +f.speed; if (!(sp > 0)) sp = mode === 'draai' ? 4 : mode === 'puls' ? 2 : 4; sp = Math.min(Math.max(sp, 0.2), 120);
    var imgs = srcs.map(function (u) { return new Promise(function (ok) { var i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { ok(null); }; i.src = asset(u); }); });
    var mySig = sig;
    Promise.all(imgs).then(function (list) {
      if (FAV.sig !== mySig) return;                       // intussen is er iets anders ingesteld
      list = list.filter(Boolean); if (!list.length) return;
      var c = document.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d');
      [].forEach.call(document.querySelectorAll('link[data-wp-fav]'), function (l) { l.remove(); });
      var el = link('', 'image/png'), t0 = Date.now();
      function tick() {
        var t = (Date.now() - t0) / 1000;
        x.clearRect(0, 0, 64, 64);
        try {
          if (mode === 'draai') { x.save(); x.translate(32, 32); x.rotate(t / sp * Math.PI * 2); x.drawImage(list[0], -23, -23, 46, 46); x.restore(); }
          else if (mode === 'puls') { var k = 0.78 + 0.22 * Math.sin(t / sp * Math.PI * 2), z = 64 * k; x.drawImage(list[0], 32 - z / 2, 32 - z / 2, z, z); }
          else x.drawImage(list[Math.floor(t * sp) % list.length], 0, 0, 64, 64);
          el.href = c.toDataURL('image/png');
        } catch (e) { clearInterval(FAV.timer); FAV.timer = 0; still(); }   // bv. beeld van een ander domein: dan blijft het stilstaand icoon
      }
      tick(); FAV.timer = setInterval(tick, mode === 'beeldjes' ? Math.max(40, Math.min(250, 500 / sp)) : 100);
    });
  }

  // pagina niet in zoekmachines: <meta name="robots" content="noindex"> (alleen voor bezoekers, niet in de editor)
  function setRobots() {
    if (EDIT) return;
    var m = document.querySelector('meta[name=robots][data-wp]');
    if (PAGE && PAGE.noindex) {
      if (!m) { m = document.createElement('meta'); m.name = 'robots'; m.setAttribute('data-wp', '1'); document.head.appendChild(m); }
      m.content = 'noindex';
    } else if (m) m.remove();
  }

  function build() {
    applyFavicon();
    document.documentElement.lang = LANG; document.documentElement.dir = rtl() ? 'rtl' : 'ltr';
    var W = SITE.site.width;
    var vw = ROOT.clientWidth || document.documentElement.clientWidth;
    var s = EDIT ? 1 : Math.min(1, vw / W);   // editor werkt altijd op de ontwerpbreedte
    var ox = Math.max(0, (vw - W * s) / 2);

    var master = (SITE.masters[PAGE.master] || { objects: [] }).objects;
    var mBody = master.filter(function (o) { return !(o.base && o.base.footer); });
    var mFoot = master.filter(function (o) { return o.base && o.base.footer; });

    // footer-zone: onder de inhoud, minimaal de paginahoogte
    var content = PAGE.objects.concat(mBody);
    var zoneTop0 = mFoot.length ? Math.min.apply(null, mFoot.map(function (o) { return o.layout.y; })) : 0;
    var zoneH = mFoot.length ? bottomOf(mFoot) - zoneTop0 : 0;
    // minimum: paginahoogte op de ontwerpbreedte, schermhoogte in een break (zoals de core)
    var minH = EDIT ? (PAGE.height || 0) : s < 1 ? document.documentElement.clientHeight / s : Math.max(PAGE.height || 0, document.documentElement.clientHeight);
    var zoneTop = Math.max(bottomOf(content) + footGap(content), minH - zoneH);
    var pageH = mFoot.length ? zoneTop + zoneH : Math.max(PAGE.height || 0, bottomOf(content));

    if (SITE.site.background) { var bgc = color(SITE.site.background); ROOT.style.background = bgc; if (!EDIT) document.body.style.background = bgc; }
    ROOT.innerHTML = ''; MEASURE = null;
    ROOT.classList.toggle('wp-break', !EDIT && vw < W);   // kolom-modus: o.a. het menu onder elkaar (ook bij het meten)
    var page = el('div', 'wp-page');
    if (!EDIT && vw < W) {                       // break: kolom-modus i.p.v. schalen
      ROOT.appendChild(page);
      buildBreak(page, W, vw, document.documentElement.clientHeight, mBody, mFoot);
      if (MEASURE) { MEASURE.remove(); MEASURE = null; }
      flowForms(page, 1);
      if (OPT.onBuilt) OPT.onBuilt(page, { scale: 1, ox: 0, vw: vw, mode: 'break' });
      document.title = trPlain(PAGE.title); setRobots();
      document.documentElement.lang = LANG;
      return;
    }
    page.style.width = W + 'px';
    page.style.height = pageH + 'px';
    page.style.transform = 'translateX(' + ox + 'px) scale(' + s + ')';
    ROOT.style.height = (pageH * s) + 'px';

    var clones = null;
    if (!EDIT) {
      clones = new Map();
      var all = mBody.concat(PAGE.objects).map(function (o) { var c = JSON.parse(JSON.stringify(o)); clones.set(o, c); return c; });
      inheritMotion(all, W);
    }
    function add(o, dy, owner) {
      var c = clones && clones.get(o) ? clones.get(o) : JSON.parse(JSON.stringify(o));
      if (dy) c.layout.y += dy;
      if (c.base && c.base.triggerSw) { c.layout.x = -ox / s; c.layout.w = vw / s; }
      var e = renderObject(c, W);
      e.dataset.top = owner;          // 'page' of 'master'
      e.dataset.dy = dy || 0;         // verschuiving van de footer-zone (alleen weergave)
      page.appendChild(e);
    }
    mBody.forEach(function (o) { add(o, 0, 'master'); });
    PAGE.objects.forEach(function (o) { add(o, 0, 'page'); });
    mFoot.forEach(function (o) { add(o, zoneTop - zoneTop0, 'master'); });
    ROOT.appendChild(page);
    flowForms(page, s);
    if (OPT.onBuilt) OPT.onBuilt(page, { scale: s, ox: ox, vw: vw });

    if (EDIT) return;
    document.title = trPlain(PAGE.title); setRobots();
    document.documentElement.lang = LANG;
    var md = document.querySelector('meta[name=description]');
    if (md) md.content = trPlain(PAGE.description);
  }

  // venster verandert: meetekenen tijdens het slepen (max. één keer per beeldje), alleen als de breedte verandert
  // (een verdwijnende adresbalk op de telefoon verandert alleen de hoogte → geen nieuwe tekenbeurt)
  function onResize() {
    var raf = 0, lastW = document.documentElement.clientWidth, hT;
    window.addEventListener('resize', function () {
      var w = document.documentElement.clientWidth;
      if (w !== lastW) {
        lastW = w;
        if (!raf) raf = requestAnimationFrame(function () { raf = 0; build(); });
      } else if (!ROOT.classList.contains('wp-break')) {   // alleen hoogte, groot scherm: rustig na afloop (footer onderaan houden)
        clearTimeout(hT); hT = setTimeout(build, 250);
      }
    });
  }

  function route() {
    SEEN.clear();                    // nieuwe pagina: animaties spelen weer
    // oude vorm #/contact?lang=en → omzetten naar het echte pad
    var h = /^#\/([^?]*)(?:\?lang=([a-z-]+))?/.exec(location.hash);
    if (h) { var hp = pageById(h[1] || SITE.site.homePage); if (hp) { history.replaceState(null, '', urlFor(hp.id, h[2] || SITE.site.defaultLanguage)); } }
    var r = parsePath(location.pathname); LANG = r.lang; PAGE = r.page;
    if (r.alias && !EDIT) { try { history.replaceState(null, '', urlFor(PAGE.id, LANG) + location.search + location.hash); } catch (e) {} }   // oud adres: de adresbalk toont het nieuwe adres
    build();
  }
  // pad → pagina en taal (ook gebruikt door de editor als die op de site zelf wordt geopend)
  function parsePath(pathname) {
    var rest = decodeURI(pathname).slice(BASE.length).replace(/\/index\.html$/, '/').replace(/\/+$/, '') || '/';
    var seg = rest.split('/').filter(Boolean), lang = SITE.site.defaultLanguage;
    if (seg.length && seg[0] !== lang && SITE.site.languages.indexOf(seg[0]) >= 0) { lang = seg.shift(); }
    var p = '/' + seg.join('/');
    var pl = p.replace(/\/$/, '') || '/', alias = false;
    var page = (p === '/' ? pageById(SITE.site.homePage) : null) ||
      SITE.pages.filter(function (pg) { return (pg.path || '/' + pg.id) === p; })[0] ||
      SITE.pages.filter(function (pg) { return (pg.aliases || []).indexOf(pl) >= 0; }).map(function (pg) { alias = true; return pg; })[0] ||   // oud adres van een hernoemde pagina
      SITE.pages.filter(function (pg) { return pg.id === seg[seg.length - 1]; })[0] ||
      pageById('404') || pageById(SITE.site.homePage) || SITE.pages[0];
    return { page: page, lang: lang, alias: alias };
  }

  // lettertypes: van de eigen server (fonts/, automatisch bij opslaan); wat daar (nog) niet staat via Google
  function loadFonts() {
    var local = EDIT ? [] : (SITE.site.fontsLocal || []);   // de editor laadt altijd via Google (nieuw toegevoegde lettertypes meteen zichtbaar)
    if (SITE.site.fontsCss && local.length) { var ll = el('link'); ll.rel = 'stylesheet'; ll.href = asset(SITE.site.fontsCss); document.head.appendChild(ll); }
    var fam = (SITE.fonts || []).filter(function (f) { return local.indexOf(f.family) < 0; }).map(function (f) { return 'family=' + f.google; }).join('&');
    if (!fam) return;
    var l = el('link'); l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?' + fam + '&display=swap';
    document.head.appendChild(l);
  }

  // ---------- voor de editor ----------
  function findObject(uuid) {
    var lists = [['page', PAGE.objects], ['master', (SITE.masters[PAGE.master] || { objects: [] }).objects]];
    for (var i = 0; i < lists.length; i++) {
      var L = lists[i][1];
      for (var j = 0; j < L.length; j++) if (L[j].uuid === uuid) return { obj: L[j], list: L, owner: lists[i][0] };
    }
    return null;
  }
  window.WPSpeler = {
    social: SOCIAL,
    site: function () { return SITE; },
    page: function () { return PAGE; },
    lang: function () { return LANG; },
    show: function (id, lang) {
      PAGE = SITE.pages.filter(function (p) { return p.id === id; })[0] || SITE.pages[0];
      if (lang) LANG = lang;
      build();
    },
    build: function () { build(); },
    setSite: function (j) { SITE = j; PAGE = SITE.pages.filter(function (p) { return p.id === PAGE.id; })[0] || SITE.pages[0]; build(); },
    findObject: findObject,
    asset: function (u) { return asset(u); },
    tr: trPlain,
    // editor op de site zelf: welke pagina/taal hoort bij het huidige adres, en het adres van een pagina
    here: function () { BASE = SITE.site.base !== undefined ? SITE.site.base.replace(/\/$/, '') : detectBase(); var r = parsePath(location.pathname); return { page: r.page.id, lang: r.lang }; },
    urlFor: function (id, lang) { return urlFor(id, lang); },
    color: color,
    load: function () {
      return fetch('site.json?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) {
        SITE = j; LANG = SITE.site.defaultLanguage; PAGE = SITE.pages[0];
        loadFonts();
        onResize();
        if (document.fonts) document.fonts.ready.then(build);
        return SITE;
      });
    }
  };
  if (EDIT) return;   // de editor start zelf via WPSpeler.load()

  // de editor opent op de site zelf: elk adres + ?edit (of Ctrl+Shift+E op de site)
  if (/[?&]edit(=|&|$)/.test(location.search) && window.parent === window) {
    if (ROOT) ROOT.remove();
    document.title = 'WEBPLAYS · editor';
    editorGate(function () {
      var eb = document.createElement('script'); eb.src = ENGINE + 'editor-boot.js?v=' + Date.now(); document.body.appendChild(eb);   // editor altijd vers (na een update geen oude versie)
    });
    return;
  }

  // Inlogpoort: de editor wordt pas geladen als de sleutel klopt (editorKey in .secrets). De sleutel wordt per browser onthouden
  // (zelfde plek als de editor: localStorage 'wpKey'). Oudere api (zonder actie 'auth') of een netwerkfout: gewoon doorgaan
  // zoals vroeger; de editor vraagt dan bij het opslaan om de sleutel.
  function editorGate(go) {
    var api = 'api/index.php';   // SITE is hier nog niet geladen: het api-adres komt uit site.json (zelfde adres als de editor gebruikt)
    function getK() { try { return localStorage.getItem('wpKey') || sessionStorage.getItem('wpKey') || ''; } catch (e) { return ''; } }
    function setK(k) { try { if (k) localStorage.setItem('wpKey', k); else { localStorage.removeItem('wpKey'); sessionStorage.removeItem('wpKey'); } } catch (e) {} }
    function check(k) {
      return fetch(api + '?a=auth', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': k || '' }, body: '{}' })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; }); });
    }
    function why(r, had) {   // melding bij een afgewezen inlog (null = geen bekende afwijzing: doorgaan zoals vroeger)
      var e = r.j && r.j.error;
      if (e === 'nokey') return 'Op de server is nog geen editorKey ingesteld.';
      if (e === 'wait') return 'Te veel foute pogingen. Probeer het over een kwartier opnieuw.';
      if (e === 'motor') return 'Deze WEBPLAYS-versie is te oud om in te loggen. Werk de motor bij.';
      if (e === 'disabled') return 'De editor van deze site staat op slot.';
      if (e === 'list') return 'De lijst met toegestane sleutels is niet bereikbaar. Probeer het straks opnieuw.';
      if (r.s === 401) return had ? 'Onjuiste of ingetrokken sleutel.' : '';
      return null;
    }
    function ui(msg, noInput) {
      var box = document.querySelector('.wp-login');
      if (box) box.remove();
      box = document.createElement('div'); box.className = 'wp-login';
      var card = document.createElement('form'); card.className = 'wp-login-card'; card.setAttribute('autocomplete', 'off');
      var th = null; try { th = localStorage.getItem('wpTheme'); } catch (e) {}
      if (th !== 'day' && th !== 'night') th = (window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches) ? 'day' : 'night';
      box.className += th === 'day' ? ' wp-day' : '';
      var h = document.createElement('img'); h.className = 'wp-login-logo'; h.alt = 'WEBPLAYS editor'; h.src = ENGINE + 'webplays-logo-stack-' + th + '.svg'; card.appendChild(h);
      var p = document.createElement('p'); p.className = 'wp-login-msg' + (msg ? ' err' : ''); p.textContent = msg || 'Vul je editor-sleutel in.'; card.appendChild(p);
      var inp = null;
      if (!noInput) {
        inp = document.createElement('input'); inp.type = 'password'; inp.placeholder = 'sleutel'; inp.setAttribute('autocomplete', 'current-password'); card.appendChild(inp);
        var b = document.createElement('button'); b.type = 'submit'; b.textContent = 'Inloggen'; card.appendChild(b);
      }
      var back = document.createElement('a'); back.href = location.pathname; back.className = 'wp-login-back'; back.textContent = 'Terug naar de site'; card.appendChild(back);
      card.addEventListener('submit', function (e) {
        e.preventDefault();
        var k = inp ? inp.value : '';
        if (!k) return;
        check(k).then(function (r) {
          if (r.s === 200 && r.j.ok) { setK(r.j.token || k); box.remove(); go(); }
          else if (why(r, true) !== null) ui(why(r, true), r.j.error === 'nokey' || r.j.error === 'motor' || r.j.error === 'disabled');
          else { setK(k); box.remove(); go(); }
        }).catch(function () { setK(k); box.remove(); go(); });
      });
      box.appendChild(card); document.body.appendChild(box);
      if (inp) inp.focus();
    }
    fetch('site.json?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.site && j.site.api) api = j.site.api; }, function () {})
      .then(function () { return check(getK()); })
      .then(function (r) {
        if (r.s === 200 && r.j.ok) { if (r.j.token) setK(r.j.token); go(); }
        else if (why(r, !!getK()) !== null) { if (r.s === 401 && r.j.error === 'key') setK(''); ui(why(r, !!getK()), r.j.error === 'nokey' || r.j.error === 'motor' || r.j.error === 'disabled'); }
        else go();
      }).catch(function () { go(); });
  }
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'E' || e.key === 'e') && !window.WP_PREVIEW) {
      e.preventDefault(); location.href = location.pathname + '?edit';
    }
  });

  // voorbeeld in de editor: de editor stuurt het (nog niet opgeslagen) bestand via postMessage
  var PREVIEW = /[?&]preview=1/.test(location.search) && window.parent !== window;
  window.WP_PREVIEW = PREVIEW;

  function boot(j) {
    SITE = j;
    BASE = SITE.site.base !== undefined ? SITE.site.base.replace(/\/$/, '') : detectBase();
    loadFonts();   // na BASE: fonts/ staat in de map van de site
    window.addEventListener('popstate', route);
    // interne links (nav, taalwissel) zonder herladen
    document.addEventListener('click', function (ev) {
      var a = ev.target.closest && ev.target.closest('a[href]');
      if (!a || ev.ctrlKey || ev.metaKey || ev.shiftKey || a.target === '_blank') return;
      var raw = a.getAttribute('href');
      if (raw.charAt(0) === '#' && raw.charAt(1) !== '/') { ev.preventDefault(); scrollToObj(raw.slice(1)); return; }
      var u = new URL(a.href, location.href);
      if (u.origin !== location.origin || u.pathname.indexOf(BASE + '/') !== 0 && u.pathname !== BASE) return;
      if (/\.[a-z0-9]{2,5}$/i.test(u.pathname)) return;     // bestanden (pdf, jpg …) gewoon openen
      ev.preventDefault();
      if (u.pathname + u.search !== location.pathname + location.search) navigate(u.pathname + u.search + u.hash);
      else if (u.hash.length > 1) scrollToObj(decodeURIComponent(u.hash.slice(1)));
    });
    onResize();
    route();
    if (document.fonts) document.fonts.ready.then(build);
    if (location.hash.length > 1 && location.hash.charAt(1) !== '/') arrive();    // direct binnenkomen op /pagina#object
  }

  if (PREVIEW) {
    window.addEventListener('message', function (ev) {
      if (ev.origin !== location.origin || !ev.data || ev.data.type !== 'wp-site') return;
      var d = ev.data;
      if (!SITE) {
        boot(d.site);
      } else {
        var keepScroll = window.scrollY;
        SITE = d.site; build(); window.scrollTo(0, keepScroll);
      }
      if (d.page && (!PAGE || d.page !== PAGE.id || (d.lang && d.lang !== LANG))) {
        history.replaceState(null, '', urlFor(d.page, d.lang || LANG)); route(); window.scrollTo(0, 0);
      }
      // de editor laten weten op welke pagina de bezoeker nu is (na klikken in het voorbeeld)
      window.parent.postMessage({ type: 'wp-page', page: PAGE && PAGE.id, lang: LANG }, location.origin);
    });
    window.parent.postMessage({ type: 'wp-ready' }, location.origin);
    window.addEventListener('popstate', function () { window.parent.postMessage({ type: 'wp-page', page: PAGE && PAGE.id, lang: LANG }, location.origin); });
    return;
  }

  var INLINE = document.getElementById('wp-site'), inlineJ = null;   // de voordeur kan site.json in de pagina zetten (scheelt een rondgang)
  try { if (INLINE) inlineJ = JSON.parse(INLINE.textContent); } catch (x) { inlineJ = null; }
  (inlineJ ? Promise.resolve(inlineJ) : fetch('site.json?t=' + Date.now(), { cache: 'no-store' })   // anders altijd de nieuwste vorm, nooit uit een cache
  .then(function (r) { return r.json(); })).then(boot).catch(function (e) {
    ROOT.textContent = 'site.json kon niet geladen worden: ' + e.message;
  });
})();
