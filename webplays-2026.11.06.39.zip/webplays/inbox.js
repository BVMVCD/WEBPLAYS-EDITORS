/*  WEBPLAYS editor — Inzendingen: wat bezoekers via formulieren hebben gestuurd.
    Knop in de bovenbalk met een teller van ongelezen inzendingen; een venster met alles, nieuwste eerst.
    Lezen via api?a=submissions, gelezen markeren via ?a=submissionsRead. Download als CSV.
*/
(function () {
  'use strict';
  var E = window.WPEditor, $ = function (id) { return document.getElementById(id); };
  if (!E || !$('bar')) return;

  // knop in de balk
  var btn = document.createElement('button');
  btn.id = 'inboxBtn'; btn.title = 'Inzendingen van formulieren';
  btn.innerHTML = 'Inzendingen <span id="inboxN"></span>';
  $('bar').insertBefore(btn, $('view'));
  btn.onclick = function () { open(); };

  // venster
  var ov = document.createElement('div'); ov.id = 'inbox'; ov.innerHTML =
    '<div class="ib-box"><div class="ib-head"><b>Inzendingen</b><span id="ibInfo"></span><span class="sp"></span>' +
    '<button id="ibKey" title="Sleutel: inzendingen versleuteld opslaan (24 woorden)">🔑 Sleutel</button><button id="ibAll">Alles gelezen</button><button id="ibDelRead" title="Alle gelezen inzendingen van dit formulier definitief verwijderen">Gelezen verwijderen</button><button id="ibCsv">Download CSV</button><button id="ibTest" title="Stuur een testmail naar het meldadres">Testmail</button>' +
    '<button id="ibClose" title="Sluiten (Esc)">✕</button></div><div id="ibTabs"></div><div id="ibList"></div></div>';
  document.body.appendChild(ov);
  ov.addEventListener('mousedown', function (e) { if (e.target === ov) close(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && ov.classList.contains('open')) close(); });
  $('ibClose').onclick = close;

  var DATA = null, TAB = null;
  function api(a, body) {
    return fetch(E.site().site.api + '?a=' + a, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': E.key() }, body: JSON.stringify(body || {})
    }).then(function (r) { return r.json().then(function (j) { return { s: r.status, j: j }; }); });
  }
  function badge(n) { var b = $('inboxN'); b.textContent = n ? n : ''; b.className = n ? 'on' : ''; }
  function count() { api('submissions', { count: true }).then(function (r) { if (r.j && r.j.ok) badge(r.j.unread); }).catch(function () {}); }
  setTimeout(count, 800); setInterval(count, 120000);

  // label van een veld uit het formulier in site.json (in de taal van de editor)
  function formDef(id) {
    var out = null;
    E.site().pages.forEach(function (p) { (p.objects || []).forEach(function (o) { if (o.type === 'form' && o.props && o.props.formId === id) out = o.props; }); });
    return out;
  }
  function plain(v) {
    var s = E.site(), lang = E.lang();
    if (typeof v === 'string' && s.translations && s.translations[v]) v = s.translations[v];
    if (v && typeof v === 'object' && !Array.isArray(v)) v = v[lang] || v[s.site.defaultLanguage] || v[Object.keys(v)[0]];
    if (Array.isArray(v)) v = v.map(function (r) { return r.t || ''; }).join('');
    return v == null ? '' : String(v);
  }
  function label(form, name) { var d = formDef(form), f = d && (d.fields || []).filter(function (x) { return x.name === name; })[0]; return f ? plain(f.label) : name; }

  function open(retry) {
    ov.classList.add('open'); $('ibList').innerHTML = '<p class="ib-empty">laden…</p>';
    api('submissions').then(function (r) {
      if (r.s === 401) {
        if (retry !== true && E.askKey) { close(); E.askKey(function () { open(true); }); return; }
        throw new Error('geen of verkeerde editor-sleutel');
      }
      if (!r.j.ok) throw new Error(r.j.error || r.s);
      DATA = r.j; badge(DATA.unread); decrypt();
      var ids = Object.keys(DATA.forms);
      if (!TAB || ids.indexOf(TAB) < 0) TAB = ids[0] || null;
      $('ibInfo').textContent = DATA.notify && DATA.notify.email
        ? 'meldingen naar ' + DATA.notify.email + (DATA.notify.mode === 'daily' ? ' (dagoverzicht)' : DATA.notify.mode === 'off' ? ' (uit)' : ' (per inzending)')
        : 'geen meldadres ingesteld (notifyEmail in .secrets)';
      render();
    }).catch(function (e) { $('ibList').innerHTML = ''; var p = document.createElement('p'); p.className = 'ib-empty'; p.textContent = 'Laden mislukt: ' + e.message; $('ibList').appendChild(p); });
  }
  function close() { ov.classList.remove('open'); }

  // ---------- versleuteling ----------
  function ENC() { return (DATA && DATA.encryption) || {}; }
  function allRows() { var a = []; Object.keys((DATA && DATA.forms) || {}).forEach(function (k) { a = a.concat(DATA.forms[k]); }); return a; }
  function locked() { return allRows().filter(function (r) { return r.enc && !r.data; }); }
  function decrypt() {
    if (!window.WPKeys || !ENC().publicKey || !WPKeys.unlocked(ENC().publicKey)) return;
    allRows().forEach(function (r) { if (r.enc && !r.data) { var d = WPKeys.open(r.enc); if (d) r.data = d; else r.bad = true; } });
  }
  function doUnlock(then) {
    WPKeys.ready().then(function () { WPKeys.unlock(ENC().publicKey, function () { decrypt(); render(); if (then) then(); }); })
      .catch(function (e) { WPPrompt.notice('Versleuteling laden mislukt: ' + e.message); });
  }
  function banner(list) {
    var e = ENC(), plain = allRows().filter(function (r) { return r.data && !r.enc; }).length, lk = locked().length;
    function bar(cls, txt, label, fn) { var b = document.createElement('div'); b.className = 'ib-banner ' + cls; b.appendChild(document.createTextNode(txt)); if (label) { var x = document.createElement('button'); x.textContent = label; x.onclick = fn; b.appendChild(x); } list.appendChild(b); }
    if (e.sodium === false) { bar('warn', 'Versleuteling is niet beschikbaar: de server mist PHP sodium.', null); return; }
    if (!e.publicKey) { bar('info', '🔓 Inzendingen worden nog leesbaar opgeslagen op de server.', 'Sleutel maken', function () { $('ibKey').click(); }); return; }
    if (lk) bar('lock', '🔒 ' + lk + ' versleutelde inzending' + (lk === 1 ? '' : 'en') + '. Alleen te lezen met je 24 woorden.', 'Ontgrendelen', function () { doUnlock(); });
    if (plain) bar('warn', plain + ' oudere inzending' + (plain === 1 ? ' staat' : 'en staan') + ' nog leesbaar op de server.', 'Nu versleutelen', function () {
      WPPrompt.confirm(plain + ' inzending(en) nu versleutelen met je publieke sleutel? Daarna zijn ze alleen nog met je 24 woorden te lezen.', { ok: 'Versleutelen' }, function () {
        api('submissionsEncrypt').then(function (r) { if (!r.j.ok) { WPPrompt.notice(r.j.error || 'Mislukt'); return; } $('ibInfo').textContent = r.j.encrypted + ' versleuteld'; open(true); });
      });
    });
  }
  $('ibKey').onclick = function () {
    var pk = ENC().publicKey || null;
    if (!window.WPKeys) return;
    WPKeys.ready().then(function () { WPKeys.setup(pk, function () { open(true); }); }).catch(function (e) { WPPrompt.notice('Versleuteling laden mislukt: ' + e.message); });
  };

  function render() {
    var tabs = $('ibTabs'); tabs.innerHTML = '';
    Object.keys(DATA.forms).forEach(function (id) {
      var n = DATA.forms[id].filter(function (r) { return !DATA.read[r.id]; }).length;
      var t = document.createElement('button'); t.textContent = id + ' (' + DATA.forms[id].length + ')' + (n ? ' · ' + n + ' nieuw' : '');
      t.className = id === TAB ? 'on' : ''; t.onclick = function () { TAB = id; render(); };
      tabs.appendChild(t);
    });
    var list = $('ibList'); list.innerHTML = '';
    banner(list);
    var rows = TAB ? DATA.forms[TAB] : [];
    if (!rows.length) { list.innerHTML = '<p class="ib-empty">Nog geen inzendingen.</p>'; return; }
    rows.forEach(function (r) {
      var c = document.createElement('div'); c.className = 'ib-card' + (DATA.read[r.id] ? '' : ' new');
      var h = document.createElement('div'); h.className = 'ib-meta';
      h.textContent = new Date(r.createdAt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' }) + ' · pagina ' + r.page + ' · ' + String(r.lang || '').toUpperCase();
      if (r.enc) h.textContent += r.data ? ' · 🔒 versleuteld opgeslagen' : '';
      c.appendChild(h);
      if (r.enc && !r.data) {
        var lk = document.createElement('div'); lk.className = 'ib-locked';
        lk.textContent = r.bad ? 'Kan niet geopend worden met deze sleutel.' : '🔒 Versleuteld. Ontgrendel met je 24 woorden om te lezen.';
        if (!r.bad) lk.onclick = function () { doUnlock(); };
        c.appendChild(lk);
      }
      Object.keys(r.data || {}).forEach(function (k) {
        var v = r.data[k]; if (v === '' || v == null) return;
        var row = document.createElement('div'); row.className = 'ib-f';
        var l = document.createElement('span'); l.textContent = label(TAB, k);
        var val = document.createElement('div');
        if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) { var a = document.createElement('a'); a.href = 'mailto:' + v; a.textContent = v; val.appendChild(a); }
        else val.textContent = v;
        row.appendChild(l); row.appendChild(val); c.appendChild(row);
      });
      var acts = document.createElement('div'); acts.className = 'ib-acts';
      if (!DATA.read[r.id]) {
        var m = document.createElement('button'); m.textContent = 'Gelezen';
        m.onclick = function () { markRead([r.id]); }; acts.appendChild(m);
      }
      var del = document.createElement('button'); del.className = 'ib-del'; del.textContent = 'Verwijderen'; del.title = 'Definitief verwijderen';
      del.onclick = function () { WPPrompt.confirm('Deze inzending definitief verwijderen?', { ok: 'Verwijderen', danger: true }, function () { remove([r.id]); }); };
      acts.appendChild(del); c.appendChild(acts);
      list.appendChild(c);
    });
  }
  function markRead(ids) {
    if (!ids.length) return;
    api('submissionsRead', { ids: ids }).then(function () { ids.forEach(function (id) { DATA.read[id] = true; }); DATA.unread = Math.max(0, DATA.unread - ids.length); badge(DATA.unread); render(); });
  }
  function remove(ids) {
    if (!ids.length) return;
    api('submissionsDelete', { ids: ids }).then(function (r) {
      if (!r.j.ok) return;
      Object.keys(DATA.forms).forEach(function (k) { DATA.forms[k] = DATA.forms[k].filter(function (x) { return ids.indexOf(x.id) < 0; }); });
      DATA.unread = 0; Object.keys(DATA.forms).forEach(function (k) { DATA.forms[k].forEach(function (x) { if (!DATA.read[x.id]) DATA.unread++; }); });
      badge(DATA.unread); render(); $('ibInfo').textContent = r.j.deleted + ' verwijderd';
    });
  }
  $('ibDelRead').onclick = function () {
    if (!DATA || !TAB) return;
    var ids = DATA.forms[TAB].filter(function (r) { return DATA.read[r.id]; }).map(function (r) { return r.id; });
    if (!ids.length) { $('ibInfo').textContent = 'geen gelezen inzendingen om te verwijderen'; return; }
    WPPrompt.confirm(ids.length + ' gelezen inzending(en) van "' + TAB + '" definitief verwijderen?', { ok: 'Verwijderen', danger: true }, function () { remove(ids); });
  };
  $('ibAll').onclick = function () { if (DATA && TAB) markRead(DATA.forms[TAB].filter(function (r) { return !DATA.read[r.id]; }).map(function (r) { return r.id; })); };
  $('ibCsv').onclick = function () {
    if (!DATA || !TAB) return;
    if (DATA.forms[TAB].some(function (r) { return r.enc && !r.data; })) { doUnlock(function () { $('ibCsv').click(); }); return; }
    var rows = DATA.forms[TAB], keys = [];
    rows.forEach(function (r) { Object.keys(r.data || {}).forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); }); });
    var q = function (v) { v = v == null ? '' : String(v); return '"' + v.replace(/"/g, '""') + '"'; };
    var csv = [['datum', 'pagina', 'taal'].concat(keys.map(function (k) { return label(TAB, k); })).map(q).join(';')]
      .concat(rows.map(function (r) { return [r.createdAt, r.page, r.lang].concat(keys.map(function (k) { return (r.data || {})[k]; })).map(q).join(';'); })).join('\r\n');
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'inzendingen-' + TAB + '.csv'; document.body.appendChild(a); a.click(); a.remove();
  };
  $('ibTest').onclick = function () {
    $('ibInfo').textContent = 'testmail versturen…';
    api('notifyTest').then(function (r) { $('ibInfo').textContent = r.j.ok ? (r.j.file ? 'testmail opgeslagen in storage/mail-out (lokaal testen)' : 'testmail verstuurd via ' + r.j.via + ' naar ' + (DATA && DATA.notify.email) + ' — niets binnen? kijk in de spam') : (r.j.error || 'mislukt'); });
  };
})();
