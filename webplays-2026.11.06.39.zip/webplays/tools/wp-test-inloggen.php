<?php
// WEBPLAYS: waarom werkt inloggen met de sleutellijst (editors.json) niet? Dit bestand test elke stap en zegt welke stap faalt.
// Zet het in de map van de site (naast de map "webplays", dus in httpdocs / op D:\ lokaal in de sitemap), open het één keer in de browser.
// Het toont GEEN geheimen: alleen JA/NEE, de hostnaam van editorsUrl en aantallen. Dit bestand blijft staan: VERWIJDER HET ZELF als je klaar bent (zeker online).
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
$ja = fn($b) => $b ? 'JA' : 'NEE';
$siteDir = __DIR__;
$secrets = dirname($siteDir) . '/.secrets';
$cfg = [];
$loadCfg = function ($f) use (&$cfg) { if (is_file($f)) { $c = @include $f; if (is_array($c)) $cfg = array_merge($cfg, array_filter($c, fn($v) => $v !== '' && $v !== null)); } };
$loadCfg($secrets . '/webplays.php');
$sid0 = (string)($cfg['siteId'] ?? '');
if ($sid0 === '') { $j0 = json_decode((string)@file_get_contents($siteDir . '/site.json'), true); $sid0 = is_array($j0) ? (string)($j0['meta']['name'] ?? '') : ''; }
$sid0 = preg_replace('/[^A-Za-z0-9._-]/', '', $sid0);
$siteFile = ($sid0 !== '' && is_file($secrets . '/' . $sid0 . '.php')) ? $secrets . '/' . $sid0 . '.php' : $secrets . '/' . basename($siteDir) . '.php';
$loadCfg($siteFile);
$rows = [];
$add = function ($k, $v, $hint = '') use (&$rows) { $rows[] = [$k, $v, $hint]; };

$add('PHP-versie', PHP_VERSION);
$sodium = function_exists('sodium_crypto_sign_verify_detached');
$add('PHP-uitbreiding sodium (nodig om de handtekening te controleren)', $ja($sodium), $sodium ? '' : '<== DIT IS DE OORZAAK: zonder sodium kan de lijst nooit goedgekeurd worden. Zet sodium aan in PHP (hosting: PHP-opties) of in php.ini: extension=sodium');
$curl = function_exists('curl_init');
$add('PHP-uitbreiding curl', $ja($curl));
$add('allow_url_fopen', $ja((bool)ini_get('allow_url_fopen')));
$add('openssl', $ja(extension_loaded('openssl')));
$add('Map .secrets gevonden', $ja(is_dir($secrets)), $secrets === '' ? '' : '(naast de sitemap verwacht)');
$add('.secrets/webplays.php gevonden', $ja(is_file($secrets . '/webplays.php')));
$add('Sitebestand .secrets/' . basename($siteFile) . ' gevonden', $ja(is_file($siteFile)), '(siteId: ' . ($sid0 === '' ? 'leeg' : $sid0) . ')');
$url = (string)($cfg['editorsUrl'] ?? ''); $file = (string)($cfg['editorsFile'] ?? '');
$add('editorsUrl ingesteld', $ja($url !== ''), $url !== '' ? 'host: ' . (parse_url($url, PHP_URL_HOST) ?: '?') . (preg_match('#^https://#i', $url) ? '' : ' <== moet met https:// beginnen') : 'of editorsFile');
$add('editorsFile ingesteld', $ja($file !== ''));
$pub = base64_decode((string)($cfg['editorsPubKey'] ?? ''), true);
$add('editorsPubKey ingesteld en 32 bytes', $ja($pub !== false && strlen($pub) === 32), ($pub === false || strlen($pub) !== 32) ? '<== openbare sleutel ontbreekt of is fout' : '');
$add('editorsMode', (string)($cfg['editorsMode'] ?? 'add'));

// 1. ophalen
$raw = null; $info = '';
if ($file !== '') { $raw = @file_get_contents($file); $info = $raw === false ? 'bestand niet te lezen' : 'bestand gelezen'; if ($raw === false) $raw = null; }
elseif ($url !== '') {
    if ($curl) {
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_USERAGENT => 'webplays-editors/1']);
        $r = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); $err = curl_error($c); curl_close($c);
        $info = 'curl: HTTP ' . $code . ($err ? ', fout: ' . $err : '');
        if ($r !== false && $code === 200) $raw = (string)$r;
    } else {
        $r = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 8, 'user_agent' => 'webplays-editors/1']]));
        $info = $r === false ? 'file_get_contents: mislukt' . (ini_get('allow_url_fopen') ? '' : ' (allow_url_fopen staat uit)') : 'file_get_contents gelukt';
        if ($r !== false) $raw = (string)$r;
    }
}
$add('Lijst (editors.json) opgehaald', $ja($raw !== null), $info . ($raw !== null ? ' · ' . strlen($raw) . ' bytes' : ' <== de server kan GitHub niet bereiken, of de URL klopt niet'));

// 2. handtekening
$payload = null;
if ($raw !== null) {
    $f = json_decode($raw, true);
    $okForm = is_array($f) && is_string($f['payload'] ?? null) && is_string($f['sig'] ?? null);
    $add('Lijst heeft het juiste formaat (payload + sig)', $ja($okForm), $okForm ? '' : '<== geen geldig editors.json (misschien een foutpagina van GitHub of een proxy)');
    if ($okForm && $sodium && $pub !== false && strlen($pub) === 32) {
        $sig = base64_decode($f['sig'], true);
        $good = $sig !== false && strlen($sig) === SODIUM_CRYPTO_SIGN_BYTES && sodium_crypto_sign_verify_detached($sig, $f['payload'], $pub);
        $add('Handtekening klopt met editorsPubKey', $ja($good), $good ? '' : '<== lijst is met een andere sleutel getekend dan editorsPubKey in .secrets');
        if ($good) { $p = json_decode($f['payload'], true); if (is_array($p) && ($p['format'] ?? '') === 'webplays-editors/1') $payload = $p; }
    }
}
// 3. site en sleutels
if ($payload) {
    $siteId = (string)($cfg['siteId'] ?? '');
    if ($siteId === '') { $j = json_decode((string)@file_get_contents($siteDir . '/site.json'), true); $siteId = is_array($j) ? (string)($j['meta']['name'] ?? '') : ''; }
    $add('Site-id dat de motor gebruikt', $siteId === '' ? '(leeg)' : $siteId);
    $s = $payload['sites'][$siteId] ?? null;
    $add('Deze site staat in de lijst', $ja(is_array($s)), is_array($s) ? '' : '<== site-id komt niet voor in de lijst; bekende sites: ' . implode(', ', array_keys((array)($payload['sites'] ?? []))));
    if (is_array($s)) {
        $add('Site uitgeschakeld (disabled)', $ja(!empty($s['disabled'])));
        $n = 0; $nu = 0; $today = date('Y-m-d');
        foreach ((array)($s['keys'] ?? []) as $k) { $n++; if (empty($k['exp']) || (string)$k['exp'] >= $today) $nu++; }
        $add('Sleutels in de lijst voor deze site (geldig / totaal)', $nu . ' / ' . $n);
    }
    $vf = trim((string)@file_get_contents($siteDir . '/webplays/VERSION.txt'));
    $add('Motorversie / minMotor in de lijst', $vf . ' / ' . ((string)($payload['minMotor'] ?? '-')), (!empty($payload['minMotor']) && version_compare($vf, (string)$payload['minMotor'], '<')) ? '<== motor is te oud voor deze lijst' : '');
}
// 4. opslag
$st = $siteDir . '/storage';
$add('Map storage bestaat', $ja(is_dir($st)));
$add('Map storage beschrijfbaar', $ja(is_dir($st) ? is_writable($st) : is_writable($siteDir)), 'nodig voor editors-cache.json en de sessiesleutel');
$cache = $st . '/editors-cache.json';
$add('editors-cache.json aanwezig', $ja(is_file($cache)), is_file($cache) ? 'leeftijd: ' . (time() - filemtime($cache)) . ' s' : '');

$w = max(array_map(fn($r) => strlen($r[0]), $rows));
echo "WEBPLAYS · test inloggen met sleutellijst\n" . str_repeat('=', 60) . "\n";
foreach ($rows as $r) echo str_pad($r[0], $w + 2) . $r[1] . ($r[2] !== '' ? '   ' . $r[2] : '') . "\n";
echo "\nLees van boven naar beneden: de eerste regel met NEE of '<==' is de oorzaak.\n";
echo "(Dit bestand blijft staan. Verwijder het zelf als je klaar bent.)\n";
