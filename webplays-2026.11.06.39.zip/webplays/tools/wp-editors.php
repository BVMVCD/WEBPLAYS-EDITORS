<?php
/*  WEBPLAYS · beheer van de centrale editor-sleutels (PHP-opdrachtregel). Hetzelfde als wp-editors.html, zelfde bestanden.
    Eén bron: editors.json (gesigneerd, in git). Namen staan er versleuteld in (alleen te lezen met editors-signing.key).
      editors-signing.key  jouw geheime ondertekensleutel — NOOIT in git; bewaar een kopie veilig

    php wp-editors.php keygen                       maakt de ondertekensleutel; toont de openbare sleutel (editorsPubKey in .secrets)
    php wp-editors.php add <site> <naam> [YYYY-MM-DD]   geeft een nieuwe sleutel uit (eenmalig getoond!), ondertekent
    php wp-editors.php revoke <site> <naam>         trekt in, ondertekent
    php wp-editors.php disable <site> | enable <site>   editor van een hele site op slot / weer open
    php wp-editors.php min-motor <versie>           motoren ouder dan deze versie mogen niet meer inloggen ('' = uit)
    php wp-editors.php list                         overzicht (zonder sleutels)
    php wp-editors.php boxkey                       maakt een nieuwe formuliersleutel: 24 woorden + publieke sleutel (boxPublicKey in .secrets/<siteId>.php). Slaat niets op.
    php wp-editors.php release <webplays.zip> [opmerking]   maakt latest.json (ondertekend) en zet de zip ernaast: de sites bieden de update aan
    php wp-editors.php handover <nieuwe-openbare-sleutel>    laat de sites een nieuwe oersleutel vertrouwen (ondertekend met de huidige)
    Opties: --dir=<map met de bestanden> (standaard: huidige map) · --key=<pad naar editors-signing.key> · --words=<pad naar bip39-english.json> (alleen boxkey)
*/
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if (!function_exists('sodium_crypto_sign_keypair')) { fwrite(STDERR, "PHP-extensie sodium ontbreekt.\n"); exit(1); }
$args = array_slice($argv, 1); $opt = [];
foreach ($args as $i => $a) if (preg_match('/^--([a-z]+)=(.*)$/', $a, $m)) { $opt[$m[1]] = $m[2]; unset($args[$i]); }
$args = array_values($args); $cmd = $args[0] ?? 'help';
$dir = rtrim($opt['dir'] ?? getcwd(), '/\\'); $out = $dir . '/editors.json';
$keyFile = $opt['key'] ?? ($dir . '/editors-signing.key');

function sk_load(string $keyFile): string {
    if (!is_file($keyFile)) { fwrite(STDERR, "Geen ondertekensleutel ($keyFile). Maak er een met: php wp-editors.php keygen\n"); exit(1); }
    $sk = base64_decode(trim((string)file_get_contents($keyFile)), true);
    if ($sk === false || strlen($sk) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) { fwrite(STDERR, "Ondertekensleutel onleesbaar.\n"); exit(1); }
    return $sk;
}
function name_key(string $sk): string { return hash_hkdf('sha256', substr($sk, 0, 32), 32, 'wp-editors-names', ''); }
function name_enc(string $sk, string $name): string { $iv = random_bytes(12); $ct = openssl_encrypt($name, 'aes-256-gcm', name_key($sk), OPENSSL_RAW_DATA, $iv, $tag, '', 16); return base64_encode($iv . $ct . $tag); }
function name_dec(string $sk, string $n): string {
    $u = base64_decode($n, true); if ($u === false || strlen($u) < 29) return '?';
    $r = openssl_decrypt(substr($u, 12, -16), 'aes-256-gcm', name_key($sk), OPENSSL_RAW_DATA, substr($u, 0, 12), substr($u, -16));
    return $r === false ? '(versleuteld)' : $r;
}
// leest editors.json; namen worden ontsleuteld (oude bestanden met leesbare namen werken ook)
function load_list(string $f, string $sk): array {
    $d = ['format' => 'webplays-editors/1', 'minMotor' => '', 'sites' => []];
    $j = is_file($f) ? json_decode((string)file_get_contents($f), true) : null; $p = is_array($j) ? json_decode((string)($j['payload'] ?? ''), true) : null;
    if (!is_array($p)) return $d;
    $d['minMotor'] = (string)($p['minMotor'] ?? '');
    foreach ((array)($p['sites'] ?? []) as $s => $v) {
        $o = ['keys' => []]; if (!empty($v['disabled'])) $o['disabled'] = true;
        foreach ((array)($v['keys'] ?? []) as $k) {
            $e = ['name' => isset($k['n']) ? name_dec($sk, (string)$k['n']) : (string)($k['name'] ?? '?'), 'hash' => (string)$k['hash']];
            foreach (['n', 'added', 'exp'] as $x) if (isset($k[$x])) $e[$x] = $k[$x];
            $o['keys'][] = $e;
        }
        $d['sites'][$s] = $o;
    }
    return $d;
}
function sign_out(array $d, string $sk, string $out): void {
    $sites = [];
    foreach ($d['sites'] as $s => $v) {
        $o = ['keys' => []]; if (!empty($v['disabled'])) $o['disabled'] = true;
        foreach ($v['keys'] as $k) { $e = ['n' => $k['n'] ?? name_enc($sk, $k['name']), 'hash' => $k['hash']]; foreach (['added', 'exp'] as $x) if (isset($k[$x])) $e[$x] = $k[$x]; $o['keys'][] = $e; }
        $sites[$s] = $o;
    }
    $p = ['format' => 'webplays-editors/1', 'issued' => gmdate('Y-m-d\TH:i:s\Z'), 'sites' => $sites];
    if (!empty($d['minMotor'])) $p['minMotor'] = $d['minMotor'];
    $payload = json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $sig = sodium_crypto_sign_detached($payload, $sk);
    file_put_contents($out, json_encode(['payload' => $payload, 'sig' => base64_encode($sig)], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
    echo "Ondertekend: $out\n";
}
function find_key(array $d, string $site, string $name): ?int { foreach ((array)($d['sites'][$site]['keys'] ?? []) as $i => $k) if (($k['name'] ?? '') === $name) return $i; return null; }

switch ($cmd) {
    case 'keygen':
        if (is_file($keyFile)) { fwrite(STDERR, "Er is al een ondertekensleutel: $keyFile (niet overschreven).\n"); exit(1); }
        $kp = sodium_crypto_sign_keypair();
        file_put_contents($keyFile, base64_encode(sodium_crypto_sign_secretkey($kp)) . "\n"); @chmod($keyFile, 0600);
        echo "Ondertekensleutel opgeslagen in: $keyFile\n  → NOOIT in git zetten. Maak een kopie op een veilige plek.\n\n";
        echo "Openbare sleutel (zet in .secrets/webplays.php als 'editorsPubKey', of in api/editors.php):\n  " . base64_encode(sodium_crypto_sign_publickey($kp)) . "\n";
        break;
    case 'add':
        [$site, $name] = [$args[1] ?? '', $args[2] ?? '']; $exp = $args[3] ?? '';
        if (!preg_match('/^[a-z0-9][a-z0-9._-]{0,60}$/i', $site) || $name === '') { fwrite(STDERR, "Gebruik: add <site> <naam> [YYYY-MM-DD]\n"); exit(1); }
        if ($exp !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) { fwrite(STDERR, "Einddatum als YYYY-MM-DD.\n"); exit(1); }
        $sk = sk_load($keyFile); $d = load_list($out, $sk);
        if (find_key($d, $site, $name) !== null) { fwrite(STDERR, "'$name' bestaat al bij $site (eerst intrekken).\n"); exit(1); }
        $key = ''; $al = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        for ($i = 0; $i < 32; $i++) $key .= $al[random_int(0, strlen($al) - 1)];
        $e = ['name' => $name, 'hash' => hash('sha256', $site . ':' . $key), 'added' => gmdate('Y-m-d')]; if ($exp !== '') $e['exp'] = $exp;
        $d['sites'][$site]['keys'][] = $e; sign_out($d, $sk, $out);
        echo "\nSleutel voor $name op $site" . ($exp ? " (tot $exp)" : '') . " — wordt maar één keer getoond:\n\n  $key\n\n";
        break;
    case 'revoke':
        [$site, $name] = [$args[1] ?? '', $args[2] ?? '']; $sk = sk_load($keyFile);
        $d = load_list($out, $sk); $i = find_key($d, $site, $name);
        if ($i === null) { fwrite(STDERR, "Niet gevonden: $name bij $site\n"); exit(1); }
        array_splice($d['sites'][$site]['keys'], $i, 1); sign_out($d, $sk, $out); echo "Ingetrokken: $name bij $site\n"; break;
    case 'disable': case 'enable':
        $site = $args[1] ?? ''; $sk = sk_load($keyFile); $d = load_list($out, $sk);
        if ($cmd === 'disable') $d['sites'][$site]['disabled'] = true; else unset($d['sites'][$site]['disabled']);
        if (!isset($d['sites'][$site]['keys'])) $d['sites'][$site]['keys'] = [];
        sign_out($d, $sk, $out); echo "$site: " . ($cmd === 'disable' ? 'editor op slot' : 'editor weer open') . "\n"; break;
    case 'min-motor':
        $sk = sk_load($keyFile); $d = load_list($out, $sk); $d['minMotor'] = $args[1] ?? ''; sign_out($d, $sk, $out); echo 'Minimale motor: ' . ($d['minMotor'] ?: '(geen)') . "\n"; break;
    case 'list':
        $d = load_list($out, sk_load($keyFile)); echo 'Minimale motor: ' . ($d['minMotor'] ?: '(geen)') . "\n";
        foreach ((array)$d['sites'] as $s => $v) { echo "\n$s" . (!empty($v['disabled']) ? '  [OP SLOT]' : '') . "\n"; foreach ($v['keys'] as $k) echo '  - ' . str_pad($k['name'], 20) . substr($k['hash'], 0, 8) . '…  ' . ($k['exp'] ?? 'geen einddatum') . (isset($k['exp']) && $k['exp'] < date('Y-m-d') ? '  [VERLOPEN]' : '') . "\n"; }
        break;
    case 'boxkey': {
        // zelfde afleiding als de editor (keys.js) en de motor (wp_box_kp): BIP39 24 woorden -> PBKDF2 -> BLAKE2b -> X25519
        if (!function_exists('sodium_crypto_box_seed_keypair')) { fwrite(STDERR, "PHP-extensie sodium ontbreekt.\n"); exit(1); }
        $wf = $opt['words'] ?? ''; if ($wf === '') foreach ([__DIR__ . '/../vendor/bip39-english.json', $dir . '/bip39-english.json', __DIR__ . '/bip39-english.json'] as $c) if (is_file($c)) { $wf = $c; break; }
        $W = $wf !== '' && is_file($wf) ? json_decode((string)file_get_contents($wf), true) : null;
        if (!is_array($W) || count($W) !== 2048) { fwrite(STDERR, "Woordenlijst niet gevonden. Geef --words=<pad naar webplays/vendor/bip39-english.json>\n"); exit(1); }
        $ent = random_bytes(32); $bits = ''; foreach (str_split($ent) as $ch) $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
        $bits .= substr(str_pad(decbin(ord(hash('sha256', $ent, true)[0])), 8, '0', STR_PAD_LEFT), 0, 8);
        $ws = []; for ($i = 0; $i < 24; $i++) $ws[] = $W[bindec(substr($bits, $i * 11, 11))];
        $ph = implode(' ', $ws); if (class_exists('Normalizer')) $ph = Normalizer::normalize($ph, Normalizer::FORM_KD);
        $kp = sodium_crypto_box_seed_keypair(sodium_crypto_generichash(hash_pbkdf2('sha512', $ph, 'mnemonic', 2048, 64, true), 'webplays-box-key-v1', 32));
        $pk = base64_encode(sodium_crypto_box_publickey($kp));
        echo "\nJe 24 woorden (schrijf ze op papier; ze worden hierna nergens bewaard):\n\n";
        foreach (array_chunk($ws, 6) as $r => $ch) { $l = ''; foreach ($ch as $j => $w) $l .= str_pad(($r * 6 + $j + 1) . '. ' . $w, 18); echo '  ' . rtrim($l) . "\n"; }
        echo "\nPublieke sleutel voor in .secrets/<siteId>.php (niet geheim):\n\n  'boxPublicKey' => '$pk',\n\n";
        echo "Gebruik niet de woorden van een echte wallet. Kwijt = de versleutelde inzendingen blijven onleesbaar.\n"; break;
    }
    case 'release': {
        $sk = sk_load($keyFile); $zip = $args[1] ?? '';
        if (!is_file($zip) || !class_exists('ZipArchive')) { fwrite(STDERR, "Geef de zip op (php wp-editors.php release webplays.zip) en zorg voor ZipArchive.\n"); exit(1); }
        $za = new ZipArchive(); if ($za->open($zip) !== true) { fwrite(STDERR, "Zip niet te openen.\n"); exit(1); }
        $ver = trim((string)$za->getFromName('webplays/VERSION.txt')); $za->close();
        if (!preg_match('/^[0-9][0-9A-Za-z._-]{0,29}$/', $ver)) { fwrite(STDERR, "Geen geldige webplays/VERSION.txt in de zip.\n"); exit(1); }
        $name = "webplays-$ver.zip"; copy($zip, "$dir/$name");
        $p = ['format' => 'webplays-update/1', 'version' => $ver, 'zip' => $name, 'sha256' => hash_file('sha256', $zip), 'size' => filesize($zip), 'issued' => time(), 'notes' => $args[2] ?? ''];
        $old = is_file("$dir/latest.json") ? json_decode((string)file_get_contents("$dir/latest.json"), true) : null; $op = $old ? json_decode((string)($old['payload'] ?? ''), true) : null;
        if (!empty($op['trust'])) $p['trust'] = $op['trust'];
        $payload = json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        file_put_contents("$dir/latest.json", json_encode(['payload' => $payload, 'sig' => base64_encode(sodium_crypto_sign_detached($payload, $sk))], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
        $zs = glob("$dir/webplays-*.zip") ?: []; usort($zs, fn($a, $b) => version_compare(basename($b, '.zip'), basename($a, '.zip')));
        foreach (array_slice($zs, 3) as $z) @unlink($z);   // de laatste drie bewaren
        echo "Versie $ver ondertekend: latest.json + $name\nZet beide in git (commit en push).\n"; break;
    }
    case 'handover': {
        $sk = sk_load($keyFile); $new = $args[1] ?? ''; $b = base64_decode($new, true);
        if ($b === false || strlen($b) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) { fwrite(STDERR, "Geef de nieuwe openbare sleutel (base64).\n"); exit(1); }
        $old = is_file("$dir/latest.json") ? json_decode((string)file_get_contents("$dir/latest.json"), true) : null; $op = $old ? json_decode((string)($old['payload'] ?? ''), true) : null;
        if (!$op) { fwrite(STDERR, "Er is nog geen latest.json: maak eerst een release.\n"); exit(1); }
        $op['trust'] = array_values(array_unique(array_merge((array)($op['trust'] ?? []), [$new]))); $op['issued'] = time();
        $payload = json_encode($op, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        file_put_contents("$dir/latest.json", json_encode(['payload' => $payload, 'sig' => base64_encode(sodium_crypto_sign_detached($payload, $sk))], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
        echo "Overdracht ondertekend. Zodra de sites latest.json ophalen, vertrouwen ze ook de nieuwe sleutel. Daarna mag je met de nieuwe oersleutel gaan tekenen.\n"; break;
    }
    default: echo preg_replace('#^/\*|\*/$#', '', explode('*/', file_get_contents(__FILE__), 2)[0] ?? '');
}
