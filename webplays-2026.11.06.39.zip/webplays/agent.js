/*  WEBPLAYS agent — typ wat je wilt, de agent maakt een VOORSTEL (operaties op site.json),
    jij ziet het in de editor en keurt goed of af. De agent schrijft nooit zelf.
*/
/*  Producten — een groep met base.product = { id, price (centen), unit } is een product.
    Onderdelen in de groep hebben een rol (base.role): name, sub, price, desc, image, button, bg.
    Gedeeld door de agent (ops addProduct / updateProduct / removeProduct) en het editorpaneel.
    Formuliervelden met "products": true (choice/select) krijgen hun keuzes automatisch uit de producten.
*/
(function () {
  'use strict';
  var ROLES = ['name', 'sub', 'price', 'desc', 'image', 'button', 'bg'];
  var ROLE_NL = { name: 'Naam', sub: 'Voor wie / inhoud', price: 'Prijs', desc: 'Omschrijving', image: 'Beeld', button: 'Knop', bg: 'Achtergrondvlak' };
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function rnd() { return Math.random().toString(36).slice(2, 7); }
  function slug(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'product'; }
  // prijs in centen → "€ 22,50"; "22,50" / "€22.50" / 2250 → centen
  function fmt(c, cur) { if (c == null || c === '') return ''; var e = (Math.round(c) / 100).toFixed(2).replace('.', ','); return (cur === 'EUR' || !cur ? '€ ' : cur + ' ') + e; }
  function cents(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return Number.isInteger(v) && v >= 1000 ? v : Math.round(v * 100);   // 22.5 → 2250; 2250 blijft 2250
    var s = String(v).replace(/[^\d,.]/g, ''); if (!s) return null;
    if (/,\d{1,2}$/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else s = s.replace(/,/g, '');
    var n = parseFloat(s); return isFinite(n) ? Math.round(n * 100) : null;
  }
  // alle kinderen met hun rol (ook in een groep in de groep, zoals de knop)
  function roleMap(g) {
    var m = {};
    (function walk(list) { (list || []).forEach(function (c) { if (c.base && c.base.role && !m[c.base.role]) m[c.base.role] = c; walk(c.children); }); })(g.children);
    return m;
  }
  function trVal(site, key) {
    var t = site.translations && site.translations[key]; if (!t) return '';
    var v = t[site.site.defaultLanguage] || t[Object.keys(t)[0]];
    return Array.isArray(v) ? v.map(function (r) { return r.t || ''; }).join('') : String(v || '');
  }
  function list(site) {
    var out = [];
    (site.pages || []).forEach(function (p) {
      (p.objects || []).forEach(function (o, i) {
        if (o.type !== 'group' || !o.base || !o.base.product) return;
        var r = roleMap(o), pr = o.base.product;
        out.push({ id: pr.id, uuid: o.uuid, page: p.id, obj: o, roles: r, price: pr.price == null ? null : pr.price, unit: pr.unit || null,
          name: r.name && r.name.props ? trVal(site, r.name.props.text) : '', image: r.image && r.image.props ? r.image.props.src : null });
      });
    });
    return out.sort(function (a, b) { return a.page === b.page ? (a.obj.layout.y - b.obj.layout.y) || (a.obj.layout.x - b.obj.layout.x) : 0; });
  }
  // keuzes in formulieren (veld met "products": true) gelijk trekken met de producten
  function syncOptions(site) {
    var ps = list(site), n = 0;
    function walk(objs) { (objs || []).forEach(function (o) {
      if (o.type === 'form' && o.props && Array.isArray(o.props.fields)) o.props.fields.forEach(function (f) {
        if (!f.products) return;
        f.options = ps.map(function (p) {
          var opt = { value: p.id };
          if (p.roles.name && p.roles.name.props) opt.label = p.roles.name.props.text;
          if (p.roles.sub && p.roles.sub.props) opt.sub = p.roles.sub.props.text;
          if (p.image) opt.img = p.image;
          return opt;
        });
        n++;
      });
      walk(o.children);
    }); }
    (site.pages || []).forEach(function (p) { walk(p.objects); });
    Object.keys(site.masters || {}).forEach(function (m) { walk(site.masters[m].objects); });
    return n;
  }
  // producten op een pagina netjes in het raster; wat eronder staat schuift mee
  function reflow(site, pageId, order, fresh) {
    var page = site.pages.filter(function (p) { return p.id === pageId; })[0]; if (!page) return;
    var ps = page.objects.filter(function (o) { return o.type === 'group' && o.base && o.base.product; });
    if (!ps.length) return;
    var old = ps.filter(function (o) { return o !== fresh; }).sort(function (a, b) { return (a.layout.y - b.layout.y) || (a.layout.x - b.layout.x); });
    if (order) ps = order.filter(function (o) { return ps.indexOf(o) >= 0; }); else ps = old;
    var g0 = old[0].layout, w = g0.w, h = Math.max.apply(null, ps.map(function (o) { return o.layout.h; }));
    var row0 = old.filter(function (o) { return Math.abs(o.layout.y - g0.y) < 6; });
    var gapX = row0.length > 1 ? row0[1].layout.x - row0[0].layout.x - w : 20;
    var W = site.site.width || 1000;
    var cols = Math.max(row0.length, Math.max(1, Math.floor((W - 2 * g0.x + gapX) / (w + gapX))));
    if (row0.length > 1) cols = row0.length;                       // het ontwerp bepaalt de rij (3 kaarten = 3 per rij)
    var gapY = Math.max(gapX, 60);   // > 48 px: op mobiel een nieuwe rij (niet kolom-voor-kolom gestapeld)
    var oldBottom = Math.max.apply(null, old.map(function (o) { return o.layout.y + o.layout.h; }));
    ps.forEach(function (o, i) {
      var c = i % cols, r = Math.floor(i / cols);
      o.layout.x = g0.x + c * (w + gapX); o.layout.y = g0.y + r * (h + gapY);
      if (o.base.motion && o.base.motion.in) o.base.motion.delay = c * 120;
    });
    var newBottom = Math.max.apply(null, ps.map(function (o) { return o.layout.y + o.layout.h; }));
    var d = newBottom - oldBottom; if (!d) return;
    page.objects.forEach(function (o) {
      if (ps.indexOf(o) >= 0) return;
      if (o.layout.y >= oldBottom - 1) o.layout.y += d;                                   // eronder: mee schuiven
      else if (o.type === 'surface' && o.layout.y + o.layout.h >= oldBottom - 1) o.layout.h += d;   // achtergrondband eromheen: groeit mee
    });
    if (page.height) page.height = Math.max(newBottom + 80, page.height + d);
  }
  function setText(site, key, val) {
    var langs = site.site.languages || [site.site.defaultLanguage || 'nl'], t = {};
    if (val && typeof val === 'object' && !Array.isArray(val)) langs.forEach(function (l) { t[l] = val[l] != null ? val[l] : (val[site.site.defaultLanguage] || val[Object.keys(val)[0]]); });
    else langs.forEach(function (l) { t[l] = val; });
    site.translations = site.translations || {}; site.translations[key] = t;
  }
  function newKeys(site, base) { var k = base, i = 2; while (site.translations && site.translations[k + '-name']) k = base + '-' + i++; return k; }
  // velden die een op mag zetten: name, sub, desc, button (tekst of {nl,en}), price, unit, image, color (bg)
  function fill(site, p, op, keyBase) {
    var r = roleMap(p);
    ['name', 'sub', 'desc', 'button'].forEach(function (k) {
      if (op[k] == null) return;
      var el = r[k]; if (k === 'button' && el && el.type === 'group') el = roleMap({ children: el.children }).button || (el.children || []).filter(function (c) { return c.type === 'text'; })[0];
      if (!el || !el.props) return;
      var key = keyBase ? keyBase + '-' + k : el.props.text;
      setText(site, key, op[k]); el.props.text = key;
    });
    if (op.price !== undefined) {
      p.base.product.price = cents(op.price);
      if (p.base.product.price == null) delete p.base.product.price;
      if (r.price && r.price.props && p.base.product.price != null) { var pk = keyBase ? keyBase + '-price' : r.price.props.text; setText(site, pk, fmt(p.base.product.price, site.shop && site.shop.currency)); r.price.props.text = pk; }
    }
    if (op.unit !== undefined) { if (op.unit) p.base.product.unit = op.unit; else delete p.base.product.unit; }
    if (op.image && r.image && r.image.props) r.image.props.src = op.image;
    if (op.color && r.bg && r.bg.surface) r.bg.surface.fills = [{ type: 'solid', color: op.color, alpha: 1 }];
  }
  function relink(obj, from, to) {   // knoppen met ?krat=klein → ?krat=suus
    (function walk(o) {
      var a = o.base && o.base.action;
      if (a && a.query) a.query = String(a.query).replace(new RegExp('(^|&)([^=&]+)=' + from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?=&|$)'), '$1$2=' + to);
      (o.children || []).forEach(walk);
    })(obj);
  }
  function renew(o) { o.uuid = o.uuid.replace(/-[a-z0-9]{5}$/, '') + '-' + rnd(); (o.children || []).forEach(renew); }

  // ---------- de drie bewerkingen (op een kopie van de site, door de agent of de editor) ----------
  function add(site, op) {
    var all = list(site);
    var src = all.filter(function (p) { return p.id === op.from || p.uuid === op.from; })[0] || all[all.length - 1];
    if (!src) return { error: 'er is nog geen product om van uit te gaan (typeer eerst een groep als product)' };
    var id = slug(op.id || (typeof op.name === 'object' ? op.name[site.site.defaultLanguage] : op.name));
    while (all.some(function (p) { return p.id === id; })) id += '-2';
    var page = site.pages.filter(function (p) { return p.id === src.page; })[0];
    var g = clone(src.obj); renew(g);
    g.base.product = { id: id };
    if (src.unit) g.base.product.unit = src.unit;
    var keyBase = newKeys(site, 'p-' + id);
    // rollen die niet zijn opgegeven: tekst van het bronproduct overnemen onder een eigen sleutel (los aan te passen)
    var r = roleMap(g);
    if (r.button && r.button.type === 'group') r.button = roleMap({ children: r.button.children }).button || (r.button.children || []).filter(function (c) { return c.type === 'text'; })[0];
    ['name', 'sub', 'desc', 'price', 'button'].forEach(function (k) {
      if (!(r[k] && r[k].props && r[k].props.text)) return;
      site.translations[keyBase + '-' + k] = clone(site.translations[r[k].props.text] || {}); r[k].props.text = keyBase + '-' + k;
    });
    fill(site, g, op, keyBase);
    relink(g, src.id, id);
    if (src.price != null && op.price === undefined) delete g.base.product.price;
    var at = page.objects.indexOf(src.obj);
    // na het laatste product van de pagina in de lijst zetten
    var lastIdx = Math.max.apply(null, all.filter(function (p) { return p.page === page.id; }).map(function (p) { return page.objects.indexOf(p.obj); }));
    page.objects.splice(Math.max(at, lastIdx) + 1, 0, g);
    var order = list(site).filter(function (p) { return p.page === page.id && p.obj !== g; }).map(function (p) { return p.obj; });
    if (op.after) { var ai = order.map(function (o) { return o.base.product.id; }).indexOf(op.after); order.splice(ai < 0 ? order.length : ai + 1, 0, g); } else order.push(g);
    reflow(site, page.id, order, g);
    syncOptions(site);
    return { id: id, uuid: g.uuid, page: page.id };
  }
  function update(site, op) {
    var p = list(site).filter(function (x) { return x.id === op.id || x.uuid === op.id; })[0];
    if (!p) return { error: 'onbekend product ' + op.id };
    fill(site, p.obj, op, null);
    if (op.newId) { var nid = slug(op.newId); relink(p.obj, p.id, nid); p.obj.base.product.id = nid; }
    syncOptions(site);
    return { id: p.obj.base.product.id, uuid: p.uuid, page: p.page };
  }
  function remove(site, op) {
    var p = list(site).filter(function (x) { return x.id === op.id || x.uuid === op.id; })[0];
    if (!p) return { error: 'onbekend product ' + op.id };
    var page = site.pages.filter(function (q) { return q.id === p.page; })[0];
    var order = list(site).filter(function (x) { return x.page === page.id && x.obj !== p.obj; }).map(function (x) { return x.obj; });
    var rest = list(site).filter(function (x) { return x.page === page.id; }).map(function (x) { return x.obj; });
    page.objects.splice(page.objects.indexOf(p.obj), 1);
    if (order.length) reflowRemove(site, page, order, rest);
    syncOptions(site);
    return { id: p.id, page: p.page };
  }
  // na weghalen: zelfde raster, onderkant kan omhoog (rij vervalt)
  function reflowRemove(site, page, order, before) {
    var oldBottom = Math.max.apply(null, before.map(function (o) { return o.layout.y + o.layout.h; }));
    var g0 = before.slice().sort(function (a, b) { return (a.layout.y - b.layout.y) || (a.layout.x - b.layout.x); })[0].layout;
    var w = g0.w, h = Math.max.apply(null, before.map(function (o) { return o.layout.h; }));
    var row0 = before.filter(function (o) { return Math.abs(o.layout.y - g0.y) < 6; });
    var gapX = row0.length > 1 ? row0[1].layout.x - row0[0].layout.x - w : 20, cols = Math.max(1, row0.length), gapY = Math.max(gapX, 60);
    order.forEach(function (o, i) { var c = i % cols, r = Math.floor(i / cols); o.layout.x = g0.x + c * (w + gapX); o.layout.y = g0.y + r * (h + gapY); if (o.base.motion && o.base.motion.in) o.base.motion.delay = c * 120; });
    var newBottom = Math.max.apply(null, order.map(function (o) { return o.layout.y + o.layout.h; }));
    var d = newBottom - oldBottom; if (!d) return;
    page.objects.forEach(function (o) {
      if (order.indexOf(o) >= 0) return;
      if (o.layout.y >= oldBottom - 1) o.layout.y += d;
      else if (o.type === 'surface' && o.layout.y + o.layout.h >= oldBottom - 1) o.layout.h += d;
    });
    if (page.height) page.height += d;
  }
  window.WPProducts = { ROLES: ROLES, ROLE_NL: ROLE_NL, list: list, roleMap: roleMap, add: add, update: update, remove: remove, syncOptions: syncOptions, fmt: fmt, cents: cents, slug: slug, trVal: trVal };
})();

(function () {
  'use strict';
  var S = window.WPSpeler, E = window.WPEditor;
  var $ = function (id) { return document.getElementById(id); };
  var PROPOSAL = null;   // { site, summary, changes, touched, page }

  // ---------- UI ----------
  var drawer = document.createElement('div');
  drawer.id = 'agent';
  drawer.innerHTML =
    '<div class="ag-head"><b>✦ Agent</b><span class="ag-hint">Ctrl+Enter = voorstel maken</span><button class="ag-x" title="Sluiten">×</button></div>' +
    '<div id="agInfo"></div>' +
    '<div id="agTarget"></div>' +
    '<textarea id="agIn" placeholder="Wat wil je veranderen? Bijvoorbeeld:\n• Maak de kop korter en krachtiger\n• Laat de kaarten na elkaar van onder inkomen\n• Laat de bol langzaam zweven\n• Maak de accentkleur groen en de knoppen ronder\n\nSelecteer eerst objecten (shift-klik voor meer) als het alleen over die gaat."></textarea>' +
    '<label id="agNewRow" title="De agent maakt eerst een nieuwe pagina en voert je opdracht daarop uit"><input type="checkbox" id="agNew"> Maak een nieuwe pagina</label>' +
    '<div class="ag-row"><button id="agGo">Voorstel maken</button>' +
    '<select id="agTier" title="Snel = goedkoop (Haiku), Slim = sterker in ontwerp (Sonnet)"><option value="fast">Snel</option><option value="smart">Slim</option></select>' +
    '<span id="agStatus"></span></div>' +
    '<div id="agResult"></div>';
  document.body.appendChild(drawer);
  var btn = document.createElement('button');
  btn.id = 'agentBtn'; btn.textContent = '✦ Agent'; btn.title = 'Agent (Ctrl+K)';
  var bar = $('bar'); bar.insertBefore(btn, bar.querySelector('.sp'));

  function open(v) {
    drawer.classList.toggle('open', v); document.body.classList.toggle('agent-open', v);
    window.dispatchEvent(new Event('resize'));                       // canvas wordt smaller/breder
    target();
    if (v) setTimeout(function () { $('agIn').focus(); }, 50);
  }
  // waar gaat het over: de selectie of de hele pagina
  var NL = { text: 'tekst', surface: 'vlak', image: 'afbeelding', group: 'groep', video: 'video', nav: 'navigatie', form: 'formulier', language: 'taalkeuze', search: 'zoeken' };
  function target() {
    var t = $('agTarget'); if (!t) return;
    var info = E.selectionInfo ? E.selectionInfo() : [];
    if (!info.length) { t.className = ''; t.innerHTML = '<span>Doel: <b>deze pagina</b></span>'; return; }
    var names = info.map(function (x) { return NL[x] || x; });
    t.className = 'sel';
    t.innerHTML = '<span>Doel: <b>' + info.length + ' geselecteerd</b> (' + names.join(', ') + ') — de agent past alleen deze aan</span><button title="Selectie wissen">×</button>';
    t.querySelector('button').onclick = function () { E.clearSelection(); };
  }
  window.addEventListener('wp-selection', target);
  // welk account betaalt, verbruik deze maand, en of de agent voor deze site aan staat (bepaald in .secrets; de sleutel zelf komt nooit in de browser)
  var DISABLED = false;
  function info() {
    fetch(E.site().site.api + '?a=agentInfo', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': E.key() }, body: '{}' })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j || !j.ok) return;
        var why = { off: 'De agent staat uit voor deze site.', nokey: 'Geen agent-sleutel ingesteld voor deze site.', limit: 'Maandlimiet bereikt.' };
        DISABLED = j.reason === 'off' || j.reason === 'nokey';
        btn.style.display = DISABLED ? 'none' : '';
        if (DISABLED) { open(false); return; }
        $('agInfo').textContent = (j.account ? 'Account: ' + j.account + ' · ' : '') + 'deze maand ca. $' + j.usdMonth.toFixed(2) + (j.limit ? ' van $' + j.limit : '') + ' · ' + j.requests + ' vragen' + (j.reason ? ' · ' + why[j.reason] : '');
        $('agInfo').className = j.reason ? 'warn' : '';
      }).catch(function () {});
  }
  setTimeout(info, 300);
  btn.onclick = function () { if (!DISABLED) open(!drawer.classList.contains('open')); };
  drawer.querySelector('.ag-x').onclick = function () { open(false); };
  document.addEventListener('keydown', function (e) {
    if (!DISABLED && (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(!drawer.classList.contains('open')); }
  });
  $('agIn').addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); ask(); } });
  $('agGo').onclick = ask;
  try { $('agTier').value = localStorage.getItem('wpAgTier') || 'fast'; } catch (e) {}
  $('agTier').onchange = function () { try { localStorage.setItem('wpAgTier', this.value); } catch (e) {} };

  function status(t, cls) { $('agStatus').textContent = t || ''; $('agStatus').className = cls || ''; }

  // ---------- vragen ----------
  function ask(retry) {
    var instruction = $('agIn').value.trim();
    if (!instruction || drawer.classList.contains('busy')) return;
    if (PROPOSAL) reject();
    drawer.classList.add('busy'); status('de agent denkt na…');
    var t0 = Date.now(), again = false;
    fetch(E.site().site.api + '?a=agent', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Key': E.key() },
      body: JSON.stringify({ instruction: instruction, site: E.site(), page: E.page(), lang: E.lang(), selection: E.selection ? E.selection() : [], tier: $('agTier').value, newPage: !!($('agNew') && $('agNew').checked) })
    }).then(function (r) { return r.json().then(function (j) { return { s: r.status, j: j }; }); })
      .then(function (res) {
        if (res.s === 401) {                                  // sleutel ontbreekt of klopt niet: vragen en opnieuw
          if (retry !== true && E.askKey) { again = true; drawer.classList.remove('busy'); status('');
            E.askKey(function () { ask(true); }, function () { status('mislukt: geen editor-sleutel', 'err'); }); return; }
          throw new Error('geen of verkeerde editor-sleutel');
        }
        if (!res.j.ok) throw new Error(res.j.error + (res.j.detail ? ' — ' + res.j.detail : ''));
        propose(res.j, ((Date.now() - t0) / 1000).toFixed(1));
      })
      .catch(function (e) { status('mislukt: ' + e.message, 'err'); })
      .then(function () { if (!again) drawer.classList.remove('busy'); });
  }

  // ---------- operaties toepassen op een kopie ----------
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function merge(t, s) {
    Object.keys(s).forEach(function (k) {
      var v = s[k];
      if (v === null) delete t[k];
      else if (v && typeof v === 'object' && !Array.isArray(v) && t[k] && typeof t[k] === 'object' && !Array.isArray(t[k])) merge(t[k], v);
      else t[k] = clone(v);
    });
    return t;
  }
  function lists(site) {
    var out = [];
    site.pages.forEach(function (p) { out.push(p.objects); });
    Object.keys(site.masters || {}).forEach(function (m) { out.push(site.masters[m].objects); });
    (function deep(arrs) { arrs.forEach(function (L) { L.forEach(function (o) { if (o.children) { out.push(o.children); deep([o.children]); } }); }); })(out.slice());
    return out;
  }
  function find(site, uuid) {
    var all = lists(site);
    for (var i = 0; i < all.length; i++) for (var j = 0; j < all[i].length; j++) if (all[i][j].uuid === uuid) return { list: all[i], idx: j, obj: all[i][j] };
    return null;
  }
  function validObject(o) {
    if (!o || typeof o.uuid !== 'string' || typeof o.type !== 'string' || !o.layout) return false;
    if (['x', 'y', 'w', 'h'].some(function (k) { return typeof o.layout[k] !== 'number' || !isFinite(o.layout[k]); })) return false;
    return !(o.children || []).some(function (c) { return !validObject(c); });
  }
  // een echte groep (type group) uit elkaar: kinderen krijgen paginacoördinaten en erven beweging/mobiel-instellingen
  function explode(g) {
    var gb = g.base || {}, gl = g.layout;
    return (g.children || []).map(function (c) {
      var k = clone(c); k.layout.x += gl.x; k.layout.y += gl.y;
      k.base = k.base || {};
      ['motion', 'hideOnMobile', 'triggerSw', 'footer', 'gid', 'gidStack'].forEach(function (b) { if (gb[b] != null && k.base[b] == null) k.base[b] = clone(gb[b]); });
      if (!Object.keys(k.base).length) delete k.base;
      return k;
    });
  }
  // objecten in een nieuwe groep: de groep krijgt de omtrek, de kinderen coördinaten binnen de groep
  function wrap(objs, uuid) {
    var x0 = Math.min.apply(null, objs.map(function (o) { return o.layout.x; })), y0 = Math.min.apply(null, objs.map(function (o) { return o.layout.y; }));
    var x1 = Math.max.apply(null, objs.map(function (o) { return o.layout.x + o.layout.w; })), y1 = Math.max.apply(null, objs.map(function (o) { return o.layout.y + o.layout.h; }));
    var g = { uuid: uuid, type: 'group', layout: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, children: objs.map(function (o) { var k = clone(o); k.layout.x -= x0; k.layout.y -= y0; return k; }) };
    // wat alle kinderen gemeen hebben (beweging, verbergen op mobiel) gaat naar de groep
    ['motion', 'hideOnMobile', 'footer'].forEach(function (b) {
      var v = objs[0].base && objs[0].base[b];
      if (v != null && objs.every(function (o) { return o.base && JSON.stringify(o.base[b]) === JSON.stringify(v); })) {
        g.base = g.base || {}; g.base[b] = clone(v); g.children.forEach(function (k) { delete k.base[b]; if (!Object.keys(k.base).length) delete k.base; });
      }
    });
    return g;
  }
  window.WPGroups = { explode: explode, wrap: wrap };
  var TYPE_NL = { text: 'tekst', surface: 'vlak', image: 'afbeelding', group: 'groep', video: 'video', nav: 'navigatie', form: 'formulier', language: 'taalkeuze', search: 'zoeken' };

  function apply(site0, ops, pageId) {
    var site = clone(site0), changes = [], touched = {}, warn = [], goPage = null, media = [];
    var page = site.pages.filter(function (p) { return p.id === pageId; })[0];
    ops.forEach(function (op) {
      try {
        if (op.op === 'update') {
          var f = find(site, op.uuid); if (!f) { warn.push('onbekend object ' + op.uuid); return; }
          merge(f.obj, op.set || {}); touched[op.uuid] = 1;
          changes.push('Aangepast: ' + (TYPE_NL[f.obj.type] || f.obj.type) + ' (' + Object.keys(op.set || {}).join(', ') + ')');
        } else if (op.op === 'add') {
          var o = op.object; if (!validObject(o)) { warn.push('ongeldig nieuw object overgeslagen'); return; }
          if (find(site, o.uuid)) o.uuid += '-' + Math.random().toString(36).slice(2, 5);
          var list = op.target === 'master' && page.master ? site.masters[page.master].objects : page.objects;
          var b = op.before ? list.map(function (x) { return x.uuid; }).indexOf(op.before) : -1;
          if (b >= 0) list.splice(b, 0, o); else list.push(o);
          touched[o.uuid] = 1; changes.push('Nieuw: ' + (TYPE_NL[o.type] || o.type));
        } else if (op.op === 'move') {
          // bestaand object naar de master of terug naar deze pagina (zelfde plek)
          var mv = find(site, op.uuid); if (!mv) { warn.push('onbekend object ' + op.uuid); return; }
          site.masters = site.masters || {};
          if ((op.target === 'master' || op.target === 'footer') && !page.master) { var mk = Object.keys(site.masters)[0] || 'standaard'; site.masters[mk] = site.masters[mk] || { objects: [] }; page.master = mk; }
          var toM = op.target === 'master' || op.target === 'footer';
          var dest = toM ? site.masters[page.master].objects : page.objects;
          if (mv.list !== dest) { mv.list.splice(mv.idx, 1); dest.push(mv.obj); }
          mv.obj.base = mv.obj.base || {};
          if (op.target === 'footer') mv.obj.base.footer = true; else { delete mv.obj.base.footer; if (!Object.keys(mv.obj.base).length) delete mv.obj.base; }
          touched[op.uuid] = 1;
          changes.push(({ master: 'Naar master: ', footer: 'Naar footer: ', page: 'Naar pagina: ' }[op.target] || 'Verplaatst: ') + (TYPE_NL[mv.obj.type] || mv.obj.type));
        } else if (op.op === 'remove') {
          var r = find(site, op.uuid); if (!r) return;
          r.list.splice(r.idx, 1); changes.push('Verwijderd: ' + (TYPE_NL[r.obj.type] || r.obj.type));
        } else if (op.op === 'text') {
          site.translations[op.key] = merge(site.translations[op.key] || {}, op.values || {});
          var first = op.values && op.values[E.lang()]; first = Array.isArray(first) ? first.map(function (x) { return x.t; }).join('') : first;
          var shown = String(first || op.key).replace(/^[“"']+|[”"']+$/g, '').slice(0, 60);
          changes.push('Tekst: “' + shown + '”');
          lists(site).forEach(function (L) { L.forEach(function (x) { if (x.props && x.props.text === op.key) touched[x.uuid] = 1; }); });
        } else if (op.op === 'color') {
          if (!/^#[0-9a-f]{6}$/i.test(op.value || '')) { warn.push('kleur ' + op.name + ' ongeldig'); return; }
          changes.push('Kleur @' + op.name + ': ' + (site.colors[op.name] || 'nieuw') + ' → ' + op.value); site.colors[op.name] = op.value;
        } else if (op.op === 'style') {
          site.styles[op.id] = merge(site.styles[op.id] || {}, op.style || {}); changes.push('Stijl: ' + op.id);
        } else if (op.op === 'font') {
          if (!site.fonts.some(function (x) { return x.family === op.family; })) { site.fonts.push({ family: op.family, google: op.google }); changes.push('Font: ' + op.family); }
        } else if (op.op === 'page') {
          var oldPath = page.path, wantPath = op.set && op.set.path;
          if (wantPath !== undefined && wantPath !== null) {
            var okPath = typeof wantPath === 'string' && /^\/[a-z0-9][a-z0-9\-\/]*$/.test(wantPath) && page.id !== site.site.homePage &&
              !site.pages.some(function (x) { return x !== page && (x.path || '/' + x.id) === wantPath; });
            if (!okPath) { warn.push('adres "' + wantPath + '" niet toegestaan of al in gebruik: niet gewijzigd'); delete op.set.path; wantPath = undefined; }
          }
          merge(page, op.set || {});
          if (wantPath && oldPath && oldPath !== page.path && oldPath !== '/') {      // oud adres blijft doorverwijzen
            page.aliases = (page.aliases || []).filter(function (x) { return x !== oldPath && x !== page.path; }); page.aliases.push(oldPath);
            if (page.aliases.length > 20) page.aliases.shift();
          }
          changes.push('Pagina: ' + Object.keys(op.set || {}).join(', '));
        } else if (op.op === 'ungroup') {
          // groep opheffen: de onderdelen worden losse objecten op dezelfde plek (en dezelfde laag)
          var g = find(site, op.uuid); if (!g) { warn.push('onbekende groep ' + op.uuid); return; }
          if (g.obj.type === 'group') {
            var kids = explode(g.obj); g.list.splice.apply(g.list, [g.idx, 1].concat(kids));
            kids.forEach(function (k) { touched[k.uuid] = 1; }); changes.push('Groep opgeheven: ' + kids.length + ' losse objecten');
          } else if (g.obj.base && g.obj.base.gid) {
            // één laag eraf (groep-in-groep blijft bestaan)
            var gid = g.obj.base.gid; g.list.forEach(function (x) {
              if (!(x.base && x.base.gid === gid)) return;
              var st = x.base.gidStack || [];
              if (st.length) { x.base.gid = st[st.length - 1]; if (st.length > 1) x.base.gidStack = st.slice(0, -1); else delete x.base.gidStack; } else delete x.base.gid;
              touched[x.uuid] = 1;
            });
            changes.push('Groep opgeheven');
          } else warn.push(op.uuid + ' is geen groep');
        } else if (op.op === 'group') {
          // objecten samen in één groep (blijft op mobiel als één geheel bij elkaar)
          var fs = (op.uuids || []).map(function (u) { return find(site, u); });
          if (fs.length < 2 || fs.some(function (x) { return !x; })) { warn.push('groeperen: onbekende objecten'); return; }
          if (fs.some(function (x) { return x.list !== fs[0].list; })) { warn.push('groeperen: objecten liggen niet op hetzelfde niveau'); return; }
          fs.sort(function (a, b) { return a.list.indexOf(a.obj) - b.list.indexOf(b.obj); });   // laagvolgorde houden
          var grp = wrap(fs.map(function (x) { return x.obj; }), op.uuid && !find(site, op.uuid) ? op.uuid : 'g-' + Math.random().toString(36).slice(2, 8));
          var L = fs[0].list, at = Math.min.apply(null, fs.map(function (x) { return L.indexOf(x.obj); }));
          fs.forEach(function (x) { L.splice(L.indexOf(x.obj), 1); }); L.splice(at, 0, grp);
          if (typeof op.name === 'string' && op.name.trim()) grp.name = op.name.trim().slice(0, 60);   // naam voor de eigenaar (bv. "kaart: bezorging")
          touched[grp.uuid] = 1; changes.push('Gegroepeerd: ' + fs.length + ' objecten');
        } else if (op.op === 'addProduct' || op.op === 'updateProduct' || op.op === 'removeProduct') {
          // producten: de motor doet het precieze werk (klonen, rollen invullen, raster, formulierkeuzes)
          var PR = window.WPProducts;
          // een getekend figuurtje (op.svg): in het voorstel als data-adres, pas bij goedkeuren als bestand in media/
          if (op.svg && op.op !== 'removeProduct') {
            var svg = String(op.svg).trim();
            if (!/^(<\?xml[^>]*>\s*)?<svg[\s>]/i.test(svg) || svg.length > 40000 || /<script|\bon[a-z]+\s*=|javascript:|<foreignobject|<iframe|<embed|<object|<image|xlink:href\s*=\s*["']\s*(?!#)|href\s*=\s*["']\s*(?!#)/i.test(svg)) {
              warn.push('getekend beeld overgeslagen (geen veilige SVG)');
            } else {
              if (!/xmlns=/.test(svg)) svg = svg.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
              var nmBase = typeof op.name === 'object' && op.name ? (op.name[site.site.defaultLanguage] || '') : (op.name || op.id || 'beeld');
              var file = PR.slug(String(op.file || nmBase).replace(/\.svg$/i, '')) + '.svg';
              var uri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
              media.push({ name: file, svg: svg, uri: uri });
              op = Object.assign({}, op, { image: uri }); delete op.svg;
              changes.push('Nieuw beeld (getekend): ' + file + ' — komt in media/ bij goedkeuren');
            }
          }
          var res = (op.op === 'addProduct' ? PR.add : op.op === 'updateProduct' ? PR.update : PR.remove)(site, op);
          if (res.error) { warn.push(res.error); return; }
          if (res.uuid) touched[res.uuid] = 1;
          var nm = PR.list(site).filter(function (x) { return x.id === res.id; })[0];
          changes.push((op.op === 'addProduct' ? 'Nieuw product: ' : op.op === 'updateProduct' ? 'Product aangepast: ' : 'Product verwijderd: ') + ((nm && nm.name) || res.id)
            + (op.op !== 'updateProduct' ? ' (kaarten opnieuw ingedeeld, keuzes in het formulier bijgewerkt)' : ''));
          if (res.page && res.page !== pageId && !goPage) goPage = res.page;
        } else if (op.op === 'addPage') {
          var np = op.page;
          if (!np || !np.id || !Array.isArray(np.objects) || !np.objects.every(validObject)) { warn.push('nieuwe pagina ongeldig'); return; }
          if (site.pages.some(function (x) { return x.id === np.id; })) np.id += '-2';
          np.path = np.path || '/' + np.id; site.pages.push(np); goPage = np.id;
          np.objects.forEach(function (x) { touched[x.uuid] = 1; }); changes.push('Nieuwe pagina: ' + np.id);
        }
      } catch (e) { warn.push(op.op + ': ' + e.message); }
    });
    return { site: site, changes: changes, touched: touched, warn: warn, page: goPage || pageId, media: media };
  }

  // ---------- voorstel tonen ----------
  function propose(res, secs) {
    var r = apply(E.site(), res.ops || [], E.page());
    if (!r.changes.length) {
      // geen wijzigingen: meestal een vraag of uitleg van de agent (bv. 'Hoe moet de nieuwe pagina heten?'): toon de tekst zodat je kunt antwoorden
      var qb = $('agResult'); qb.innerHTML = '';
      if (res.summary) { var qs = document.createElement('p'); qs.className = 'ag-sum'; qs.textContent = res.summary; qb.appendChild(qs); }
      status(res.summary ? 'de agent heeft een vraag of opmerking' : 'geen wijzigingen voorgesteld' + (r.warn.length ? ' (' + r.warn.join('; ') + ')' : ''), res.summary ? 'ok' : 'err');
      info(); return;
    }
    PROPOSAL = r;
    document.body.classList.add('ag-preview');
    E.preview(r.site, r.page);
    mark();
    var u = res.costUsd !== undefined ? ' · $' + Number(res.costUsd).toFixed(res.costUsd < 0.01 ? 4 : 3) + (res.usage && res.usage.cache_read_input_tokens ? ' (cache)' : '') : '';
    status('voorstel klaar in ' + secs + 's' + u, 'ok');
    info();
    var box = $('agResult');
    box.innerHTML = '';
    var sum = document.createElement('p'); sum.className = 'ag-sum'; sum.textContent = res.summary || 'Voorstel'; box.appendChild(sum);
    var ul = document.createElement('ul');
    r.changes.forEach(function (c) { var li = document.createElement('li'); li.textContent = c; ul.appendChild(li); });
    r.warn.forEach(function (c) { var li = document.createElement('li'); li.className = 'warn'; li.textContent = '⚠ ' + c; ul.appendChild(li); });
    box.appendChild(ul);
    var row = document.createElement('div'); row.className = 'ag-row';
    var ok = document.createElement('button'); ok.className = 'ag-ok'; ok.textContent = '✓ Goedkeuren';
    var no = document.createElement('button'); no.className = 'ag-no'; no.textContent = 'Afwijzen';
    ok.onclick = approve; no.onclick = reject;
    row.appendChild(ok); row.appendChild(no); box.appendChild(row);
    var note = document.createElement('p'); note.className = 'ag-note';
    note.textContent = 'Goedkeuren zet het voorstel in de editor; daarna gewoon opslaan (Ctrl+S). Afwijzen laat alles zoals het was.';
    box.appendChild(note);
  }
  function mark() {
    if (!PROPOSAL) return;
    Object.keys(PROPOSAL.touched).forEach(function (id) {
      document.querySelectorAll('#wp-root [data-uuid="' + id + '"]').forEach(function (n) { n.classList.add('ag-changed'); });
    });
  }
  // na elke herbouw (resize) de markering opnieuw zetten
  var prevBuilt = window.WP_OPTIONS.onBuilt;
  window.WP_OPTIONS.onBuilt = function (a, b) { prevBuilt && prevBuilt(a, b); mark(); };

  function end() { PROPOSAL = null; document.body.classList.remove('ag-preview'); $('agResult').innerHTML = ''; }
  // getekende beelden uit het voorstel naar media/ (zelfde weg en controle als uploaden in de Beeld-bibliotheek)
  function upload(m, retry) {
    return fetch(E.site().site.api + '?a=mediaUpload&name=' + encodeURIComponent(m.name), {
      method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-WP-Key': E.key() }, body: new Blob([m.svg], { type: 'image/svg+xml' })
    }).then(function (r) { return r.json().catch(function () { return { ok: false, error: 'HTTP ' + r.status }; }).then(function (j) { j._s = r.status; return j; }); })
      .then(function (j) {
        if (j._s === 401 && retry !== true && E.askKey) return new Promise(function (ok, no) { E.askKey(function () { upload(m, true).then(ok, no); }, function () { no(new Error('geen editor-sleutel')); }); });
        if (!j.ok || !j.item) throw new Error(j.error || 'uploaden mislukt');
        return j.item.file;
      });
  }
  function approve() {
    if (!PROPOSAL) return;
    var p = PROPOSAL, todo = p.media || [];
    if (!todo.length) { end(); E.adopt(p.site, p.page); status('overgenomen — nog niet opgeslagen (Ctrl+S)', 'ok'); $('agIn').value = ''; return; }
    status('beeld opslaan in media/…');
    var json = JSON.stringify(p.site), names = [];
    todo.reduce(function (chain, m) {
      return chain.then(function () { return upload(m).then(function (file) {
        names.push(file.replace(/^media\//, ''));
        json = json.split(JSON.stringify(m.uri).slice(1, -1)).join(file);     // data-adres → media/naam.svg (kaart én formulierkeuze)
      }); });
    }, Promise.resolve()).then(function () {
      end(); E.adopt(JSON.parse(json), p.page);
      window.dispatchEvent(new Event('wp-media-changed'));
      status('overgenomen, ' + names.join(', ') + ' staat in media/ — nog niet opgeslagen (Ctrl+S)', 'ok'); $('agIn').value = '';
    }).catch(function (e) { status('beeld niet opgeslagen: ' + e.message + ' — voorstel staat nog open', 'err'); });
  }
  function reject() { if (!PROPOSAL) return; end(); E.restore(); status('afgewezen', ''); }
  window.WPAgent = { approve: approve, reject: reject };
})();
