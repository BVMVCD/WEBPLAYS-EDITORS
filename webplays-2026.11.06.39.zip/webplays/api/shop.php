<?php
declare(strict_types=1);
/*  WEBPLAYS shop (neutraal): producten en bedragen komen uit site.json; de server rekent altijd zelf.
    - collectie met "role": "products"; item: price {amount (centen), currency, vat, incl}, sell {online, min, max, step}, specs.gewichtKg
    - site.shop: {currency, vat:{naam: percentage}, priceDisplay, orderPrefix, fulfilment:[{id, kind, price, rules, freeAbove}], fulfilment:[…]} (betalen staat NIET in site.json: zie .secrets)
    - formulier met props.order {collection, item, qty, fulfilment?}: bij verzenden wordt de bestelling opnieuw uitgerekend en met nummer opgeslagen.
    Geen betaalprovider hier: betalen volgt in een apart koppelvlak (api/pay/<provider>.php). Alle bedragen zijn gehele centen. */

function wp_shop_cfg(array $site): array {
    $s = is_array($site['shop'] ?? null) ? $site['shop'] : [];
    return $s + ['currency' => 'EUR', 'vat' => ['hoog' => 21, 'laag' => 9, 'nul' => 0], 'priceDisplay' => 'incl', 'orderPrefix' => '', 'fulfilment' => []];
}
function wp_shop_find(array $site, string $collection, string $sku): ?array {
    foreach (($site['collections'][$collection]['items'] ?? []) as $it) {
        if (!is_array($it)) continue;
        if ((string)($it['sku'] ?? '') === $sku || (string)($it['id'] ?? '') === $sku) return $it;
    }
    return null;
}
function wp_shop_vat_rate(array $cfg, $key): float {
    $k = (string)($key ?? 'hoog');
    return isset($cfg['vat'][$k]) ? (float)$cfg['vat'][$k] : 0.0;
}
// € 19,95 (nl) — voor weergave in meldingen
function wp_money(int $cents, string $cur = 'EUR'): string {
    $sym = ['EUR' => '€', 'USD' => '$', 'GBP' => '£'][$cur] ?? $cur;
    return $sym . ' ' . number_format($cents / 100, 2, ',', '.');
}
/*  $lines = [['sku' => 'BNK-30101', 'qty' => 2], …]; $opt: collection, fulfilment (id)
    geeft ['ok' => true, 'lines' => [...], 'shipping' => [...], 'totals' => [...], 'currency' => …] of ['ok' => false, 'error' => 'code'] */
function wp_shop_quote(array $site, array $lines, array $opt = []): array {
    $cfg = wp_shop_cfg($site);
    $coll = (string)($opt['collection'] ?? 'producten');
    $cur = (string)$cfg['currency'];
    if (!$lines) return ['ok' => false, 'error' => 'empty'];
    $out = []; $net = 0; $vat = 0; $gross = 0; $grams = 0; $vatBy = [];
    foreach ($lines as $l) {
        $sku = (string)($l['sku'] ?? ''); $qty = $l['qty'] ?? null;
        if (!is_int($qty) && !(is_string($qty) && ctype_digit($qty))) return ['ok' => false, 'error' => 'qty:' . $sku];
        $qty = (int)$qty;
        $it = wp_shop_find($site, $coll, $sku);
        if (!$it || ($it['active'] ?? true) === false) return ['ok' => false, 'error' => 'unknown:' . $sku];
        $sell = is_array($it['sell'] ?? null) ? $it['sell'] : [];
        if (($sell['online'] ?? true) === false) return ['ok' => false, 'error' => 'notforsale:' . $sku];
        $pr = $it['price'] ?? null;
        if (!is_array($pr) || !isset($pr['amount']) || !is_int($pr['amount']) || $pr['amount'] < 0) return ['ok' => false, 'error' => 'noprice:' . $sku];
        if (!empty($pr['currency']) && $pr['currency'] !== $cur) return ['ok' => false, 'error' => 'currency:' . $sku];
        $min = (int)($sell['min'] ?? 1); $max = (int)($sell['max'] ?? 999); $step = max(1, (int)($sell['step'] ?? 1));
        if ($qty < $min || $qty > $max || ($qty - $min) % $step !== 0) return ['ok' => false, 'error' => 'qty:' . $sku];
        $rate = wp_shop_vat_rate($cfg, $pr['vat'] ?? 'hoog');
        $incl = !empty($pr['incl']);
        if ($incl) { $lg = $pr['amount'] * $qty; $ln = (int)round($lg / (1 + $rate / 100)); }
        else { $ln = $pr['amount'] * $qty; $lg = $ln + (int)round($ln * $rate / 100); }
        $lv = $lg - $ln;
        $net += $ln; $vat += $lv; $gross += $lg; $vatBy[(string)$rate] = ($vatBy[(string)$rate] ?? 0) + $lv;
        $kg = $it['specs']['gewichtKg'] ?? null; $g = isset($sell['grams']) ? (int)$sell['grams'] : (is_numeric($kg) ? (int)round((float)$kg * 1000) : 0);
        $grams += $g * $qty;
        $out[] = ['sku' => (string)($it['sku'] ?? $it['id']), 'name' => $it['name'] ?? $sku, 'qty' => $qty, 'unit' => (string)($it['unit'] ?? ''),
                  'unitAmount' => $pr['amount'], 'incl' => $incl, 'vatRate' => $rate, 'net' => $ln, 'vat' => $lv, 'gross' => $lg];
    }
    // verzending / afhalen
    $ship = ['id' => null, 'kind' => null, 'net' => 0, 'vat' => 0, 'gross' => 0];
    $opts = is_array($cfg['fulfilment']) ? $cfg['fulfilment'] : [];
    if ($opts) {
        $want = (string)($opt['fulfilment'] ?? '');
        $f = null;
        foreach ($opts as $o) if (is_array($o) && ($want === '' ? count($opts) === 1 : (string)($o['id'] ?? '') === $want)) $f = $o;
        if (!$f) return ['ok' => false, 'error' => 'fulfilment'];
        $price = (int)($f['price'] ?? 0);
        foreach (($f['rules'] ?? []) as $r) {                       // eerste regel waar het gewicht (gram) onder valt
            if (!isset($r['upTo']) || $r['upTo'] === null || $grams <= (int)$r['upTo']) { $price = (int)($r['price'] ?? 0); break; }
        }
        if (isset($f['freeAbove']) && $gross >= (int)$f['freeAbove']) $price = 0;
        $r = wp_shop_vat_rate($cfg, $f['vat'] ?? 'hoog'); $sn = (int)round($price / (1 + $r / 100));   // verzendprijs is altijd inclusief btw
        $ship = ['id' => (string)($f['id'] ?? ''), 'kind' => (string)($f['kind'] ?? ''), 'net' => $sn, 'vat' => $price - $sn, 'gross' => $price];
        $net += $sn; $vat += $price - $sn; $gross += $price;
        if ($price) $vatBy[(string)$r] = ($vatBy[(string)$r] ?? 0) + ($price - $sn);
    }
    return ['ok' => true, 'currency' => $cur, 'lines' => $out, 'shipping' => $ship, 'grams' => $grams,
            'totals' => ['net' => $net, 'vat' => $vat, 'gross' => $gross, 'vatBy' => $vatBy]];
}
// volgend bestelnummer (vergrendeld; getal loopt nooit terug)
function wp_shop_next_number(array $site): string {
    $cfg = wp_shop_cfg($site);
    $f = STORAGE . '/order-seq.txt';
    if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
    $fh = fopen($f, 'c+'); if (!$fh) return (string)$cfg['orderPrefix'] . date('ymdHis');
    flock($fh, LOCK_EX);
    $n = (int)trim((string)stream_get_contents($fh)) + 1;
    ftruncate($fh, 0); rewind($fh); fwrite($fh, (string)$n); fflush($fh); flock($fh, LOCK_UN); fclose($fh);
    return (string)$cfg['orderPrefix'] . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}
// bestelling bij een formulierinzending (props.order); geeft het 'order'-blok voor de rij, of een foutcode
function wp_shop_order_from_form(array $site, array $orderDef, array $rawData): array {
    $item = (string)($orderDef['item'] ?? ''); $qtyKey = (string)($orderDef['qty'] ?? '');
    $sku = trim((string)($rawData[$item] ?? ''));
    $qty = $qtyKey !== '' ? trim((string)($rawData[$qtyKey] ?? '1')) : '1';
    $q = wp_shop_quote($site, [['sku' => $sku, 'qty' => $qty]], [
        'collection'  => (string)($orderDef['collection'] ?? 'producten'),
        'fulfilment'  => (string)($orderDef['fulfilment'] ?? ''),
    ]);
    if (!$q['ok']) return $q;
    $now = gmdate('c');
    return ['ok' => true, 'order' => [
        'number' => wp_shop_next_number($site), 'status' => 'nieuw', 'currency' => $q['currency'],
        'lines' => $q['lines'], 'shipping' => $q['shipping'], 'totals' => $q['totals'],
        'log' => [['at' => $now, 'status' => 'nieuw']],
    ]];
}
// mandje: lijst [{sku, qty}] (max 50 regels), samengevoegd per SKU
function wp_shop_clean_cart(array $cart): ?array {
    if (count($cart) > 50) return null;
    $m = [];
    foreach ($cart as $l) {
        if (!is_array($l)) return null;
        $sku = (string)($l['sku'] ?? ''); $q = $l['qty'] ?? null;
        if ($sku === '' || strlen($sku) > 64 || !(is_int($q) || (is_string($q) && ctype_digit($q)))) return null;
        $m[$sku] = ($m[$sku] ?? 0) + (int)$q;
    }
    $out = []; foreach ($m as $k => $q) $out[] = ['sku' => (string)$k, 'qty' => $q];
    return $out;
}
function wp_shop_quote_public(array $site, array $cart, string $fulfil, string $coll = 'producten'): array {
    $lines = wp_shop_clean_cart($cart);
    if ($lines === null) return ['ok' => false, 'error' => 'cart'];
    if (!$lines) return ['ok' => true, 'empty' => true];
    if ($fulfil === '') { $fo = wp_shop_cfg($site)['fulfilment']; if ($fo && is_array($fo[0] ?? null)) $fulfil = (string)($fo[0]['id'] ?? ''); }
    $q = wp_shop_quote($site, $lines, ['collection' => $coll, 'fulfilment' => $fulfil]);
    if (!$q['ok']) return $q;
    unset($q['grams']);
    return $q;
}
// bestelling uit een mandje (props.order.cart = true); geeft ['ok' => true, 'order' => …] of een foutcode
function wp_shop_order_from_cart(array $site, array $orderDef, array $cart, string $fulfil): array {
    $lines = wp_shop_clean_cart($cart);
    if (!$lines) return ['ok' => false, 'error' => 'empty'];
    if ($fulfil === '') $fulfil = (string)($orderDef['fulfilment'] ?? '');
    if ($fulfil === '') { $fo = wp_shop_cfg($site)['fulfilment']; if ($fo && is_array($fo[0] ?? null)) $fulfil = (string)($fo[0]['id'] ?? ''); }
    $q = wp_shop_quote($site, $lines, ['collection' => (string)($orderDef['collection'] ?? 'producten'), 'fulfilment' => $fulfil]);
    if (!$q['ok']) return $q;
    return ['ok' => true, 'order' => [
        'number' => wp_shop_next_number($site), 'status' => 'nieuw', 'currency' => $q['currency'],
        'lines' => $q['lines'], 'shipping' => $q['shipping'], 'totals' => $q['totals'],
        'log' => [['at' => gmdate('c'), 'status' => 'nieuw']],
    ]];
}
// leesbare regels voor in de melding (bestelnummer, regels, totaal)
function wp_shop_order_items(array $site, array $order): array {
    $cfg = wp_shop_cfg($site); $cur = (string)($order['currency'] ?? $cfg['currency']);
    $dl = (string)($site['site']['defaultLanguage'] ?? 'nl'); $rows = [];
    $rows[] = ['Bestelnummer', (string)($order['number'] ?? ''), 'text', 'order-number'];
    $t = '';
    foreach (($order['lines'] ?? []) as $l) {
        $nm = $l['name'] ?? $l['sku']; if (is_array($nm)) $nm = $nm[$dl] ?? reset($nm);
        $t .= $l['qty'] . ' × ' . $nm . ' (' . ($l['sku'] ?? '') . ') — ' . wp_money((int)$l['gross'], $cur) . "\n";
    }
    if (!empty($order['shipping']['id'])) $t .= ($order['shipping']['kind'] === 'pickup' ? 'Afhalen' : 'Verzending') . ' — ' . wp_money((int)$order['shipping']['gross'], $cur) . "\n";
    $rows[] = ['Bestelling', rtrim($t), 'text', 'order-lines'];
    $tt = $order['totals'] ?? [];
    $rows[] = ['Totaal', wp_money((int)($tt['gross'] ?? 0), $cur) . ' incl. btw (btw ' . wp_money((int)($tt['vat'] ?? 0), $cur) . ')', 'text', 'order-total'];
    if (!empty($order['payment'])) $rows[] = ['Betaling', ucfirst((string)($order['payment']['provider'] ?? '')) . ' — ' . (string)($order['status'] ?? ''), 'text', 'order-status'];
    return $rows;
}
