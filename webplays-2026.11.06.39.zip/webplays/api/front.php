<?php
// De voordeur van een site: index.php van de site laadt dit bestand (zie het sjabloon index.php en .htaccess).
if (!defined('WP_SITE_DIR')) { http_response_code(404); exit; }
require_once __DIR__ . '/seo.php';
wp_front();
