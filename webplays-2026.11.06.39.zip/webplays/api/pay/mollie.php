<?php
declare(strict_types=1);
/*  Mollie-koppeling. Sleutels in .secrets:  'payProvider' => 'mollie',  'mollieKey' => 'test_…' of 'live_…'
    (optioneel 'mollieApi' voor een testserver; standaard https://api.mollie.com/v2). Modus volgt uit de sleutel. */
function wp_pay_mollie_call(string $method, string $path, array $cfg, ?array $body = null): array {
    $key = (string)($cfg['mollieKey'] ?? '');
    if (!preg_match('/^(test|live)_[A-Za-z0-9]{10,}$/', $key)) throw new RuntimeException('mollieKey ontbreekt of heeft een onjuist formaat');
    $base = rtrim((string)($cfg['mollieApi'] ?? 'https://api.mollie.com/v2'), '/');
    [$code, $j] = wp_http($method, $base . $path, ['Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        $body === null ? null : json_encode($body, JSON_UNESCAPED_UNICODE));
    if ($code < 200 || $code >= 300 || !$j) throw new RuntimeException('Mollie ' . $code . (isset($j['detail']) ? ': ' . $j['detail'] : '') . (!empty($GLOBALS['wp_http_err']) ? ' [' . $GLOBALS['wp_http_err'] . ']' : ''));
    return $j;
}
function wp_pay_mollie_create(array $order, array $ctx): array {
    $body = [
        'amount'      => ['currency' => (string)$order['currency'], 'value' => number_format(((int)$order['totals']['gross']) / 100, 2, '.', '')],
        'description' => (string)$ctx['description'],
        'redirectUrl' => (string)$ctx['redirectUrl'],
        'locale'      => (string)$ctx['locale'],
        'metadata'    => ['order' => (string)$order['number']],
    ];
    if (!empty($ctx['webhookUrl'])) $body['webhookUrl'] = (string)$ctx['webhookUrl'];
    $j = wp_pay_mollie_call('POST', '/payments', $ctx['cfg'], $body);
    $url = $j['_links']['checkout']['href'] ?? null;
    if (empty($j['id']) || !$url) throw new RuntimeException('Mollie gaf geen betaallink');
    return ['id' => (string)$j['id'], 'url' => (string)$url];
}
function wp_pay_mollie_status(string $id, array $cfg): string {
    $j = wp_pay_mollie_call('GET', '/payments/' . rawurlencode($id), $cfg);
    $s = (string)($j['status'] ?? 'open');
    return in_array($s, ['paid', 'failed', 'canceled', 'expired'], true) ? $s : 'open';   // open, pending, authorized → nog niet klaar
}
