<?php
/*  WEBPLAYS API (motor: webplays/api/core.php) — één ingang voor het dynamische deel (gesplitst dynamisch).
    Bezoekers lezen de vorm (site.json) direct als bestand; hier komt alleen wat iemand doet:
    een bezoeker (form) of de editor (save).
    Aanroep: api/index.php?a=<actie>   (form = bezoeker, save/agent = editor)
*/
declare(strict_types=1);

// PHP 7.4-compatibel (sommige hosts draaien nog PHP 7): deze drie bestaan pas vanaf PHP 8
if (!function_exists('str_contains')) { function str_contains(string $h, string $n): bool { return $n === '' || strpos($h, $n) !== false; } }
if (!function_exists('str_starts_with')) { function str_starts_with(string $h, string $n): bool { return $n === '' || strncmp($h, $n, strlen($n)) === 0; } }
if (!function_exists('str_ends_with')) { function str_ends_with(string $h, string $n): bool { return $n === '' || substr($h, -strlen($n)) === $n; } }
require_once __DIR__ . '/shop.php';
require_once __DIR__ . '/pay.php';
require_once __DIR__ . '/editors.php';   // centrale editor-sleutels (gesigneerde lijst), sessietokens en inlogrem
require_once __DIR__ . '/updater.php';   // motor bijwerken (ondertekende aankondiging, controle, wisselen, terugzetten)
require_once __DIR__ . '/seo.php';   // sitemap, robots.txt en de voordeur (titel, omschrijving, delen) per pagina   // webshop (producten, bedragen, bestelnummer); geen provider hier

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// de motor staat op één plek; de site geeft zijn eigen map door (WP_SITE_DIR, zie api/index.php van de site).
// Direct aanroepen van de motor zonder site kan niet.
if (!defined('WP_SITE_DIR')) { http_response_code(404); exit; }
// opslag (versies, formulieren, logboek, config): standaard storage/ in de site; online liefst BUITEN de webroot (WP_STORAGE_DIR)
define('STORAGE', defined('WP_STORAGE_DIR') ? WP_STORAGE_DIR : WP_SITE_DIR . '/storage');
define('SITE_FILE', WP_SITE_DIR . '/site.json');
if (!defined('WP_SECRETS')) define('WP_SECRETS', dirname(WP_SITE_DIR) . '/.secrets');   // lokaal D:\WWW\.secrets, online naast httpdocs
const WP_MEDIA_RX = '/^[a-z0-9][a-z0-9._-]*\.(jpe?g|png|gif|webp|svg)$/i';   // beeldbestanden in media/
const MAX_BODY = 2000000;   // 2 MB; formulieren worden hieronder strenger begrensd

function reply(array $out, int $code = 200): never {
    http_response_code($code);
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}


// editor-rechten: sleutel, of lokaal zonder sleutel als 'requireKey' => false
// instellingen: storage/config.php < .secrets/webplays.php (motor en editor, gedeeld) < .secrets/<siteId>.php (deze site)
function wp_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $cfgFile = STORAGE . '/config.php';
    $cfg = is_file($cfgFile) ? require $cfgFile : [];
    if (!is_array($cfg)) $cfg = [];
    $secFile = (string)($cfg['secretsFile'] ?? WP_SECRETS . '/webplays.php');
    if (is_file($secFile)) { $sec = require $secFile; if (is_array($sec)) $cfg = array_merge($cfg, array_filter($sec, fn($v) => $v !== '' && $v !== null)); }
    // per site iets anders (meldingen naar de klant, eigen SMTP, betaalsleutels): .secrets/<siteId>.php wint van webplays.php
    //   siteId = 'siteId' uit de config, anders meta.name uit site.json. Lokaal en online hetzelfde bestand, ongeacht mapnaam of (sub)domein.
    //   Een testkopie die eigen instellingen nodig heeft, krijgt een eigen siteId (bv. make-peas-test). Zie WEBPLAYS_config_per_site.md
    //   Terugval voor oude opstellingen: bestaat <siteId>.php niet, dan wordt .secrets/<mapnaam van de site>.php gelezen.
    $sid = (string)($cfg['siteId'] ?? '');
    if ($sid === '') { $j = json_decode((string)@file_get_contents(SITE_FILE), true); $sid = is_array($j) ? (string)($j['meta']['name'] ?? '') : ''; }
    $sid = preg_replace('/[^A-Za-z0-9._-]/', '', $sid);
    $ok = fn($n) => $n !== '' && $n[0] !== '.' && $n !== 'webplays' && $n !== 'cacert';
    $siteSec = $ok($sid) ? dirname($secFile) . '/' . $sid . '.php' : '';
    if ($siteSec === '' || !is_file($siteSec)) $siteSec = dirname($secFile) . '/' . basename(WP_SITE_DIR) . '.php';
    if (is_file($siteSec) && $siteSec !== $secFile) { $s2 = require $siteSec; if (is_array($s2)) $cfg = array_merge($cfg, array_filter($s2, fn($v) => $v !== '' && $v !== null)); }
    return $cfg;
}

// Controle bij OPSLAAN in de editor. Lezen blijft soepel: een oude site.json die niet bewerkt wordt, raakt hierdoor nooit stuk.
// Nu: taalcodes (komen in de taalkiezer als HTML terecht) en het script-pad van een tekenmotor (props.plan.script wordt als script geladen).
// Een script-pad mag alleen een .js in de site zijn (bv. media/wpconfigurator.js) of 'cdn:pad.js'; geen http(s):, '//', data:, javascript: of '..'.
// Onbekende velden blijven bewaard (de rest van site.json wordt niet aangeraakt).
function wp_site_check(array $in): array {
    $issues = [];
    $lang = fn($c) => is_string($c) && preg_match('/^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8}){0,3}$/', $c) === 1;
    foreach ((array)($in['site']['languages'] ?? []) as $c) {
        if (!$lang($c)) $issues[] = 'Ongeldige taalcode: ' . (is_scalar($c) ? mb_substr((string)$c, 0, 20) : '?');
    }
    if (isset($in['site']['defaultLanguage']) && !$lang($in['site']['defaultLanguage'])) $issues[] = 'Ongeldige hoofdtaal';
    $su = $in['site']['url'] ?? null;
    if ($su !== null && $su !== '' && (!is_string($su) || preg_match('#^https?://[a-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~/-]*)?$#i', $su) !== 1)) $issues[] = 'Ongeldig site-adres (bijv. https://www.voorbeeld.nl)';
    // bestandspaden voor favicon en deelplaatjes: alleen een afbeelding in de site (of cdn:), geen extern adres, geen ..
    $okp = fn($p) => is_string($p) && preg_match('/\.(svg|png|gif|webp|jpe?g|ico|avif)$/i', $p) === 1 && !str_contains($p, '..') && !str_contains($p, '\\')
        && (str_starts_with($p, 'cdn:') || preg_match('#^(/|[a-z][a-z0-9+.-]*:)#i', $p) !== 1);
    $fv = $in['site']['favicon'] ?? null;
    if ($fv !== null) {
        if (!is_array($fv)) $issues[] = 'Ongeldige favicon';
        else {
            foreach (['file', 'fallback'] as $k) if ((isset($fv[$k]) && $fv[$k] !== '' && !$okp($fv[$k]))) $issues[] = 'Ongeldig favicon-pad (' . $k . ')';
            $fr = $fv['frames'] ?? [];
            if (!is_array($fr) || count($fr) > 60) $issues[] = 'Favicon: maximaal 60 beeldjes';
            else foreach ($fr as $p) if (!$okp($p)) { $issues[] = 'Ongeldig favicon-pad (beeldje)'; break; }
            if (isset($fv['animate']) && !in_array($fv['animate'], ['', 'geen', 'draai', 'puls', 'beeldjes'], true)) $issues[] = 'Ongeldige favicon-animatie';
            if (isset($fv['speed']) && (!is_numeric($fv['speed']) || $fv['speed'] < 0 || $fv['speed'] > 1000)) $issues[] = 'Ongeldige favicon-snelheid';
        }
    }
    foreach ((array)($in['pages'] ?? []) as $pga) {
        if (!is_array($pga) || !isset($pga['aliases'])) continue;
        if (!is_array($pga['aliases']) || count($pga['aliases']) > 20) { $issues[] = 'Te veel oude adressen bij pagina ' . mb_substr((string)($pga['id'] ?? '?'), 0, 30); break; }
        foreach ($pga['aliases'] as $al) if (!is_string($al) || preg_match('#^/[A-Za-z0-9][A-Za-z0-9_./-]{0,120}$#', $al) !== 1 || str_contains($al, '..')) { $issues[] = 'Ongeldig oud adres bij pagina ' . mb_substr((string)($pga['id'] ?? '?'), 0, 30); break 2; }
    }
    foreach (['weightWarn', 'weightHigh'] as $wk) if (isset($in['site'][$wk]) && (!is_numeric($in['site'][$wk]) || $in['site'][$wk] <= 0 || $in['site'][$wk] > 1000)) $issues[] = 'site.' . $wk . ' moet een aantal MB zijn (1-1000)';
    if (isset($in['org'])) {
        $og = $in['org'];
        if (!is_array($og)) $issues[] = 'org moet een object zijn';
        else {
            foreach (['name', 'email', 'telephone', 'logo'] as $k) if (isset($og[$k]) && (!is_string($og[$k]) || strlen($og[$k]) > 300)) $issues[] = 'org.' . $k . ' moet tekst zijn';
            if (isset($og['sameAs'])) { if (!is_array($og['sameAs']) || count($og['sameAs']) > 20) $issues[] = 'org.sameAs moet een lijst van max. 20 adressen zijn'; else foreach ($og['sameAs'] as $u) if (!is_string($u) || !preg_match('#^https?://#i', $u)) { $issues[] = 'org.sameAs: elk adres begint met https://'; break; } }
        }
    }
    $shs = $in['site']['share'] ?? null;
    if ($shs !== null && $shs !== '' && !$okp($shs)) $issues[] = 'Ongeldig deelplaatje van de site';
    foreach ((array)($in['pages'] ?? []) as $pgx) if (is_array($pgx) && isset($pgx['share']) && $pgx['share'] !== '' && !$okp($pgx['share'])) { $issues[] = 'Ongeldig deelplaatje bij pagina ' . mb_substr((string)($pgx['id'] ?? '?'), 0, 30); break; }
    $walk = function ($x) use (&$walk, &$issues) {
        if (!is_array($x)) return;
        foreach ($x as $k => $v) {
            if ($k === 'plan' && is_array($v) && array_key_exists('script', $v)) {
                $s = $v['script'];
                $ok = is_string($s) && $s !== '' && preg_match('/\.js$/i', $s) === 1 && !str_contains($s, '..') && !str_contains($s, '\\')
                    && (str_starts_with($s, 'cdn:') || preg_match('#^(/|[a-z][a-z0-9+.-]*:)#i', $s) !== 1);
                if (!$ok) $issues[] = 'Ongeldig script-pad bij een tekenmotor: ' . (is_string($s) ? mb_substr($s, 0, 60) : '?');
            }
            $walk($v);
        }
    };
    $walk($in);
    return array_slice(array_values(array_unique($issues)), 0, 10);
}

// editorKey mag één sleutel zijn of meerdere, gescheiden door komma's ('key_1,key_2') of een array. Lege delen tellen niet mee.
function wp_editor_keys(array $cfg): array {
    $k = $cfg['editorKey'] ?? '';
    $list = is_array($k) ? $k : explode(',', (string)$k);
    return array_values(array_filter(array_map(fn($x) => trim((string)$x), $list), fn($x) => $x !== ''));
}
function wp_key_ok(array $cfg, string $sent): bool {
    return wp_ed_who($cfg, $sent) !== null;      // centrale lijst, lokale editorKey (niet bij strict) of een sessietoken
}
// de lijst kan een site of een oude motor helemaal op slot zetten (ook voor lokale sleutels): 'motor' | 'disabled' | null
function wp_ed_policy(array $cfg): ?string {
    if (!wp_ed_central($cfg)) return null;
    $why = ''; wp_ed_entries($cfg, $why);
    return ($why === 'motor' || $why === 'disabled') ? $why : null;
}

function editorAuth(): array {
    $cfg = wp_config();
    // 'requireKey' => false  →  geen sleutel nodig (lokaal én online). Let op: online kan dan iedereen opslaan en de agent gebruiken.
    $skip  = ($cfg['requireKey'] ?? true) === false;
    if (!$skip) {
        if (wp_ed_blocked()) reply(['ok' => false, 'error' => 'wait'], 429);
        if ($pol = wp_ed_policy($cfg)) reply(['ok' => false, 'error' => $pol], 403);
        if (!wp_key_ok($cfg, (string)($_SERVER['HTTP_X_WP_KEY'] ?? ''))) { if (($_SERVER['HTTP_X_WP_KEY'] ?? '') !== '') wp_ed_fail(); reply(['ok' => false, 'error' => 'key'], 401); }
    }
    return $cfg;
}

// beeld uploaden: het bestand zelf is de body (geen JSON), dus vóór het JSON-deel
if (($_GET['a'] ?? '') === 'mediaUpload') { if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['ok' => false, 'error' => 'method'], 405); editorAuth(); wp_media_upload(); }

// betaalprovider: webhook (POST id=…) en terugkeerpagina (GET) zijn geen JSON, dus ook vóór het JSON-deel
if (($_GET['a'] ?? '') === 'shop-webhook' && $_SERVER['REQUEST_METHOD'] === 'POST') wp_pay_webhook();
if (($_GET['a'] ?? '') === 'shop-return') wp_pay_return();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['ok' => false, 'error' => 'method'], 405);

$raw = file_get_contents('php://input', false, null, 0, MAX_BODY + 1);
if ($raw === false || strlen($raw) > MAX_BODY) reply(['ok' => false, 'error' => 'size'], 413);
$in = json_decode($raw, true);
if (!is_array($in)) reply(['ok' => false, 'error' => 'json'], 400);

$action = $_GET['a'] ?? '';
date_default_timezone_set((string)(wp_config()['timezone'] ?? 'Europe/Amsterdam'));   // tijden in meldingen in jouw tijdzone
wp_retention();    // inzendingen ouder dan de bewaartermijn opruimen (hooguit één keer per dag)
wp_digest_due();   // dagoverzicht van inzendingen versturen als het tijd is (geen cronjob nodig)
if ($action === 'form' && strlen($raw) > 20000) reply(['ok' => false, 'error' => 'size'], 413);

switch ($action) {

    case 'shop-quote':
        // mandje uitrekenen voor weergave (de echte bestelling rekent de server opnieuw uit)
        $site = json_decode((string)file_get_contents(SITE_FILE), true) ?: [];
        reply(wp_shop_quote_public($site, is_array($in['cart'] ?? null) ? $in['cart'] : [], (string)($in['fulfilment'] ?? ''), (string)($in['collection'] ?? 'producten')));

    case 'form':
        // velden en regels komen uit dezelfde vorm: site.json (de waarheid)
        $site = json_decode((string)file_get_contents(SITE_FILE), true);
        $formId = (string)($in['formId'] ?? '');
        $def = null;
        foreach ($site['pages'] ?? [] as $p) {
            foreach ($p['objects'] ?? [] as $o) {
                if (($o['type'] ?? '') === 'form' && ($o['props']['formId'] ?? '') === $formId) $def = $o['props'];
            }
        }
        if (!$def) reply(['ok' => false, 'error' => 'form'], 404);

        $data = is_array($in['data'] ?? null) ? $in['data'] : [];
        if (!empty($data['website'])) reply(['ok' => true]); // honeypot: stil negeren

        $clean = [];
        foreach ($def['fields'] as $f) {
            if (($f['type'] ?? '') === 'cart' || (($f['type'] ?? '') === 'choice' && !empty($f['cart']))) continue;    // winkelmandje: komt als lijst SKU/aantal mee en wordt hieronder opnieuw uitgerekend
            $v = trim((string)($data[$f['name']] ?? ''));
            if (in_array($f['type'] ?? '', ['choice', 'select'], true)) {   // alleen een van de opties uit site.json
                if ($v === '') { if (!empty($f['required'])) reply(['ok' => false, 'error' => 'required:' . $f['name']], 422); $clean[$f['name']] = ''; continue; }
                $hit = null; foreach ($f['options'] ?? [] as $op) if ((string)($op['value'] ?? '') === $v) $hit = $op;
                if (!$hit) reply(['ok' => false, 'error' => 'option:' . $f['name']], 422);
                $lb = $hit['label'] ?? $v; if (is_string($lb) && isset($site['translations'][$lb])) $lb = $site['translations'][$lb];
                if (is_array($lb)) $lb = $lb[$site['site']['defaultLanguage'] ?? 'nl'] ?? reset($lb);
                $clean[$f['name']] = is_string($lb) ? $lb : $v;
                continue;
            }
            if (($f['type'] ?? '') === 'qty') {                          // aantal: geheel getal tussen min en max
                $n = filter_var($v, FILTER_VALIDATE_INT);
                $lo = (int)($f['min'] ?? 1); $hi = (int)($f['max'] ?? 10);
                if ($n === false || $n < $lo || $n > $hi) reply(['ok' => false, 'error' => 'qty:' . $f['name']], 422);
                $clean[$f['name']] = (string)$n;
                continue;
            }
            if (($f['type'] ?? '') === 'pickup') {                       // afhaalpunt + datum: alles opnieuw controleren tegen site.json
                if ($v === '') { if (!empty($f['required'])) reply(['ok' => false, 'error' => 'required:' . $f['name']], 422); $clean[$f['name']] = ''; continue; }
                $why = wp_pickup_check($site, $v, $label);
                if ($why) reply(['ok' => false, 'error' => 'pickup:' . $why], 422);
                $clean[$f['name']] = $label;
                continue;
            }
            if (!empty($f['required']) && $v === '') reply(['ok' => false, 'error' => 'required:' . $f['name']], 422);
            if (($f['type'] ?? '') === 'email' && $v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) reply(['ok' => false, 'error' => 'email'], 422);
            $clean[$f['name']] = mb_substr($v, 0, 5000);
        }
        // props.requireOne = ["phone", "email"]: minstens één van deze velden ingevuld
        if (!empty($def['requireOne']) && is_array($def['requireOne'])) {
            $any = false; foreach ($def['requireOne'] as $nm) if (($clean[$nm] ?? '') !== '') $any = true;
            if (!$any) reply(['ok' => false, 'error' => 'requireOne'], 422);
        }

        $orderBlock = null;   // formulier met props.order: bestelling opnieuw uitrekenen uit site.json (nooit uit de browser)
        if (!empty($def['order']) && is_array($def['order'])) {
            $ob = !empty($def['order']['cart'])
                ? wp_shop_order_from_cart($site, $def['order'], is_array($in['cart'] ?? null) ? $in['cart'] : [], (string)($in['fulfilment'] ?? ''))
                : wp_shop_order_from_form($site, $def['order'], $data);
            if (!$ob['ok']) reply(['ok' => false, 'error' => 'shop:' . $ob['error']], 422);
            $orderBlock = $ob['order'];
        }
        $row = [
            'id'        => bin2hex(random_bytes(8)),
            'formId'    => $formId,
            'page'      => (string)($in['page'] ?? ''),
            'lang'      => (string)($in['lang'] ?? ''),
            'createdAt' => gmdate('c'),
            'data'      => $clean,
        ];
        // versleutelen met je publieke sleutel: de server kan schrijven, maar niet meer lezen (alleen jij, met je 24 woorden)
        if ($orderBlock) $row['order'] = $orderBlock;
        if ($pk = wp_box_pk()) { $row['enc'] = base64_encode(sodium_crypto_box_seal(json_encode($clean, JSON_UNESCAPED_UNICODE), $pk)); unset($row['data']); }
        if (!is_dir(STORAGE)) mkdir(STORAGE, 0775, true);
        // één bestand per formulier, één regel per inzending (JSON Lines)
        $ok = file_put_contents(STORAGE . '/form-' . preg_replace('/[^a-z0-9_-]/i', '', $formId) . '.jsonl',
            json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
        if ($ok === false) reply(['ok' => false, 'error' => 'store'], 500);
        $pay = $orderBlock ? wp_pay_start($site, $row) : null;   // betaalprovider ingesteld in .secrets? dan eerst betalen
        if (!$pay) wp_notify($site, $def, $row);      // seintje naar de eigenaar (bij betalen pas als het betaald is)
        reply(['ok' => true, 'id' => $row['id']] + ($orderBlock ? ['order' => ['number' => $orderBlock['number'], 'total' => $orderBlock['totals']['gross'], 'currency' => $orderBlock['currency']]] : []) + ($pay ? ['pay' => ['url' => $pay['url']]] : []));

    case 'submissions':
        // editor: alle inzendingen (nieuwste eerst) + wat al gelezen is
        editorAuth();
        // staat er een sleutel in .secrets? dan worden oude, nog leesbare inzendingen vanzelf versleuteld (geen knop nodig)
        if ($pkAuto = wp_box_pk()) wp_rewrite(function ($r) use ($pkAuto) {
            if (!isset($r['data']) || isset($r['enc'])) return $r;
            $r['enc'] = base64_encode(sodium_crypto_box_seal(json_encode($r['data'], JSON_UNESCAPED_UNICODE), $pkAuto)); unset($r['data']);
            return $r;
        });
        $read = json_decode((string)@file_get_contents(STORAGE . '/forms-read.json'), true) ?: [];
        $forms = [];
        foreach (glob(STORAGE . '/form-*.jsonl') ?: [] as $f) {
            $rows = [];
            foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) { $r = json_decode($line, true); if (is_array($r)) $rows[] = empty($in['count']) ? wp_box_open($r) : $r; }
            $forms[preg_replace('/^form-|\.jsonl$/', '', basename($f))] = array_reverse($rows);
        }
        $unread = 0; foreach ($forms as $rows) foreach ($rows as $r) if (empty($read[$r['id'] ?? ''])) $unread++;
        $cfg = wp_config();
        reply(['ok' => true, 'forms' => !empty($in['count']) ? new stdClass() : $forms, 'read' => $read ?: new stdClass(), 'unread' => $unread,
               'notify' => ['email' => (string)($cfg['notifyEmail'] ?? ''), 'mode' => (string)($cfg['notifyMode'] ?? 'each')],
               'encryption' => ['publicKey' => wp_box_pk() ? base64_encode(wp_box_pk()) : null, 'sodium' => function_exists('sodium_crypto_box_seal'), 'onServer' => (bool)wp_box_kp()]]);

    case 'submissionsEncrypt':
        // editor: oude, nog leesbare inzendingen in één keer versleutelen (ook in de wachtrij van het dagoverzicht)
        editorAuth();
        $pk = wp_box_pk(); if (!$pk) reply(['ok' => false, 'error' => 'Geen boxPublicKey in .secrets/webplays.php'], 422);
        $n = wp_rewrite(function ($r) use ($pk) {
            if (!isset($r['data']) || isset($r['enc'])) return $r;
            $r['enc'] = base64_encode(sodium_crypto_box_seal(json_encode($r['data'], JSON_UNESCAPED_UNICODE), $pk)); unset($r['data']);
            return $r;
        });
        reply(['ok' => true, 'encrypted' => $n]);

    case 'submissionsRead':
        editorAuth();
        $read = json_decode((string)@file_get_contents(STORAGE . '/forms-read.json'), true) ?: [];
        foreach ((array)($in['ids'] ?? []) as $id) if (is_string($id) && preg_match('/^[a-f0-9]{16}$/', $id)) $read[$id] = gmdate('c');
        file_put_contents(STORAGE . '/forms-read.json', json_encode($read), LOCK_EX);
        reply(['ok' => true]);

    case 'submissionsDelete':
        // editor: inzendingen definitief verwijderen (ook uit de wachtrij van het dagoverzicht)
        editorAuth();
        $ids = array_values(array_filter((array)($in['ids'] ?? []), fn($id) => is_string($id) && preg_match('/^[a-f0-9]{16}$/', $id)));
        $n = wp_prune(fn($r) => in_array($r['id'] ?? '', $ids, true));
        $read = json_decode((string)@file_get_contents(STORAGE . '/forms-read.json'), true) ?: [];
        foreach ($ids as $id) unset($read[$id]);
        file_put_contents(STORAGE . '/forms-read.json', json_encode($read ?: new stdClass()), LOCK_EX);
        reply(['ok' => true, 'deleted' => $n]);

    case 'notifyTest':
        editorAuth();
        $cfg = wp_config();
        if (empty($cfg['notifyEmail'])) reply(['ok' => false, 'error' => 'Geen notifyEmail ingesteld in .secrets/webplays.php'], 422);
        $siteT = json_decode((string)@file_get_contents(SITE_FILE), true) ?: [];
        $lookT = wp_mail_look($siteT, null);
        [$htmlT, $inlT] = wp_mail_page($lookT, 'Testmail 👋', 'Dit is een test. Komt deze mail aan, dan komen meldingen van inzendingen ook aan.', '', [['Naar je website', wp_site_url(), true]]);
        $okm = wp_mail((string)$cfg['notifyEmail'], 'Testmail van je website', "Dit is een test. Komen meldingen van inzendingen aan, dan staat alles goed.\n\n" . wp_site_url(), null, $htmlT, $inlT);
        $via = ($cfg['mailMode'] ?? '') === 'file' ? 'bestand' : (!empty($cfg['smtpHost']) ? 'SMTP ' . $cfg['smtpHost'] : 'PHP mail() van de server');
        reply(['ok' => $okm, 'file' => ($cfg['mailMode'] ?? '') === 'file', 'via' => $via,
               'error' => $okm ? null : 'Versturen mislukt via ' . $via . ': ' . ($GLOBALS['WP_MAIL_ERR'] ?? '') . (empty($cfg['smtpHost']) ? " — tip: stel SMTP in (smtpHost/smtpUser/smtpPass in .secrets)." : '')]);

    case 'auth':
        // inlogpoort van de editor (speler.js, vóór de editor geladen wordt): klopt de sleutel? Schrijft en leest niets (behalve de inlogrem).
        // 'requireKey' => false (lokaal): altijd ok. Geen sleutel ingesteld (geen editorKey en geen centrale lijst): error 'nokey'.
        // Na een geldige sleutel krijgt de browser een sessietoken (editor onthoudt dat in plaats van de sleutel zelf).
        $cfgA = wp_config();
        if (($cfgA['requireKey'] ?? true) !== false) {
            if (!wp_ed_central($cfgA) && !wp_editor_keys($cfgA)) reply(['ok' => false, 'error' => 'nokey'], 401);
            if (wp_ed_blocked()) reply(['ok' => false, 'error' => 'wait'], 429);
            if ($pol = wp_ed_policy($cfgA)) reply(['ok' => false, 'error' => $pol], 403);
            $sentA = (string)($_SERVER['HTTP_X_WP_KEY'] ?? '');
            $who = wp_ed_who($cfgA, $sentA);
            if (!$who) {
                if ($sentA !== '') { wp_ed_fail(); usleep(500000); }   // een foute poging kost even tijd (remt raden)
                $why = ''; if (wp_ed_central($cfgA) && !wp_ed_load($cfgA) && !wp_editor_keys($cfgA)) reply(['ok' => false, 'error' => 'list'], 503);
                reply(['ok' => false, 'error' => 'key'], 401);
            }
            wp_ed_ok();
            $out = ['ok' => true, 'name' => $who['name']];
            if (strncmp($sentA, 'wp1.', 4) !== 0) $out += wp_ed_token($cfgA, $who['id'], $who['name']);   // eerste inlog: token uitgeven
            reply($out);
        }
        reply(['ok' => true]);

    case 'updateCheck':
        // editor: is er een nieuwere motor? (alleen als 'updateUrl' in .secrets staat)
        editorAuth();
        reply(wp_upd_check(wp_config(), !empty($in['force'])));
    case 'updateInstall':
        // editor: de nieuwe motor installeren (ondertekend, gecontroleerd, met terugzetten)
        editorAuth();
        reply(wp_upd_install(wp_config()));

    case 'sitemap':
        // sitemap.xml en robots.txt opnieuw maken uit de huidige site.json (bijv. voor sites die nog niet met deze versie zijn opgeslagen)
        editorAuth();
        reply(['ok' => true, 'sitemap' => wp_sitemap_write(json_decode((string)file_get_contents(SITE_FILE), true) ?: [])]);

    case 'save':
        // editor: schrijft een nieuwe versie van de vorm; de oude gaat naar storage/versions
        editorAuth();

        if (($in['meta']['format'] ?? '') !== 'webplays-site/1' || !is_array($in['pages'] ?? null) || !is_array($in['site'] ?? null))
            reply(['ok' => false, 'error' => 'format'], 422);

        $siteIssues = wp_site_check($in);
        if ($siteIssues) reply(['ok' => false, 'error' => 'site', 'issues' => $siteIssues], 422);

        $brandIssues = wp_brand_check($in);
        if ($brandIssues && ($in['brand']['enforce'] ?? 'warn') === 'block')
            reply(['ok' => false, 'error' => 'brand', 'issues' => $brandIssues], 422);

        $fp = fopen(SITE_FILE, 'c+');
        if (!$fp || !flock($fp, LOCK_EX)) reply(['ok' => false, 'error' => 'lock'], 500);
        $oldRaw = stream_get_contents($fp);
        $old = json_decode((string)$oldRaw, true) ?: [];
        $oldVer = (int)($old['meta']['version'] ?? 0);
        if ((int)($in['meta']['version'] ?? -1) !== $oldVer) {
            flock($fp, LOCK_UN); fclose($fp);
            reply(['ok' => false, 'error' => 'conflict', 'version' => $oldVer], 409);
        }

        $dir = STORAGE . '/versions';
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        file_put_contents($dir . '/site-v' . $oldVer . '.json', $oldRaw);

        // als objecten decoderen, zodat lege {} ook {} blijven (en niet [])
        $doc = json_decode($raw);
        // lettertypes automatisch lokaal: één keer bij Google ophalen, daarna van de eigen server (sneller, en Google ziet je bezoekers niet)
        [$famLocal, $fontsCss] = wp_fonts_local(is_array($in['fonts'] ?? null) ? $in['fonts'] : [], wp_config());
        if ($famLocal) { $doc->site->fontsLocal = $famLocal; $doc->site->fontsCss = $fontsCss; }
        else { unset($doc->site->fontsLocal, $doc->site->fontsCss); }
        $doc->meta->version   = $oldVer + 1;
        $doc->meta->previous  = 'sha256:' . hash('sha256', (string)$oldRaw);
        $doc->meta->updatedAt = gmdate('Y-m-d\TH:i:s\Z');
        $json = json_encode($doc, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n";

        ftruncate($fp, 0); rewind($fp);
        $ok = fwrite($fp, $json) === strlen($json);
        fflush($fp); flock($fp, LOCK_UN); fclose($fp);
        if (!$ok) reply(['ok' => false, 'error' => 'write'], 500);
        $smap = wp_sitemap_write(json_decode($json, true) ?: []);
        reply(['ok' => true, 'version' => $doc->meta->version, 'previous' => $doc->meta->previous, 'updatedAt' => $doc->meta->updatedAt,
               'fontsLocal' => $famLocal, 'fontsCss' => $fontsCss, 'brandIssues' => $brandIssues, 'sitemap' => $smap]);

    case 'mediaList':
        // beeldbibliotheek: wat er in media/ van deze site staat (de map is de waarheid, geen database)
        editorAuth();
        $dir = wp_media_dir(); $items = [];
        foreach (scandir($dir) ?: [] as $f) if (preg_match(WP_MEDIA_RX, $f) && is_file("$dir/$f")) $items[] = wp_media_item($dir, $f);
        usort($items, fn($a, $b) => $b['time'] <=> $a['time']);
        reply(['ok' => true, 'items' => $items]);

    case 'mediaDelete':
        // niet echt weg: naar storage/media-prullenbak, zodat ongedaan maken in de editor nooit een kapot beeld geeft
        editorAuth();
        $f = basename((string)($in['file'] ?? ''));
        $dir = wp_media_dir();
        if (!preg_match(WP_MEDIA_RX, $f) || !is_file("$dir/$f")) reply(['ok' => false, 'error' => 'Bestand niet gevonden'], 404);
        $bin = STORAGE . '/media-prullenbak'; if (!is_dir($bin)) mkdir($bin, 0775, true);
        rename("$dir/$f", $bin . '/' . date('Ymd-His') . '-' . $f);
        reply(['ok' => true]);

    case 'agentInfo':
        // status van de agent voor deze site (nooit de sleutel zelf): staat hij aan, welk account wordt belast, verbruik deze maand
        $cfg = editorAuth(); $st = wp_agent_state($cfg);
        reply(['ok' => true, 'enabled' => $st['reason'] === '', 'reason' => $st['reason'], 'account' => $st['account'], 'usdMonth' => round($st['usd'], 2), 'requests' => $st['n'], 'limit' => $st['limit']]);

    case 'agent':
        // de agent maakt een VOORSTEL (operaties); hij schrijft nooit zelf. De editor toont het, jij keurt goed.
        // Wie betaalt wordt bepaald in .secrets: anthropicKey in .secrets/<siteId>.php = het account van die klant; zonder eigen sleutel geldt die
        // in .secrets/webplays.php (jouw account). 'agentEnabled' => true in <siteId>.php zet de agent voor die site AAN (zonder die regel geen agent, ook niet op jouw account). 'agentMaxUsdMonth' = maandlimiet.
        $cfg = editorAuth();
        $st = wp_agent_state($cfg); $apiKey = $st['key']; $account = $st['account'];
        if ($st['reason'] === 'off')   reply(['ok' => false, 'error' => 'De agent staat uit voor deze site', 'detail' => "zet 'agentEnabled' => true in .secrets/<siteId>.php"], 403);
        if ($st['reason'] === 'nokey') reply(['ok' => false, 'error' => 'Geen agent-sleutel voor deze site', 'detail' => 'zet anthropicKey in .secrets/<siteId>.php (eigen account) of .secrets/webplays.php (standaard)'], 403);
        if ($st['reason'] === 'limit') reply(['ok' => false, 'error' => 'Maandlimiet van de agent bereikt', 'detail' => '$' . round($st['usd'], 4) . ' van $' . $st['limit'] . ' (agentMaxUsdMonth) — volgende maand weer of limiet verhogen'], 429);
        $instruction = trim(mb_substr((string)($in['instruction'] ?? ''), 0, 2000));
        $site = $in['site'] ?? null; $pageId = (string)($in['page'] ?? ''); $lang = (string)($in['lang'] ?? 'nl');
        if ($instruction === '' || !is_array($site)) reply(['ok' => false, 'error' => 'input'], 422);

        // compacte context: deze pagina, de master, palet, stijlen, fonts, de teksten die erbij horen, en de paginalijst
        $page = null; foreach ($site['pages'] ?? [] as $p) if (($p['id'] ?? '') === $pageId) $page = $p;
        if (!$page) reply(['ok' => false, 'error' => 'page'], 422);
        $master = $page['master'] ? ($site['masters'][$page['master']] ?? null) : null;
        $blob = json_encode([$page, $master]);
        $tr = [];
        foreach (($site['translations'] ?? []) as $k => $v) if (strpos($blob, '"' . $k . '"') !== false) $tr[$k] = $v;
        // overzicht van de opbouw: helpt de agent te rekenen (waar banden liggen, waar de inhoud eindigt)
        $preview = function ($o) use ($site, $lang) {
            $k = $o['props']['text'] ?? null; if (!is_string($k)) return null;
            $v = $site['translations'][$k][$lang] ?? $site['translations'][$k]['nl'] ?? $k;
            if (is_array($v)) $v = implode('', array_map(fn($r) => $r['t'] ?? '', $v));
            return mb_substr((string)$v, 0, 50);
        };
        $summ = []; $bottom = 0;
        foreach ([['page', $page['objects'] ?? []], ['master', $master['objects'] ?? []]] as [$owner, $list]) {
            foreach ($list as $o) {
                $L = $o['layout'] ?? []; $isFoot = !empty($o['base']['footer']);
                $summ[] = array_filter(['uuid' => $o['uuid'] ?? '', 'owner' => $owner, 'type' => $o['type'] ?? '', 'x' => $L['x'] ?? 0, 'y' => $L['y'] ?? 0,
                    'w' => $L['w'] ?? 0, 'h' => $L['h'] ?? 0, 'band' => !empty($o['base']['triggerSw']) ?: null, 'footer' => $isFoot ?: null, 'text' => $preview($o)], fn($v) => $v !== null);
                if ($owner === 'page' || !$isFoot) $bottom = max($bottom, ($L['y'] ?? 0) + ($L['h'] ?? 0));
            }
        }
        usort($summ, fn($a, $b) => $a['y'] <=> $b['y']);
        // selectie uit de editor: de agent werkt dan alleen op deze objecten
        $selIds = array_values(array_filter(array_map('strval', (array)($in['selection'] ?? []))));
        $selection = [];
        $walk = function ($list) use (&$walk, &$selection, $selIds) { foreach ($list as $o) { if (in_array($o['uuid'] ?? '', $selIds, true)) $selection[] = $o; if (!empty($o['children'])) $walk($o['children']); } };
        $walk($page['objects'] ?? []); $walk($master['objects'] ?? []);
        // wat binnen een geselecteerd vlak ligt (tekst op een kaart), hoort er voor de agent bij
        $inside = function ($a, $b) { $A = $a['layout']; $B = $b['layout']; $band = !empty($a['base']['triggerSw']);
            return ($a['type'] ?? '') === 'surface' && $B['y'] >= $A['y'] - 1 && $B['y'] + $B['h'] <= $A['y'] + $A['h'] + 1
                && ($band || ($B['x'] >= $A['x'] - 1 && $B['x'] + $B['w'] <= $A['x'] + $A['w'] + 1)) && $A['w'] * $A['h'] > $B['w'] * $B['h']; };
        foreach ($selection as $sel) foreach (array_merge($page['objects'] ?? [], $master['objects'] ?? []) as $o) {
            if (in_array($o['uuid'] ?? '', $selIds, true) || !isset($o['layout'])) continue;
            if (isset($sel['layout']) && $inside($sel, $o)) { $o['_insideSelected'] = $sel['uuid']; $selection[] = $o; $selIds[] = $o['uuid']; }
        }
        $ctx = [
            'layoutSummary' => ['designWidth' => $site['site']['width'] ?? 1000, 'pageHeight' => $page['height'] ?? null, 'contentBottom' => $bottom,
                                'note' => 'objects sorted by y; footer objects of the master are placed automatically under the content', 'objects' => $summ],
            'site' => $site['site'] ?? [], 'colors' => $site['colors'] ?? new stdClass(), 'fonts' => $site['fonts'] ?? [],
            'brand' => $site['brand'] ?? new stdClass(), 'styles' => $site['styles'] ?? new stdClass(), 'pages' => array_map(fn($p) => ['id' => $p['id'], 'path' => $p['path'] ?? null, 'title' => $p['title'] ?? null], $site['pages'] ?? []),
            'currentPage' => $page, 'master' => $master, 'translations' => $tr ?: new stdClass(), 'editorLanguage' => $lang,
        ];
        // producten op de hele site (ook op andere pagina's) + formulieren die hun keuzes eruit halen + beelden in media/
        $tx = function ($k) use ($site, $lang) { if (!is_string($k)) return null; $v = $site['translations'][$k][$lang] ?? $site['translations'][$k]['nl'] ?? null;
            if (is_array($v)) $v = implode('', array_map(fn($r) => $r['t'] ?? '', $v)); return $v === null ? null : mb_substr((string)$v, 0, 120); };
        $prods = []; $pforms = [];
        foreach ($site['pages'] ?? [] as $pg) {
            foreach ($pg['objects'] ?? [] as $o) {
                if (($o['type'] ?? '') === 'group' && !empty($o['base']['product']['id'])) {
                    $r = []; $rw = function ($l) use (&$rw, &$r) { foreach ($l as $c) { $ro = $c['base']['role'] ?? null; if ($ro && !isset($r[$ro])) $r[$ro] = $c; if (!empty($c['children'])) $rw($c['children']); } };
                    $rw($o['children'] ?? []);
                    $prods[] = array_filter(['id' => $o['base']['product']['id'], 'uuid' => $o['uuid'] ?? '', 'page' => $pg['id'] ?? '',
                        'price' => $o['base']['product']['price'] ?? null, 'unit' => $o['base']['product']['unit'] ?? null,
                        'name' => $tx($r['name']['props']['text'] ?? null), 'sub' => $tx($r['sub']['props']['text'] ?? null),
                        'priceText' => $tx($r['price']['props']['text'] ?? null), 'desc' => $tx($r['desc']['props']['text'] ?? null),
                        'image' => $r['image']['props']['src'] ?? null, 'color' => $r['bg']['surface']['fills'][0]['color'] ?? null,
                        'layout' => $o['layout'] ?? null], fn($v) => $v !== null);
                }
            }
            $fw = function ($l) use (&$fw, &$pforms, $pg) { foreach ($l as $o) { if (($o['type'] ?? '') === 'form') foreach ($o['props']['fields'] ?? [] as $f) if (!empty($f['products'])) $pforms[] = ['page' => $pg['id'] ?? '', 'formId' => $o['props']['formId'] ?? '', 'field' => $f['name'] ?? '']; if (!empty($o['children'])) $fw($o['children']); } };
            $fw($pg['objects'] ?? []);
        }
        if ($prods) {
            $ctx['products'] = $prods; $ctx['productForms'] = $pforms;
            // de getekende figuurtjes van de bestaande producten als stijlvoorbeeld (klein; alleen eigen svg's uit media/)
            $ex = [];
            foreach ($prods as $pr) {
                $src = (string)($pr['image'] ?? '');
                if (!preg_match('#^media/([a-z0-9][a-z0-9._-]*\.svg)$#i', $src, $mm) || isset($ex[$src])) continue;
                $fp = WP_SITE_DIR . '/media/' . $mm[1];
                if (is_file($fp) && filesize($fp) <= 4000) $ex[$src] = ['file' => $src, 'svg' => (string)file_get_contents($fp)];
                if (count($ex) >= 4) break;
            }
            if ($ex) $ctx['characterExamples'] = array_values($ex);
        }
        $md = WP_SITE_DIR . '/media'; $mfiles = [];
        if (is_dir($md)) foreach (scandir($md) ?: [] as $mf) if (preg_match(WP_MEDIA_RX, $mf)) $mfiles[] = 'media/' . $mf;
        if ($mfiles) $ctx['media'] = array_slice($mfiles, 0, 200);

        // instructies: één bestand naast de API (voor alle sites gelijk) + optioneel per site (toon, merk, wensen)
        $system = (string)@file_get_contents(__DIR__ . '/agent-instructions.md');
        if ($system === '') reply(['ok' => false, 'error' => 'api/agent-instructions.md ontbreekt'], 500);
        $siteNotes = (string)@file_get_contents(STORAGE . '/agent-site.md');
        if ($siteNotes !== '') $system .= "\n\n## 8. About this site (from the owner)\n\n" . $siteNotes;
        // prompt caching: instructies en site-context worden 5 minuten bewaard (vervolgvragen kosten dan ~1/10 voor dat deel);
        // alleen selectie en opdracht wisselen per vraag en staan daarom achteraan, buiten de cache
        $user = [
            ['type' => 'text', 'text' => "SITE CONTEXT (JSON):\n" . json_encode($ctx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 'cache_control' => ['type' => 'ephemeral']],
            ['type' => 'text', 'text' => ($selection
                ? "SELECTION (JSON, the instruction is about these objects):\n" . json_encode($selection, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                  . "\n\nSELECTED OBJECTS: " . implode(', ', array_map(fn($o) => $o['uuid'] . ' (' . ($o['type'] ?? '') . ')', $selection))
                : "NO SELECTION (the instruction is about the current page).")
              . (!empty($in['newPage']) ? "\n\nNEW PAGE MODE (the user ticked 'Maak een nieuwe pagina'): if the name of the page is not clear from the instruction, ask for it first (propose with empty ops); otherwise FIRST create a new page with an `addPage` op (see 'A new page' in the instructions) and carry out the instruction on that new page, not on the current page." : '')
              . "\n\nINSTRUCTION:\n" . $instruction],
        ];
        // het voorstel komt als tool-aanroep 'propose' (geldige JSON); doet het model dat niet, dan zoeken we de JSON in de tekst
        $tool = ['name' => 'propose', 'description' => 'Deliver the proposal: a short Dutch summary and the list of operations.',
                 'input_schema' => ['type' => 'object', 'required' => ['summary', 'ops'], 'properties' => [
                     'summary' => ['type' => 'string', 'description' => '1-3 short sentences in Dutch'],
                     'ops' => ['type' => 'array', 'items' => ['type' => 'object', 'required' => ['op'], 'properties' => ['op' => ['type' => 'string',
                         'enum' => ['update', 'add', 'move', 'remove', 'text', 'color', 'style', 'font', 'page', 'addPage', 'group', 'ungroup', 'addProduct', 'updateProduct', 'removeProduct']]]]]]]];
        $url = (string)($cfg['agentUrl'] ?? 'https://api.anthropic.com/v1/messages');
        set_time_limit(300);
        $headers = ['content-type: application/json', 'x-api-key: ' . $apiKey, 'anthropic-version: 2023-06-01'];
        // twee modellen: 'fast' (goedkoop, standaard Haiku) en 'smart' (sterker in ontwerp, standaard Sonnet); alleen deze twee zijn toegestaan
        $tier  = ($in['tier'] ?? 'fast') === 'smart' ? 'smart' : 'fast';
        $model = $tier === 'smart' ? (string)($cfg['agentModel'] ?? 'claude-sonnet-5-5') : (string)($cfg['agentModelFast'] ?? 'claude-haiku-5-5');
        $base = ['model' => $model, 'max_tokens' => (int)($cfg['agentMaxTokens'] ?? 12000),
                 'system' => [['type' => 'text', 'text' => $system, 'cache_control' => ['type' => 'ephemeral']]],
                 'tools' => [$tool]];   // geen geforceerde tool_choice: niet elk model ondersteunt die
        $messages = [['role' => 'user', 'content' => $user]];
        $allowed = ['update', 'add', 'move', 'remove', 'text', 'color', 'style', 'font', 'page', 'addPage', 'group', 'ungroup', 'addProduct', 'updateProduct', 'removeProduct'];
        $out = null; $text = ''; $api = []; $use = [];
        if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
        for ($try = 1; $try <= 2 && $out === null; $try++) {
            [$code, $resp, $err] = wp_post($url, $headers, json_encode($base + ['messages' => $messages], JSON_UNESCAPED_UNICODE), $cfg);
            if ($resp !== false && $code >= 400 && stripos((string)$resp, 'credit balance') !== false) reply(['ok' => false, 'error' => 'Het saldo van het agent-account' . ($account !== '' ? ' (' . $account . ')' : '') . ' is op', 'detail' => 'Credits aanvullen in de Anthropic Console, of haal agentEnabled weg'], 402);
            if ($code === 401) reply(['ok' => false, 'error' => 'De agent-sleutel wordt geweigerd' . ($account !== '' ? ' (' . $account . ')' : ''), 'detail' => 'controleer anthropicKey in .secrets'], 502);
            if ($resp === false || $code >= 400) reply(['ok' => false, 'error' => 'API ' . $code . ' ' . $err, 'detail' => mb_substr((string)$resp, 0, 400)], 502);
            $api = json_decode((string)$resp, true) ?: [];
            foreach (['input_tokens', 'output_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens'] as $k) $use[$k] = ($use[$k] ?? 0) + (int)($api['usage'][$k] ?? 0);
            @file_put_contents(STORAGE . '/agent-last.json', (string)$resp);      // laatste ruwe antwoord, om te kunnen zien wat er misging
            [$out, $text, $toolIds] = wp_extract($api);
            if ($out !== null || $try === 2 || ($api['stop_reason'] ?? '') === 'max_tokens') break;
            // geen geldig voorstel: één keer terugsturen met de vraag het alsnog via 'propose' te doen
            $fix = 'Your answer did not contain a valid proposal, so nothing was changed. Call the tool "propose" now with '
                 . '{"summary": "...", "ops": [ ...operation objects... ]}. "ops" must be a JSON array of objects, not a string.';
            $content = [];
            foreach ($toolIds as $id) $content[] = ['type' => 'tool_result', 'tool_use_id' => $id, 'is_error' => true, 'content' => $fix];
            if (!$content) $content[] = ['type' => 'text', 'text' => $fix];
            $messages[] = ['role' => 'assistant', 'content' => $api['content'] ?? [['type' => 'text', 'text' => $text ?: '...']]];
            $messages[] = ['role' => 'user', 'content' => $content];
        }
        if (!is_array($out) || !is_array($out['ops'] ?? null)) {
            $why = ($api['stop_reason'] ?? '') === 'max_tokens' ? 'Het voorstel was te lang en is afgebroken (agentMaxTokens verhogen of kleiner vragen)' : 'Het antwoord van de agent was geen geldig voorstel (er is niets veranderd)';
            reply(['ok' => false, 'error' => $why, 'detail' => mb_substr($text, 0, 400)], 502);
        }
        $ops = array_values(array_filter($out['ops'], fn($o) => is_array($o) && in_array($o['op'] ?? '', $allowed, true)));

        $cost = wp_cost($model, $use, $cfg);
        // alles gelogd (zonder de site zelf)
        if (!is_dir(STORAGE)) mkdir(STORAGE, 0775, true);
        file_put_contents(STORAGE . '/agent-log.jsonl', json_encode(['at' => gmdate('c'), 'page' => $pageId, 'instruction' => $instruction, 'model' => $model, 'account' => $account,
            'summary' => $out['summary'] ?? '', 'selection' => $selIds, 'ops' => count($ops), 'usage' => $use, 'costUsd' => $cost], JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
        reply(['ok' => true, 'summary' => (string)($out['summary'] ?? ''), 'ops' => $ops, 'usage' => $use, 'model' => $model, 'costUsd' => $cost, 'account' => $account]);

    default:
        reply(['ok' => false, 'error' => 'action'], 404);
}

// zoek in vrije tekst het eerste complete JSON-object met "ops" (haakjes tellen, strings overslaan)
function wp_find_proposal(string $t): ?array {
    $n = strlen($t);
    for ($i = 0; $i < $n; $i++) {
        if ($t[$i] !== '{') continue;
        $d = 0; $inS = false; $esc = false;
        for ($j = $i; $j < $n; $j++) {
            $ch = $t[$j];
            if ($inS) { if ($esc) $esc = false; elseif ($ch === '\\') $esc = true; elseif ($ch === '"') $inS = false; continue; }
            if ($ch === '"') $inS = true;
            elseif ($ch === '{') $d++;
            elseif ($ch === '}' && --$d === 0) {
                $o = json_decode(substr($t, $i, $j - $i + 1), true);
                if (is_array($o) && isset($o['ops']) && is_array($o['ops'])) return $o;
                break;
            }
        }
    }
    return null;
}

// één POST naar de Messages API (curl met CA-bundel; anders streams)
function wp_post(string $url, array $headers, string $body, array $cfg): array {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $headers,
                                CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 170]);
        // certificaten: WAMP heeft vaak geen CA-bundel. Zoek er een (verificatie blijft AAN)
        foreach ([(string)($cfg['caFile'] ?? ''), WP_SECRETS . '/cacert.pem', __DIR__ . '/cacert.pem'] as $ca) {
            if ($ca !== '' && is_file($ca)) { curl_setopt($ch, CURLOPT_CAINFO, $ca); break; }
        }
        $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        return [$code, $resp, $err];
    }
    $caf = WP_SECRETS . '/cacert.pem';
    $resp = @file_get_contents($url, false, stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers), 'content' => $body, 'timeout' => 170, 'ignore_errors' => true],
                                                                  'ssl' => is_file($caf) ? ['cafile' => $caf, 'verify_peer' => true] : []]));
    $code = 200;
    foreach ($http_response_header ?? [] as $h) if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $code = (int)$m[1];
    return [$code, $resp, $resp === false ? 'request' : ''];
}

// voorstel uit een API-antwoord halen: tool 'propose' (ook als ops per ongeluk als tekst is meegegeven), anders JSON in de tekst
function wp_extract(array $api): array {
    $text = ''; $out = null; $ids = [];
    foreach (($api['content'] ?? []) as $c) {
        $t = $c['type'] ?? '';
        if ($t === 'text') $text .= $c['text'] ?? '';
        if ($t === 'tool_use') {
            $ids[] = $c['id'] ?? '';
            $in = $c['input'] ?? null;
            if (is_array($in) && is_string($in['ops'] ?? null)) { $d = json_decode($in['ops'], true); if (is_array($d)) $in['ops'] = $d; }
            if (is_array($in) && is_array($in['ops'] ?? null)) $out = $in;
        }
    }
    if ($out === null) $out = wp_find_proposal($text);
    if ($out !== null && empty($out['summary'])) $out['summary'] = trim($text);
    return [$out, $text, array_values(array_filter($ids))];
}

// kosten in dollars (prijzen per miljoen tokens; aan te passen in de config met 'agentPrices')
// agent: staat STANDAARD UIT; pas aan met 'agentEnabled' => true in .secrets/<siteId>.php. Welk account betaalt en verbruik deze maand voor DEZE site (uit .secrets en storage/agent-log.jsonl). Geeft nooit de sleutel terug naar de browser.
//   reason: '' = ok, 'off' (agentEnabled false), 'nokey' (geen sleutel), 'limit' (agentMaxUsdMonth bereikt)
function wp_agent_state(array $cfg): array {
    $key = (string)((($cfg['anthropicKey'] ?? '') ?: getenv('ANTHROPIC_API_KEY')) ?: '');
    $limit = (float)($cfg['agentMaxUsdMonth'] ?? 0); $usd = 0.0; $n = 0; $ym = gmdate('Y-m');
    $f = STORAGE . '/agent-log.jsonl';
    if (is_file($f)) foreach ((@file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []) as $line) {
        $r = json_decode($line, true);
        if (is_array($r) && strncmp((string)($r['at'] ?? ''), $ym, 7) === 0) { $usd += (float)($r['costUsd'] ?? 0); $n++; }
    }
    $reason = ($cfg['agentEnabled'] ?? false) !== true ? 'off' : ($key === '' ? 'nokey' : ($limit > 0 && $usd >= $limit ? 'limit' : ''));
    return ['key' => $key, 'account' => (string)($cfg['agentAccount'] ?? ''), 'usd' => $usd, 'n' => $n, 'limit' => $limit, 'reason' => $reason];
}

function wp_cost(string $model, array $u, array $cfg): float {
    $prices = ($cfg['agentPrices'] ?? []) + [
        'claude-haiku-5-5'  => ['in' => 0.10, 'out' => 0.50,  'write' => 0.125, 'read' => 0.01],
        'claude-sonnet-5-5' => ['in' => 2.00, 'out' => 10.00, 'write' => 2.50,  'read' => 0.20],
        'claude-opus-5-5'   => ['in' => 4.00, 'out' => 20.00, 'write' => 5.00,  'read' => 0.40],
    ];
    $p = $prices[$model] ?? $prices['claude-sonnet-5-5'];
    return round((($u['input_tokens'] ?? 0) * $p['in'] + ($u['output_tokens'] ?? 0) * $p['out']
                + ($u['cache_creation_input_tokens'] ?? 0) * $p['write'] + ($u['cache_read_input_tokens'] ?? 0) * $p['read']) / 1e6, 5);
}

// ---------- meldingen van formulierinzendingen ----------
// .secrets/webplays.php:  'notifyEmail' => 'jij@domein.nl'   (meerdere: komma's)
//                         'notifyMode'  => 'each' (standaard, per inzending) | 'daily' (één overzicht per dag) | 'off'
//                         'notifyFrom'  => 'website@domein.nl' (optioneel; standaard noreply@<domein>)
function wp_site_url(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $base = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $base . '/';
}
function wp_mail(string $to, string $subject, string $body, ?string $replyTo, ?string $html = null, array $inline = []): bool {
    $cfg = wp_config();
    $host = preg_replace('/^www\./', '', preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? 'localhost'));
    $from = (string)($cfg['notifyFrom'] ?? ('noreply@' . $host));
    $h = ['From: ' . $from, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: 8bit'];
    if ($replyTo && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) $h[] = 'Reply-To: ' . $replyTo;
    if ($html !== null) [$h, $body] = wp_mime($h, $body, $html, $inline);   // tekst + opgemaakte versie in één mail
    $subj = function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($subject, 'UTF-8') : $subject;
    $ok = false;
    // lokaal testen zonder mailserver: 'mailMode' => 'file' schrijft elke mail als .eml in storage/mail-out/ (dubbelklik = openen in je mailprogramma)
    if (($cfg['mailMode'] ?? '') === 'file') {
        $dir = STORAGE . '/mail-out'; if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $eml = 'To: ' . $to . "\r\nSubject: " . $subj . "\r\nDate: " . date('r') . "\r\n" . implode("\r\n", $h) . "\r\n\r\n" . str_replace(["\r\n", "\n"], ["\n", "\r\n"], $body);
        $ok = (bool)@file_put_contents($dir . '/' . date('Y-m-d_His') . '_' . substr(bin2hex(random_bytes(3)), 0, 6) . '.eml', $eml);
        @file_put_contents(STORAGE . '/mail-log.jsonl', json_encode(['at' => gmdate('c'), 'subject' => $subject, 'ok' => $ok, 'file' => true]) . "\n", FILE_APPEND | LOCK_EX);
        return $ok;
    }
    $GLOBALS['WP_MAIL_ERR'] = '';
    foreach (array_filter(array_map('trim', explode(',', $to))) as $addr) {
        if (!filter_var($addr, FILTER_VALIDATE_EMAIL)) continue;
        if (!empty($cfg['smtpHost'])) {
            // betrouwbaar: via een echte mailbox (SMTP met wachtwoord) — komt niet in de spam en wordt niet geweigerd
            $err = '';
            $one = wp_smtp($cfg, $from, $addr, $subj, $h, $body, $err);
            if (!$one) $GLOBALS['WP_MAIL_ERR'] = $err;
            $ok = $one || $ok;
        } else {
            $one = @mail($addr, $subj, $body, implode("\r\n", $h), '-f' . $from) || @mail($addr, $subj, $body, implode("\r\n", $h));
            if (!$one) $GLOBALS['WP_MAIL_ERR'] = 'PHP mail() weigert (' . ((error_get_last()['message'] ?? '') ?: 'geen details') . ')';
            $ok = $one || $ok;
        }
    }
    @file_put_contents(STORAGE . '/mail-log.jsonl', json_encode(['at' => gmdate('c'), 'subject' => $subject, 'ok' => $ok,
        'via' => !empty($cfg['smtpHost']) ? 'smtp' : 'mail', 'error' => $GLOBALS['WP_MAIL_ERR'] ?: null], JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
    return $ok;
}
// ---------- opgemaakte meldingen in de huisstijl van de site ----------
// Kleuren en letters komen uit het formulier zelf (accent, ink, fieldBg, font, labelFont, look) en uit site.json.
// Optioneel in site.json:  "site": { "mail": { "title": "Vitabox Kratje Vers", "logo": "media/logo-mail.png", "showTitle": false, "accent": "@rood", "bg": "@creme" } }
//   logo: png/jpg/gif (svg toont niet in Gmail/Outlook); wordt in de mail ingesloten, dus zichtbaar zonder "afbeeldingen laden".
// Optioneel per formulier:  "notifyTitle": "Nieuwe bestelling! 🥕"   (tekst of vertaalsleutel)
function wp_txt(array $site, $v): string {
    if (is_string($v) && isset($site['translations'][$v])) $v = $site['translations'][$v];
    if (is_array($v)) { $v = $v['nl'] ?? reset($v); if (is_array($v)) $v = implode('', array_map(fn($r) => is_array($r) ? ($r['t'] ?? '') : (string)$r, $v)); }
    return (string)$v;
}
function wp_mail_col(array $site, $v, string $fb): string {
    $v = is_string($v) ? trim($v) : '';
    if ($v !== '' && $v[0] === '@') $v = (string)($site['colors'][substr($v, 1)] ?? '');
    return preg_match('/^#[0-9a-f]{3}([0-9a-f]{3})?$/i', $v) ? $v : $fb;
}
function wp_mail_look(array $site, ?array $def): array {
    $m = $site['site']['mail'] ?? [];
    $cols = array_values(array_filter($site['colors'] ?? [], 'is_string'));
    $fam = fn($f) => $f ? "'" . str_replace("'", '', (string)$f) . "'," : '';
    $logo = (string)($m['logo'] ?? '');
    $logoFile = ($logo !== '' && preg_match('/^[\w\/.-]+\.(png|jpe?g|gif)$/i', $logo) && !str_contains($logo, '..') && is_file(WP_SITE_DIR . '/' . $logo)) ? WP_SITE_DIR . '/' . $logo : null;
    return [
        'accent' => wp_mail_col($site, $m['accent'] ?? ($def['accent'] ?? null), wp_mail_col($site, $cols[0] ?? '', '#333333')),
        'ink'    => wp_mail_col($site, $def['ink'] ?? ($m['ink'] ?? '@ink'), '#222222'),
        'muted'  => wp_mail_col($site, $m['muted'] ?? '@muted', '#6b6b6b'),
        'bg'     => wp_mail_col($site, $m['bg'] ?? ($site['site']['background'] ?? null), '#f4f4f4'),
        'card'   => wp_mail_col($site, $def['fieldBg'] ?? ($m['card'] ?? null), '#ffffff'),
        'line'   => wp_mail_col($site, $m['line'] ?? '@lijn', '#e6e6e6'),
        'font'   => $fam($def['font'] ?? ($m['font'] ?? null)) . 'Arial,Helvetica,sans-serif',
        'head'   => $fam($def['labelFont'] ?? ($m['headFont'] ?? ($def['font'] ?? null))) . 'Arial,Helvetica,sans-serif',
        'strip'  => ($def['look'] ?? ($m['look'] ?? '')) === 'strip',
        'radius' => max(0, min(30, (int)($def['radius'] ?? ($m['radius'] ?? 12)))),
        'title'  => wp_txt($site, $m['title'] ?? ($site['meta']['name'] ?? ($_SERVER['HTTP_HOST'] ?? 'website'))),
        'logo'   => $logoFile,
        'showTitle' => !($logoFile && ($m['showTitle'] ?? true) === false),   // site.mail.showTitle:false = alleen het logo in de kop (titel blijft in het onderwerp)
        // Apple Mail/iOS tonen de eigen letters van de site; Gmail/Outlook vallen terug op Arial
        'fontsCss' => !empty($site['site']['fontsCss']) && preg_match('/^[\w\/.?=-]+$/', (string)$site['site']['fontsCss']) ? wp_site_url() . $site['site']['fontsCss'] : '',
    ];
}
// tekst die leesbaar op een kleur staat: wit of de inktkleur
function wp_mail_on(string $hex, string $ink): string {
    $h = ltrim($hex, '#'); if (strlen($h) === 3) $h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
    [$r, $g, $b] = array_map('hexdec', str_split($h, 2));
    return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 160 ? $ink : '#ffffff';
}
// de inzending als lijst [label, waarde, soort] — keuzes met hun leesbare naam
function wp_row_items(array $site, ?array $def, array $row): array {
    $fields = []; foreach (($def['fields'] ?? []) as $f) if (isset($f['name'])) $fields[$f['name']] = $f;
    $out = [];
    foreach (($row['data'] ?? []) as $k => $v) {
        $f = $fields[$k] ?? []; $v = (string)$v;
        if (in_array($f['type'] ?? '', ['choice', 'select'], true)) foreach (($f['options'] ?? []) as $o) {
            if (is_array($o) && (string)($o['value'] ?? '') === $v) { $v = wp_txt($site, $o['label'] ?? $v); break; }
        }
        $kind = $f['type'] ?? ''; if ($kind === '' && filter_var($v, FILTER_VALIDATE_EMAIL)) $kind = 'email';
        $out[] = [isset($f['label']) ? wp_txt($site, $f['label']) : $k, $v, $kind, $k];
    }
    if (!empty($row['order']) && is_array($row['order'])) $out = array_merge($out, wp_shop_order_items($site, $row['order']));
    return $out;
}
function wp_row_meta(array $row): string {
    return date('d-m-Y H:i', strtotime($row['createdAt'] ?? 'now')) . ' · pagina ' . ($row['page'] ?? '') . ' · ' . strtoupper((string)($row['lang'] ?? ''));
}
// leesbare tekst van één inzending (de platte-tekstversie van de mail)
function wp_row_text(array $site, ?array $def, array $row): string {
    $row = wp_box_open($row);
    $t = isset($row['enc']) && !isset($row['data']) ? "(De inhoud is versleuteld. Alleen jij kunt hem lezen: open de editor › Inzendingen.)\n" : '';
    foreach (wp_row_items($site, $def, $row) as [$l, $v]) $t .= $l . ":\n  " . str_replace("\n", "\n  ", $v) . "\n";
    return $t . "\n(" . wp_row_meta($row) . ")\n";
}
// dezelfde inzending als kaart in de huisstijl
function wp_row_html(array $site, ?array $def, array $row, array $L): string {
    $e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8');
    $row = wp_box_open($row);
    $card = 'background:' . $L['card'] . ';border-radius:' . $L['radius'] . 'px;'
          . ($L['strip'] ? 'border:3px solid ' . $L['ink'] . ';box-shadow:6px 6px 0 ' . $L['ink'] . ';' : 'border:1px solid ' . $L['line'] . ';');
    $h = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="' . $card . 'border-collapse:separate;">';
    if (isset($row['enc']) && !isset($row['data'])) {
        $h .= '<tr><td style="padding:22px 24px;font-family:' . $L['font'] . ';font-size:15px;line-height:1.55;color:' . $L['ink'] . ';">🔒 De inhoud is versleuteld. Alleen jij kunt hem lezen: open de editor › Inzendingen.</td></tr>';
    } else {
        $items = wp_row_items($site, $def, $row); $n = count($items);
        foreach ($items as $i => [$l, $v, $kind]) {
            $val = $v === '' ? '<span style="color:' . $L['muted'] . ';">—</span>' : nl2br($e($v));
            if ($v !== '' && $kind === 'email' && filter_var($v, FILTER_VALIDATE_EMAIL)) $val = '<a href="mailto:' . $e($v) . '" style="color:' . $L['ink'] . ';text-decoration:underline;">' . $e($v) . '</a>';
            if ($v !== '' && $kind === 'tel') $val = '<a href="tel:' . $e(preg_replace('/[^\d+]/', '', $v)) . '" style="color:' . $L['ink'] . ';text-decoration:underline;">' . $e($v) . '</a>';
            $sep = $i < $n - 1 ? 'border-bottom:2px dashed ' . $L['line'] . ';' : '';
            $h .= '<tr><td style="padding:14px 24px;' . $sep . '">'
                . '<div style="font-family:' . $L['head'] . ';font-size:13px;font-weight:600;letter-spacing:.3px;color:' . $L['muted'] . ';margin:0 0 3px;">' . $e($l) . '</div>'
                . '<div style="font-family:' . $L['font'] . ';font-size:16px;line-height:1.5;color:' . $L['ink'] . ';font-weight:500;">' . $val . '</div></td></tr>';
        }
    }
    return $h . '</table>'
         . '<div style="font-family:' . $L['font'] . ';font-size:12px;color:' . $L['muted'] . ';padding:12px 4px 0;">' . $e(wp_row_meta($row)) . '</div>';
}
// knoppen om meteen te reageren: mailen, bellen, WhatsApp
function wp_row_buttons(array $site, ?array $def, array $row): array {
    $row = wp_box_open($row); $b = []; $name = '';
    foreach (wp_row_items($site, $def, $row) as [$l, $v, $kind, $k]) {
        if ($v === '') continue;
        if ($name === '' && in_array($k, ['name', 'naam'], true)) $name = trim(explode(' ', $v)[0]);
        if ($kind === 'email' && filter_var($v, FILTER_VALIDATE_EMAIL)) $mail = $v;
        if ($kind === 'tel') $tel = preg_replace('/[^\d+]/', '', $v);
    }
    $who = $name !== '' ? ' ' . $name : '';
    if (!empty($mail)) $b[] = ['Mail' . $who . ' terug', 'mailto:' . $mail, true];
    if (!empty($tel)) {
        $b[] = ['Bel' . $who, 'tel:' . $tel, empty($mail)];
        $wa = preg_replace('/^\+/', '', preg_replace('/^0(?=6)/', '31', preg_replace('/^00/', '', $tel)));
        if (preg_match('/^\d{9,15}$/', $wa)) $b[] = ['WhatsApp', 'https://wa.me/' . $wa, false];
    }
    return $b;
}
// de hele mail: kop met logo, titel, intro, inhoud, knoppen, voetregel. Geeft [html, ingesloten beelden].
function wp_mail_page(array $L, string $heading, string $intro, string $content, array $buttons): array {
    $e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8');
    $inline = [];
    $onAcc = wp_mail_on($L['accent'], $L['ink']);
    $logo = '';
    if ($L['logo']) { $inline['logo@wp'] = $L['logo']; $logo = '<img src="cid:logo@wp" alt="" height="44" style="display:inline-block;height:44px;width:auto;border:0;vertical-align:middle;margin-right:12px;">'; }
    $btns = '';
    foreach ($buttons as [$label, $href, $primary]) {
        $bg = $primary ? $L['accent'] : $L['card']; $fg = $primary ? $onAcc : $L['ink'];
        $bd = $L['strip'] ? '3px solid ' . $L['ink'] : '1px solid ' . ($primary ? $L['accent'] : $L['line']);
        $btns .= '<a href="' . $e($href) . '" style="display:inline-block;margin:0 10px 10px 0;padding:12px 20px;background:' . $bg . ';color:' . $fg . ';border:' . $bd . ';border-radius:999px;font-family:' . $L['head'] . ';font-size:15px;font-weight:600;text-decoration:none;' . ($L['strip'] ? 'box-shadow:4px 4px 0 ' . $L['ink'] . ';' : '') . '">' . $e($label) . '</a>';
    }
    $host = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    $html = '<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      . '<meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light"><title>' . $e($heading) . '</title>'
      . (!empty($L['fontsCss']) ? '<link rel="stylesheet" href="' . $e($L['fontsCss']) . '">' : '') . '</head>'
      . '<body style="margin:0;padding:0;background:' . $L['bg'] . ';">'
      . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:' . $L['bg'] . ';"><tr><td align="center" style="padding:28px 14px 36px;">'
      . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;">'
      // kop: logo + naam
      . '<tr><td style="padding:0 4px 18px;font-family:' . $L['head'] . ';font-size:20px;font-weight:700;color:' . $L['ink'] . ';">' . $logo . '' . ($L['showTitle'] ? '<span style="vertical-align:middle;">' . $e($L['title']) . '</span>' : '') . '</td></tr>'
      // band in de accentkleur met de titel
      . '<tr><td style="background:' . $L['accent'] . ';border-radius:' . $L['radius'] . 'px;padding:22px 24px;' . ($L['strip'] ? 'border:3px solid ' . $L['ink'] . ';box-shadow:6px 6px 0 ' . $L['ink'] . ';' : '') . '">'
      . '<div style="font-family:' . $L['head'] . ';font-size:26px;line-height:1.15;font-weight:700;color:' . $onAcc . ';">' . $e($heading) . '</div>'
      . ($intro !== '' ? '<div style="font-family:' . $L['font'] . ';font-size:15px;line-height:1.5;color:' . $onAcc . ';margin-top:6px;opacity:.92;">' . $e($intro) . '</div>' : '')
      . '</td></tr>'
      . '<tr><td style="height:22px;line-height:22px;font-size:0;">&nbsp;</td></tr>'
      . ($content !== '' ? '<tr><td>' . $content . '</td></tr><tr><td style="height:22px;line-height:22px;font-size:0;">&nbsp;</td></tr>' : '')
      . ($btns !== '' ? '<tr><td style="padding:0 0 6px;">' . $btns . '</td></tr>' : '')
      . '<tr><td style="padding:18px 4px 0;border-top:2px solid ' . $L['line'] . ';font-family:' . $L['font'] . ';font-size:12px;line-height:1.5;color:' . $L['muted'] . ';">'
      . 'Verstuurd door je website' . ($host !== '' ? ' · ' . $e($host) : '') . '</td></tr>'
      . '</table></td></tr></table></body></html>';
    return [$html, $inline];
}
// MIME: platte tekst + HTML (+ ingesloten beelden) → [headers, body]
function wp_mime(array $h, string $text, string $html, array $inline): array {
    $h = array_values(array_filter($h, fn($x) => stripos($x, 'Content-Type:') !== 0 && stripos($x, 'Content-Transfer-Encoding:') !== 0));
    $alt = 'alt_' . bin2hex(random_bytes(8)); $rel = 'rel_' . bin2hex(random_bytes(8));
    $b64 = fn($x) => rtrim(chunk_split(base64_encode($x), 76, "\r\n"));
    $txt = "--$alt\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . $b64($text) . "\r\n";
    $htm = "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . $b64($html) . "\r\n";
    $imgs = '';
    foreach ($inline as $cid => $file) {
        $data = @file_get_contents($file); if ($data === false) continue;
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION)); $mt = ['png' => 'image/png', 'gif' => 'image/gif'][$ext] ?? 'image/jpeg';
        $imgs .= "--$rel\r\nContent-Type: $mt; name=\"" . basename($file) . "\"\r\nContent-Transfer-Encoding: base64\r\nContent-ID: <$cid>\r\nContent-Disposition: inline; filename=\"" . basename($file) . "\"\r\n\r\n" . $b64($data) . "\r\n";
    }
    if ($imgs !== '') {
        $part = "--$alt\r\nContent-Type: multipart/related; boundary=\"$rel\"\r\n\r\n--$rel\r\n" . $htm . $imgs . "--$rel--\r\n";
    } else {
        $part = "--$alt\r\n" . $htm;
    }
    $h[] = 'Content-Type: multipart/alternative; boundary="' . $alt . '"';
    return [$h, $txt . $part . "--$alt--\r\n"];
}
function wp_notify(array $site, ?array $def, array $row): void {
    $cfg = wp_config();
    $to = (string)($cfg['notifyEmail'] ?? ''); $mode = (string)($cfg['notifyMode'] ?? 'each');
    if ($to === '' || $mode === 'off') return;
    if ($mode === 'daily') { @file_put_contents(STORAGE . '/notify-queue.jsonl', json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX); return; }
    $row = wp_box_open($row);
    $reply = null; foreach (($row['data'] ?? []) as $v) if (filter_var($v, FILTER_VALIDATE_EMAIL)) { $reply = $v; break; }
    $who = ''; foreach (['name', 'naam'] as $k) if (!empty($row['data'][$k])) { $who = (string)$row['data'][$k]; break; }
    $L = wp_mail_look($site, $def);
    $heading = !empty($def['notifyTitle']) ? wp_txt($site, $def['notifyTitle']) : 'Nieuwe inzending';
    $intro = ($who !== '' ? $who . ' heeft' : 'Iemand heeft') . ' het formulier ingevuld op je website.';
    $buttons = array_merge(wp_row_buttons($site, $def, $row), [['Alle inzendingen', wp_site_url() . '?edit', false]]);
    [$html, $inl] = wp_mail_page($L, $heading, $intro, wp_row_html($site, $def, $row, $L), $buttons);
    wp_mail($to, $heading . ($who !== '' ? ' · ' . $who : '') . ' · ' . $L['title'],
        "Er is een formulier ingevuld op je website.\n\n" . wp_row_text($site, $def, $row)
        . "\nAlle inzendingen: " . wp_site_url() . "?edit  (knop Inzendingen)\n" . ($reply ? "Beantwoorden kan direct met 'Antwoorden'.\n" : ''), $reply, $html, $inl);
}
function wp_digest_due(): void {
    $cfg = wp_config();
    if (($cfg['notifyMode'] ?? 'each') !== 'daily' || empty($cfg['notifyEmail'])) return;
    $q = STORAGE . '/notify-queue.jsonl'; $last = STORAGE . '/notify-last.txt';
    if (!is_file($q) || filesize($q) === 0) return;
    if (is_file($last) && time() - (int)file_get_contents($last) < 86400) return;
    $fh = fopen($q, 'c+'); if (!$fh || !flock($fh, LOCK_EX | LOCK_NB)) return;     // één tegelijk
    $rows = array_filter(array_map(fn($l) => json_decode($l, true), file($q, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []));
    $site = json_decode((string)@file_get_contents(SITE_FILE), true) ?: [];
    $body = count($rows) . " nieuwe inzending(en) sinds het vorige overzicht.\n";
    $cards = ''; $L = null;
    foreach ($rows as $r) {
        $def = null;
        foreach ($site['pages'] ?? [] as $p) foreach ($p['objects'] ?? [] as $o) if (($o['type'] ?? '') === 'form' && ($o['props']['formId'] ?? '') === ($r['formId'] ?? '')) $def = $o['props'];
        $L = $L ?? wp_mail_look($site, $def);
        $body .= "\n—— " . ($r['formId'] ?? '') . " ——\n" . wp_row_text($site, $def, $r);
        $cards .= wp_row_html($site, $def, $r, $L) . '<div style="height:26px;line-height:26px;font-size:0;">&nbsp;</div>';
    }
    $body .= "\nAlle inzendingen: " . wp_site_url() . "?edit  (knop Inzendingen)\n";
    $L = $L ?? wp_mail_look($site, null);
    [$html, $inl] = wp_mail_page($L, 'Dagoverzicht', count($rows) . ' nieuwe inzending(en) sinds het vorige overzicht.', $cards, [['Alle inzendingen', wp_site_url() . '?edit', true]]);
    if (wp_mail((string)$cfg['notifyEmail'], 'Dagoverzicht: ' . count($rows) . ' inzending(en) · ' . $L['title'], $body, null, $html, $inl)) { ftruncate($fh, 0); file_put_contents($last, (string)time()); }
    flock($fh, LOCK_UN); fclose($fh);
}

// kleine SMTP-verzender (geen extra bibliotheek): STARTTLS op 587 of SSL op 465, inloggen met AUTH LOGIN.
// .secrets/webplays.php:  'smtpHost' => 'smtp.example.nl', 'smtpPort' => 587, 'smtpSecure' => 'tls' | 'ssl' | 'none',
//                         'smtpUser' => 'website@make-peas.com', 'smtpPass' => '…'   (wachtwoord ALLEEN hier)
function wp_smtp(array $cfg, string $from, string $to, string $subj, array $headers, string $body, string &$err): bool {
    $host = (string)$cfg['smtpHost']; $secure = (string)($cfg['smtpSecure'] ?? 'tls');
    $port = (int)($cfg['smtpPort'] ?? ($secure === 'ssl' ? 465 : 587));
    $ca = WP_SECRETS . '/cacert.pem';
    $ctx = stream_context_create(['ssl' => array_filter(['verify_peer' => true, 'verify_peer_name' => true, 'cafile' => is_file($ca) ? $ca : null, 'SNI_enabled' => true, 'peer_name' => $host])]);
    $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 20, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) { $err = "geen verbinding met $host:$port ($es)"; return false; }
    stream_set_timeout($fp, 20);
    $read = function () use ($fp) { $d = ''; while (($l = fgets($fp, 1024)) !== false) { $d .= $l; if (strlen($l) < 4 || $l[3] === ' ') break; } return $d; };
    $cmd = function ($c, $want) use ($fp, $read, &$err) {
        if ($c !== null) fwrite($fp, $c . "\r\n");
        $r = $read();
        if ((int)substr($r, 0, 3) !== $want) { $err = 'server zegt: ' . trim(preg_replace('/\s+/', ' ', $r)) ?: 'geen antwoord'; return false; }
        return true;
    };
    $me = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    $ok = $cmd(null, 220) && $cmd('EHLO ' . $me, 250);
    if ($ok && $secure === 'tls') {
        $ok = $cmd('STARTTLS', 220) && @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        if (!$ok && !$err) $err = 'TLS-handshake mislukt (certificaat?)';
        $ok = $ok && $cmd('EHLO ' . $me, 250);
    }
    if ($ok && !empty($cfg['smtpUser'])) {
        $ok = $cmd('AUTH LOGIN', 334) && $cmd(base64_encode((string)$cfg['smtpUser']), 334) && $cmd(base64_encode((string)($cfg['smtpPass'] ?? '')), 235);
        if (!$ok) $err = 'inloggen mislukt (gebruikersnaam/wachtwoord?) — ' . $err;
    }
    $data = 'To: ' . $to . "\r\nSubject: " . $subj . "\r\nDate: " . date('r') . "\r\nMessage-ID: <" . bin2hex(random_bytes(8)) . '@' . $me . ">\r\n"
          . implode("\r\n", $headers) . "\r\n\r\n" . preg_replace('/^\./m', '..', str_replace(["\r\n", "\n"], ["\n", "\r\n"], $body));
    $ok = $ok && $cmd('MAIL FROM:<' . $from . '>', 250) && $cmd('RCPT TO:<' . $to . '>', 250) && $cmd('DATA', 354) && $cmd($data . "\r\n.", 250);
    @fwrite($fp, "QUIT\r\n"); fclose($fp);
    return $ok;
}

// ---------- bewaren en verwijderen van inzendingen ----------
// .secrets/webplays.php:  'formRetentionMonths' => 12   (0 of weg = alles bewaren)
// haalt rijen weg waarvoor $drop(rij) true geeft, in alle formulierbestanden; geeft het aantal terug
function wp_prune(callable $drop): int {
    $n = 0;
    foreach (array_merge(glob(STORAGE . '/form-*.jsonl') ?: [], [STORAGE . '/notify-queue.jsonl']) as $f) {
        if (!is_file($f)) continue;
        $fh = fopen($f, 'c+'); if (!$fh) continue;
        flock($fh, LOCK_EX);
        $keep = []; $was = 0;
        while (($line = fgets($fh)) !== false) {
            if (trim($line) === '') continue;
            $was++; $r = json_decode($line, true);
            if (is_array($r) && $drop($r)) continue;
            $keep[] = rtrim($line, "\r\n");
        }
        if (count($keep) !== $was) {
            if (!str_ends_with($f, 'notify-queue.jsonl')) $n += $was - count($keep);
            ftruncate($fh, 0); rewind($fh); fwrite($fh, $keep ? implode("\n", $keep) . "\n" : ''); fflush($fh);
        }
        flock($fh, LOCK_UN); fclose($fh);
    }
    return $n;
}
function wp_retention(): void {
    $m = (int)(wp_config()['formRetentionMonths'] ?? 0);
    if ($m <= 0) return;
    $last = STORAGE . '/retention-last.txt';
    if (is_file($last) && time() - (int)file_get_contents($last) < 86400) return;
    $limit = strtotime('-' . $m . ' months');
    $n = wp_prune(fn($r) => strtotime($r['createdAt'] ?? 'now') < $limit);
    @file_put_contents($last, (string)time());
    if ($n) @file_put_contents(STORAGE . '/mail-log.jsonl', json_encode(['at' => gmdate('c'), 'retention' => $n . ' inzending(en) ouder dan ' . $m . ' maanden verwijderd']) . "\n", FILE_APPEND | LOCK_EX);
}

// ---------- afhaalpunt (veldtype pickup) ----------
// site.json → "afhaal": {lead, weeks, places:[{id, plaats, actief, dagen, tijd, plek}], blocked:[{place|'*', date, reden}]}
function wp_pickup_check(array $site, string $v, ?string &$label): ?string {
    $label = null;
    if (!preg_match('/^([a-z0-9_-]{1,60})\|(\d{4}-\d{2}-\d{2})$/i', $v, $m)) return 'format';
    [$all, $id, $date] = $m;
    $A = $site['afhaal'] ?? [];
    $place = null;
    foreach ($A['places'] ?? [] as $q) if (($q['id'] ?? '') === $id) { $place = $q; break; }
    if (!$place || (isset($place['actief']) && $place['actief'] === false)) return 'place';
    $d = DateTime::createFromFormat('!Y-m-d', $date);
    if (!$d || $d->format('Y-m-d') !== $date) return 'date';
    $first = new DateTime('today'); $first->modify('+' . (int)($A['lead'] ?? 2) . ' days');
    $last = new DateTime('today'); $last->modify('+' . (7 * (int)($A['weeks'] ?? 6) + 7) . ' days');
    if ($d < $first || $d > $last) return 'date';
    $map = ['zo' => 0, 'ma' => 1, 'di' => 2, 'wo' => 3, 'do' => 4, 'vr' => 5, 'za' => 6];
    $days = array_map(fn($x) => $map[$x] ?? -1, (array)($place['dagen'] ?? []));
    if (!in_array((int)$d->format('w'), $days, true)) return 'day';
    foreach ($A['blocked'] ?? [] as $b) {
        if (($b['date'] ?? '') === $date && in_array($b['place'] ?? '', ['*', $id], true)) return 'blocked';
    }
    $dn = ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'][(int)$d->format('w')];
    // tijd: staat er per dag een tijd ("wo 17:00–18:30 · za 10:00–12:00"), neem dan alleen die van de gekozen dag
    $tijd = (string)($place['tijd'] ?? '');
    foreach (preg_split('/\s*[·,;]\s*/u', $tijd) as $seg) if (preg_match('/^' . $dn . '\b\s*(.+)$/iu', trim($seg), $tm)) { $tijd = $tm[1]; break; }
    $label = ($place['plaats'] ?? $id) . (empty($place['plek']) ? '' : ' (' . $place['plek'] . ')') . ' · ' . $dn . ' ' . $d->format('d-m-Y') . ($tijd === '' ? '' : ' · ' . $tijd);
    return null;
}

// ---------- beeld (media/ van de site) ----------
function wp_media_dir(): string { $d = WP_SITE_DIR . '/media'; if (!is_dir($d)) mkdir($d, 0775, true); return $d; }
function wp_media_item(string $dir, string $f): array {
    $p = "$dir/$f"; $w = 0; $h = 0;
    if (preg_match('/\.svg$/i', $f)) {
        $x = (string)file_get_contents($p, false, null, 0, 4000);
        if (preg_match('/viewBox\s*=\s*["\'][\d.\-]+[\s,]+[\d.\-]+[\s,]+([\d.]+)[\s,]+([\d.]+)/i', $x, $m)) { $w = (int)round((float)$m[1]); $h = (int)round((float)$m[2]); }
    } else { $s = @getimagesize($p); if ($s) { $w = (int)$s[0]; $h = (int)$s[1]; } }
    return ['file' => 'media/' . $f, 'name' => $f, 'w' => $w, 'h' => $h, 'size' => (int)filesize($p), 'time' => (int)filemtime($p)];
}
function wp_media_upload(): never {
    $max = 15 * 1024 * 1024;   // de editor verkleint foto's al vóór het uploaden; dit is de vangrail
    $data = file_get_contents('php://input', false, null, 0, $max + 1);
    if ($data === false || strlen($data) > $max) reply(['ok' => false, 'error' => 'Bestand te groot (max 15 MB)'], 413);
    if (strlen($data) < 12) reply(['ok' => false, 'error' => 'Leeg bestand'], 400);
    // het type uit de inhoud zelf, niet uit de naam
    $ext = null;
    if (str_starts_with($data, "\xFF\xD8\xFF")) $ext = 'jpg';
    elseif (str_starts_with($data, "\x89PNG")) $ext = 'png';
    elseif (str_starts_with($data, 'GIF8')) $ext = 'gif';
    elseif (substr($data, 0, 4) === 'RIFF' && substr($data, 8, 4) === 'WEBP') $ext = 'webp';
    elseif (stripos(substr($data, 0, 2000), '<svg') !== false) $ext = 'svg';
    if (!$ext) reply(['ok' => false, 'error' => 'Alleen JPG, PNG, WebP, GIF of SVG'], 415);
    if ($ext === 'svg' && preg_match('/<script|\bon[a-z]+\s*=|javascript:|<foreignobject|<iframe|<embed|<object/i', $data))
        reply(['ok' => false, 'error' => 'Deze SVG bevat scripts en wordt niet geplaatst'], 415);
    $base = strtolower(pathinfo((string)($_GET['name'] ?? ''), PATHINFO_FILENAME));
    $base = trim(preg_replace('/[^a-z0-9]+/', '-', iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base) ?: $base), '-');
    $base = substr($base !== '' ? $base : 'beeld', 0, 60);
    $dir = wp_media_dir(); $f = "$base.$ext"; $i = 2;
    while (is_file("$dir/$f")) $f = $base . '-' . $i++ . ".$ext";
    if (file_put_contents("$dir/$f", $data) !== strlen($data)) reply(['ok' => false, 'error' => 'Opslaan mislukt (schrijfrechten op media/?)'], 500);
    reply(['ok' => true, 'item' => wp_media_item($dir, $f)]);
}

// ---------- lettertypes lokaal (fonts/ van de site) ----------
function wp_get(string $url, array $cfg, int $timeout = 15): array {
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';   // zo levert Google woff2
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_FOLLOWLOCATION => true, CURLOPT_USERAGENT => $ua]);
        foreach ([(string)($cfg['caFile'] ?? ''), WP_SECRETS . '/cacert.pem', __DIR__ . '/cacert.pem'] as $ca) {
            if ($ca !== '' && is_file($ca)) { curl_setopt($ch, CURLOPT_CAINFO, $ca); break; }
        }
        $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$code, $resp === false ? '' : (string)$resp];
    }
    $caf = WP_SECRETS . '/cacert.pem';
    $resp = @file_get_contents($url, false, stream_context_create(['http' => ['header' => "User-Agent: $ua", 'timeout' => $timeout, 'ignore_errors' => true],
                                                                  'ssl' => is_file($caf) ? ['cafile' => $caf, 'verify_peer' => true] : []]));
    $code = 200;
    foreach ($http_response_header ?? [] as $h) if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $code = (int)$m[1];
    return [$resp === false ? 0 : $code, $resp === false ? '' : (string)$resp];
}
// geeft [families die lokaal staan, 'fonts/fonts.css?v=…'] — wat niet lukt, blijft gewoon via Google

// Huisstijl-controle (site.json → "brand"). enforce: "off" | "warn" (standaard: melden bij opslaan) | "block" (opslaan weigeren).
// Controleert: ruwe #kleuren, kleurnamen buiten het palet, lettertypes buiten de lijst, logo kleiner dan het minimum.
function wp_brand_check(array $site): array {
    $b = $site['brand'] ?? null;
    if (!is_array($b) || ($b['enforce'] ?? 'warn') === 'off') return [];
    $palette = array_flip(array_map('strval', $b['palette'] ?? []));
    $fonts   = array_flip(array_map('strval', $b['fonts'] ?? []));
    $rawOk   = !empty($b['rawColors']);
    $logo    = $b['logo']['src'] ?? null; $minW = (float)($b['logo']['minWidth'] ?? 0);
    $out = [];
    $add = function (string $m) use (&$out) { if (count($out) < 60) $out[] = $m; };
    $colorKeys = ['color' => 1, 'activeColor' => 1, 'accent' => 1];
    $walk = function ($node, string $where) use (&$walk, $add, $palette, $fonts, $rawOk, $colorKeys, $logo, $minW) {
        if (!is_array($node)) return;
        if ($logo && ($node['type'] ?? '') === 'image' && ($node['props']['src'] ?? '') === $logo && $minW > 0 && (float)($node['layout']['w'] ?? 0) < $minW)
            $add("$where: logo smaller than {$minW}px");
        foreach ($node as $k => $v) {
            if (is_string($k) && isset($colorKeys[$k]) && is_string($v)) {
                if ($v !== '' && $v[0] === '#' && !$rawOk) $add("$where: raw colour $v (use a palette name)");
                elseif ($v !== '' && $v[0] === '@' && $palette && !isset($palette[substr($v, 1)])) $add("$where: colour $v is not in the brand palette");
            } elseif ($k === 'font' && is_string($v) && $fonts && !isset($fonts[$v])) {
                $add("$where: font \"$v\" is not a brand font");
            } elseif (is_array($v)) {
                $walk($v, is_string($v['uuid'] ?? null) ? (string)$v['uuid'] : $where);
            }
        }
    };
    foreach ($site['pages'] ?? [] as $p)   $walk($p['objects'] ?? [], 'page ' . ($p['id'] ?? '?'));
    foreach ($site['masters'] ?? [] as $id => $m) $walk($m['objects'] ?? [], 'master ' . $id);
    $walk($site['styles'] ?? [], 'styles');
    if ($palette) foreach (array_keys($site['colors'] ?? []) as $n) if (!isset($palette[$n])) $add("colour \"$n\" is defined but not in the brand palette");
    return $out;
}

function wp_fonts_local(array $fonts, array $cfg): array {
    if (($cfg['fontsLocal'] ?? true) === false) return [[], null];          // uitzetten kan: 'fontsLocal' => false in .secrets
    $api = (string)($cfg['fontsApi'] ?? 'https://fonts.googleapis.com/css2');
    $dir = WP_SITE_DIR . '/fonts';
    $manFile = $dir . '/fonts.json';
    $man = is_file($manFile) ? (json_decode((string)file_get_contents($manFile), true) ?: []) : [];
    $fams = []; $css = ''; $changed = false; $t0 = microtime(true);
    foreach ($fonts as $f) {
        $spec = (string)($f['google'] ?? ''); $fam = (string)($f['family'] ?? '');
        if ($spec === '' || $fam === '' || !preg_match('/^[A-Za-z0-9+:;@,.\-]+$/', $spec)) continue;
        if (!isset($man[$spec])) {
            if (microtime(true) - $t0 > 40) continue;                         // opslaan nooit eindeloos laten wachten; de rest volgt bij de volgende keer
            [$code, $sheet] = wp_get($api . '?family=' . $spec . '&display=swap', $cfg);
            if ($code !== 200 || !str_contains($sheet, '@font-face')) continue;
            // alleen latin en latin-ext (Nederlands, Duits, Frans…); zonder subset-opmerkingen: alles
            $blocks = []; $hasSub = preg_match_all('#/\*\s*([a-z\-]+)\s*\*/\s*(@font-face\s*\{[^}]*\})#i', $sheet, $mm, PREG_SET_ORDER);
            if ($hasSub) { foreach ($mm as $m) if (in_array(strtolower($m[1]), ['latin', 'latin-ext'], true)) $blocks[] = $m[2]; }
            else { preg_match_all('#@font-face\s*\{[^}]*\}#i', $sheet, $m2); $blocks = $m2[0]; }
            if (!$blocks) continue;
            if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return [[], null];
            $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($fam)), '-');
            $ok = true; $out = [];
            foreach ($blocks as $i => $b) {
                if (!preg_match('#url\(([^)]+)\)#', $b, $u)) { $ok = false; break; }
                $src = trim($u[1], "'\" ");
                $host = (string)parse_url($src, PHP_URL_HOST);
                if ($host !== 'fonts.gstatic.com' && $host !== (string)parse_url($api, PHP_URL_HOST)) { $ok = false; break; }
                $ext = preg_match('#\.(woff2|woff|ttf|otf)(\?|$)#i', $src, $e) ? strtolower($e[1]) : 'woff2';
                $name = $slug . '-' . substr(md5($src), 0, 8) . '.' . $ext;
                if (!is_file("$dir/$name")) {
                    [$c2, $bin] = wp_get($src, $cfg, 20);
                    if ($c2 !== 200 || strlen($bin) < 100) { $ok = false; break; }
                    file_put_contents("$dir/$name", $bin);
                }
                $out[] = str_replace($u[0], "url('$name')", $b);
            }
            if (!$ok) continue;
            $man[$spec] = ['family' => $fam, 'css' => implode("\n", $out), 'at' => gmdate('Y-m-d\TH:i:s\Z')];
            $changed = true;
        }
        $fams[] = $man[$spec]['family']; $css .= "/* $fam */\n" . $man[$spec]['css'] . "\n";
    }
    if (!$fams) return [[], null];
    if ($changed) file_put_contents($manFile, json_encode($man, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $cur = is_file("$dir/fonts.css") ? (string)file_get_contents("$dir/fonts.css") : '';
    if ($cur !== $css) file_put_contents("$dir/fonts.css", $css);
    return [$fams, 'fonts/fonts.css?v=' . substr(md5($css), 0, 8)];
}

// ---------- versleuteling (sleutelpaar uit je 24 woorden; op de server staat alleen de publieke sleutel) ----------
// .secrets/webplays.php:  'boxPublicKey' => '…'   (de editor maakt hem: Inzendingen › Sleutel)
// Gemak (zoals 'requireKey' => false): 'boxPhrase' => '24 woorden' in .secrets. Dan maakt de server de inzendingen
// zelf open voor de editor en de meldingsmails. Op de schijf blijven ze versleuteld; wie de server binnenkomt, kan ze wel lezen.
function wp_box_kp(): ?string {
    static $kp = false;
    if ($kp !== false) return $kp;
    $ph = trim(preg_replace('/[^a-z]+/', ' ', strtolower((string)(wp_config()['boxPhrase'] ?? ''))));   // onder elkaar, met nummers: maakt niet uit
    if ($ph === '' || !function_exists('sodium_crypto_box_seed_keypair') || count(explode(' ', $ph)) !== 24) return $kp = null;
    if (class_exists('Normalizer')) $ph = Normalizer::normalize($ph, Normalizer::FORM_KD);
    $seed = hash_pbkdf2('sha512', $ph, 'mnemonic', 2048, 64, true);                 // BIP39
    return $kp = sodium_crypto_box_seed_keypair(sodium_crypto_generichash($seed, 'webplays-box-key-v1', 32));
}
function wp_box_open(array $r): array {   // inzending openmaken als de server de woorden heeft
    if (!isset($r['enc']) || isset($r['data']) || !($kp = wp_box_kp())) return $r;
    $raw = base64_decode((string)$r['enc'], true);
    $plain = $raw !== false ? sodium_crypto_box_seal_open($raw, $kp) : false;
    if ($plain !== false) { $d = json_decode($plain, true); if (is_array($d)) $r['data'] = $d; }
    return $r;
}
function wp_box_pk(): ?string {
    static $pk = false;
    if ($pk !== false) return $pk;
    if ($kp = wp_box_kp()) return $pk = sodium_crypto_box_publickey($kp);
    $b = (string)(wp_config()['boxPublicKey'] ?? '');
    $raw = $b !== '' ? base64_decode(strtr($b, '-_', '+/'), true) : false;
    return $pk = ($raw !== false && strlen($raw) === 32 && function_exists('sodium_crypto_box_seal')) ? $raw : null;
}
// elke inzending herschrijven (zelfde vergrendeling als wp_prune); geeft het aantal gewijzigde regels
function wp_rewrite(callable $fn): int {
    $n = 0;
    foreach (array_merge(glob(STORAGE . '/form-*.jsonl') ?: [], [STORAGE . '/notify-queue.jsonl']) as $f) {
        if (!is_file($f)) continue;
        $fh = fopen($f, 'c+'); if (!$fh) continue;
        flock($fh, LOCK_EX);
        $out = []; $ch = 0;
        while (($line = fgets($fh)) !== false) {
            if (trim($line) === '') continue;
            $r = json_decode($line, true);
            if (!is_array($r)) { $out[] = rtrim($line, "\r\n"); continue; }
            $nr = $fn($r);
            if ($nr !== $r) { $ch++; if (!str_ends_with($f, 'notify-queue.jsonl')) $n++; }
            $out[] = json_encode($nr, JSON_UNESCAPED_UNICODE);
        }
        if ($ch) { ftruncate($fh, 0); rewind($fh); fwrite($fh, $out ? implode("\n", $out) . "\n" : ''); fflush($fh); }
        flock($fh, LOCK_UN); fclose($fh);
    }
    return $n;
}
