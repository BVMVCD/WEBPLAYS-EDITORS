<?php
declare(strict_types=1);
/*  WEBPLAYS betalen (neutraal): één vast koppelvlak, per provider één bestand in api/pay/<naam>.php.
    Provider en sleutel staan ALLEEN in .secrets:  'payProvider' => 'mollie',  'mollieKey' => 'test_…' (of live_…).
    In site.json staat niets over betalen. Modus (test/live) volgt uit de sleutel.
    Een provider-bestand levert twee functies:
      wp_pay_<naam>_create(array $order, array $ctx): array   → ['id' => …, 'url' => …]   (ctx: cfg, description, redirectUrl, webhookUrl, locale)
      wp_pay_<naam>_status(string $id, array $cfg): string    → 'paid' | 'failed' | 'canceled' | 'expired' | 'open'
    Bedragen zijn gehele centen. De status komt altijd van de provider zelf, nooit uit de browser of de URL. */

function wp_pay_provider(): ?string {
    $p = strtolower(preg_replace('/[^a-z0-9]/i', '', (string)(wp_config()['payProvider'] ?? '')));
    if ($p === '' || !is_file(__DIR__ . '/pay/' . $p . '.php')) return null;
    require_once __DIR__ . '/pay/' . $p . '.php';
    return function_exists('wp_pay_' . $p . '_create') ? $p : null;
}
// HTTP-aanroep (curl, anders streams). Geeft [statuscode, body-array|null]
function wp_http(string $method, string $url, array $headers = [], ?string $body = null): array {
    $h = []; foreach ($headers as $k => $v) $h[] = $k . ': ' . $v;
    // eigen CA-bestand (voor lokaal op Windows/WAMP zonder php.ini-aanpassing): 'caFile' in .secrets, of cacert.pem naast .secrets/webplays.php
    $ca = (string)(wp_config()['caFile'] ?? '');
    if ($ca === '' || !is_file($ca)) { $try = WP_SECRETS . '/cacert.pem'; $ca = is_file($try) ? $try : ''; }
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $h, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8] + ($ca !== '' ? [CURLOPT_CAINFO => $ca] : []));
        if ($body !== null) curl_setopt($c, CURLOPT_POSTFIELDS, $body);
        $res = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); $GLOBALS['wp_http_err'] = $res === false ? curl_error($c) : ''; curl_close($c);
    } else {
        $ctx = stream_context_create(['http' => ['method' => $method, 'header' => implode("\r\n", $h), 'content' => $body ?? '', 'timeout' => 20, 'ignore_errors' => true], 'ssl' => $ca !== '' ? ['cafile' => $ca] : []]);
        $res = @file_get_contents($url, false, $ctx); $code = 0; $GLOBALS['wp_http_err'] = $res === false ? 'streams: geen verbinding' : '';
        foreach (($http_response_header ?? []) as $l) if (preg_match('#^HTTP/\S+\s+(\d+)#', $l, $m)) $code = (int)$m[1];
    }
    $j = is_string($res) ? json_decode($res, true) : null;
    return [$code, is_array($j) ? $j : null];
}
function wp_pay_private_host(): bool {
    $h = preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
    return $h === 'localhost' || !str_contains($h, '.') || (bool)preg_match('/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/', $h) || str_ends_with($h, '.local') || str_ends_with($h, '.test');
}
// order bijwerken (op bestelnummer); geeft [gewijzigd?, rij] terug
function wp_pay_update(string $number, callable $fn): ?array {
    $found = null;
    wp_rewrite(function (array $r) use ($number, $fn, &$found) {
        if (($r['order']['number'] ?? null) !== $number) return $r;
        $new = $fn($r);
        if ($new !== $r && ($r['order'] ?? null) !== ($new['order'] ?? null)) $found = $new;
        elseif ($found === null) $found = $r + ['_same' => true];
        return $new;
    });
    return $found;
}
// betaling starten voor een zojuist opgeslagen bestelling; geeft ['id','url'] of null (fout is dan gelogd)
function wp_pay_start(array $site, array $row): ?array {
    $p = wp_pay_provider(); $o = $row['order'] ?? null;
    if (!$p || !$o || (int)($o['totals']['gross'] ?? 0) <= 0) return null;
    $cfg = wp_config(); $num = (string)$o['number'];
    $token = bin2hex(random_bytes(12));
    $base = wp_site_url() . 'api/index.php';
    $ctx = [
        'cfg' => $cfg, 'description' => 'Bestelling ' . $num,
        'redirectUrl' => $base . '?a=shop-return&o=' . rawurlencode($num) . '&k=' . $token . '&l=' . rawurlencode((string)($row['lang'] ?? '')),
        'webhookUrl'  => (wp_pay_private_host() ? null : $base . '?a=shop-webhook'),
        'locale'      => (string)($cfg['payLocale'] ?? 'nl_NL'),
    ];
    try { $res = ('wp_pay_' . $p . '_create')($o, $ctx); } catch (Throwable $e) { $res = ['error' => $e->getMessage()]; }
    $now = gmdate('c');
    if (empty($res['id']) || empty($res['url'])) {
        wp_pay_update($num, function (array $r) use ($now, $res) { $r['order']['log'][] = ['at' => $now, 'status' => 'betaling-fout', 'note' => mb_substr((string)($res['error'] ?? 'onbekend'), 0, 200)]; return $r; });
        return null;
    }
    wp_pay_update($num, function (array $r) use ($now, $p, $res, $token) {
        $r['order']['status'] = 'wacht-op-betaling'; $r['order']['token'] = $token;
        $r['order']['payment'] = ['provider' => $p, 'id' => $res['id']];
        $r['order']['log'][] = ['at' => $now, 'status' => 'wacht-op-betaling'];
        return $r;
    });
    return ['id' => $res['id'], 'url' => $res['url']];
}
// status bij de provider opvragen en in de bestelling verwerken (idempotent). Geeft de nieuwe orderstatus of null
function wp_pay_sync(array $site, string $number): ?string {
    $p = wp_pay_provider(); if (!$p) return null;
    $row = wp_pay_update($number, fn(array $r) => $r);
    $pay = $row['order']['payment'] ?? null;
    if (!$pay || ($pay['provider'] ?? '') !== $p) return $row['order']['status'] ?? null;
    try { $st = ('wp_pay_' . $p . '_status')((string)$pay['id'], wp_config()); } catch (Throwable $e) { return $row['order']['status'] ?? null; }
    $map = ['paid' => 'betaald', 'failed' => 'mislukt', 'canceled' => 'geannuleerd', 'expired' => 'verlopen'];
    if (!isset($map[$st])) return $row['order']['status'] ?? null;      // open: niets veranderen
    $new = $map[$st]; $now = gmdate('c'); $changed = false;
    $upd = wp_pay_update($number, function (array $r) use ($new, $now, &$changed) {
        $cur = $r['order']['status'] ?? '';
        if ($cur === $new || in_array($cur, ['betaald', 'verzonden', 'afgehaald', 'terugbetaald'], true)) return $r;   // nooit terug of dubbel
        $r['order']['status'] = $new; $r['order']['log'][] = ['at' => $now, 'status' => $new]; $changed = true;
        return $r;
    });
    if ($changed && $new === 'betaald' && $upd) {                       // eigenaar krijgt het seintje pas bij een betaalde bestelling
        unset($upd['_same']);
        $def = wp_form_def($site, (string)($upd['formId'] ?? ''));
        wp_notify($site, $def, $upd);
        wp_pay_customer_mail($site, $def, $upd);
    }
    return $new;
}
// bevestiging aan de klant na een betaalde bestelling (alleen als er een e-mailadres is en de server de gegevens kan lezen)
// tekst per taal: site.json → translations["wp.<naam>.<index>"] (per taal) wint van de ingebouwde tekst; onbekende taal valt terug op Engels
function wp_pay_text(array $site, string $lang, string $name, array $fallback, array $built): array {
    $out = $built[$lang] ?? ($built['en'] ?? $fallback);
    foreach ($out as $i => $v) {
        $o = $site['translations']['wp.' . $name . '.' . $i][$lang] ?? null;
        if (is_string($o) && $o !== '') $out[$i] = $o;
    }
    return $out;
}
function wp_pay_customer_mail(array $site, ?array $def, array $row): void {
    $num = (string)($row['order']['number'] ?? '');
    $log = function (string $note) use ($num) { $now = gmdate('c'); wp_pay_update($num, function (array $r) use ($now, $note) { $r['order']['log'][] = ['at' => $now, 'status' => 'klantmail', 'note' => $note]; return $r; }); };
    $row = wp_box_open($row);
    $to = ''; foreach (($row['data'] ?? []) as $k => $v) if (is_string($v) && filter_var($v, FILTER_VALIDATE_EMAIL)) { $to = $v; break; }
    if ($to === '') { $log('geen e-mailadres (of versleuteld)'); return; }
    $lang = (string)($row['lang'] ?? ($site['site']['defaultLanguage'] ?? 'nl'));
    $T = wp_pay_text($site, $lang, 'mail', ['Bedankt voor je bestelling', 'We hebben je betaling ontvangen. Dit is je bevestiging:', 'Bestelling'], [
        'nl' => ['Bedankt voor je bestelling', 'We hebben je betaling ontvangen. Dit is je bevestiging:', 'Bestelling'],
        'en' => ['Thank you for your order', 'We have received your payment. This is your confirmation:', 'Order'],
        'de' => ['Danke für deine Bestellung', 'Wir haben deine Zahlung erhalten. Das ist deine Bestätigung:', 'Bestellung'],
        'fr' => ['Merci pour votre commande', 'Nous avons bien reçu votre paiement. Voici votre confirmation :', 'Commande'],
    ]);
    $c = is_array($def['confirm'] ?? null) ? $def['confirm'] : [];                       // optioneel per formulier: props.confirm {title, intro}
    $heading = !empty($c['title']) ? wp_txt($site, $c['title']) : $T[0];
    $intro = !empty($c['intro']) ? wp_txt($site, $c['intro']) : $T[1];
    $keep = []; foreach (($def['fields'] ?? []) as $f) if (in_array($f['type'] ?? '', ['pickup'], true) || ($f['name'] ?? '') === 'name') $keep[$f['name']] = $row['data'][$f['name']] ?? '';
    $row2 = ['id' => $row['id'] ?? '', 'createdAt' => $row['createdAt'] ?? gmdate('c'), 'page' => $T[2] . ' ' . $num, 'lang' => $lang, 'data' => array_filter($keep, fn($v) => $v !== ''), 'order' => $row['order']];
    $L = wp_mail_look($site, $def);
    [$html, $inl] = wp_mail_page($L, $heading, $intro, wp_row_html($site, $def, $row2, $L), []);
    $cfg = wp_config();
    $ok = wp_mail($to, $heading . ' · ' . $num . ' · ' . $L['title'], $heading . "\n\n" . $intro . "\n\n" . wp_row_text($site, $def, $row2), (string)($cfg['notifyEmail'] ?? '') ?: null, $html, $inl);
    $log($ok ? 'verstuurd' : 'mislukt');
}
function wp_form_def(array $site, string $formId): ?array {
    foreach (($site['pages'] ?? []) as $pg) {
        $stack = [$pg];
        while ($stack) {
            $n = array_pop($stack);
            if (!is_array($n)) continue;
            if (($n['props']['formId'] ?? null) === $formId) return $n['props'];
            foreach ($n as $v) if (is_array($v)) $stack[] = $v;
        }
    }
    return null;
}
// webhook: de provider meldt alleen een id; wij vragen de echte status zelf op. Altijd 200.
function wp_pay_webhook(): never {
    $id = (string)($_POST['id'] ?? '');
    http_response_code(200);
    if (!preg_match('/^[A-Za-z0-9_]{3,64}$/', $id)) exit('ok');
    $site = json_decode((string)@file_get_contents(SITE_FILE), true) ?: [];
    $num = null;
    wp_rewrite(function (array $r) use ($id, &$num) { if (($r['order']['payment']['id'] ?? null) === $id) $num = $r['order']['number']; return $r; });
    if ($num) wp_pay_sync($site, (string)$num);
    exit('ok');
}
// terugkeerpagina: klein, neutraal; status uit de opslag (na een verversing bij de provider)
function wp_pay_return(): never {
    $site = json_decode((string)@file_get_contents(SITE_FILE), true) ?: [];
    $num = (string)($_GET['o'] ?? ''); $k = (string)($_GET['k'] ?? '');
    $row = wp_pay_update($num, fn(array $r) => $r);
    $st = null;
    if ($row && isset($row['order']['token']) && hash_equals((string)$row['order']['token'], $k)) $st = wp_pay_sync($site, $num) ?? ($row['order']['status'] ?? null);
    $lang = (string)($_GET['l'] ?? ($site['site']['defaultLanguage'] ?? 'nl')); if (!preg_match('/^[a-z]{2,3}(-[A-Za-z]{2,4})?$/', $lang)) $lang = 'nl';
    $T = [
        'betaald' => wp_pay_text($site, $lang, 'ret.paid', ['Thank you, your payment has been received', 'We have received your order %s and will get started.'], [
            'nl' => ['Bedankt, je betaling is ontvangen', 'We hebben je bestelling %s ontvangen en gaan ermee aan de slag.'],
            'en' => ['Thank you, your payment has been received', 'We have received your order %s and will get started.'],
            'de' => ['Danke, deine Zahlung ist eingegangen', 'Wir haben deine Bestellung %s erhalten und legen los.'],
            'fr' => ['Merci, votre paiement a été reçu', 'Nous avons bien reçu votre commande %s et nous nous en occupons.']]),
        'open' => wp_pay_text($site, $lang, 'ret.open', ['We are still waiting for your payment', 'Order %s: you will hear from us once the payment arrives. Feel free to refresh this page.'], [
            'nl' => ['We wachten nog op je betaling', 'Bestelling %s: zodra de betaling binnen is, krijg je bericht. Ververs deze pagina gerust.'],
            'en' => ['We are still waiting for your payment', 'Order %s: you will hear from us once the payment arrives. Feel free to refresh this page.'],
            'de' => ['Wir warten noch auf deine Zahlung', 'Bestellung %s: Sobald die Zahlung eingegangen ist, melden wir uns. Du kannst diese Seite aktualisieren.'],
            'fr' => ['Nous attendons encore votre paiement', 'Commande %s : vous aurez de nos nouvelles dès réception du paiement. Vous pouvez actualiser cette page.']]),
        'mislukt' => wp_pay_text($site, $lang, 'ret.failed', ['The payment failed', 'Order %s has not been paid. You can try again.'], [
            'nl' => ['De betaling is niet gelukt', 'Bestelling %s is niet betaald. Je kunt het opnieuw proberen.'],
            'en' => ['The payment failed', 'Order %s has not been paid. You can try again.'],
            'de' => ['Die Zahlung ist fehlgeschlagen', 'Bestellung %s wurde nicht bezahlt. Du kannst es erneut versuchen.'],
            'fr' => ['Le paiement a échoué', 'La commande %s n’a pas été payée. Vous pouvez réessayer.']]),
        'nf' => wp_pay_text($site, $lang, 'ret.nf', ['Not found', 'This order was not found.'], [
            'nl' => ['Niet gevonden', 'Deze bestelling is niet gevonden.'], 'en' => ['Not found', 'This order was not found.'],
            'de' => ['Nicht gefunden', 'Diese Bestellung wurde nicht gefunden.'], 'fr' => ['Introuvable', 'Cette commande est introuvable.']]),
        'back' => wp_pay_text($site, $lang, 'ret.back', ['Back to the website', ''], [
            'nl' => ['Terug naar de website', ''], 'en' => ['Back to the website', ''], 'de' => ['Zurück zur Website', ''], 'fr' => ['Retour au site', '']]),
    ];
    $rtl = in_array(explode('-', $lang)[0], is_array($site['site']['rtl'] ?? null) ? $site['site']['rtl'] : ['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'yi', 'ckb', 'ug', 'dv'], true);
    $kind = $st === 'betaald' ? 'betaald' : (in_array($st, ['mislukt', 'geannuleerd', 'verlopen'], true) ? 'mislukt' : 'open');
    if ($st === null) { http_response_code(404); $t = $T['nf']; } else $t = $T[$kind];
    $title = htmlspecialchars($t[0]); $msg = htmlspecialchars(sprintf($t[1], $num));
    header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store');
    $home = htmlspecialchars(wp_site_url());
    echo '<!doctype html><html lang="' . htmlspecialchars($lang) . '" dir="' . ($rtl ? 'rtl' : 'ltr') . '"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $title . '</title>'
       . '<body style="font:16px/1.5 system-ui,sans-serif;max-width:32rem;margin:15vh auto;padding:0 1.2rem;text-align:center">'
       . '<h1 style="font-size:1.5rem">' . $title . '</h1><p>' . $msg . '</p><p><a href="' . $home . '">' . ($rtl ? '→ ' : '← ') . htmlspecialchars($T['back'][0]) . '</a></p></body></html>';
    exit;
}
