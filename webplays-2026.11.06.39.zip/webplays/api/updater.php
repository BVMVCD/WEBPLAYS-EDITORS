<?php
/*  WEBPLAYS · motor bijwerken (api/updater.php)
    Eén ondertekend bestand (latest.json, in git naast editors.json) zegt welke motorversie er is. De site controleert de handtekening
    met dezelfde openbare sleutel als de sleutellijst (de oersleutel van de eigenaar), haalt de zip op, controleert de sha256, de
    inhoud en de PHP-syntaxis, en wisselt dan de map `webplays` om. De vorige versie blijft staan (webplays.oud) en wordt teruggezet
    als iets misgaat. Er wordt NOOIT iets geïnstalleerd zonder geldige handtekening, en nooit een oudere of gelijke versie.

    Config (.secrets/webplays.php):
      'updateUrl'    => 'https://raw.githubusercontent.com/<gebruiker>/<repo>/main/latest.json'   (leeg = geen updates)
      'editorsPubKey'=> '<openbare sleutel van de oersleutel>'    (dezelfde als voor de sleutellijst)
      'updateTtl'    => 600            (seconden dat de uitkomst van "is er een nieuwe versie" bewaard blijft)
      'updateMethod' => 'auto' | 'swap' | 'copy'     auto probeert eerst wisselen, dan bestanden vervangen

    latest.json = {"payload":"<json-tekst>","sig":"<base64>"}; payload:
      {"format":"webplays-update/1","version":"2026.11.04.32","zip":"webplays-2026.11.04.32.zip","sha256":"<hex>","size":123,
       "issued":1762290000,"notes":"…","trust":["<base64 openbare sleutel>", …]}
      zip = bestandsnaam naast latest.json (of een volledig https-adres). trust = extra openbare sleutels die vanaf nu ook gelden
      (overdracht naar een nieuwe oersleutel: het bericht is met de OUDE sleutel ondertekend, zo hoef je geen server aan te raken).
*/

const WP_UPD_FORMAT = 'webplays-update/1';
const WP_UPD_MAX_ZIP = 20000000;      // 20 MB
const WP_UPD_MAX_UNPACKED = 60000000; // 60 MB

function wp_upd_motor_dir(): string { return dirname(__DIR__); }
function wp_upd_version(): string {
    $v = trim((string)@file_get_contents(wp_upd_motor_dir() . '/VERSION.txt'));
    return preg_match('/^[0-9A-Za-z._-]{1,30}$/', $v) ? $v : '0';
}
function wp_upd_state_file(): string { return STORAGE . '/update-state.json'; }
function wp_upd_state(): array { $s = json_decode((string)@file_get_contents(wp_upd_state_file()), true); return is_array($s) ? $s : []; }
function wp_upd_state_save(array $s): void { if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true); @file_put_contents(wp_upd_state_file(), json_encode($s, JSON_UNESCAPED_SLASHES), LOCK_EX); }
function wp_upd_log(string $m): void { if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true); @file_put_contents(STORAGE . '/update-log.txt', date('c') . '  ' . $m . "\n", FILE_APPEND | LOCK_EX); }

// alle sleutels die een update mogen tekenen: de oersleutel uit .secrets plus sleutels die een eerder ondertekend bericht heeft toegevoegd
function wp_upd_keys(array $cfg): array {
    $out = [];
    $main = base64_decode((string)($cfg['editorsPubKey'] ?? (defined('WP_EDITORS_PUBKEY') ? WP_EDITORS_PUBKEY : '')), true);
    if ($main !== false && strlen($main) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) $out[] = $main;
    $t = json_decode((string)@file_get_contents(STORAGE . '/trusted-keys.json'), true);
    foreach (is_array($t) ? $t : [] as $k) { $b = base64_decode((string)$k, true); if ($b !== false && strlen($b) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES && !in_array($b, $out, true)) $out[] = $b; }
    return $out;
}
function wp_upd_verify(string $raw, array $cfg): ?array {
    if (!function_exists('sodium_crypto_sign_verify_detached')) return null;
    $f = json_decode($raw, true);
    if (!is_array($f) || !is_string($f['payload'] ?? null) || !is_string($f['sig'] ?? null)) return null;
    $sig = base64_decode($f['sig'], true);
    if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) return null;
    foreach (wp_upd_keys($cfg) as $k) {
        if (sodium_crypto_sign_verify_detached($sig, $f['payload'], $k)) {
            $p = json_decode($f['payload'], true);
            return is_array($p) && ($p['format'] ?? '') === WP_UPD_FORMAT ? $p : null;
        }
    }
    return null;
}
// https (of http naar je eigen computer voor testen)
function wp_upd_url_ok(string $u): bool {
    return (bool)preg_match('#^https://#i', $u) || (bool)preg_match('#^http://(127\.0\.0\.1|localhost)(:\d+)?/#i', $u);
}
function wp_upd_get(string $url, int $timeout, int $max): ?string {
    if (!wp_upd_url_ok($url)) return null;
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
            CURLOPT_USERAGENT => 'webplays-update/1', CURLOPT_PROTOCOLS => CURLPROTO_HTTPS | CURLPROTO_HTTP, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_NOPROGRESS => false, CURLOPT_PROGRESSFUNCTION => function ($r, $dt, $d) use ($max) { return $d > $max ? 1 : 0; }]
            + (wp_ca_file(wp_config()) !== '' ? [CURLOPT_CAINFO => wp_ca_file(wp_config())] : []));
        $r = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); curl_close($c);
        return ($r !== false && $code === 200 && strlen((string)$r) <= $max) ? (string)$r : null;
    }
    $r = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => $timeout, 'user_agent' => 'webplays-update/1', 'follow_location' => 1, 'max_redirects' => 3]]), 0, $max + 1);
    return ($r !== false && strlen($r) <= $max) ? $r : null;
}

// de nieuwste, gecontroleerde aankondiging (of een foutmelding in gewoon Nederlands)
function wp_upd_fetch_latest(array $cfg, ?string &$err): ?array {
    $url = (string)($cfg['updateUrl'] ?? '');
    if (!wp_upd_keys($cfg)) { $err = 'Er staat geen openbare sleutel in .secrets (editorsPubKey).'; return null; }
    $raw = wp_upd_get($url, 8, 200000);
    if ($raw === null) { $err = 'De update-aankondiging is niet bereikbaar. Probeer het straks opnieuw.'; return null; }
    $p = wp_upd_verify($raw, $cfg);
    if (!$p) { $err = 'De handtekening van de aankondiging klopt niet. Er is niets geïnstalleerd.'; return null; }
    $iss = (int)($p['issued'] ?? 0); $st = wp_upd_state();
    if ($iss && $iss < (int)($st['issued'] ?? 0)) { $err = 'Dit is een oudere aankondiging dan de laatste die deze site zag. Genegeerd.'; return null; }
    // overdracht: sleutels die dit (door een vertrouwde sleutel ondertekende) bericht toevoegt, gelden vanaf nu ook
    if (!empty($p['trust']) && is_array($p['trust'])) {
        $have = json_decode((string)@file_get_contents(STORAGE . '/trusted-keys.json'), true); $have = is_array($have) ? $have : [];
        $add = false;
        foreach ($p['trust'] as $k) { $b = base64_decode((string)$k, true); if ($b !== false && strlen($b) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES && !in_array($k, $have, true)) { $have[] = (string)$k; $add = true; } }
        if ($add) { if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true); @file_put_contents(STORAGE . '/trusted-keys.json', json_encode(array_values($have)), LOCK_EX); wp_upd_log('nieuwe vertrouwde sleutel(s) toegevoegd'); }
    }
    if ($iss > (int)($st['issued'] ?? 0)) { $st['issued'] = $iss; wp_upd_state_save($st); }
    return $p;
}

// is er een nieuwere versie? (bewaart de uitkomst even, zodat de editor niet bij elke start GitHub hoeft te vragen)
function wp_upd_check(array $cfg, bool $force = false): array {
    $cur = wp_upd_version();
    if (empty($cfg['updateUrl'])) return ['ok' => true, 'configured' => false, 'current' => $cur];
    $cache = STORAGE . '/update-check.json'; $ttl = (int)($cfg['updateTtl'] ?? 600);
    $c = is_file($cache) ? json_decode((string)@file_get_contents($cache), true) : null;
    if (!$force && is_array($c) && time() - (int)($c['at'] ?? 0) < $ttl && ($c['current'] ?? '') === $cur && is_array($c['out'] ?? null)) return $c['out'];
    $err = null; $p = wp_upd_fetch_latest($cfg, $err);
    if (!$p) return ['ok' => false, 'configured' => true, 'current' => $cur, 'error' => $err];
    $v = (string)($p['version'] ?? '');
    $okv = (bool)preg_match('/^[0-9][0-9A-Za-z._-]{0,29}$/', $v);
    $out = ['ok' => true, 'configured' => true, 'current' => $cur, 'latest' => $okv ? $v : $cur, 'newer' => $okv && version_compare($v, $cur, '>'), 'notes' => substr((string)($p['notes'] ?? ''), 0, 300)];
    if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
    @file_put_contents($cache, json_encode(['at' => time(), 'current' => $cur, 'out' => $out]), LOCK_EX);
    return $out;
}

function wp_upd_rrmdir(string $d): void {
    if (!is_dir($d) || is_link($d)) { @unlink($d); return; }
    foreach (scandir($d) ?: [] as $f) { if ($f === '.' || $f === '..') continue; $p = $d . '/' . $f; if (is_dir($p) && !is_link($p)) wp_upd_rrmdir($p); else @unlink($p); }
    @rmdir($d);
}
function wp_upd_rcopy(string $from, string $to): bool {
    if (!is_dir($to) && !@mkdir($to, 0775, true)) return false;
    foreach (scandir($from) ?: [] as $f) {
        if ($f === '.' || $f === '..') continue;
        $a = $from . '/' . $f; $b = $to . '/' . $f;
        if (is_dir($a) && !is_link($a)) { if (!wp_upd_rcopy($a, $b)) return false; }
        else { $tmp = $b . '.wp-tmp'; if (!@copy($a, $tmp) || !@rename($tmp, $b)) { @unlink($tmp); return false; } }
    }
    return true;
}
function wp_upd_files(string $dir, string $base = ''): array {
    $out = [];
    foreach (scandir($dir . ($base === '' ? '' : '/' . $base)) ?: [] as $f) {
        if ($f === '.' || $f === '..') continue;
        $rel = $base === '' ? $f : $base . '/' . $f;
        if (is_dir($dir . '/' . $rel)) $out = array_merge($out, wp_upd_files($dir, $rel)); else $out[] = $rel;
    }
    return $out;
}
// PHP-bestanden op syntax controleren zonder ze uit te voeren
function wp_upd_syntax(string $dir): ?string {
    foreach (wp_upd_files($dir) as $rel) {
        if (!preg_match('/\.php$/i', $rel)) continue;
        $src = (string)@file_get_contents($dir . '/' . $rel);
        try { token_get_all($src, TOKEN_PARSE); } catch (\Throwable $e) { return $rel . ': ' . $e->getMessage(); }
    }
    return null;
}
function wp_upd_complete(string $dir, string $ver): bool {
    foreach (['VERSION.txt', 'speler.js', 'speler.css', 'editor.js', 'api/core.php', 'api/updater.php'] as $f) if (!is_file($dir . '/' . $f)) return false;
    return trim((string)@file_get_contents($dir . '/VERSION.txt')) === $ver;
}

// installeren. Altijd een antwoord in gewoon Nederlands; bij een fout is er niets veranderd (of is het teruggezet).
function wp_upd_install(array $cfg): array {
    $fail = function (string $m) { wp_upd_log('MISLUKT: ' . $m); return ['ok' => false, 'error' => $m]; };
    if (!class_exists('ZipArchive')) return $fail('Deze server kan geen zip uitpakken (ZipArchive ontbreekt).');
    if (!is_dir(STORAGE) && !@mkdir(STORAGE, 0775, true)) return $fail('De opslagmap is niet beschrijfbaar.');
    $lock = @fopen(STORAGE . '/update.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) return ['ok' => false, 'error' => 'Er wordt al bijgewerkt. Wacht even en probeer het opnieuw.'];
    @set_time_limit(120);
    $dir = wp_upd_motor_dir(); $cur = wp_upd_version(); $parent = dirname($dir); $name = basename($dir);
    $err = null; $p = wp_upd_fetch_latest($cfg, $err);
    if (!$p) return $fail((string)$err);
    $ver = (string)($p['version'] ?? '');
    if (!preg_match('/^[0-9][0-9A-Za-z._-]{0,29}$/', $ver)) return $fail('De versie in de aankondiging is ongeldig.');
    if (!version_compare($ver, $cur, '>')) return ['ok' => false, 'error' => 'Je hebt al de nieuwste versie (' . $cur . ').'];
    $sha = strtolower((string)($p['sha256'] ?? ''));
    if (!preg_match('/^[0-9a-f]{64}$/', $sha)) return $fail('De aankondiging bevat geen geldige controlesom.');
    $zipRef = (string)($p['zip'] ?? '');
    $zipUrl = wp_upd_url_ok($zipRef) ? $zipRef : (preg_match('#^[A-Za-z0-9._-]+\.zip$#', $zipRef) ? preg_replace('#[^/]*$#', '', (string)$cfg['updateUrl']) . $zipRef : '');
    if ($zipUrl === '') return $fail('Het zip-adres in de aankondiging is ongeldig.');
    $bin = wp_upd_get($zipUrl, 60, WP_UPD_MAX_ZIP);
    if ($bin === null) return $fail('De zip kon niet worden opgehaald (' . basename($zipUrl) . '). Is hij al online? GitHub heeft soms even nodig, probeer het over een paar minuten.');
    if (hash('sha256', $bin) !== $sha) return $fail('De zip klopt niet met de ondertekende controlesom (mogelijk nog een oude kopie bij GitHub). Er is niets geïnstalleerd; probeer het over enkele minuten opnieuw.');
    $tmpZip = STORAGE . '/upd-' . bin2hex(random_bytes(4)) . '.zip'; @file_put_contents($tmpZip, $bin);
    $stage = null; $cleanup = function () use (&$stage, $tmpZip) { @unlink($tmpZip); if ($stage) wp_upd_rrmdir($stage); };

    // 1. de zip controleren voordat er iets wordt uitgepakt
    $z = new ZipArchive();
    if ($z->open($tmpZip) !== true) { $cleanup(); return $fail('De zip is niet te openen.'); }
    $total = 0;
    if ($z->numFiles < 5 || $z->numFiles > 3000) { $z->close(); $cleanup(); return $fail('De zip heeft een onverwachte inhoud.'); }
    for ($i = 0; $i < $z->numFiles; $i++) {
        $n = (string)$z->getNameIndex($i); $st = $z->statIndex($i); $total += (int)($st['size'] ?? 0);
        if (strncmp($n, 'webplays/', 9) !== 0 || strpos($n, '..') !== false || strpos($n, '\\') !== false || $n[0] === '/' || preg_match('#(^|/)(site\.json|\.secrets|media|storage)(/|$)#', $n)) { $z->close(); $cleanup(); return $fail('De zip bevat een niet-toegestaan pad (' . $n . ').'); }
    }
    if ($total > WP_UPD_MAX_UNPACKED) { $z->close(); $cleanup(); return $fail('De zip is uitgepakt te groot.'); }

    // 2. uitpakken naast de motor (of in de opslagmap als de bovenliggende map niet beschrijfbaar is)
    $canParent = is_writable($parent);
    $stage = ($canParent ? $parent : STORAGE) . '/.wp-upd-' . bin2hex(random_bytes(4));
    if (!@mkdir($stage, 0775, true)) { $z->close(); $cleanup(); return $fail('Kan geen tijdelijke map maken.'); }
    $ok = $z->extractTo($stage); $z->close();
    $new = $stage . '/webplays';
    if (!$ok || !is_dir($new)) { $cleanup(); return $fail('Uitpakken is mislukt.'); }
    if (!wp_upd_complete($new, $ver)) { $cleanup(); return $fail('De zip is niet compleet of het versienummer klopt niet.'); }
    if ($e = wp_upd_syntax($new)) { $cleanup(); return $fail('Een PHP-bestand in de update is stuk (' . $e . '). Er is niets veranderd.'); }

    // 3. wisselen: eerst de nette manier (map vervangen), anders bestanden vervangen
    $method = (string)($cfg['updateMethod'] ?? 'auto'); $used = ''; $old = $parent . '/' . $name . '.oud';
    if (($method === 'auto' || $method === 'swap') && $canParent) {
        if (is_dir($old)) wp_upd_rrmdir($old);
        if (@rename($dir, $old)) {
            if (@rename($new, $dir)) { $used = 'swap'; }
            else { @rename($old, $dir); }   // terug: de oude map staat weer op zijn plek
        }
    }
    if ($used === '' && ($method === 'auto' || $method === 'copy')) {
        $bk = $canParent ? $old : STORAGE . '/webplays-oud';
        if (is_dir($bk)) wp_upd_rrmdir($bk);
        if (!wp_upd_rcopy($dir, $bk)) { $cleanup(); return $fail('Kan geen reservekopie van de huidige versie maken. Er is niets veranderd.'); }
        if (wp_upd_rcopy($new, $dir)) { $used = 'copy'; }
        else { wp_upd_rcopy($bk, $dir); $cleanup(); return $fail('Bestanden vervangen is mislukt; de vorige versie is teruggezet.'); }
    }
    if ($used === '') { $cleanup(); return $fail('Deze server laat het wisselen niet toe (geen schrijfrechten op de motormap).'); }

    // 4. controle na het wisselen; zo niet, direct terug
    clearstatcache(true);
    if (!wp_upd_complete($dir, $ver)) {
        $bk = $canParent ? $old : STORAGE . '/webplays-oud';
        if ($used === 'swap') { @rename($dir, $dir . '.mislukt'); @rename($old, $dir); wp_upd_rrmdir($dir . '.mislukt'); } else { wp_upd_rcopy($bk, $dir); }
        $cleanup(); return $fail('De nieuwe versie bleek na het installeren niet in orde; de vorige versie is teruggezet.');
    }
    if (function_exists('opcache_reset')) @opcache_reset();
    $st = wp_upd_state(); $st += ['issued' => 0]; $st['version'] = $ver; $st['from'] = $cur; $st['at'] = time(); $st['method'] = $used; wp_upd_state_save($st);
    @unlink(STORAGE . '/update-check.json');
    wp_upd_log("bijgewerkt $cur -> $ver ($used)");
    $cleanup();
    return ['ok' => true, 'from' => $cur, 'to' => $ver, 'method' => $used];
}
