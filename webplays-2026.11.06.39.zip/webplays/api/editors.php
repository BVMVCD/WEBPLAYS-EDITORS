<?php
/*  WEBPLAYS · centrale editor-sleutels (api/editors.php)
    Eén gesigneerd bestand (editors.json, in git) zegt welke editor-sleutels op welke site mogen. Het bestand bevat alleen HASHES
    (nooit de sleutels zelf) en een handtekening van de eigenaar (Ed25519); de motor controleert die met de openbare sleutel hieronder.
    Een site haalt het bestand zelf op (editorsUrl in .secrets) en bewaart het even (storage/editors-cache.json).
    Intrekken = sleutel uit editors.src.json halen, tools/wp-editors.php sign, committen. Zie tools/wp-editors.php.

    Config (.secrets/webplays.php of per site):
      'editorsUrl'       => 'https://raw.githubusercontent.com/…/editors.json'   (of 'editorsFile' => '/pad/naar/editors.json')
      'editorsMode'      => 'add' | 'strict'     add (standaard): centrale sleutels én de lokale editorKey werken; strict: alleen centraal
      'editorsPubKey'    => '<base64 openbare sleutel>'   (anders de constante hieronder)
      'siteId'           => 'make-peas'          (anders meta.name uit site.json; bepaalt ook de naam van .secrets/<siteId>.php)
      'caFile'           => '…/cacert.pem'       (anders .secrets/cacert.pem als dat bestaat)
      'editorsTtl' => 900 · 'editorsGraceDays' => 7 · 'sessionHours' => 12
*/
const WP_EDITORS_PUBKEY = '';   // openbare sleutel van de eigenaar (base64): uitvoer van `php tools/wp-editors.php keygen`

function wp_ed_motor_version(): string {
    $v = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION.txt'));
    return preg_match('/^[0-9A-Za-z._-]{1,30}$/', $v) ? $v : '0';
}
function wp_ed_site_id(array $cfg): string {
    if (!empty($cfg['siteId']) && is_string($cfg['siteId'])) return $cfg['siteId'];
    $j = json_decode((string)@file_get_contents(SITE_FILE), true);
    return is_array($j) ? (string)($j['meta']['name'] ?? '') : '';
}
function wp_ed_central(array $cfg): bool { return !empty($cfg['editorsUrl']) || !empty($cfg['editorsFile']); }
function wp_ed_strict(array $cfg): bool { return wp_ed_central($cfg) && ($cfg['editorsMode'] ?? 'add') === 'strict'; }

// controleert handtekening en geeft de inhoud terug (of null)
function wp_ed_verify(string $raw, array $cfg): ?array {
    if (!function_exists('sodium_crypto_sign_verify_detached')) return null;
    $pub = base64_decode((string)($cfg['editorsPubKey'] ?? WP_EDITORS_PUBKEY), true);
    if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return null;
    $f = json_decode($raw, true);
    if (!is_array($f) || !is_string($f['payload'] ?? null) || !is_string($f['sig'] ?? null)) return null;
    $sig = base64_decode($f['sig'], true);
    if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) return null;
    if (!sodium_crypto_sign_verify_detached($sig, $f['payload'], $pub)) return null;
    $p = json_decode($f['payload'], true);
    return is_array($p) && ($p['format'] ?? '') === 'webplays-editors/1' ? $p : null;
}
// eigen CA-bestand (lokaal op Windows/WAMP zonder CA in php.ini): 'caFile' in .secrets, of .secrets/cacert.pem
function wp_ca_file(array $cfg = []): string {
    foreach ([(string)($cfg['caFile'] ?? ''), WP_SECRETS . '/cacert.pem'] as $ca) if ($ca !== '' && is_file($ca)) return $ca;
    return '';
}
function wp_ed_fetch(array $cfg): ?string {
    if (!empty($cfg['editorsFile'])) { $r = @file_get_contents((string)$cfg['editorsFile']); return $r === false ? null : $r; }
    $u = (string)($cfg['editorsUrl'] ?? ''); if (!preg_match('#^https://#i', $u)) return null;
    if (function_exists('curl_init')) {
        $c = curl_init($u); curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_USERAGENT => 'webplays-editors/1', CURLOPT_MAXFILESIZE => 500000] + (wp_ca_file($cfg) !== '' ? [CURLOPT_CAINFO => wp_ca_file($cfg)] : []));
        $r = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); curl_close($c);
        return ($r !== false && $code === 200) ? (string)$r : null;
    }
    $r = @file_get_contents($u, false, stream_context_create(['http' => ['timeout' => 5, 'user_agent' => 'webplays-editors/1']]));
    return $r === false ? null : $r;
}
// de actuele, gecontroleerde lijst: eerst de cache (ttl), dan ophalen, anders de laatste goede kopie binnen de coulance
function wp_ed_load(array $cfg): ?array {
    static $mem = false; if ($mem !== false) return $mem;
    $cache = STORAGE . '/editors-cache.json'; $ttl = (int)($cfg['editorsTtl'] ?? 900); $grace = (int)($cfg['editorsGraceDays'] ?? 7) * 86400;
    $c = is_file($cache) ? json_decode((string)@file_get_contents($cache), true) : null;
    if (is_array($c) && is_string($c['raw'] ?? null) && time() - (int)($c['at'] ?? 0) < $ttl && ($p = wp_ed_verify($c['raw'], $cfg))) return $mem = $p;
    $raw = wp_ed_fetch($cfg);
    if ($raw !== null && ($p = wp_ed_verify($raw, $cfg))) {
        if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
        @file_put_contents($cache, json_encode(['at' => time(), 'raw' => $raw]), LOCK_EX);
        return $mem = $p;
    }
    // ophalen of controleren mislukt: de oude kopie mag nog even (netwerk, GitHub of DNS uit de lucht)
    if (is_array($c) && is_string($c['raw'] ?? null) && time() - (int)($c['at'] ?? 0) < $grace && ($p = wp_ed_verify($c['raw'], $cfg))) return $mem = $p;
    return $mem = null;
}
// de sleutelregels voor deze site (geldige, niet verlopen, niet uitgeschakeld) + reden als er niets mag
function wp_ed_entries(array $cfg, string &$why): array {
    $p = wp_ed_load($cfg);
    if ($p === null) { $why = 'list'; return []; }
    if (!empty($p['minMotor']) && version_compare(wp_ed_motor_version(), (string)$p['minMotor'], '<')) { $why = 'motor'; return []; }
    $site = $p['sites'][wp_ed_site_id($cfg)] ?? null;
    if (!is_array($site)) { $why = 'site'; return []; }
    if (!empty($site['disabled'])) { $why = 'disabled'; return []; }
    $out = []; $now = date('Y-m-d');
    foreach ((array)($site['keys'] ?? []) as $k) {
        if (!is_array($k) || !is_string($k['hash'] ?? null) || !preg_match('/^[0-9a-f]{64}$/', $k['hash'])) continue;
        if (!empty($k['exp']) && (string)$k['exp'] < $now) continue;
        $out[] = ['id' => substr($k['hash'], 0, 16), 'name' => (string)($k['name'] ?? ''), 'hash' => $k['hash']];
    }
    return $out;
}
function wp_ed_hash(string $site, string $key): string { return hash('sha256', $site . ':' . $key); }

// ---- sessietokens: de lange sleutel hoeft niet in de browser te blijven staan ----
function wp_ed_secret(): string {
    $f = STORAGE . '/session.key';
    if (is_file($f)) { $s = (string)@file_get_contents($f); if (strlen($s) >= 32) return $s; }
    if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
    $s = bin2hex(random_bytes(32)); @file_put_contents($f, $s, LOCK_EX); @chmod($f, 0600);
    return $s;
}
function wp_ed_b64(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function wp_ed_unb64(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/'), false); }
function wp_ed_token(array $cfg, string $id, string $name): array {
    $exp = time() + max(1, (int)($cfg['sessionHours'] ?? 12)) * 3600;
    $body = wp_ed_b64(json_encode(['i' => $id, 'n' => $name, 'e' => $exp, 's' => wp_ed_site_id($cfg)]));
    return ['token' => 'wp1.' . $body . '.' . hash_hmac('sha256', $body, wp_ed_secret()), 'exp' => $exp];
}
// geldig token? geeft ['id','name'] terug. Het sleutel-id moet nog bestaan (ingetrokken = sessie weg).
function wp_ed_token_check(array $cfg, string $t): ?array {
    $p = explode('.', $t); if (count($p) !== 3 || $p[0] !== 'wp1') return null;
    if (!hash_equals(hash_hmac('sha256', $p[1], wp_ed_secret()), $p[2])) return null;
    $d = json_decode(wp_ed_unb64($p[1]), true);
    if (!is_array($d) || (int)($d['e'] ?? 0) < time() || ($d['s'] ?? null) !== wp_ed_site_id($cfg)) return null;
    $id = (string)($d['i'] ?? '');
    $ok = false;
    if (wp_ed_central($cfg)) { $why = ''; foreach (wp_ed_entries($cfg, $why) as $e) if ($e['id'] === $id) $ok = true; }
    if (!$ok && !wp_ed_strict($cfg)) foreach (wp_editor_keys($cfg) as $k) if (substr(hash('sha256', 'local:' . $k), 0, 16) === $id) $ok = true;
    return $ok ? ['id' => $id, 'name' => (string)($d['n'] ?? '')] : null;
}
// een getypte sleutel: centraal (hash) of lokaal (editorKey, alleen als niet strict). Geeft ['id','name'] of null.
function wp_ed_key_match(array $cfg, string $sent): ?array {
    if ($sent === '') return null;
    $found = null;
    if (wp_ed_central($cfg)) {
        $why = ''; $h = wp_ed_hash(wp_ed_site_id($cfg), $sent);
        foreach (wp_ed_entries($cfg, $why) as $e) if (hash_equals($e['hash'], $h)) $found = ['id' => $e['id'], 'name' => $e['name']];
    }
    if (!wp_ed_strict($cfg)) foreach (wp_editor_keys($cfg) as $k) if (hash_equals($k, $sent)) $found = $found ?: ['id' => substr(hash('sha256', 'local:' . $k), 0, 16), 'name' => ''];
    return $found;
}
function wp_ed_who(array $cfg, string $sent): ?array {
    if (strncmp($sent, 'wp1.', 4) === 0) return wp_ed_token_check($cfg, $sent);
    return wp_ed_key_match($cfg, $sent);
}

// ---- gokken remmen: te veel foute pogingen vanaf één adres = even wachten ----
function wp_ed_ratefile(): string { return STORAGE . '/auth-fail-' . substr(hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '')), 0, 12) . '.json'; }
function wp_ed_blocked(): bool {
    $d = json_decode((string)@file_get_contents(wp_ed_ratefile()), true);
    return is_array($d) && (int)($d['n'] ?? 0) >= 8 && time() - (int)($d['t'] ?? 0) < 600;
}
function wp_ed_fail(): void {
    $f = wp_ed_ratefile(); $d = json_decode((string)@file_get_contents($f), true);
    if (!is_array($d) || time() - (int)($d['t'] ?? 0) >= 600) $d = ['n' => 0];
    $d['n'] = (int)$d['n'] + 1; $d['t'] = time();
    if (!is_dir(STORAGE)) @mkdir(STORAGE, 0775, true);
    @file_put_contents($f, json_encode($d), LOCK_EX);
}
function wp_ed_ok(): void { @unlink(wp_ed_ratefile()); }
