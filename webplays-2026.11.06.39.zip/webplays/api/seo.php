<?php
// SEO-hulpfuncties van de motor: sitemap.xml, robots.txt en de voordeur (HTML-kop per pagina). Wordt geladen door core.php en front.php.

// ---------- sitemap.xml en robots.txt: komen uit site.json (pagina's, talen); gemaakt bij elke opslag ----------
// Adres: site.url als dat ingevuld is, anders het adres waarop de editor draait. Lokaal (localhost, IP, .local/.test) geen sitemap: die zou verkeerde adressen bevatten.
function wp_sitemap_base(array $site): ?string {
    $u = trim((string)($site['site']['url'] ?? ''));
    if ($u !== '') return rtrim($u, '/');
    $h = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($h === '' || $h === 'localhost' || preg_match('/^[\d.:\[\]]+$/', $h) || preg_match('/\.(local|test|localhost|invalid)$/', $h)) return null;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    return ($https ? 'https://' : 'http://') . (string)$_SERVER['HTTP_HOST'];
}
function wp_sitemap_write(array $site): string {
    $base = wp_sitemap_base($site);
    if ($base === null) return 'geen-adres';
    $langs = array_values(array_filter((array)($site['site']['languages'] ?? ['nl']), 'is_string')) ?: ['nl'];
    $def = (string)($site['site']['defaultLanguage'] ?? $langs[0]);
    $home = (string)($site['site']['homePage'] ?? '');
    $lastmod = substr((string)($site['meta']['updatedAt'] ?? gmdate('c')), 0, 10);
    $url = function (array $pg, string $lang) use ($base, $def, $home): string {
        $id = (string)($pg['id'] ?? '');
        $p = ($id === $home) ? '/' : (string)($pg['path'] ?? ('/' . $id));
        $pre = $lang !== $def ? '/' . $lang : '';
        return $base . $pre . (($p === '/' && $pre !== '') ? '' : $p);
    };
    $esc = fn($x) => htmlspecialchars($x, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    $out = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
    $n = 0;
    foreach ((array)($site['pages'] ?? []) as $pg) {
        if (!is_array($pg) || empty($pg['id']) || !empty($pg['noindex']) || $pg['id'] === '404') continue;
        $path = (string)($pg['path'] ?? '');
        if (strpbrk($path, ':{*') !== false) continue;                    // sjablonen met een variabel adres
        foreach ($langs as $l) {
            $out .= "  <url><loc>" . $esc($url($pg, $l)) . "</loc><lastmod>$lastmod</lastmod>";
            if (count($langs) > 1) {
                foreach ($langs as $l2) $out .= '<xhtml:link rel="alternate" hreflang="' . $esc($l2) . '" href="' . $esc($url($pg, $l2)) . '"/>';
                $out .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . $esc($url($pg, $def)) . '"/>';
            }
            $out .= "</url>\n"; $n++;
        }
    }
    $out .= "</urlset>\n";
    if (file_put_contents(WP_SITE_DIR . '/sitemap.xml', $out, LOCK_EX) === false) return 'schrijffout';
    // robots.txt alleen maken (of bijwerken) als hij nog niet bestaat of door WEBPLAYS is gemaakt: een eigen robots.txt blijft ongemoeid
    $rf = WP_SITE_DIR . '/robots.txt'; $cur = is_file($rf) ? (string)file_get_contents($rf) : null;
    if ($cur === null || str_contains($cur, '# webplays')) @file_put_contents($rf, "# webplays\nUser-agent: *\nAllow: /\n\nSitemap: $base/sitemap.xml\n", LOCK_EX);
    return 'ok:' . $n;
}


// ---------- de voordeur: elk paginaadres gaat via index.php van de site (zie .htaccess) ----------
// Zet per pagina in de HTML wat robots nodig hebben: titel, omschrijving, canonical, hreflang, Open Graph en Twitter-kaart, noindex.
// De speler neemt daarna over zoals altijd. Staat er iets mis (geen site.json, geen index.html), dan komt de gewone index.html.
function wp_front_text($v, array $site, string $lang): string {
    $tr = $site['translations'] ?? [];
    if (is_string($v) && isset($tr[$v])) $v = $tr[$v];
    if (is_array($v) && array_is_list($v)) { $o = ''; foreach ($v as $r) $o .= is_array($r) ? (string)($r['t'] ?? '') : (string)$r; return $o; }
    if (is_array($v)) { $d = (string)($site['site']['defaultLanguage'] ?? 'nl'); $v = $v[$lang] ?? $v[$d] ?? ''; if (is_array($v)) return wp_front_text($v, $site, $lang); }
    return is_string($v) ? $v : '';
}
function wp_front_asset(?string $p, array $site, ?string $base): ?string {
    $p = trim((string)$p); if ($p === '') return null;
    if (preg_match('#^https?://#i', $p)) return $p;
    if (str_starts_with($p, 'cdn:')) return !empty($site['site']['cdn']) ? rtrim((string)$site['site']['cdn'], '/') . '/' . ltrim(substr($p, 4), '/') : null;
    return $base === null ? null : $base . '/' . ltrim($p, '/');
}

// ---------- inhoud van de pagina als gewone HTML (voor robots, delen en lezers zonder JavaScript) ----------
// Kopjes: props.tag (h1-h6 of p) wint; anders de grootste lettertypen op de pagina (>= 26 px) in volgorde h1, h2, h3. De speler vervangt dit blok zodra hij laadt.
function wp_front_body(array $site, array $page, string $lang, string $def, string $dir): string {
    $e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $home = (string)($site['site']['homePage'] ?? '');
    $pageUrl = function (string $id, ?string $q = null) use ($site, $lang, $def, $dir, $home): ?string {
        foreach ($site['pages'] as $pg) if (is_array($pg) && ($pg['id'] ?? '') === $id) {
            $p = ($id === $home) ? '/' : (string)($pg['path'] ?? ('/' . $id)); $pre = $lang !== $def ? '/' . $lang : '';
            $u = $dir . $pre . (($p === '/' && $pre !== '') ? '' : $p); if ($u === '') $u = '/';
            return $u . ($q ? '?' . ltrim($q, '?') : '');
        }
        return null;
    };
    $tr = function ($v) use ($site, $lang) { return wp_front_text($v, $site, $lang); };
    $href = function ($a) use ($pageUrl, $tr, $dir, $page) {
        if (!is_array($a)) return null;
        $t = (string)($a['type'] ?? ''); $tg = $a['target'] ?? '';
        if ($t === 'page' && is_string($tg)) return $pageUrl($tg, isset($a['query']) ? (string)$a['query'] : null);
        if ($t === 'mail') { $m = trim($tr($tg)); return $m !== '' ? 'mailto:' . $m : null; }
        if ($t === 'url') { $u = trim($tr($tg)); if ($u === '') return null; return (preg_match('#^([a-z][a-z0-9+.-]*:|//)#i', $u) || $u[0] === '/') ? $u : $dir . '/' . $u; }
        if ($t === 'scroll' && is_string($tg)) { $pg = isset($a['page']) ? $pageUrl((string)$a['page']) : null; return ($pg ?? '') . '#' . $tg; }
        return null;
    };
    $asset = function (?string $p) use ($dir, $site) {
        $p = trim((string)$p); if ($p === '') return null;
        if (preg_match('#^https?://#i', $p)) return $p;
        if (str_starts_with($p, 'cdn:')) return !empty($site['site']['cdn']) ? rtrim((string)$site['site']['cdn'], '/') . '/' . ltrim(substr($p, 4), '/') : null;
        return $dir . '/' . ltrim($p, '/');
    };
    $styles = (array)($site['styles'] ?? []);
    $sizeOf = function (array $o) use ($styles): float {
        $p = (array)($o['props'] ?? []); if (isset($p['size'])) return (float)$p['size'];
        $s = $styles[(string)($p['style'] ?? '')]['props']['size'] ?? 16; return (float)$s;
    };
    $runs = function ($v) use ($site, $lang, $e) {
        $tr = $site['translations'] ?? [];
        if (is_string($v) && isset($tr[$v])) $v = $tr[$v];
        if (is_array($v) && !array_is_list($v)) { $d = (string)($site['site']['defaultLanguage'] ?? 'nl'); $v = $v[$lang] ?? $v[$d] ?? ''; }
        if (is_array($v) && array_is_list($v)) {
            $o = ''; foreach ($v as $r) { if (!is_array($r)) { $o .= nl2br($e((string)$r), false); continue; }
                $t = nl2br($e((string)($r['t'] ?? '')), false); if (!empty($r['b'])) $t = '<strong>' . $t . '</strong>'; if (!empty($r['i'])) $t = '<em>' . $t . '</em>'; $o .= $t; }
            return $o;
        }
        return is_string($v) ? nl2br($e($v), false) : '';
    };
    // volgorde: van boven naar beneden; masterinhoud (kop) en pagina samen, de footer van de master achteraan
    $sortY = function (array $a): array { usort($a, fn($x, $y) => [(int)($x['layout']['y'] ?? 0), (int)($x['layout']['x'] ?? 0)] <=> [(int)($y['layout']['y'] ?? 0), (int)($y['layout']['x'] ?? 0)]); return $a; };
    $master = (array)(($site['masters'][$page['master'] ?? ''] ?? [])['objects'] ?? []);
    $mBody = array_values(array_filter($master, fn($o) => is_array($o) && empty($o['base']['footer'])));
    $mFoot = array_values(array_filter($master, fn($o) => is_array($o) && !empty($o['base']['footer'])));
    $body = $sortY(array_merge($mBody, array_values(array_filter((array)($page['objects'] ?? []), 'is_array'))));
    $foot = $sortY($mFoot);

    // kopniveaus: de grootste lettertypen (alleen losse tekst, niet in een knop)
    $explicitH1 = false; $sizes = [];
    $scan = function (array $list, bool $inLink) use (&$scan, &$explicitH1, &$sizes, $sizeOf) {
        foreach ($list as $o) { if (!is_array($o)) continue;
            if (($o['type'] ?? '') === 'text') { $tg = $o['props']['tag'] ?? ''; if ($tg === 'h1') $explicitH1 = true; if (!$inLink && $tg === '' ) { $s = $sizeOf($o); if ($s >= 26) $sizes[(string)$s] = $s; } }
            if (!empty($o['children'])) $scan((array)$o['children'], $inLink || !empty($o['base']['action']));
        }
    };
    $scan($body, false); rsort($sizes);
    $firstH1 = !$explicitH1;
    $levelOf = function (array $o) use (&$sizes, &$firstH1, $sizeOf, $explicitH1) {
        $tg = (string)($o['props']['tag'] ?? '');
        if (preg_match('/^h[1-6]$/', $tg)) return $tg; if ($tg === 'p') return 'p';
        $s = $sizeOf($o); $i = array_search($s, $sizes, true); if ($i === false) return 'p';
        $l = $i + ($explicitH1 ? 2 : 1); if ($l > 3) return 'p';      // automatisch alleen h1-h3; meer niveaus kies je zelf met props.tag
        if ($l === 1) { if ($firstH1) { $firstH1 = false; return 'h1'; } return 'h2'; }
        return 'h' . $l;
    };
    $render = function (array $list, bool $inLink) use (&$render, $runs, $levelOf, $href, $asset, $tr, $e, $site, $lang, $pageUrl, $page): string {
        $out = '';
        foreach ($list as $o) { if (!is_array($o)) continue;
            $t = (string)($o['type'] ?? '');
            if ($t === 'text') {
                $h = trim($runs($o['props']['text'] ?? '')); if ($h === '') continue;
                $lv = $inLink ? 'span' : $levelOf($o); $out .= "<$lv>$h</$lv>\n";
            } elseif ($t === 'image') {
                $src = $asset($o['props']['src'] ?? null); $alt = trim($tr($o['props']['alt'] ?? ''));
                if (!$src || ($alt === '' && !$inLink)) continue;      // zonder alt-tekst is het sieraad: laat het weg
                $img = '<img src="' . $e($src) . '" alt="' . $e($alt) . '">';
                $a = $href($o['base']['action'] ?? null); $out .= ($a && !$inLink ? '<a href="' . $e($a) . '">' . $img . '</a>' : $img) . "\n";
            } elseif ($t === 'group') {
                $a = $inLink ? null : $href($o['base']['action'] ?? null);
                $in = $render((array)($o['children'] ?? []), $inLink || $a !== null);
                if (trim($in) === '') continue;
                $out .= $a ? '<a href="' . $e($a) . '">' . $in . "</a>\n" : $in;
            } elseif ($t === 'icon') {      // sociaal icoon of ander icoon met een link: de link met een tekst erin
                $a = $inLink ? null : $href($o['base']['action'] ?? null); if (!$a) continue;
                $nm = trim($tr($o['props']['alt'] ?? '')); $ic = (string)($o['props']['icon'] ?? '');
                if ($nm === '' && str_starts_with($ic, 'social:')) $nm = ['linkedin' => 'LinkedIn', 'instagram' => 'Instagram', 'facebook' => 'Facebook', 'x' => 'X', 'youtube' => 'YouTube', 'tiktok' => 'TikTok', 'whatsapp' => 'WhatsApp', 'github' => 'GitHub', 'pinterest' => 'Pinterest', 'bluesky' => 'Bluesky', 'threads' => 'Threads', 'mastodon' => 'Mastodon', 'mail' => 'E-mail'][substr($ic, 7)] ?? '';
                if ($nm === '') $nm = trim($tr($site['icons']['items'][$ic]['label'] ?? ''));
                if ($nm !== '') $out .= '<a href="' . $e($a) . '"><span>' . $e($nm) . "</span></a>\n";
            } elseif ($t === 'nav') {
                $li = '';
                foreach ((array)($o['props']['items'] ?? []) as $it) { if (!is_array($it)) continue; $a = $href($it['action'] ?? null); $lb = trim($tr($it['label'] ?? '')); if ($a && $lb !== '') $li .= '<li><a href="' . $e($a) . '">' . $e($lb) . "</a></li>\n"; }
                if ($li !== '') $out .= "<nav><ul>\n$li</ul></nav>\n";
            } elseif ($t === 'form') {
                $lbs = []; foreach ((array)($o['props']['fields'] ?? $o['fields'] ?? []) as $fd) if (is_array($fd) && !empty($fd['label'])) $lbs[] = $e(trim($tr($fd['label'])));
                if ($lbs) $out .= '<form><p>' . implode(' · ', array_filter($lbs)) . "</p></form>\n";
            }
        }
        return $out;
    };
    $main = $render($body, false); $ft = $render($foot, false);
    if (trim($main . $ft) === '') return '';
    return '<div id="wp-seo" style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap">' . "\n<main>\n" . $main . "</main>\n" . ($ft !== '' ? "<footer>\n" . $ft . "</footer>\n" : '') . "</div>\n";
}


// 301 met behoud van ?query
function wp_front_redirect(string $to): never {
    $qs = (string)($_SERVER['QUERY_STRING'] ?? '');
    header('Location: ' . ($to === '' ? '/' : $to) . ($qs !== '' ? '?' . $qs : ''), true, 301);
    exit;
}
// www/https: één vast adres (site.url). Alleen als site.url staat en het verzoek op hetzelfde domein komt (www of niet) of op http; uit te zetten met site.forceCanonical:false.
function wp_front_host(array $site): void {
    $u = trim((string)($site['site']['url'] ?? ''));
    if ($u === '' || ($site['site']['forceCanonical'] ?? true) === false) return;
    $p = parse_url($u); if (!is_array($p) || empty($p['host']) || empty($p['scheme'])) return;
    $want = strtolower($p['host']); $reqHost = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($reqHost === '' || preg_match('/^[\d.:\[\]]+$/', $reqHost) || $reqHost === 'localhost') return;
    $strip = fn($h) => preg_replace('/^www\./', '', $h);
    if ($strip($reqHost) !== $strip($want)) return;                       // ander domein (test, staging): niet aanraken
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https' || ($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '') === 'on' || (string)($_SERVER['SERVER_PORT'] ?? '') === '443' || str_contains((string)($_SERVER['HTTP_CF_VISITOR'] ?? ''), 'https');
    $wantHttps = strtolower($p['scheme']) === 'https';
    if ($reqHost === $want && (!$wantHttps || $https)) return;
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    header('Location: ' . strtolower($p['scheme']) . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . $uri, true, 301);
    exit;
}


// ---------- gestructureerde data (JSON-LD) voor zoekmachines: organisatie, website, broodkruimels en producten ----------
// Organisatiegegevens (optioneel) in site.org: {"name","logo","sameAs":[…],"email","telephone"}; naam anders de eerste helft van de titel van de homepagina.
// adressen van social-iconen op de site (https): zonder site.org.sameAs gaan ze automatisch als sameAs naar zoekmachines
function wp_front_social_links(array $site): array {
    $out = []; $tr = $site['translations'] ?? [];
    $walk = function (array $list) use (&$walk, &$out, $site) {
        foreach ($list as $o) { if (!is_array($o)) continue;
            if (($o['type'] ?? '') === 'icon' && str_starts_with((string)($o['props']['icon'] ?? ''), 'social:') && ($o['props']['icon'] ?? '') !== 'social:mail' && ($o['base']['action']['type'] ?? '') === 'url') {
                $u = trim(wp_front_text($o['base']['action']['target'] ?? '', $site, (string)($site['site']['defaultLanguage'] ?? 'nl')));
                if (preg_match('#^https://#i', $u)) $out[$u] = true;
            }
            if (!empty($o['children'])) $walk((array)$o['children']);
        }
    };
    foreach ((array)($site['pages'] ?? []) as $pg) if (is_array($pg)) $walk((array)($pg['objects'] ?? []));
    foreach ((array)($site['masters'] ?? []) as $m) if (is_array($m)) $walk((array)($m['objects'] ?? []));
    return array_slice(array_keys($out), 0, 20);
}
function wp_front_jsonld(array $site, array $page, string $lang, string $def, ?string $base, string $dir): string {
    $home = (string)($site['site']['homePage'] ?? '');
    $abs = fn(string $p) => ($base ?? '') . $p;
    $pgUrl = function (array $pg, string $l) use ($abs, $dir, $def, $home): string {
        $id = (string)$pg['id']; $p = ($id === $home) ? '/' : (string)($pg['path'] ?? ('/' . $id)); $pre = $l !== $def ? '/' . $l : '';
        $u = $dir . $pre . (($p === '/' && $pre !== '') ? '' : $p); return $abs($u === '' ? '/' : $u);
    };
    $tx = fn($v) => trim(wp_front_text($v, $site, $lang));
    $homePage = null; foreach ($site['pages'] as $pg) if (is_array($pg) && ($pg['id'] ?? '') === $home) { $homePage = $pg; break; }
    $org = (array)($site['org'] ?? []);
    $name = trim((string)($org['name'] ?? $site['site']['name'] ?? ''));
    if ($name === '' && $homePage) $name = trim(explode(' · ', $tx($homePage['title'] ?? ''))[0]);
    $graph = [];
    $siteUrl = $abs(($dir === '' ? '' : $dir) . '/'); $orgId = $siteUrl . '#organisatie';
    if ($name !== '') {
        $o = ['@type' => 'Organization', '@id' => $orgId, 'name' => $name, 'url' => $siteUrl];
        $logo = wp_front_asset($org['logo'] ?? null, $site, $base); if ($logo) $o['logo'] = $logo;
        if (!empty($org['sameAs']) && is_array($org['sameAs'])) $o['sameAs'] = array_values(array_filter($org['sameAs'], fn($u) => is_string($u) && preg_match('#^https?://#i', $u)));
        elseif ($soc = wp_front_social_links($site)) $o['sameAs'] = $soc;
        foreach (['email', 'telephone'] as $k) if (!empty($org[$k]) && is_string($org[$k])) $o[$k] = $org[$k];
        $graph[] = $o;
        $graph[] = ['@type' => 'WebSite', '@id' => $siteUrl . '#website', 'url' => $siteUrl, 'name' => $name, 'inLanguage' => $lang, 'publisher' => ['@id' => $orgId]];
    }
    // broodkruimels: Home > pagina
    if (($page['id'] ?? '') !== $home && $homePage) {
        $hn = $name !== '' ? $name : 'Home'; $pt = trim(explode(' · ', $tx($page['title'] ?? ''))[0]) ?: (string)$page['id'];
        $graph[] = ['@type' => 'BreadcrumbList', 'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => $hn, 'item' => $pgUrl($homePage, $lang)],
            ['@type' => 'ListItem', 'position' => 2, 'name' => $pt, 'item' => $pgUrl($page, $lang)]]];
    }
    // producten: uit een bestelformulier (keuzeveld met winkelmandje) of een collectie-blok op de pagina
    $want = []; $labels = [];
    $walk = function (array $list) use (&$walk, &$want, &$labels, $site) {
        foreach ($list as $o) { if (!is_array($o)) continue;
            $t = (string)($o['type'] ?? '');
            if ($t === 'form') foreach ((array)($o['props']['fields'] ?? []) as $fd) {
                if (!is_array($fd) || ($fd['type'] ?? '') !== 'choice' || empty($fd['cart'])) continue;
                $c = (string)($fd['collection'] ?? 'producten');
                foreach ((array)($fd['options'] ?? []) as $op) if (is_array($op) && isset($op['value'])) { $want[$c][(string)$op['value']] = true; if (!empty($op['img'])) $labels[$c][(string)$op['value']] = $op['img']; }
            }
            if (str_starts_with($t, 'collection-') && !empty($o['props']['collection'])) $want[(string)$o['props']['collection']]['*'] = true;
            if (!empty($o['children'])) $walk((array)$o['children']);
        }
    };
    $walk((array)($page['objects'] ?? []));
    $items = [];
    foreach ($want as $cn => $ids) {
        $col = $site['collections'][$cn] ?? null; if (!is_array($col) || ($col['role'] ?? '') !== 'products') continue;
        foreach ((array)($col['items'] ?? []) as $it) {
            if (!is_array($it) || !is_numeric($it['price']['amount'] ?? null)) continue;
            $key = (string)($it['sku'] ?? $it['id'] ?? ''); if (!isset($ids['*']) && !isset($ids[$key]) && !isset($ids[(string)($it['id'] ?? '')])) continue;
            $nm = $tx($it['name'] ?? ''); if ($nm === '') continue;
            $p = ['@type' => 'Product', 'name' => $nm];
            $d = $tx($it['description'] ?? ''); if ($d !== '') $p['description'] = $d;
            $im = $it['images'][0]['src'] ?? ($labels[$cn][$key] ?? $labels[$cn][(string)($it['id'] ?? '')] ?? null);
            $im = wp_front_asset(is_string($im) ? $im : null, $site, $base) ?? (is_string($im) && $im !== '' ? $abs($dir . '/' . ltrim($im, '/')) : null);
            if ($im) $p['image'] = $im;
            if ($key !== '') $p['sku'] = $key;
            $p['offers'] = ['@type' => 'Offer', 'price' => number_format(((int)$it['price']['amount']) / 100, 2, '.', ''), 'priceCurrency' => (string)($it['price']['currency'] ?? 'EUR'),
                'availability' => (($it['sell']['online'] ?? true) === false) ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock', 'url' => $pgUrl($page, $lang)];
            $items[] = $p;
        }
    }
    foreach ($items as $p) $graph[] = $p;
    if (!$graph) return '';
    return '<script type="application/ld+json">' . json_encode(['@context' => 'https://schema.org', '@graph' => $graph], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . "</script>\n";
}

function wp_front(): never {
    $shellFile = WP_SITE_DIR . '/index.html';
    $shell = is_file($shellFile) ? (string)file_get_contents($shellFile) : '';
    $rawJson = (string)@file_get_contents(WP_SITE_DIR . '/site.json');
    $site = json_decode($rawJson, true);
    header('Content-Type: text/html; charset=utf-8');
    if (extension_loaded('zlib') && !ini_get('zlib.output_compression') && str_contains((string)($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip')) ob_start('ob_gzhandler');   // de pagina klein over de lijn
    if ($shell === '') { http_response_code(404); echo 'index.html ontbreekt'; exit; }
    if (!is_array($site) || isset($_GET['edit']) || !is_array($site['pages'] ?? null)) { echo $shell; exit; }

    wp_front_host($site);
    $def = (string)($site['site']['defaultLanguage'] ?? 'nl');
    $langs = array_values(array_filter((array)($site['site']['languages'] ?? [$def]), 'is_string')) ?: [$def];
    $home = (string)($site['site']['homePage'] ?? '');
    // pad t.o.v. de map van de site
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    $path = rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
    if ($dir !== '' && str_starts_with($path, $dir)) $path = substr($path, strlen($dir));
    $rawPath = $path;
    $path = preg_replace('#/(index\.(php|html))?$#', '', $path) ?? '';
    $lang = $def;
    $defPrefixed = false;
    foreach ($langs as $l) if ($l !== $def && ($path === '/' . $l || str_starts_with($path, '/' . $l . '/'))) { $lang = $l; $path = substr($path, strlen($l) + 1); break; }
    if ($lang === $def && ($path === '/' . $def || str_starts_with($path, '/' . $def . '/'))) { $path = substr($path, strlen($def) + 1); $defPrefixed = true; }   // /nl/waarom -> /waarom
    if ($path === '') $path = '/';
    $page = null;
    foreach ($site['pages'] as $pg) {
        if (!is_array($pg) || empty($pg['id'])) continue;
        $pp = ($pg['id'] === $home) ? '/' : (string)($pg['path'] ?? ('/' . $pg['id']));
        if (rtrim($pp, '/') === rtrim($path, '/') || ($pp === '/' && $path === '/')) { $page = $pg; break; }
    }
    $canonOf = function (array $pg, string $l) use ($dir, $def, $home): string {
        $np = ($pg['id'] === $home) ? '/' : (string)($pg['path'] ?? ('/' . $pg['id'])); $pre = $l !== $def ? '/' . $l : '';
        $to = $dir . $pre . (($np === '/' && $pre !== '') ? '' : $np); return $to === '' ? '/' : $to;
    };
    $is404 = false;
    if (!$page) {
        $pl = '/' . trim($path, '/'); $last = basename($pl);
        // oud adres van een hernoemde pagina (page.aliases) of alleen de id van een pagina: 301 naar het echte adres, met behoud van taal en ?query
        foreach ($site['pages'] as $pg) {
            if (!is_array($pg) || empty($pg['id'])) continue;
            if (in_array($pl, (array)($pg['aliases'] ?? []), true) || ($pg['id'] === $last && $pg['id'] !== '404')) wp_front_redirect($canonOf($pg, $lang));
        }
        // onbekend adres: echte 404-status; staat er een pagina met id "404", dan toont die zich, anders de gewone shell
        http_response_code(404); $is404 = true;
        foreach ($site['pages'] as $pg) if (is_array($pg) && ($pg['id'] ?? '') === '404') { $page = $pg; break; }
        if (!$page) { echo preg_replace('#</head>#i', '<meta name="robots" content="noindex">' . "\n</head>", $shell, 1) ?? $shell; exit; }
        $page['noindex'] = true;
    } else {
        // vaste schrijfwijze: geen slash aan het eind, geen /index.html, geen taalvoorvoegsel voor de standaardtaal
        $canon = $canonOf($page, $lang);
        $seen = $dir . $rawPath; if ($seen === '') $seen = '/';
        if ($canon !== $seen) wp_front_redirect($canon);
    }

    $base = wp_sitemap_base($site);        // null = lokaal: dan geen absolute adressen (canonical, delen)
    $e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $title = trim(wp_front_text($page['title'] ?? '', $site, $lang));
    $desc = trim(preg_replace('/\s+/', ' ', wp_front_text($page['description'] ?? '', $site, $lang)));
    $img = wp_front_asset($page['share'] ?? ($site['site']['share'] ?? null), $site, $base);
    $urlFor = function (string $l) use ($base, $def, $home, $page): ?string {
        if ($base === null) return null;
        $id = (string)$page['id']; $p = ($id === $home) ? '/' : (string)($page['path'] ?? ('/' . $id));
        $pre = $l !== $def ? '/' . $l : '';
        return $base . $pre . (($p === '/' && $pre !== '') ? '' : $p);
    };
    $self = $is404 ? null : $urlFor($lang);
    $rtl = in_array(strtolower(explode('-', $lang)[0]), (array)($site['site']['rtl'] ?? ['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'yi', 'ckb', 'ug', 'dv']), true);

    $h = '';
    if ($self) $h .= '<link rel="canonical" href="' . $e($self) . '">' . "\n";
    if ($self && count($langs) > 1 && empty($page['noindex'])) {
        foreach ($langs as $l) $h .= '<link rel="alternate" hreflang="' . $e($l) . '" href="' . $e($urlFor($l)) . '">' . "\n";
        $h .= '<link rel="alternate" hreflang="x-default" href="' . $e($urlFor($def)) . '">' . "\n";
    }
    if (!empty($page['noindex'])) $h .= '<meta name="robots" content="noindex">' . "\n";
    if ($title !== '') $h .= '<meta property="og:title" content="' . $e($title) . '">' . "\n" . '<meta name="twitter:title" content="' . $e($title) . '">' . "\n";
    if ($desc !== '') $h .= '<meta property="og:description" content="' . $e($desc) . '">' . "\n" . '<meta name="twitter:description" content="' . $e($desc) . '">' . "\n";
    $h .= '<meta property="og:type" content="website">' . "\n";
    if ($self) $h .= '<meta property="og:url" content="' . $e($self) . '">' . "\n";
    if ($img) $h .= '<meta property="og:image" content="' . $e($img) . '">' . "\n" . '<meta name="twitter:image" content="' . $e($img) . '">' . "\n";
    $h .= '<meta name="twitter:card" content="' . ($img ? 'summary_large_image' : 'summary') . '">' . "\n";

    if ($title !== '') $shell = preg_replace('#<title>.*?</title>#is', '<title>' . $e($title) . '</title>', $shell, 1, $n) ?? $shell;
    if ($desc !== '') {
        $shell = preg_replace('#<meta\s+name=["\']description["\'][^>]*>#i', '', $shell) ?? $shell;
        $h = '<meta name="description" content="' . $e($desc) . '">' . "\n" . $h;
    }
    if (empty($page['noindex']) && !$is404) $h .= wp_front_jsonld($site, $page, $lang, $def, $base, $dir);
    // snelheid: de motorbestanden krijgen ?v=<versie> (dan mogen ze lang in de cache), het lettertypeblad en de grootste beelden boven de vouw worden vooraf opgehaald
    $ver = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION.txt'));
    if (preg_match('/^[0-9A-Za-z._-]{1,30}$/', $ver)) $shell = preg_replace('#((?:src|href)=["\'][^"\']*/speler\.(?:js|css))(?=["\'])#i', '$1?v=' . $ver, $shell) ?? $shell;
    if (!empty($site['site']['fontsLocal']) && !empty($site['site']['fontsCss']) && is_string($site['site']['fontsCss'])) $h .= '<link rel="preload" as="style" href="' . $e(($dir === '' ? '' : $dir) . '/' . ltrim($site['site']['fontsCss'], '/')) . '">' . "\n";
    $pre = 0;
    $ml = (array)(($site['masters'][$page['master'] ?? ''] ?? [])['objects'] ?? []);
    foreach (array_merge($ml, (array)($page['objects'] ?? [])) as $po) {
        if ($pre >= 2) break;
        if (!is_array($po) || ($po['type'] ?? '') !== 'image' || empty($po['props']['src']) || !is_string($po['props']['src'])) continue;
        if ((int)($po['layout']['y'] ?? 9999) > 700 || (int)($po['layout']['w'] ?? 0) < 200 || !empty($po['base']['footer'])) continue;
        $su = wp_front_asset($po['props']['src'], $site, null) ?? ($dir . '/' . ltrim($po['props']['src'], '/'));
        $h .= '<link rel="preload" as="image" href="' . $e($su) . '">' . "\n"; $pre++;
    }
    // site.json meteen in de pagina: een rondgang minder voor de bezoeker (de editor leest hem altijd vers)
    if (strlen($rawJson) < 600000 && !$is404) $h .= '<script id="wp-site" type="application/json">' . str_replace('<', '\\u003c', $rawJson) . "</script>\n";
    $shell = preg_replace('#</head>#i', $h . '</head>', $shell, 1) ?? $shell;
    $shell = preg_replace('#<html\b[^>]*>#i', '<html lang="' . $e($lang) . '"' . ($rtl ? ' dir="rtl"' : '') . '>', $shell, 1) ?? $shell;
    $content = wp_front_body($site, $page, $lang, $def, $dir);
    if ($content !== '') $shell = preg_replace('#(<div\s+id=["\']wp-root["\'][^>]*>)#i', '$1' . "\n" . str_replace(['\\', '$'], ['\\\\', '\\$'], $content), $shell, 1) ?? $shell;
    echo $shell; exit;
}
