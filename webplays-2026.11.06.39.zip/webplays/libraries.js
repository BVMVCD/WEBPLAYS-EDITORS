/*  WEBPLAYS editor — bibliotheken: Kleuren, Stijlen, Lettertypes (Beeld volgt).
    Zoals de zwevende bibliotheken van de oude editor (WPEFloatingLibrary): niet-modale vensters, verplaatsbaar,
    van formaat te veranderen, te docken onderin (alleen de titelbalk) en weer los te maken, meerdere tegelijk open.
    Positie, formaat en dock-stand worden per bibliotheek onthouden.

    Geen aparte "presets" meer: de bibliotheken tonen gewoon wat de site al kent (site.json):
      kleuren    = het palet (site.colors) — verwijzingen als "@naam", dus één kleur aanpassen past de hele site aan
      stijlen    = site.styles (tekst- en vlakstijlen)
      lettertypes= site.fonts
    Slepen en loslaten (payload { libType, id, data } zoals in WEBPLAYS):
      kleur  → op de RAND (alleen als het object een lijn heeft), het MIDDEN van tekst/knop/menu (tekstkleur) of de rest (VULLING);
               op een lege plek: de achtergrond van de site.  Heel palet → vulling, leesbare tekst en accent in één keer.
      stijl  → op een tekst of vlak: de stijl wint (eigen afwijkingen weg); op een lege plek: nieuwe tekst in die stijl.
      font   → op een tekst.
    Klikken in een bibliotheek past toe op de selectie. Alles gaat via de editor, dus Ctrl+Z werkt.
*/
(function () {
  'use strict';
  var E = window.WPEditor, S = window.WPSpeler, $ = function (id) { return document.getElementById(id); };
  if (!E || !S || !$('bar')) return;

  // ================= vensters (de WEBPLAYS-chrome) =================
  var WINS = {}, SLOTS = [], STORE = 'wpLibs', _changed = E.changed;
  function load() { try { return JSON.parse(localStorage.getItem(STORE) || '{}'); } catch (e) { return {}; } }
  function save(id, patch) { var all = load(); all[id] = Object.assign(all[id] || {}, patch); try { localStorage.setItem(STORE, JSON.stringify(all)); } catch (e) {} }

  function createWin(o) {
    if (WINS[o.id]) { WINS[o.id].focus(); if (WINS[o.id].docked) WINS[o.id].dock(false); return WINS[o.id]; }
    var st = load()[o.id] || {};
    var w = document.createElement('div'); w.className = 'wplib'; w.id = 'lib-' + o.id;
    w.innerHTML = '<div class="wplib-tb"><span class="wplib-t"></span><span class="wplib-dock" title="Dock onderin">▾</span><span class="wplib-x" title="Sluiten">✕</span></div><div class="wplib-body"></div>';
    w.querySelector('.wplib-t').textContent = o.title;
    var pos = { left: st.left != null ? st.left : o.left, top: st.top != null ? st.top : o.top, width: st.width || o.width, height: st.height || o.height };
    function applyXY() { w.style.left = Math.max(0, Math.min(pos.left, innerWidth - 120)) + 'px'; w.style.top = Math.max(46, Math.min(pos.top, innerHeight - 40)) + 'px'; }
    function applyPos() { applyXY(); w.style.width = pos.width + 'px'; w.style.height = pos.height + 'px'; }
    applyPos(); document.body.appendChild(w);
    var inst = { id: o.id, el: w, body: w.querySelector('.wplib-body'), docked: false, slot: null, build: o.build };
    inst.focus = function () { var z = 55; Object.keys(WINS).forEach(function (k) { z = Math.max(z, +WINS[k].el.style.zIndex || 55); }); w.style.zIndex = z + 1; };
    // alleen opnieuw tekenen als kleuren/stijlen/lettertypes echt veranderd zijn (anders verdwijnt wat je net wilt pakken)
    function sig() { var s = E.site(); return JSON.stringify([s.colors, s.styles, s.fonts]); }
    inst.render = function (force) { var g = sig(); if (!force && g === inst.sig) return; inst.sig = g; var sc = inst.body.scrollTop; inst.body.innerHTML = ''; o.build(inst.body, inst); inst.body.scrollTop = sc; };
    inst.dock = function (on) {
      inst.docked = on; w.classList.toggle('docked', on);
      if (on) {
        var r = w.getBoundingClientRect(); pos = { left: r.left, top: r.top, width: r.width, height: r.height };
        var i = 0; while (SLOTS[i]) i++; SLOTS[i] = true; inst.slot = i;
        w.style.top = ''; w.style.height = ''; w.style.width = '170px'; w.style.left = (12 + i * 178) + 'px';
        w.querySelector('.wplib-dock').textContent = '▴'; w.querySelector('.wplib-dock').title = 'Losmaken';
      } else {
        if (inst.slot !== null) { SLOTS[inst.slot] = false; inst.slot = null; }
        applyPos(); w.querySelector('.wplib-dock').textContent = '▾'; w.querySelector('.wplib-dock').title = 'Dock onderin';
      }
      save(o.id, { docked: on, left: pos.left, top: pos.top, width: pos.width, height: pos.height }); inst.focus();
    };
    inst.close = function () { if (inst.slot !== null) SLOTS[inst.slot] = false; w.remove(); delete WINS[o.id]; save(o.id, { open: false }); menuState(); };
    w.querySelector('.wplib-x').onclick = function (e) { e.stopPropagation(); inst.close(); };
    w.querySelector('.wplib-dock').onclick = function (e) { e.stopPropagation(); inst.dock(!inst.docked); };
    // slepen aan de titelbalk (geen scroll-lock: gewoon doorwerken op het canvas)
    w.querySelector('.wplib-tb').addEventListener('mousedown', function (e) {
      inst.focus();
      if (inst.docked || e.target.classList.contains('wplib-x') || e.target.classList.contains('wplib-dock')) return;
      var sx = e.clientX, sy = e.clientY, l0 = pos.left, t0 = pos.top; e.preventDefault();
      function mv(ev) { pos.left = l0 + ev.clientX - sx; pos.top = t0 + ev.clientY - sy; applyXY(); }   // alleen verplaatsen, maat blijft
      function up() { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); save(o.id, { left: pos.left, top: pos.top }); }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
    w.addEventListener('mousedown', function () { inst.focus(); });
    // formaat onthouden (resize: both)
    // formaat onthouden: alleen als jij aan de hoek trekt (box-sizing: border-box, dus geen groei door de rand)
    if (window.ResizeObserver) new ResizeObserver(function () {
      if (inst.docked) return; var r = w.getBoundingClientRect(), nw = Math.round(r.width), nh = Math.round(r.height);
      if (nw > 60 && (Math.abs(nw - pos.width) > 1 || Math.abs(nh - pos.height) > 1)) { pos.width = nw; pos.height = nh; save(o.id, { width: nw, height: nh }); }
    }).observe(w);
    w.addEventListener('mouseenter', function () { if (!DRAG) inst.render(); });   // altijd de actuele stand van het bestand
    WINS[o.id] = inst; inst.render(); inst.focus();
    if (st.docked) inst.dock(true);
    save(o.id, { open: true }); menuState();
    return inst;
  }

  // ================= hulp: objecten, kleuren =================
  function site() { return E.site(); }
  function lists() {
    var s = site(), p = s.pages.filter(function (x) { return x.id === E.page(); })[0];
    return [p ? p.objects : [], (s.masters[p && p.master] || { objects: [] }).objects];
  }
  function deepFind(uuid) {
    var hit = null;
    (function walk(arr) { arr.forEach(function (o) { if (hit) return; if (o.uuid === uuid) hit = o; else if (o.children) walk(o.children); }); })([].concat(lists()[0], lists()[1]));
    return hit;
  }
  function styleOf(o) { var id = (o.props && o.props.style) || (o.surface && o.surface.style); return id && site().styles ? site().styles[id] : null; }
  function surf(o) { var st = styleOf(o), s = {}; if (st && st.kind === 'surface') for (var k in st.props) s[k] = st.props[k]; for (var j in (o.surface || {})) s[j] = o.surface[j]; return s; }
  function hasLine(o) { var s = surf(o); return !!(s.stroke && s.stroke.width > 0); }
  function hex(c) { return String(S.color(c) || '#000000').replace('#', '').toUpperCase(); }
  function lum(h) { h = hex(h); var c = [0, 2, 4].map(function (i) { var v = parseInt(h.substr(i, 2), 16) / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function sat(h) { h = hex(h); var r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16), mx = Math.max(r, g, b), mn = Math.min(r, g, b); return mx ? (mx - mn) / mx : 0; }
  var TEXTISH = { text: 1, nav: 1, language: 1, form: 1, video: 1 };

  // kleur toepassen per type en zone — DE ENE plek
  function applyColor(o, ref, zone) {
    if (zone === 'line' && !hasLine(o)) zone = 'fill';
    if (zone === 'text') {
      if (o.type === 'form' || o.type === 'video') { o.props = o.props || {}; o.props.accent = ref; return true; }
      if (o.type === 'nav' || o.type === 'language' || o.type === 'text') { o.props = o.props || {}; o.props.color = ref; return true; }
      zone = 'fill';
    }
    o.surface = o.surface || {};
    if (zone === 'line') { var sk = surf(o).stroke; o.surface.stroke = { width: sk.width, color: ref, alpha: sk.alpha != null ? sk.alpha : 1 }; return true; }
    var cur = (surf(o).fills || [])[0], a = cur && cur.type === 'solid' && cur.alpha > 0 ? cur.alpha : 1;
    o.surface.fills = [{ type: 'solid', color: ref, alpha: a }];
    return true;
  }
  // heel palet: vulling, leesbare tekst, accent (lijn) — zoals WEBPLAYS _applyPaletteRoles
  function applyPalette(o, names, offset) {
    var refs = names.map(function (n) { return '@' + n; });
    var fill = refs[(offset || 0) % refs.length], rest = refs.filter(function (r) { return r !== fill; });
    function bestText(bg) { var b = null, bc = 0; (rest.length ? rest : refs).forEach(function (c) { var k = contrast(bg, c); if (k > bc) { bc = k; b = c; } }); return b; }
    var text = bestText(fill), accent = rest.filter(function (c) { return c !== text; }).sort(function (a, b) { return sat(b) - sat(a); })[0] || text;
    if (o.type === 'group') { (o.children || []).forEach(function (c) { if (c.type === 'surface') applyColor(c, fill, 'fill'); if (c.type === 'text') applyColor(c, text, 'text'); }); return; }
    if (TEXTISH[o.type]) { applyColor(o, accent, 'text'); return; }
    applyColor(o, fill, 'fill'); if (hasLine(o)) applyColor(o, accent, 'line');
  }
  function applyStyle(o, id) {
    var st = site().styles[id]; if (!st) return false;
    if (st.kind === 'text') {
      if (o.type !== 'text') return false;
      o.props = o.props || {}; o.props.style = id;
      ['font', 'size', 'weight', 'lineHeight', 'letterSpacing', 'color', 'italic'].forEach(function (k) { delete o.props[k]; });   // de stijl wint
      return true;
    }
    if (o.type === 'group') { var n = 0; (o.children || []).forEach(function (c) { if (c.type === 'surface' && applyStyle(c, id)) n++; }); return n > 0; }
    if (o.type === 'text' || o.type === 'nav' || o.type === 'form' || o.type === 'language') return false;
    o.props = o.props || {}; o.props.style = id; o.surface = {};          // vlakstijl wint: eigen vulling/rand weg
    return true;
  }
  function applyFont(o, fam) { if (o.type !== 'text' && o.type !== 'nav') return false; o.props = o.props || {}; o.props.font = fam; return true; }

  // ================= slepen en loslaten op het canvas =================
  var DRAG = null, ZONE = null, EDGE_IN = 10, EDGE_OUT = 12;
  function payload(e, p) { DRAG = p; try { e.dataTransfer.setData('application/json', JSON.stringify(p)); } catch (x) {} e.dataTransfer.effectAllowed = 'copy'; }
  document.addEventListener('dragend', function () { DRAG = null; hideZone(); });
  document.addEventListener('dragleave', function (e) { if (DRAG && DRAG.files && !e.relatedTarget) { DRAG = null; hideZone(); } });

  function canvasHit(x, y) {
    var pageEl = E.pageEl(); if (!pageEl) return null;
    var els = document.elementsFromPoint(x, y), prim = null;
    for (var i = 0; i < els.length; i++) { var d = els[i]; if (d.dataset && d.dataset.uuid && pageEl.contains(d)) { prim = d; break; } }
    var out = { el: prim, obj: prim ? deepFind(prim.dataset.uuid) : null, inCanvas: !!document.elementFromPoint(x, y) && $('canvas').contains(document.elementFromPoint(x, y)), pageEl: pageEl };
    return out;
  }
  function edgeDist(r, x, y) {
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return -Math.min(x - r.left, r.right - x, y - r.top, r.bottom - y);
    var dx = Math.max(r.left - x, 0, x - r.right), dy = Math.max(r.top - y, 0, y - r.bottom); return Math.sqrt(dx * dx + dy * dy);
  }
  // doel + zone voor een kleur
  function colorTarget(x, y, hit) {
    var best = null, area = 1e12;
    [].forEach.call(hit.pageEl.querySelectorAll('[data-uuid]'), function (d) {
      var o = deepFind(d.dataset.uuid); if (!o || !hasLine(o)) return;
      var r = d.getBoundingClientRect(), dd = edgeDist(r, x, y);
      if (dd <= EDGE_OUT && dd >= -EDGE_IN && r.width * r.height < area) { best = { el: d, obj: o }; area = r.width * r.height; }
    });
    if (best && (!hit.el || best.el === hit.el || edgeDist(hit.el.getBoundingClientRect(), x, y) > -EDGE_IN || area <= hit.el.getBoundingClientRect().width * hit.el.getBoundingClientRect().height)) return { el: best.el, obj: best.obj, zone: 'line' };
    if (!hit.obj) return null;
    if (TEXTISH[hit.obj.type]) {
      var r = hit.el.getBoundingClientRect(), lowH = r.height < 60;
      var inX = x >= r.left + r.width * .25 && x <= r.right - r.width * .25, inY = y >= r.top + r.height * .25 && y <= r.bottom - r.height * .25;
      if (inX && (lowH || inY)) return { el: hit.el, obj: hit.obj, zone: 'text' };
      if (hit.obj.type !== 'text') return { el: hit.el, obj: hit.obj, zone: 'text' };
    }
    if (hit.obj.type === 'image' && !hasLine(hit.obj)) return { el: hit.el, obj: hit.obj, zone: null };
    return { el: hit.el, obj: hit.obj, zone: 'fill' };
  }
  function target(x, y) {
    if (!DRAG) return null;
    var hit = canvasHit(x, y); if (!hit || !hit.inCanvas) return null;
    var t = DRAG.libType;
    if (t === 'color' || t === 'palette') {
      var c = colorTarget(x, y, hit);
      if (c) return c.zone ? { el: c.el, obj: c.obj, zone: c.zone, label: t === 'palette' ? 'PALET' : ({ line: 'RAND', text: 'TEKST', fill: 'VULLING' })[c.zone] } : { el: c.el, obj: c.obj, zone: null, label: 'KLEUR NIET VOOR DIT OBJECT' };
      return t === 'color' ? { el: hit.pageEl, obj: null, zone: 'bg', label: 'ACHTERGROND SITE' } : null;
    }
    if (t === 'style') {
      var st = site().styles[DRAG.id];
      if (!hit.obj) return st ? { el: null, obj: null, zone: 'new', label: (st.kind === 'text' ? 'NIEUWE TEKST · ' : 'NIEUW VLAK · ') + (st.name || DRAG.id).toUpperCase(), x: x, y: y } : null;
      var ok = st && (st.kind === 'text' ? hit.obj.type === 'text' : (['text', 'nav', 'form', 'language'].indexOf(hit.obj.type) < 0));
      if (st && !ok && st.kind === 'surface') {        // tekst ligt op een kaart: dan krijgt de kaart eronder de style
        var under = document.elementsFromPoint(x, y).filter(function (d) { return d.dataset && d.dataset.uuid && hit.pageEl.contains(d) && d !== hit.el; })
          .map(function (d) { return { el: d, obj: deepFind(d.dataset.uuid) }; }).filter(function (h) { return h.obj && ['text', 'nav', 'form', 'language'].indexOf(h.obj.type) < 0; })[0];
        if (under) { hit = { el: under.el, obj: under.obj, pageEl: hit.pageEl }; ok = true; }
      }
      return { el: hit.el, obj: hit.obj, zone: ok ? 'style' : null, label: ok ? 'STIJL · ' + (st.name || DRAG.id).toUpperCase() : 'STIJL NIET VOOR DIT OBJECT' };
    }
    if (t === 'image') {
      if (!hit.obj) return { el: null, obj: null, zone: 'new', label: 'NIEUW BEELD', x: x, y: y };
      var accepts = function (o) { return o && (o.type === 'image' || o.type === 'surface' || o.type === 'video'); };
      if (!accepts(hit.obj)) {                          // tekst op een kaart: dan de kaart eronder
        var und = document.elementsFromPoint(x, y).filter(function (d) { return d.dataset && d.dataset.uuid && hit.pageEl.contains(d) && d !== hit.el; })
          .map(function (d) { return { el: d, obj: deepFind(d.dataset.uuid) }; }).filter(function (h) { return accepts(h.obj); })[0];
        if (und) hit = { el: und.el, obj: und.obj, pageEl: hit.pageEl };
      }
      var zi = ({ image: ['replace', 'BEELD VERVANGEN'], surface: ['imgfill', 'FOTO IN VLAK'], video: ['poster', 'POSTERBEELD VIDEO'] })[hit.obj.type];
      return zi ? { el: hit.el, obj: hit.obj, zone: zi[0], label: zi[1] } : { el: hit.el, obj: hit.obj, zone: null, label: 'BEELD NIET VOOR DIT OBJECT' };
    }
    if (t === 'font') {
      if (!hit.obj) return null;
      var okf = hit.obj.type === 'text' || hit.obj.type === 'nav';
      return { el: hit.el, obj: hit.obj, zone: okf ? 'font' : null, label: okf ? 'LETTERTYPE · ' + DRAG.id.toUpperCase() : 'ALLEEN OP TEKST' };
    }
    return null;
  }
  // zone-feedback tijdens het slepen (WEBPLAYS: RAND / TEKST / VULLING)
  function showZone(x, y) {
    var t = target(x, y); if (!t) { hideZone(); return; }
    if (!ZONE) { ZONE = document.createElement('div'); ZONE.className = 'wplib-zone'; ZONE.innerHTML = '<b></b>'; document.body.appendChild(ZONE); }
    var r = t.el ? t.el.getBoundingClientRect() : { left: t.x - 2, top: t.y - 2, width: 4, height: 4 };
    if (t.zone === 'bg') r = $('canvas').getBoundingClientRect();
    ZONE.style.cssText = 'display:block;left:' + r.left + 'px;top:' + r.top + 'px;width:' + r.width + 'px;height:' + r.height + 'px';
    ZONE.className = 'wplib-zone z-' + (t.zone || 'no'); ZONE.firstChild.textContent = t.label;
  }
  function hideZone() { if (ZONE) ZONE.style.display = 'none'; }
  var rafXY = null, raf = 0;
  function hasFiles(e) { return e.dataTransfer && [].indexOf.call(e.dataTransfer.types || [], 'Files') >= 0; }
  // een bestand dat naast een doel valt, mag de browser nooit 'openen' (dan ben je je werk kwijt)
  window.addEventListener('dragover', function (e) { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('drop', function (e) { if (hasFiles(e)) e.preventDefault(); });
  document.addEventListener('dragover', function (e) {
    if (!DRAG && hasFiles(e) && $('canvas').contains(e.target)) DRAG = { libType: 'image', id: null, files: true };
    if (!DRAG || !$('canvas').contains(e.target)) return;
    e.preventDefault(); e.dataTransfer.dropEffect = 'copy';
    rafXY = [e.clientX, e.clientY];
    if (!raf) raf = requestAnimationFrame(function () { raf = 0; if (rafXY) showZone(rafXY[0], rafXY[1]); });
  });
  document.addEventListener('drop', function (e) {
    if (!DRAG || !$('canvas').contains(e.target)) return;
    e.preventDefault();
    var t = target(e.clientX, e.clientY), p = DRAG; hideZone(); DRAG = null;
    if (!t || !t.zone) { if (t && t.el) flash(t.el, '#999'); return; }
    var sel = E.selection(), targets = [t.obj];
    // in een meervoudige selectie geldt een drop op één van de geselecteerde voor allemaal
    if (t.obj && sel.length > 1 && sel.indexOf(t.obj.uuid) >= 0) targets = sel.map(deepFind).filter(Boolean);
    if (p.libType === 'color') {
      if (t.zone === 'bg') { site().site.background = '@' + p.id; E.changed('achtergrond: ' + p.id); return; }
      targets.forEach(function (o) { applyColor(o, '@' + p.id, o === t.obj ? t.zone : (TEXTISH[o.type] ? 'text' : 'fill')); });
      E.changed('kleur ' + p.id);
    } else if (p.libType === 'palette') {
      targets.forEach(function (o, i) { applyPalette(o, p.data.names, i); }); E.changed('palet toegepast');
    } else if (p.libType === 'style') {
      if (t.zone === 'new') { (site().styles[p.id].kind === 'text' ? newText : newSurface)(p.id, e.clientX, e.clientY); return; }
      var n = 0; targets.forEach(function (o) { if (applyStyle(o, p.id)) n++; }); if (n) E.changed('stijl ' + (site().styles[p.id].name || p.id));
    } else if (p.libType === 'font') {
      targets.forEach(function (o) { applyFont(o, p.id); }); E.changed('lettertype ' + p.id);
    } else if (p.libType === 'image') {
      var cx = e.clientX, cy = e.clientY;
      if (p.files) {                                  // van het bureaublad: eerst uploaden, dan plaatsen
        uploadFiles(e.dataTransfer.files, function (items) {
          items.forEach(function (it, i) { placeImage(it, i ? { zone: 'new' } : t, targets, cx + i * 30, cy + i * 30); });
        });
        return;
      }
      placeImage(p.data, t, targets, cx, cy);
    }
  });
  // beeld op zijn plek: vervangen, als foto in een vlak, als poster, of nieuw
  function applyImage(o, it, zone) {
    o.props = o.props || {};
    if (zone === 'replace' && o.type === 'image') { o.props.src = it.file; o.props.ow = it.w || undefined; o.props.oh = it.h || undefined; delete o.props.focus; return true; }
    if (zone === 'poster' && o.type === 'video') { o.props.poster = it.file; return true; }
    if (o.type === 'surface' || zone === 'imgfill') { o.surface = o.surface || {}; o.surface.fills = [{ type: 'image', src: it.file, fit: 'crop' }]; return true; }
    return false;
  }
  function placeImage(it, t, targets, cx, cy) {
    if (t.zone === 'new') { newImage(it, cx, cy); return; }
    var n = 0; targets.forEach(function (o) { if (applyImage(o, it, o === t.obj ? t.zone : null)) n++; });
    if (n) E.changed('beeld ' + it.name);
  }
  function newImage(it, cx, cy) {
    var s = site(), r = E.pageEl().getBoundingClientRect(), k = E.scale();
    var pg = s.pages.filter(function (x) { return x.id === E.page(); })[0], id = 'i-' + Math.random().toString(36).slice(2, 8);
    var w = Math.min(480, it.w || 480), h = it.w && it.h ? Math.round(w * it.h / it.w) : 320;
    var x = Math.round((cx - r.left) / k - w / 2), y = Math.round((cy - r.top) / k - h / 2);
    var alt = {}; s.site.languages.forEach(function (l) { alt[l] = ''; });
    pg.objects.push({ uuid: id, type: 'image', layout: { x: Math.max(0, x), y: Math.max(0, y), w: w, h: h }, props: { src: it.file, fit: 'crop', ow: it.w || undefined, oh: it.h || undefined, alt: alt } });
    E.changed('nieuw beeld ' + it.name); E.setSelection([id]);
  }
  function flash(el, c) { if (!el) return; var o = el.style.outline; el.style.outline = '2px solid ' + c; setTimeout(function () { el.style.outline = o; }, 600); }
  // stijl op een lege plek: nieuwe tekst in die stijl, precies waar je losliet
  function newText(styleId, cx, cy) {
    var s = site(), st = s.styles[styleId], pageEl = E.pageEl(), r = pageEl.getBoundingClientRect(), k = E.scale();
    var pg = s.pages.filter(function (x) { return x.id === E.page(); })[0];
    var size = (st.props && st.props.size) || 16, id = 't-' + Math.random().toString(36).slice(2, 8), key = 'tx-' + Math.random().toString(36).slice(2, 8);
    var vals = {}; s.site.languages.forEach(function (l) { vals[l] = l === 'nl' ? 'Nieuwe tekst' : l === 'de' ? 'Neuer Text' : l === 'fr' ? 'Nouveau texte' : 'New text'; });
    s.translations = s.translations || {}; s.translations[key] = vals;
    var x = Math.round((cx - r.left) / k), y = Math.round((cy - r.top) / k), w = Math.min(560, Math.max(160, size * 12));
    pg.objects.push({ uuid: id, type: 'text', layout: { x: x, y: y, w: w, h: Math.round(size * ((st.props && st.props.lineHeight) || 1.3) + 6) }, props: { text: key, style: styleId } });
    E.changed('nieuwe tekst (' + (st.name || styleId) + ')'); E.setSelection([id]);
  }

  function newSurface(styleId, cx, cy) {
    var s = site(), st = s.styles[styleId], r = E.pageEl().getBoundingClientRect(), k = E.scale();
    var pg = s.pages.filter(function (x) { return x.id === E.page(); })[0], id = 's-' + Math.random().toString(36).slice(2, 8);
    var w = 300, h = 180, x = Math.round((cx - r.left) / k - w / 2), y = Math.round((cy - r.top) / k - h / 2);
    pg.objects.push({ uuid: id, type: 'surface', layout: { x: x, y: y, w: w, h: h }, props: { style: styleId }, surface: {} });
    E.changed('nieuw vlak (' + (st.name || styleId) + ')'); E.setSelection([id]);
  }

  // ================= de bibliotheken =================
  function applyToSelection(fn, msg) {
    var objs = E.selection().map(deepFind).filter(Boolean);
    if (!objs.length) { $('status').textContent = 'selecteer eerst een object, of sleep naar de pagina'; return; }
    var n = 0; objs.forEach(function (o) { if (fn(o) !== false) n++; });
    if (n) E.changed(msg);
  }
  function el(tag, cls, txt) { var d = document.createElement(tag); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }

  function buildColors(body) {
    var s = site(), names = Object.keys(s.colors || {});
    var pal = el('div', 'wplib-pal'); pal.draggable = true; pal.title = 'Heel palet: sleep op een object (vulling, leesbare tekst en accent in één keer)';
    names.forEach(function (n) { var i = el('i'); i.style.background = s.colors[n]; pal.appendChild(i); });
    pal.addEventListener('dragstart', function (e) { payload(e, { libType: 'palette', id: 'palette', data: { names: names } }); });
    body.appendChild(el('div', 'wplib-h', 'Heel palet')); body.appendChild(pal);
    body.appendChild(el('div', 'wplib-h', 'Kleuren'));
    var grid = el('div', 'wplib-grid');
    names.forEach(function (n) {
      var c = el('div', 'wplib-sw'); c.draggable = true; c.title = n + '  ' + s.colors[n] + '\nslepen: rand · tekst · vulling\nklik: op de selectie · dubbelklik: aanpassen';
      var i = el('i'); i.style.background = s.colors[n]; c.appendChild(i); c.appendChild(el('span', null, n));
      c.addEventListener('dragstart', function (e) { payload(e, { libType: 'color', id: n, data: { color: s.colors[n] } }); });
      c.onclick = function () { applyToSelection(function (o) { return applyColor(o, '@' + n, TEXTISH[o.type] ? 'text' : 'fill'); }, 'kleur ' + n); };
      c.ondblclick = function () {
        var pick = el('input'); pick.type = 'color'; pick.value = s.colors[n]; pick.style.cssText = 'position:fixed;left:-99px;top:0';
        document.body.appendChild(pick);
        pick.oninput = function () { s.colors[n] = pick.value; i.style.background = pick.value; E.changed('kleur ' + n + ' aangepast'); };
        pick.onchange = function () { pick.remove(); }; pick.click();
      };
      grid.appendChild(c);
    });
    var add = el('div', 'wplib-sw add'); add.title = 'Kleur toevoegen aan het palet'; add.appendChild(el('i', null, '+')); add.appendChild(el('span', null, 'nieuw'));
    add.onclick = function () {
      WPPrompt.ask('Naam van de nieuwe kleur. Daarna kies je de kleur zelf (dubbelklik).', { title: 'Kleur toevoegen', placeholder: 'bijv. accent2', ok: 'Toevoegen',
        validate: function (v) { if (!/^[a-z0-9_-]+$/i.test(v)) return 'Alleen letters, cijfers, - en _'; if (s.colors[v]) return 'Die naam bestaat al.'; return null; } },
        function (nm) { s.colors[nm] = '#00A4E4'; E.changed('kleur ' + nm + ' toegevoegd'); WINS.colors && WINS.colors.render(true); });
    };
    grid.appendChild(add); body.appendChild(grid);
    body.appendChild(el('div', 'wplib-tip', 'Sleep op een object: RAND · TEKST · VULLING. Op een lege plek: achtergrond van de site.'));
  }

  function textPreview(st, txt) {
    var p = st.props || {}, d = el('div', 'wplib-tx', txt);
    if (p.font) d.style.fontFamily = '"' + p.font + '",system-ui,sans-serif';
    d.style.fontSize = Math.min(p.size || 15, 24) + 'px'; if (p.weight) d.style.fontWeight = p.weight;
    if (p.letterSpacing) d.style.letterSpacing = Math.min(p.letterSpacing, 3) + 'px';
    if (p.italic) d.style.fontStyle = 'italic';
    return d;
  }
  function uniqueId(prefix, name) {
    var base = prefix + (name || 'style').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || prefix + 'style';
    var id = base, i = 2; while (site().styles[id]) id = base + '-' + i++; return id;
  }
  // in de editor van een stijl: wijzigen zonder het venster opnieuw op te bouwen (anders verlies je de focus)
  function quiet(inst, msg) { _changed(msg); Object.keys(WINS).forEach(function (k) { if (WINS[k] !== inst) WINS[k].render(); }); inst.sig = JSON.stringify([site().colors, site().styles, site().fonts]); }

  // ---------- veldjes voor de stijl-editor ----------
  function row(label, ctrl) { var r = el('label', 'wplib-row'); r.appendChild(el('span', null, label)); r.appendChild(ctrl); return r; }
  function numIn(val, min, max, step, on) { var i = el('input'); i.type = 'number'; i.value = val; i.min = min; i.max = max; i.step = step || 1; i.oninput = function () { if (i.value !== '') on(+i.value); }; return i; }
  function rangeIn(val, on) { var w = el('div', 'wplib-range'), i = el('input'), o = el('em', null, Math.round(val * 100) + '%'); i.type = 'range'; i.min = 0; i.max = 100; i.value = Math.round(val * 100); i.oninput = function () { o.textContent = i.value + '%'; on(i.value / 100); }; w.appendChild(i); w.appendChild(o); return w; }
  function colorIn(val, on) {
    var w = el('div', 'wplib-col'), names = Object.keys(site().colors || {});
    var sel = el('select'); sel.appendChild(new Option('— geen —', ''));
    names.forEach(function (n) { sel.appendChild(new Option(n, '@' + n)); });
    var dot = el('i'); function paint() { dot.style.background = sel.value ? S.color(sel.value) : 'transparent'; }
    sel.value = val && names.indexOf(String(val).slice(1)) >= 0 ? val : ''; paint();
    sel.onchange = function () { paint(); on(sel.value || null); };
    w.appendChild(dot); w.appendChild(sel); return w;
  }
  var SHADOWS = { '': null, zacht: [{ dx: 0, dy: 8, blur: 24, spread: 0, color: '#000000', alpha: .10 }], middel: [{ dx: 0, dy: 14, blur: 34, spread: 0, color: '#000000', alpha: .18 }], sterk: [{ dx: 0, dy: 24, blur: 60, spread: 0, color: '#000000', alpha: .28 }] };
  function shadowName(sh) { if (!sh || !sh.length) return ''; var a = sh[0].alpha; return a <= .12 ? 'zacht' : a <= .2 ? 'middel' : 'sterk'; }

  function styleEditor(inst, id) {
    var st = site().styles[id], p = st.props = st.props || {}, box = el('div', 'wplib-edit');
    function ch(m) { quiet(inst, (st.name || id) + ': ' + m); }
    if (st.kind === 'surface') {
      var f = (p.fills || [])[0] || {}, sk = p.stroke || { width: 0 }, rad = (p.shape && p.shape.radius) ? p.shape.radius[0] : 0;
      box.appendChild(row('Vulkleur', colorIn(f.color, function (v) { p.fills = v ? [{ type: 'solid', color: v, alpha: f.alpha != null ? f.alpha : 1 }] : []; f = p.fills[0] || {}; ch('vulkleur'); })));
      box.appendChild(row('Dekking vulling', rangeIn(f.alpha != null ? f.alpha : 1, function (v) { if (p.fills && p.fills[0]) { p.fills[0].alpha = v; f = p.fills[0]; ch('dekking vulling'); } })));
      box.appendChild(row('Lijnkleur', colorIn(sk.color, function (v) { p.stroke = { width: v ? (sk.width || 1) : 0, color: v || '#000000', alpha: 1 }; sk = p.stroke; ch('lijnkleur'); })));
      box.appendChild(row('Lijndikte', numIn(sk.width || 0, 0, 40, 1, function (v) { p.stroke = { width: v, color: sk.color || '@ink', alpha: sk.alpha != null ? sk.alpha : 1 }; sk = p.stroke; ch('lijndikte'); })));
      box.appendChild(row('Radius', numIn(rad, 0, 400, 1, function (v) { p.shape = { kind: 'rect', radius: [v, v, v, v] }; ch('radius'); })));
      var shs = el('select'); ['', 'zacht', 'middel', 'sterk'].forEach(function (k) { shs.appendChild(new Option(k || '— geen —', k)); }); shs.value = shadowName(p.shadows);
      shs.onchange = function () { if (SHADOWS[shs.value]) p.shadows = JSON.parse(JSON.stringify(SHADOWS[shs.value])); else delete p.shadows; ch('schaduw'); };
      box.appendChild(row('Schaduw', shs));
      box.appendChild(row('Dekking', rangeIn(p.opacity != null ? p.opacity : 1, function (v) { if (v >= 1) delete p.opacity; else p.opacity = v; ch('dekking'); })));
    } else {
      var fs = el('select'); fs.appendChild(new Option('— systeem —', '')); (site().fonts || []).forEach(function (x) { fs.appendChild(new Option(x.family, x.family)); });
      fs.value = p.font || ''; fs.onchange = function () { if (fs.value) p.font = fs.value; else delete p.font; ch('lettertype'); };
      box.appendChild(row('Lettertype', fs));
      box.appendChild(row('Grootte', numIn(p.size || 16, 6, 200, 1, function (v) { p.size = v; ch('grootte'); })));
      var ws = el('select'); [300, 400, 500, 600, 700, 800].forEach(function (x) { ws.appendChild(new Option(x, x)); }); ws.value = p.weight || 400;
      ws.onchange = function () { p.weight = +ws.value; ch('gewicht'); }; box.appendChild(row('Gewicht', ws));
      box.appendChild(row('Regelafstand', numIn(p.lineHeight || 1.4, .8, 3, .05, function (v) { p.lineHeight = v; ch('regelafstand'); })));
      box.appendChild(row('Letterafstand', numIn(p.letterSpacing || 0, -5, 20, .1, function (v) { if (v) p.letterSpacing = v; else delete p.letterSpacing; ch('letterafstand'); })));
      box.appendChild(row('Kleur', colorIn(p.color, function (v) { if (v) p.color = v; else delete p.color; ch('kleur'); })));
      var it = el('input'); it.type = 'checkbox'; it.checked = !!p.italic; it.onchange = function () { if (it.checked) p.italic = true; else delete p.italic; ch('cursief'); };
      box.appendChild(row('Cursief', it));
    }
    var acts = el('div', 'wplib-acts');
    var rn = el('button', null, 'Hernoemen'); rn.onclick = function () {
      WPPrompt.ask('Nieuwe naam voor deze stijl.', { title: 'Hernoemen', value: st.name || id, ok: 'Opslaan' }, function (v) { st.name = v; E.changed('stijl hernoemd'); inst.render(true); });
    };
    var del = el('button', 'danger', 'Verwijderen'); del.onclick = function () {
      var users = usersOf(id);
      WPPrompt.confirm('Stijl "' + (st.name || id) + '" verwijderen?' + (users.length ? '\n' + users.length + ' object(en) gebruiken hem; die houden hun huidige uiterlijk.' : ''), { ok: 'Verwijderen', danger: true }, function () {
        users.forEach(function (o) { bake(o, st); });                       // eerst het uiterlijk vastleggen in het object zelf
        delete site().styles[id]; inst.editing = null; E.changed('stijl verwijderd'); inst.render(true);
      });
    };
    acts.appendChild(rn); acts.appendChild(del); box.appendChild(acts);
    return box;
  }
  function allObjects() {
    var out = [], s = site();
    function walk(a) { a.forEach(function (o) { out.push(o); if (o.children) walk(o.children); }); }
    s.pages.forEach(function (p) { walk(p.objects || []); }); Object.keys(s.masters || {}).forEach(function (m) { walk(s.masters[m].objects || []); });
    return out;
  }
  function usersOf(id) { return allObjects().filter(function (o) { return o.props && o.props.style === id; }); }
  function bake(o, st) {
    var cp = JSON.parse(JSON.stringify(st.props || {}));
    if (st.kind === 'text') { Object.keys(cp).forEach(function (k) { if (o.props[k] == null) o.props[k] = cp[k]; }); }
    else { o.surface = Object.assign(cp, o.surface || {}); }
    delete o.props.style;
  }
  // + Van selectie: het uiterlijk van het geselecteerde object wordt een stijl
  function fromSelection(kind, inst) {
    var o = E.selection().map(deepFind).filter(Boolean)[0];
    if (o && o.type === 'group' && kind === 'surface') o = (o.children || []).filter(function (c) { return c.type === 'surface'; })[0];
    if (!o || (kind === 'text' ? o.type !== 'text' : ['text', 'nav', 'form', 'language'].indexOf(o.type) >= 0)) {
      WPPrompt.notice(kind === 'text' ? 'Selecteer eerst een tekst; zijn opmaak wordt de nieuwe stijl.' : 'Selecteer eerst een vlak, kaart of knop; zijn uiterlijk wordt de nieuwe style.'); return;
    }
    WPPrompt.ask(kind === 'text' ? 'Naam voor de nieuwe tekststijl.' : 'Naam voor de nieuwe style.', { title: kind === 'text' ? 'Typografie van selectie' : 'Style van selectie', placeholder: kind === 'text' ? 'bijv. Kop 3' : 'bijv. Kaart wit', ok: 'Maken' }, function (name) {
      var props = {};
      if (kind === 'text') {
        var base = o.props && o.props.style && site().styles[o.props.style] ? site().styles[o.props.style].props : {};
        ['font', 'size', 'weight', 'lineHeight', 'letterSpacing', 'color', 'italic'].forEach(function (k) { var v = (o.props && o.props[k] != null) ? o.props[k] : base[k]; if (v != null) props[k] = v; });
      } else {
        var sf = surf(o); ['fills', 'stroke', 'shape', 'shadows', 'opacity'].forEach(function (k) { if (sf[k] != null) props[k] = JSON.parse(JSON.stringify(sf[k])); });
      }
      var id = uniqueId(kind === 'text' ? 'tx-' : 'sf-', name);
      site().styles[id] = { kind: kind, name: name, props: props };
      applyStyle(o, id);                               // het object gebruikt meteen zijn eigen nieuwe stijl
      inst.editing = id; E.changed((kind === 'text' ? 'tekststijl ' : 'style ') + name + ' gemaakt'); inst.render(true);
    });
  }
  function styleCard(inst, id, preview) {
    var st = site().styles[id], c = el('div', 'wplib-st' + (inst.editing === id ? ' open' : ''));
    var head = el('div', 'wplib-sthead'); head.draggable = true; head.appendChild(preview);   // de kop sleep je, ook als de editor open staat
    var pen = el('span', 'wplib-pen', '✎'); pen.title = 'Aanpassen (werkt door op alles met deze stijl)';
    pen.onclick = function (e) { e.stopPropagation(); inst.editing = inst.editing === id ? null : id; inst.render(true); };
    head.appendChild(pen); c.appendChild(head);
    head.addEventListener('dragstart', function (e) { payload(e, { libType: 'style', id: id, data: { kind: st.kind } }); });
    head.onclick = function () { applyToSelection(function (o) { return applyStyle(o, id); }, 'stijl ' + (st.name || id)); };
    var n = usersOf(id).length; c.title = (st.name || id) + ' · gebruikt door ' + n + ' object' + (n === 1 ? '' : 'en') + '\nslepen of klikken: toepassen · ✎: aanpassen';
    if (inst.editing === id) { var ed = styleEditor(inst, id); ed.addEventListener('mousedown', function (e) { e.stopPropagation(); }); c.appendChild(ed); }
    return c;
  }

  // ---------- STYLES: vulkleur, lijn, radius, schaduw, dekking ----------
  function buildStyles(body, inst) {
    var s = site(), ids = Object.keys(s.styles || {}).filter(function (id) { return s.styles[id].kind === 'surface'; });
    var add = el('button', 'wplib-btn', '+ Van selectie'); add.title = 'Selecteer een vlak, kaart of knop: zijn uiterlijk wordt een style'; add.onclick = function () { fromSelection('surface', inst); };
    body.appendChild(add);
    if (!ids.length) body.appendChild(el('div', 'wplib-tip', 'Nog geen styles. Selecteer een mooie kaart of knop en klik "+ Van selectie".'));
    ids.forEach(function (id) {
      var st = s.styles[id], p = st.props || {}, f = (p.fills || [])[0];
      var pv = el('div', 'wplib-sfprev'), i = el('i');
      if (f) i.style.background = f.type === 'solid' ? S.color(f.color) : 'linear-gradient(' + (f.angle || 180) + 'deg,' + (f.stops || []).map(function (x) { return S.color(x.color); }).join(',') + ')';
      if (f && f.alpha != null && f.alpha < 1) i.style.opacity = Math.max(.15, f.alpha);
      if (p.stroke && p.stroke.width) i.style.boxShadow = 'inset 0 0 0 ' + Math.min(4, p.stroke.width) + 'px ' + S.color(p.stroke.color);
      if (p.shape && p.shape.radius) i.style.borderRadius = Math.min(16, p.shape.radius[0]) + 'px';
      if (p.shadows && p.shadows.length) i.style.filter = 'drop-shadow(0 3px 5px rgba(0,0,0,.25))';
      pv.appendChild(i);
      var tx = el('div'); tx.appendChild(el('b', null, st.name || id));
      tx.appendChild(el('span', 'wplib-meta', [f ? 'vulling' : 'geen vulling', p.stroke && p.stroke.width ? 'lijn ' + p.stroke.width : '', p.shape && p.shape.radius ? 'radius ' + p.shape.radius[0] : '', p.shadows ? 'schaduw' : '', p.opacity != null ? Math.round(p.opacity * 100) + '%' : ''].filter(Boolean).join(' · ')));
      pv.appendChild(tx);
      body.appendChild(styleCard(inst, id, pv));
    });
    body.appendChild(el('div', 'wplib-tip', 'Sleep op een vlak, kaart, knop of beeld. Op een lege plek: nieuw vlak. Een style aanpassen (✎) werkt overal door.'));
  }

  // ---------- TYPOGRAFIE: tekststijlen + de lettertypes van de site ----------
  function googleLink(fonts) {
    var fam = fonts.map(function (f) { return 'family=' + f.google; }).join('&'); if (!fam) return;
    var href = 'https://fonts.googleapis.com/css2?' + fam + '&display=swap';
    if (!document.querySelector('link[href="' + href + '"]')) { var l = document.createElement('link'); l.rel = 'stylesheet'; l.href = href; document.head.appendChild(l); }
  }
  function buildTypo(body, inst) {
    var s = site(), ids = Object.keys(s.styles || {}).filter(function (id) { return s.styles[id].kind === 'text'; }), fonts = s.fonts || [];
    var add = el('button', 'wplib-btn', '+ Van selectie'); add.title = 'Selecteer een tekst: zijn opmaak wordt een tekststijl'; add.onclick = function () { fromSelection('text', inst); };
    body.appendChild(add);
    body.appendChild(el('div', 'wplib-h', 'Tekststijlen'));
    ids.forEach(function (id) {
      var st = s.styles[id], p = st.props || {}, pv = el('div', 'wplib-txprev');
      pv.appendChild(textPreview(st, 'Aa ' + (st.name || id)));
      pv.appendChild(el('span', 'wplib-meta', [p.font, p.size ? p.size + 'px' : '', p.weight || ''].filter(Boolean).join(' · ')));
      body.appendChild(styleCard(inst, id, pv));
    });
    body.appendChild(el('div', 'wplib-h', 'Lettertypes'));
    fonts.forEach(function (f) {
      var c = el('div', 'wplib-st'); c.draggable = true; c.title = 'Slepen of klikken: op een tekst of menu';
      var d = el('div', 'wplib-tx', 'Aa Bb Cc 123'); d.style.fontFamily = '"' + f.family + '",system-ui,sans-serif'; d.style.fontSize = '18px';
      c.appendChild(d); c.appendChild(el('span', 'wplib-meta', f.family));
      c.addEventListener('dragstart', function (e) { payload(e, { libType: 'font', id: f.family, data: f }); });
      c.onclick = function () { applyToSelection(function (o) { return applyFont(o, f.family); }, 'lettertype ' + f.family); };
      body.appendChild(c);
    });
    var addf = el('button', 'wplib-btn', '+ Google-lettertype toevoegen');
    addf.onclick = function () {
      WPPrompt.ask('Naam van het lettertype, precies zoals op Google Fonts.', { title: 'Lettertype toevoegen', placeholder: 'bijv. Fraunces of DM Sans', ok: 'Toevoegen',
        validate: function (v) { return fonts.some(function (f) { return f.family.toLowerCase() === v.toLowerCase(); }) ? 'Dit lettertype staat er al.' : null; } },
        function (nm) {
          var f = { family: nm, google: nm.replace(/ /g, '+') + ':wght@400;500;600;700' };
          s.fonts = fonts.concat([f]); googleLink([f]); E.changed('lettertype ' + nm + ' toegevoegd'); inst.render(true);
        });
    };
    body.appendChild(addf);
    body.appendChild(el('div', 'wplib-tip', 'Sleep een tekststijl op een tekst, of op een lege plek voor een nieuwe tekst. ✎ past de stijl overal aan.'));
  }

  // ---------- BEELD: uploaden (verkleind, als WebP), bibliotheek, slepen ----------
  var MEDIA = null, MEDIA_BUSY = '';
  function api(a, body, raw, name) {
    var url = site().site.api + '?a=' + a + (name ? '&name=' + encodeURIComponent(name) : '');
    return fetch(url, { method: 'POST', headers: { 'Content-Type': raw ? 'application/octet-stream' : 'application/json', 'X-WP-Key': E.key() }, body: raw || JSON.stringify(body || {}) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'HTTP ' + r.status }; }).then(function (j) { j._s = r.status; return j; }); });
  }
  function withKey(run) {   // 401: één keer om de sleutel vragen en opnieuw
    return run().then(function (j) { if (j._s === 401 && E.askKey) return new Promise(function (ok) { E.askKey(function () { ok(run()); }, function () { ok(j); }); }); return j; });
  }
  function loadMedia() {
    return withKey(function () { return api('mediaList'); }).then(function (j) { MEDIA = j.ok ? j.items : []; if (!j.ok) MEDIA_BUSY = 'Laden mislukt: ' + (j.error || j._s); renderImages(); });
  }
  function renderImages() { if (WINS.images) WINS.images.render(true); }
  window.addEventListener('wp-media-changed', function () { if (MEDIA) loadMedia(); });   // bv. een beeld dat de agent tekende
  // foto's vóór het uploaden verkleinen (langste zijde 2400 px) en als WebP opslaan — zoals vroeger in Flash
  var MAX_SIDE = 2400;
  function prepare(file) {
    return new Promise(function (done) {
      var keep = /svg|gif/.test(file.type) || !/^image\//.test(file.type);   // svg/gif (animatie) blijven zoals ze zijn
      if (keep || !window.createImageBitmap) { done({ blob: file, name: file.name }); return; }
      createImageBitmap(file).then(function (bm) {
        var k = Math.min(1, MAX_SIDE / Math.max(bm.width, bm.height)), cv = document.createElement('canvas');
        cv.width = Math.round(bm.width * k); cv.height = Math.round(bm.height * k);
        cv.getContext('2d').drawImage(bm, 0, 0, cv.width, cv.height);
        var base = file.name.replace(/\.[^.]+$/, '');
        cv.toBlob(function (b) {
          if (b && b.type === 'image/webp') { done(file.type === 'image/webp' && k === 1 && file.size <= b.size ? { blob: file, name: file.name } : { blob: b, name: base + '.webp' }); return; }
          cv.toBlob(function (j) { done({ blob: j || file, name: j ? base + '.jpg' : file.name }); }, 'image/jpeg', .86);   // browser zonder WebP-export
        }, 'image/webp', .86);
      }).catch(function () { done({ blob: file, name: file.name }); });
    });
  }
  function uploadFiles(list, then) {
    var files = [].filter.call(list || [], function (f) { return /^image\//.test(f.type) || /\.(jpe?g|png|gif|webp|svg)$/i.test(f.name); });
    if (!files.length) { WPPrompt.notice('Alleen beelden: JPG, PNG, WebP, GIF of SVG.'); return; }
    var out = [], errs = [], i = 0;
    (function next() {
      if (i >= files.length) {
        MEDIA_BUSY = ''; MEDIA = out.concat(MEDIA || []); renderImages();
        $('status').textContent = out.length + ' beeld' + (out.length === 1 ? '' : 'en') + ' geüpload';
        if (errs.length) WPPrompt.notice(errs.join('\n'), { title: 'Niet alles is gelukt' });
        if (then && out.length) then(out);
        return;
      }
      var f = files[i++]; MEDIA_BUSY = 'uploaden ' + i + ' van ' + files.length + ' · ' + f.name; renderImages();
      prepare(f).then(function (p) {
        return withKey(function () { return api('mediaUpload', null, p.blob, p.name); });
      }).then(function (j) { if (j.ok) out.push(j.item); else errs.push(f.name + ': ' + (j.error || 'mislukt')); next(); })
        .catch(function (x) { errs.push(f.name + ': ' + x.message); next(); });
    })();
  }
  function imageUses() {   // hoe vaak elk beeld in de site gebruikt wordt
    var n = {};
    allObjects().forEach(function (o) {
      var p = o.props || {};
      if (o.type === 'image' && p.src) n[p.src] = (n[p.src] || 0) + 1;
      if (o.type === 'video' && p.poster) n[p.poster] = (n[p.poster] || 0) + 1;
      ((o.surface && o.surface.fills) || []).forEach(function (f) { if (f.type === 'image' && f.src) n[f.src] = (n[f.src] || 0) + 1; });
    });
    Object.keys(site().styles || {}).forEach(function (k) { ((site().styles[k].props || {}).fills || []).forEach(function (f) { if (f.type === 'image' && f.src) n[f.src] = (n[f.src] || 0) + 1; }); });
    return n;
  }
  // gewicht per pagina: de som van de bestanden die de pagina laadt (een beeld dat vaker voorkomt telt één keer; kopstukken uit masters tellen mee)
  function pageFiles(pg) {
    var s = site(), n = {}, out = [];
    function walk(a) { (a || []).forEach(function (o) {
      var p = o.props || {};
      if (o.type === 'image' && p.src) n[p.src] = 1;
      if (o.type === 'video' && p.poster) n[p.poster] = 1;
      ((o.surface && o.surface.fills) || []).forEach(function (f) { if (f.type === 'image' && f.src) n[f.src] = 1; });
      if (o.children) walk(o.children);
    }); }
    walk(pg.objects || []); Object.keys(s.masters || {}).forEach(function (m) { walk(s.masters[m].objects || []); });
    var by = {}; (MEDIA || []).forEach(function (m) { by[m.file] = m; });
    Object.keys(n).forEach(function (f) { if (by[f] && by[f].size) out.push({ file: f, name: by[f].name, size: by[f].size }); });
    out.sort(function (a, b) { return b.size - a.size; });
    return out;
  }
  function weightOf(list) { return list.reduce(function (t, x) { return t + x.size; }, 0); }
  function wLimits() { var w = site().site || {}; return { warn: (w.weightWarn || 5) * 1048576, high: (w.weightHigh || 10) * 1048576 }; }
  function wLevel(b) { var l = wLimits(); return b >= l.high ? 'high' : b >= l.warn ? 'warn' : ''; }
  function kb(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' kB'; }
  function thumb(it, uses, removable) {
    var c = el('div', 'wplib-img'); c.draggable = true;
    var im = el('img'); im.src = S.asset ? S.asset(it.file) : it.file; im.alt = ''; im.loading = 'lazy'; im.draggable = false;
    im.onload = function () { if (!it.w) { it.w = im.naturalWidth; it.h = im.naturalHeight; } };
    c.appendChild(im);
    var u = uses[it.file] || 0;
    if (u) c.appendChild(el('em', null, u + '×'));
    c.title = it.name + (it.w ? ' · ' + it.w + '×' + it.h : '') + (it.size ? ' · ' + kb(it.size) : '') + '\n' + (u ? 'gebruikt: ' + u + '×' : 'nog niet gebruikt') + '\nslepen: op een beeld = vervangen · op een vlak = foto erin · lege plek = nieuw beeld';
    c.addEventListener('dragstart', function (e) { payload(e, { libType: 'image', id: it.file, data: it }); try { e.dataTransfer.setDragImage(im, 30, 30); } catch (x) {} });
    c.onclick = function () {
      applyToSelection(function (o) { return applyImage(o, it, o.type === 'image' ? 'replace' : o.type === 'video' ? 'poster' : 'imgfill'); }, 'beeld ' + it.name);
    };
    if (removable) {
      var x = el('span', 'wplib-imgx', '\u2715'); x.title = 'Verwijderen';
      x.onclick = function (e) {
        e.stopPropagation();
        WPPrompt.confirm('"' + it.name + '" verwijderen?' + (u ? '\nLet op: het wordt nog ' + u + '× gebruikt in de site; daar wordt het dan leeg.' : ''), { ok: 'Verwijderen', danger: true }, function () {
          withKey(function () { return api('mediaDelete', { file: it.name }); }).then(function (j) {
            if (!j.ok) { WPPrompt.notice(j.error || 'Verwijderen mislukt'); return; }
            MEDIA = MEDIA.filter(function (m) { return m.file !== it.file; }); renderImages(); $('status').textContent = it.name + ' verwijderd';
          });
        });
      };
      c.appendChild(x);
    }
    return c;
  }
  function buildImages(body, inst) {
    if (MEDIA === null) { body.appendChild(el('div', 'wplib-tip', 'laden…')); loadMedia(); return; }
    var inp = el('input'); inp.type = 'file'; inp.multiple = true; inp.accept = 'image/*'; inp.style.display = 'none';
    inp.onchange = function () { uploadFiles(inp.files); inp.value = ''; };
    var up = el('button', 'wplib-btn', '+ Uploaden'); up.onclick = function () { inp.click(); };
    body.appendChild(inp); body.appendChild(up);
    var drop = el('div', 'wplib-drop', MEDIA_BUSY || 'of sleep foto\'s hierheen'); if (MEDIA_BUSY) drop.classList.add('busy');
    body.appendChild(drop);
    var uses = imageUses(), grid = el('div', 'wplib-imgs');
    // gewicht van de huidige pagina: één rustige regel; boven de grens kleurt hij en krijgen de zwaarste beelden een rand
    var pgs = site().pages, cur = pgs.filter(function (x) { return x.id === E.page(); })[0], heavy = {};
    if (cur && MEDIA.length) {
      var files = pageFiles(cur), tot = weightOf(files), lvl = wLevel(tot);
      var wl = el('div', 'wplib-wt' + (lvl ? ' ' + lvl : ''));
      var t1 = el('span', null, 'Deze pagina · ' + files.length + ' beeld' + (files.length === 1 ? '' : 'en') + ' · ' + kb(tot));
      var more = el('button', null, '▾'); more.title = 'Alle pagina\'s'; wl.appendChild(t1); wl.appendChild(more); body.appendChild(wl);
      if (lvl) {   // de zwaarste beelden tot de pagina weer onder de grens zou vallen (max. 5)
        var lim = wLimits().warn, rest = tot;
        files.slice(0, 5).forEach(function (x) { if (rest > lim || x.size > lim / 3) { heavy[x.file] = 1; } rest -= x.size; });
        var names = Object.keys(heavy);
        if (names.length) wl.title = 'Zwaarste beelden op deze pagina:\n' + files.filter(function (x) { return heavy[x.file]; }).map(function (x) { return x.name + ' · ' + kb(x.size); }).join('\n');
      }
      var all = el('div', 'wplib-wall'); all.style.display = 'none';
      pgs.forEach(function (pg) { var fl = pageFiles(pg), w = weightOf(fl), l = wLevel(w), r = el('div', l || ''); r.appendChild(el('span', null, (pg.title && (pg.title[E.lang && E.lang()] || pg.title.nl || Object.values(pg.title)[0])) ? String((pg.title[E.lang && E.lang()] || pg.title.nl || Object.values(pg.title)[0])).split(' · ')[0] : pg.id)); r.appendChild(el('b', null, fl.length ? kb(w) : '–')); all.appendChild(r); });
      more.onclick = function () { all.style.display = all.style.display === 'none' ? '' : 'none'; };
      body.appendChild(all);
    }
    MEDIA.forEach(function (it) { var c = thumb(it, uses, true); if (heavy[it.file]) c.classList.add('heavy'); if (it.size && it.size > 300 * 1024) c.appendChild(el('small', null, kb(it.size))); grid.appendChild(c); });
    if (MEDIA.length) body.appendChild(grid); else body.appendChild(el('div', 'wplib-tip', 'Nog geen beelden in media/.'));
    // beelden die de site al gebruikt maar niet in media/ staan
    var inMedia = {}; MEDIA.forEach(function (m) { inMedia[m.file] = 1; });
    var extra = Object.keys(uses).filter(function (f) { return !inMedia[f] && /\.(jpe?g|png|gif|webp|svg|avif)(\?|$)/i.test(f); });
    if (extra.length) {
      body.appendChild(el('div', 'wplib-h', 'Ook in de site'));
      var g2 = el('div', 'wplib-imgs'); extra.forEach(function (f) { g2.appendChild(thumb({ file: f, name: f.split('/').pop(), w: 0, h: 0 }, uses, false)); }); body.appendChild(g2);
    }
    body.appendChild(el('div', 'wplib-tip', 'Foto\'s worden verkleind (max. 2400 px) en als WebP bewaard. Sleep op een beeld om te vervangen, op een vlak voor een foto erin, of op een lege plek voor een nieuw beeld. Je kunt ook direct vanaf je bureaublad op de pagina slepen.'));
    // bestanden vanaf het bureaublad in het venster
    body.ondragover = function (e) { if (hasFiles(e)) { e.preventDefault(); e.stopPropagation(); body.classList.add('over'); } };
    body.ondragleave = function (e) { if (!body.contains(e.relatedTarget)) body.classList.remove('over'); };
    body.ondrop = function (e) { if (!hasFiles(e)) return; e.preventDefault(); e.stopPropagation(); body.classList.remove('over'); DRAG = null; uploadFiles(e.dataTransfer.files); };
  }

  var LIBS = {
    colors: { title: 'KLEUREN', left: 24, top: 70, width: 236, height: 360, build: buildColors },
    styles: { title: 'STYLES', left: 270, top: 70, width: 270, height: 420, build: buildStyles },
    typo:   { title: 'TYPOGRAFIE', left: 550, top: 70, width: 270, height: 440, build: buildTypo },
    images: { title: 'BEELD', left: 830, top: 70, width: 290, height: 460, build: buildImages }
  };
  function open(id) { var d = LIBS[id]; return createWin({ id: id, title: d.title, left: d.left, top: d.top, width: d.width, height: d.height, build: d.build }); }

  // ================= knop + menu in de balk =================
  var btn = document.createElement('button'); btn.id = 'libBtn'; btn.textContent = 'Bibliotheek ▾'; btn.title = 'Kleuren, styles, typografie en beeld van deze site';
  $('pageBtn').after(btn);
  var menu = el('div', 'wplib-menu'); document.body.appendChild(menu);
  [['colors', 'Kleuren'], ['styles', 'Styles'], ['typo', 'Typografie'], ['images', 'Beeld']].forEach(function (x) {
    var b = el('button', null, x[1]); b.dataset.lib = x[0];
    b.onclick = function () { menu.classList.remove('open'); if (WINS[x[0]]) WINS[x[0]].close(); else open(x[0]); };
    menu.appendChild(b);
  });
  function menuState() { [].forEach.call(menu.querySelectorAll('button'), function (b) { b.classList.toggle('on', !!WINS[b.dataset.lib]); }); }
  btn.onclick = function (e) { e.stopPropagation(); var r = btn.getBoundingClientRect(); menu.style.left = r.left + 'px'; menu.style.top = (r.bottom + 4) + 'px'; menu.classList.toggle('open'); };
  document.addEventListener('mousedown', function (e) { if (!menu.contains(e.target) && e.target !== btn) menu.classList.remove('open'); });

  // andere vensters (paginaboom, straks lagen) gebruiken dezelfde WEBPLAYS-chrome
  window.WPLibs = { createWin: createWin, wins: WINS, stored: function (id) { return load()[id] || {}; } };

  // wat open stond, staat weer open (na herladen)
  var st = load(); Object.keys(LIBS).forEach(function (id) { if (st[id] && st[id].open) open(id); });
  // na een eigen wijziging meteen bijwerken; andere wijzigingen (undo, paneel, agent) zie je zodra de muis in het venster komt
  E.changed = function (m) { _changed(m); Object.keys(WINS).forEach(function (k) { WINS[k].render(); }); };
})();
